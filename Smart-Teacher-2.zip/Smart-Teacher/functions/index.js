/* ==========================================================================
   Cloud Function: بتراقب /pq (طابور الإشعارات اللي بيكتبه التطبيق)
   وبترسل Push فعلي عن طريق FCM لأي توكن محفوظ للمستخدم تحت /fcm/{uid}
   ثم تمسح العنصر من الطابور.
   ========================================================================== */
const {onValueCreated} = require("firebase-functions/v2/database");
const {initializeApp} = require("firebase-admin/app");
const {getDatabase} = require("firebase-admin/database");
const {getMessaging} = require("firebase-admin/messaging");

initializeApp();

exports.sendPush = onValueCreated(
    {
      ref: "/pq/{pushId}",
      // ⚠️ عدّل الاسم ده لو عندك أكتر من قاعدة بيانات أو الاسم مختلف
      instance: "smart-teacher-om-default-rtdb",
      region: "us-central1",
    },
    async (event) => {
      const data = event.data.val();
      const pushRef = event.data.ref;
      const db = getDatabase();

      try {
        if (!data || !data.to || !data.txt) return;

        const tokSnap = await db.ref("/fcm/" + data.to).get();
        if (!tokSnap.exists()) return;

        const tokens = [];
        const keys = [];
        tokSnap.forEach((c) => {
          const t = c.val() && c.val().t;
          if (t) {
            tokens.push(t);
            keys.push(c.key);
          }
        });
        if (!tokens.length) return;

        const res = await getMessaging().sendEachForMulticast({
          tokens,
          notification: {
            title: "المعلم الذكي",
            body: String(data.txt).slice(0, 180),
          },
          webpush: {fcmOptions: {link: "/"}},
        });

        // نظّف أي توكن بقى غير صالح (المستخدم شيل الإذن أو مسح الكاش)
        const updates = {};
        res.responses.forEach((r, i) => {
          if (
            !r.success &&
            r.error &&
            (r.error.code === "messaging/registration-token-not-registered" ||
              r.error.code === "messaging/invalid-registration-token")
          ) {
            updates["/fcm/" + data.to + "/" + keys[i]] = null;
          }
        });
        if (Object.keys(updates).length) await db.ref().update(updates);
      } finally {
        await pushRef.remove();
      }
    },
);
