// الإعدادات بتتقرا في js/00-config-api.js من المتغيرات دي بالاسم ده بالظبط (self.ST_*)
// التهيئة (initializeApp) بيعملها التطبيق نفسه — ما تعملهاش هنا.
self.ST_FB = {
  apiKey: "AIzaSyBjvFgWK_Z0qwg4aW8zrsDEJDs-zjdY4os",
  authDomain: "smart-teacher-om.firebaseapp.com",
  databaseURL: "https://smart-teacher-om-default-rtdb.firebaseio.com",
  projectId: "smart-teacher-om",
  storageBucket: "smart-teacher-om.firebasestorage.app",
  messagingSenderId: "903679875256",
  appId: "1:903679875256:web:1c2cbabd042794abdf7c4d"
};

// رابط الـ Worker (نفس الرابط الافتراضي الموجود في js/00-config-api.js)
self.ST_WORKER_URL = "https://smart-teacher.shanabooai.workers.dev/";

// مفتاح VAPID للإشعارات (اختياري دلوقتي)
self.ST_VAPID = "";
