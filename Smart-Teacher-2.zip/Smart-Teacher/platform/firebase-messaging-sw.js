/* ==========================================================================
   Service Worker لاستقبال إشعارات Push وهي مقفولة (التاب مقفول أو المتصفح في الخلفية)
   ⚠️ لازم يكون في جذر الموقع (نفس مكان index.html) باسم firebase-messaging-sw.js بالظبط
   ⚙️ الإعدادات بتتقرا من firebase-config.js (نفس ملف الموقع) — مفيش قيم هنا
   ========================================================================== */
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

importScripts('firebase-config.js');   /* ← نفس ملف إعدادات الموقع */
firebase.initializeApp(self.ST_FB);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
  const title = (payload.notification && payload.notification.title) || 'المعلم الذكي';
  const body = (payload.notification && payload.notification.body) || (payload.data && payload.data.txt) || '';
  self.registration.showNotification(title, {
    body,
    dir: 'rtl',
    lang: 'ar',
    tag: 'smart-teacher-notif'
  });
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  event.waitUntil(clients.openWindow('/'));
});
