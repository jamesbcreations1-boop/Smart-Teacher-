/* ▓▓ 00-config-api.js — الإعدادات (Firebase/EmailJS/Worker) + الاتصال بالـ Worker + توكن الدخول
   بيتحمّل بعد: بداية التحميل  |  وبعده: 01-sync.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* Smart Teacher — المعلم الذكي | app.js
   الأقسام مرتّبة بنفس ترتيب التحميل الأصلي — لا تغيّر الترتيب (كل قسم بيعدّل اللي قبله). */
/* ==========================================================================
   [00] النواة: الحالة، المزامنة، الواجهة الأساسية
   ========================================================================== */
/* الإصدار الأول المعتمد — جُمعت فيه إضافات التجارب السابقة */
/* الإعدادات كلها جاية من firebase-config.js (في جذر الموقع) — ما تحطش قيم هنا */
const CFG={FB:self.ST_FB||{},VAPID_KEY:self.ST_VAPID||'',OTP_URL:'',EMAIL:{SERVICE:'service_50lm2ms',TEMPLATE:'template_thrma4o',TEMPLATE_RESET:'template_ec5gjq8',KEY:'i42KqK_P2Vb8D2cHB'},DB_URL:((self.ST_FB||{}).databaseURL||''),API:(self.ST_WORKER_URL||''),GROQ_KEYS:[]};
/* تنبيه واضح لو لسه ما حطّيتش بيانات Firebase الجديدة */
if(!/^AIza/.test(CFG.FB.apiKey||'')||/PUT_/.test(JSON.stringify(CFG.FB))){document.addEventListener('DOMContentLoaded',()=>{const d=document.createElement('div');d.style.cssText='position:fixed;inset:0 0 auto 0;z-index:99999;background:#b91c1c;color:#fff;padding:12px 14px;font:700 14px/1.6 Cairo,sans-serif;text-align:center';d.textContent='⚠️ إعدادات Firebase ناقصة: افتح الملف firebase-config.js والصق apiKey وappId وmessagingSenderId من Firebase Console.';document.body.appendChild(d)})}

const $=s=>document.querySelector(s),uid=()=>{try{return crypto.randomUUID()}catch(e){return 'st_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10)}},esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
/*AUTH*/
let AUTH_TOKEN='';
const AUTH_READY=Promise.race([(async()=>{
  try{
    if(!window.firebase||!CFG.FB.apiKey)return;
    firebase.initializeApp(CFG.FB);
    const au=firebase.auth();
    await new Promise(res=>{
      au.onAuthStateChanged(async user=>{
        if(!user){AUTH_TOKEN='';res();return}
        try{AUTH_TOKEN=await user.getIdToken()}catch(e){}
        res();
      });
    });
    setInterval(async()=>{try{const u=firebase.auth().currentUser;if(u)AUTH_TOKEN=await u.getIdToken(true)}catch(e){}},45*60*1000);
  }catch(e){console.warn('firebase auth init failed',e)}
})(),new Promise(r=>setTimeout(r,6000))]);
const withAuth=u=>AUTH_TOKEN?u+(u.includes('?')?'&':'?')+'auth='+AUTH_TOKEN:u;

/* ===== Worker API: الاتصال الموحّد بالـ Backend (Cloudflare Worker) ===== */
CFG.API=CFG.API||'https://smart-teacher-api.kimookol117.workers.dev';
async function idToken(force){try{const u=window.firebase&&firebase.auth().currentUser;if(u)AUTH_TOKEN=await u.getIdToken(!!force)}catch(e){}return AUTH_TOKEN}
function apiErr(e){const s=e&&e.status;if(s===0)return(e&&e.message)||'تعذر الاتصال بالخادم';if(s===401)return 'انتهت الجلسة، سجّل الدخول من جديد';if(s===403)return 'هذا الموقع غير مسموح له بالاتصال بالخادم (ALLOWED_ORIGINS)';if(s===413)return 'الملف أو الصورة كبيرة جداً';if(s===429)return 'طلبات كثيرة، انتظر قليلاً ثم حاول';if(s===503)return 'خدمة الذكاء الاصطناعي غير متاحة حالياً';if(s>=500)return 'خطأ في الـ Worker ('+s+')'+((e&&e.data&&e.data.detail)?': '+e.data.detail:'')+' — افتح رابط الـ Worker/health?check=1 وشوف إيه الناقص';return (e&&e.message)||'حدث خطأ في الخادم'}
async function api(path,o={}){
  const method=o.method||'GET',auth=o.auth!==false,tmo=o.timeout||30000,hasBody=o.body!==undefined;
  if(auth)await AUTH_READY;
  const send=async force=>{
    const h={};if(hasBody)h['Content-Type']='application/json';
    if(auth){const t=await idToken(force);if(t)h.Authorization='Bearer '+t}
    const c=new AbortController(),tm=setTimeout(()=>c.abort(),tmo);
    try{return await fetch(CFG.API.replace(/\/$/,'')+path,{method,headers:h,body:hasBody?JSON.stringify(o.body):undefined,signal:c.signal})}finally{clearTimeout(tm)}
  };
  let r;
  try{r=await send(false);if(auth&&r.status===401)r=await send(true)}
  catch(e){const x=new Error(e&&e.name==='AbortError'?'انتهت مهلة الاتصال بالخادم':'تعذر الاتصال بالخادم، تحقق من الإنترنت');x.status=0;throw x}
  let d=null;try{d=await r.json()}catch(e){}
  if(!r.ok){const x=new Error((d&&d.error&&(d.error.message||d.error))||('HTTP '+r.status));x.status=r.status;x.data=d;throw x}
  return d;
}
/* إدارة الجلسة: لو المستخدم خرج (S.me فاضي) نقفل جلسة Firebase الموثّقة ونرجع للدخول المجهول */
let LGN=0;
function syncSession(){try{if(LGN||S.me||!window.firebase)return;const u=firebase.auth().currentUser;if(u&&!u.isAnonymous){AUTH_TOKEN='';firebase.auth().signOut().catch(()=>{})}}catch(e){}}
/* جلسة خلفية بعد إنشاء حساب جديد (الحساب لازم يوصل القاعدة الأول فنعيد المحاولة) */
async function bgSession(id,pw,n){
  n=n||0;if(!id||!pw||!window.firebase)return;
  try{const r=await api('/login',{method:'POST',body:{id:String(id).trim().toLowerCase(),password:pw},auth:false,timeout:15000});
    if(r&&r.token){LGN=1;try{await firebase.auth().signInWithCustomToken(r.token);await idToken(true)}finally{LGN=0}}
  }catch(e){if(n<5&&(e.status===401||e.status===0))setTimeout(()=>bgSession(id,pw,n+1),3000)}
}
let S={u:[],g:[],e:[],s:[],m:[],n:[],p:[],k:[],pl:[],nw:[],cf:[],sp:[],rd:{},keys:[],mute:0,me:null,dark:null};
try{S=Object.assign(S,JSON.parse(localStorage.getItem('stp')||'{}'));if(!S.me){const sm=localStorage.getItem('st_me');if(sm)S.me=sm}if(Array.isArray(S.u))S.u.forEach(u=>{if(u&&u.pw)delete u.pw})}catch(e){}
try{const _a=JSON.parse(localStorage.getItem('st_av')||'null');if(_a&&_a.id&&Array.isArray(S.u)){const _u=S.u.find(x=>x.id===_a.id);if(_u&&!_u.av)_u.av=_a.av}}catch(e){}
const save=()=>{cache();qpush();syncSession()};
