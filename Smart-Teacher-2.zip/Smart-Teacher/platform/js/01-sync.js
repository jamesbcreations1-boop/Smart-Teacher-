/* ▓▓ 01-sync.js — المزامنة مع قاعدة البيانات (pull/push) والتخزين المحلي
   بيتحمّل بعد: 00-config-api.js  |  وبعده: 02-ui-base.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/*SYNC*/
const DB=(CFG.DB_URL||'').replace(/\/$/,''),COLS=['u','g','e','s','m','n','p','k','nw','cf','sp'],BK='stpb:'+DB;let BASE={},PT=null,ONLINE=0,PL=0;
try{BASE=JSON.parse(localStorage.getItem(BK)||'{}')}catch(e){}
const cj=x=>JSON.stringify(x,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a<b?-1:1)):v),unread=()=>S.n.filter(n=>n.to===S.me&&!n.r).reduce((a,n)=>a+(n.c||1),0);
let CT;const wr=()=>{try{try{if(S.me)localStorage.setItem('st_me',S.me);else localStorage.removeItem('st_me');try{const _u=S.u.find(x=>x.id===S.me);if(_u&&_u.av&&_u.av.length<3e5)localStorage.setItem('st_av',JSON.stringify({id:_u.id,av:_u.av}))}catch(x){}localStorage.setItem('st_dark',S.dark===true?'1':S.dark===false?'0':'');const _m=me();if(_m&&_m.role)localStorage.setItem('st_role',_m.role);else localStorage.removeItem('st_role')}catch(e){}
const mk=lim=>{const safe={...S};if(Array.isArray(S.u))safe.u=S.u.map(u=>{const x={...u};delete x.pw;if(lim&&x.av&&x.av.length>2e4)delete x.av;return x});if(lim&&Array.isArray(S.m))safe.m=S.m.slice(-lim);return JSON.stringify(safe)};
try{localStorage.setItem('stp',mk(0));localStorage.setItem(BK,JSON.stringify(BASE))}catch(e){try{localStorage.setItem('stp',mk(300));localStorage.setItem(BK,'{}')}catch(x){}}}catch(e){}},cache=()=>{clearTimeout(CT);CT=setTimeout(wr,1200)};addEventListener('pagehide',wr);
function norm(c,x){if(c==='g'){x.st=x.st||[];x.mat=x.mat||[]}if(c==='e'){x.q=x.q||[];x.q.forEach(q=>q.o=q.o||[])}if(c==='s')x.a=x.a||{};return x}
function flat(c,x){const r={id_:0};delete r.id_;for(const k in x){if(c==='u'&&k==='pw')continue;if(x[k]==null)continue;if(c==='g'&&k==='st')x.st.forEach(y=>r[x.id+'/st/'+y.u]=y);else if(c==='at'&&(k==='r'||k==='t')&&typeof x[k]==='object')Object.keys(x[k]).forEach(u=>{r[x.id+'/'+k+'/'+u]=x[k][u]});else r[x.id+'/'+k]=x[k]}return r}
const fj=(c,x)=>{const f=flat(c,x),r={};for(const p in f)r[p]=cj(f[p]);return r};
function unflat(c,o){const x=JSON.parse(JSON.stringify(o));if(c==='g'&&x.st)x.st=Object.values(x.st).filter(Boolean).sort((a,b)=>a.u<b.u?-1:1);return norm(c,x)}
function qpush(){if(DB){clearTimeout(PT);PT=setTimeout(push,700)}}
async function push(){await AUTH_READY;const up={},L={};COLS.forEach(c=>{const B=BASE[c]||{};L[c]={};S[c].forEach(x=>{const f=flat(c,x);for(const p in f){const j=cj(f[p]);L[c][p]=j;if(B[p]!==j)up[c+'/'+p]=f[p]}});for(const p in B)if(!(p in L[c])&&!(c==='u'&&/\/av$/.test(p)))up[c+'/'+p]=null});
if(!Object.keys(up).length)return;try{const r=await fetch(withAuth(DB+'/db.json'),{method:'PATCH',body:JSON.stringify(up)});if(r.ok){COLS.forEach(c=>BASE[c]=L[c]);ONLINE=1;cache()}else ONLINE=0}catch(e){ONLINE=0}}
const ET={};let ETOK=(()=>{try{return localStorage.getItem('st_noet')!=='1'}catch(e){return true}})();
/* ===== تحميل البيانات حسب الصفحة (بدل ما كل الجداول تتحمّل مرة واحدة) =====
   ALWAYS: بتتحمّل في أي صفحة (الأساسيات: المستخدمون، مجموعاتي، الإشعارات، إعدادات الموقع، الأخبار)
   PAGEMAP: الجداول الإضافية اللي كل صفحة محتاجاها. الصفحة اللي مش مذكورة بتاخد _default.
   الزائر (من غير تسجيل دخول): إعدادات الموقع والأخبار فقط.  لوحة الإدارة: كل الجداول.
   ⚠️ لو ضفت صفحة/ميزة جديدة بتقرا S.xx من جدول مش في ALWAYS، ضيف الجدول هنا في صفحته. */
/* إعدادات الموقع اللي الزائر (قبل الدخول) يقدر يقراها — لازم تتطابق مع قواعد القاعدة (worker/database.rules.json ← cf) */
const PUBCF=['site','brand','themes','cthemes','txt','banner','bsch','ctl','maint','feat','supc','socs','sub','subc'],
ALWAYS=['u','g','n','cf','nw'],
PAGEMAP={dash:['e','s','m','p','pl','at','pay','ev'],group:['e','s','m','p','pl','at','pay','ev'],sess:['at','pay','ev'],gx:['e','s','at','pay','ev'],
 studio:['e','k'],exam:['e','s','d','k'],review:['e','s','d','k'],grade:['e','s','d','k'],disputes:['e','s','d'],rec:['e','s','bt','k','pl'],board:['e','s'],
 chats:['m','p'],pm:['m','p'],soc:['m','p','f','fc','fl','ff'],prof:['m','p','f','fc','fl','ff'],news:[],notes:[],ai:[],sub:[],set:['pl','sup','sm'],
 reports:['e','s','at','pay','ev','pl'],_default:['e','s','pl']};
const colsFor=()=>{if(!S.me&&!AUTH_TOKEN)return COLS.filter(c=>c==='cf'||c==='nw');const p=V&&V.p;if(p==='stadm')return COLS;const x=PAGEMAP[p]||PAGEMAP._default;return COLS.filter(c=>ALWAYS.includes(c)||x.includes(c))};
async function pull(want){if(!DB||PL||document.hidden&&want!=='all')return;await AUTH_READY;PL=1;let NM=0,RT=null;try{try{await idToken()}catch(e){}const d={},list=want==='all'||!want&&!Array.isArray(want)?(colsFor()):want;
let list2=list;if(!AUTH_TOKEN){list2=list.filter(c=>c!=='cf'&&c!=='nw');if(list.length){const g1=async p=>{try{const r=await fetch(DB+'/db/'+p+'.json');return r.ok?await r.json():null}catch(e){return null}};const [nw,...cs]=await Promise.all([g1('nw'),...PUBCF.map(i=>g1('cf/'+i))]);d.nw=nw||{};d.cf={};PUBCF.forEach((i,k)=>{if(cs[k])d.cf[i]=cs[k]})}}
await Promise.all(list2.map(async c=>{
/* الرسائل الخاصة (p): القواعد بتسمح بقراءة رسائلك إنت بس، فبنجيبها باستعلامين (أنا المرسل / أنا المستلم) بدل ما نقرا الجدول كله */
const _uid=()=>{if(S.me)return S.me;try{const t=AUTH_TOKEN||'';if(t.split('.').length===3){const j=JSON.parse(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));return j.user_id||j.sub||''}}catch(e){}return ''};
if(c==='p'&&AUTH_TOKEN&&_uid()&&!(me()&&me().role==='admin')){const q=f=>DB+'/db/p.json?orderBy='+encodeURIComponent('"'+f+'"')+'&equalTo='+encodeURIComponent('"'+_uid()+'"');
 try{const rs=await Promise.all(['a','b'].map(async f=>{let r=await fetch(withAuth(q(f)));if(r.status===401){try{await(RT=RT||idToken(true))}catch(e){}r=await fetch(withAuth(q(f)))}return r.ok?await r.json():null}));if(rs.some(x=>x===null))return;d.p=Object.assign({},rs[0]||{},rs[1]||{})}catch(e){}return}
const url=DB+'/db/'+encodeURIComponent(c)+'.json';const go1=async et=>{const h={};if(et&&ETOK){h['X-Firebase-ETag']='true';if(ET[c])h['If-None-Match']=ET[c]}return fetch(withAuth(url),Object.keys(h).length?{headers:h}:undefined)};
try{let r;try{r=await go1(true)}catch(e){if(ETOK){ETOK=false;try{localStorage.setItem('st_noet','1')}catch(x){}r=await go1(false)}else throw e}
if(r.status===401&&AUTH_TOKEN){try{await(RT=RT||idToken(true))}catch(e){}r=await go1(false)}
if(r.status===304){NM++;return}if(r.ok){const e=r.headers.get('ETag');if(e)ET[c]=e;d[c]=(await r.json())||{}}}catch(e){}}));const o=unread();let ch=0;ONLINE=(Object.keys(d).length||NM)?1:0;
COLS.forEach(c=>{if(!(c in d))return;if(c==='k'&&!isT())return;if(c==='sp'&&!((me()&&me().role==='admin')||sessionStorage.getItem('st_adm')==='1'))return;const rem=window.stFilt?window.stFilt(c,d[c]||{}):(d[c]||{}),B=BASE[c]=BASE[c]||{},arr=S[c],mp=new Map(arr.map(x=>[x.id,x])),bg={};for(const p in B){const k=p.slice(0,p.indexOf('/'));(bg[k]=bg[k]||[]).push(p)}const ids=new Set([...mp.keys(),...Object.keys(rem),...Object.keys(bg)]);
ids.forEach(id=>{const lo=mp.get(id),lf=lo?fj(c,lo):{},bp=bg[id]||[],bs=Object.fromEntries(bp.map(p=>[p,B[p]]));if(c==='u'&&lo&&!lo.av)delete bs[id+'/av'];if(cj(lf)!==cj(bs))return;
if(rem[id]){const it=unflat(c,rem[id]);if(c==='u'&&it)delete it.pw;const rf=fj(c,it);bp.forEach(p=>delete B[p]);Object.assign(B,rf);if(cj(rf)!==cj(lf)){const i=arr.findIndex(x=>x.id===id);i<0?arr.push(it):arr[i]=it;ch=1}}
else if(bp.length){bp.forEach(p=>delete B[p]);const i=arr.findIndex(x=>x.id===id);if(i>=0){arr.splice(i,1);ch=1}}})});
if(ch){S.m.sort((a,b)=>(a.d||0)-(b.d||0));S.p.sort((a,b)=>a.d-b.d);S.n.sort((a,b)=>b.d-a.d)}if(ch)cache();if(unread()>o)bell();
if(ch&&V.p!=='exam'&&!document.activeElement?.matches('input,textarea,select'))R()}catch(e){ONLINE=0}PL=0}
/*ENDSYNC*/
