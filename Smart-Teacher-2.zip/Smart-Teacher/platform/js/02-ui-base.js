/* ▓▓ 02-ui-base.js — الواجهة الأساسية: الهيدر والتنقل والرسم (R) والأدوات العامة
   بيتحمّل بعد: 01-sync.js  |  وبعده: 03-auth-screens.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
let V={p:'dash'},D=null,T=null,OTP=null;
const me=()=>S.u.find(u=>u.id===S.me),isT=()=>me()?.role==='teacher',G=id=>S.g.find(g=>g.id===id),E=id=>S.e.find(e=>e.id===id),U=id=>S.u.find(u=>u.id===id);
function toast(t){const x=$('#toast');x.textContent=t;x.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>x.style.display='none',3500)}
function go(p,a,t){V={p,a,t:t||V.t};Q='';if(p!=='exam'&&T){clearInterval(T);T=null}R();$('#app').classList.add('an');setTimeout(()=>$('#app').classList.remove('an'),500);scrollTo(0,0)}
function notify(to,txt,k){const ex=k&&S.n.find(n=>n.to===to&&n.k===k&&!n.r);if(ex){ex.txt=txt;ex.d=Date.now();ex.c=(ex.c||1)+1}else{S.n.unshift({id:uid(),to,txt,k,r:0,d:Date.now()});window.pq&&pq(to,txt)}save();if(to===S.me)bell()}
let AC;const tone=(f,d=.25,ty='sine',v=.25)=>{if(S.mute)return;try{AC=AC||new(window.AudioContext||webkitAudioContext)();AC.resume();const o=AC.createOscillator(),g=AC.createGain();o.type=ty;o.frequency.value=f;o.connect(g);g.connect(AC.destination);const t=AC.currentTime;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.start(t);o.stop(t+d)}catch(e){}};
const bell=()=>{tone(1318,.5);setTimeout(()=>tone(1760,.7),180)},alarm=()=>{tone(900,.18,'square',.3);setTimeout(()=>tone(700,.18,'square',.3),220)};
document.addEventListener('click',()=>{try{AC=AC||new(window.AudioContext||webkitAudioContext)();AC.resume()}catch(e){}},{once:true});
addEventListener('storage',e=>{if(DB||e.key!=='stp'||!e.newValue)return;const m0=S.me,dk=S.dark,o=S.n.filter(n=>n.to===m0&&!n.r).length;try{Object.assign(S,JSON.parse(e.newValue))}catch(x){return}S.me=m0;S.dark=dk;if(S.n.filter(n=>n.to===m0&&!n.r).length>o)bell();if(V.p!=='exam'&&!document.activeElement?.matches('input,textarea'))R()});
function th(){const d=S.dark??matchMedia('(prefers-color-scheme:dark)').matches;document.documentElement.dataset.theme=d?'dark':'light';}
const H=(t,id)=>{let a=0xdeadbeef,b=0x41c6ce57;const s=id+'|'+nz(t);for(let i=0,c;i<s.length;i++){c=s.charCodeAt(i);a=Math.imul(a^c,2654435761);b=Math.imul(b^c,1597334677)}a=Math.imul(a^a>>>16,2246822507)^Math.imul(b^b>>>13,3266489909);b=Math.imul(b^b>>>16,2246822507)^Math.imul(a^a>>>13,3266489909);return 4294967296*(2097151&b)+(a>>>0)};
const nz=t=>String(t||'').toLowerCase().replace(/[\u064B-\u0652\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/\s+/g,' ').trim();
const isOk=(q,s)=>{const o=s.ov?s.ov[q.id]:undefined;if(o!==undefined)return !!o;const a=nz(s.a[q.id]);return !!a&&(q.h!==undefined?H(a,q.id)===q.h:a===nz(q.a))},score=(e,s)=>{const n=e.q.length;if(!n)return 0;return Math.round(e.q.filter(q=>isOk(q,s)).length/n*100)};
const gStu=g=>g.st.filter(x=>x.s==='ok'||x.s==='sus');
const gScores=g=>S.s.filter(s=>E(s.e)?.g===g.id).map(s=>score(E(s.e),s));
const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length):0;
/* ===== SmartTeacher v2: تقارير موحدة ولوحة إدارة مقيدة بالدور ===== */
function stRoleLabel(r){return ({teacher:'المعلم',student:'الطالب',parent:'ولي الأمر',assistant:'مساعد المدرس',admin:'الإدارة'})[r]||'مستخدم'}
function stPctBar(v){v=Math.max(0,Math.min(100,Number(v)||0));return `<div class="st-v2-bar" aria-label="${v}%"><i style="width:${v}%"></i></div>`}
function stCsv(rows,filename){
  if(!rows||!rows.length)return toast('لا توجد بيانات لتصديرها');
  const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
  const csv='\ufeff'+rows.map(r=>r.map(quote).join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=filename||'smart-teacher-report.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function stReports(){
  const m=me();if(!m)return auth();
  const role=m.role||'student';let gs=[],kids=[],ex=[],subs=[];
  if(role==='teacher')gs=S.g.filter(g=>g.t===m.id);
  else if(role==='assistant')gs=S.g.filter(g=>(g.as||[]).includes(m.id));
  else if(role==='student')gs=S.g.filter(g=>(g.st||[]).some(x=>x.u===m.id&&(x.s==='ok'||x.s==='sus')));
  else if(role==='parent'){
    kids=(S.pl||[]).filter(x=>x.p===m.id).map(x=>U(x.s)).filter(Boolean);
    const kidIds=new Set(kids.map(x=>x.id));gs=S.g.filter(g=>(g.st||[]).some(x=>kidIds.has(x.u)&&(x.s==='ok'||x.s==='sus')));
  } else if(role==='admin') gs=S.g.slice();
  ex=role==='student'?S.e.filter(e=>gs.some(g=>g.id===e.g)):S.e.filter(e=>gs.some(g=>g.id===e.g));
  const exIds=new Set(ex.map(e=>e.id)),kidIds=new Set(kids.map(x=>x.id));
  subs=S.s.filter(x=>exIds.has(x.e)&&(role==='student'?x.u===m.id:role==='parent'?kidIds.has(x.u):true));
  const rows=subs.map(s=>({s,e:E(s.e),u:U(s.u)})).filter(x=>x.e);
  const values=rows.map(x=>score(x.e,x.s)),average=avg(values),passed=values.filter(x=>x>=50).length;
  const studentIds=new Set();gs.forEach(g=>(g.st||[]).forEach(x=>{if(x.s==='ok'||x.s==='sus')studentIds.add(x.u)}));
  const isLearner=role==='student'||role==='parent';
  const cards=role==='admin'?
    [[S.u.length,'الحسابات'],[S.g.length,'المجموعات'],[S.e.length,'الامتحانات'],[S.s.length,'التسليمات']]:
    isLearner?[[role==='parent'?kids.length:1,role==='parent'?'الأبناء المرتبطون':'حساب الطالب'],[ex.length,'الامتحانات'],[rows.length,'التسليمات'],[rows.length?average+'%':'—','متوسط الدرجات']]:
    [[gs.length,'المجموعات'],[studentIds.size,'الطلاب'],[ex.length,'الامتحانات'],[rows.length,'التسليمات']];
  const recent=rows.slice().sort((a,b)=>(b.s.d||0)-(a.s.d||0)).slice(0,8);
  window.__stV2ReportRows=[['الطالب','الامتحان','المجموعة','الدرجة %','تاريخ التسليم'],...rows.map(x=>[x.u?.name||'طالب',x.e.name,G(x.e.g)?.title||'',score(x.e,x.s),new Date(x.s.d||Date.now()).toLocaleString('ar-EG')])];
  const title=role==='teacher'?'تقارير المعلم':role==='assistant'?'متابعة مساعد المدرس':role==='parent'?'متابعة الأبناء':role==='admin'?'ملخص الإدارة':'تقرير أدائي';
  const noKids=role==='parent'&&!kids.length;
  return `<section class="st-v2-page"><div class="st-v2-hero"><div><span class="st-v2-eyebrow">SMART TEACHER • V2</span><h2>${title}</h2><p>أهلاً ${esc(m.name||'بك')} — ملخص واضح للأداء والأنشطة المتاحة لحسابك.</p></div><div class="st-v2-hero-icon">▦</div></div>
  <div class="st-v2-kpis">${cards.map((x,i)=>`<article class="st-v2-kpi"><span>${['◈','▤','✓','↗'][i]}</span><b>${x[0]}</b><small>${x[1]}</small></article>`).join('')}</div>
  ${noKids?`<div class="card"><h3>ربط حساب ولي الأمر</h3><p>لم يظهر حساب طالب مرتبط بهذا الحساب بعد. استخدم كود الربط الذي توفره المنصة أو راجع المعلم.</p></div>`:''}
  ${(role==='teacher'||role==='assistant'||role==='admin')?`<div class="card st-v2-card"><div class="row"><h3>ملخص المجموعات</h3><span class="tag">${gs.length} مجموعة</span></div>${gs.slice().sort((a,b)=>(b.act||0)-(a.act||0)).slice(0,8).map(g=>{const ge=ex.filter(e=>e.g===g.id),sr=rows.filter(x=>x.e.g===g.id),avv=avg(sr.map(x=>score(x.e,x.s)));return `<div class="st-v2-group"><div><b>${esc(g.title||'مجموعة بدون اسم')}</b><small>${ge.length} امتحان • ${new Set((g.st||[]).filter(x=>x.s==='ok'||x.s==='sus').map(x=>x.u)).size} طالب</small></div><div class="st-v2-group-score"><b>${sr.length?avv+'%':'—'}</b>${stPctBar(sr.length?avv:0)}</div><button class="b s" onclick="go('group','${g.id}')">فتح</button></div>`}).join('')||`<p class="mut">لا توجد مجموعات متاحة لهذا الحساب.</p>`}</div>`:''}
  <div class="card st-v2-card"><div class="row"><div><h3>${isLearner?'آخر النتائج':'آخر التسليمات'}</h3><p class="mut">البيانات المعروضة حسب صلاحيات حسابك.</p></div><button class="b s" onclick="stCsv(window.__stV2ReportRows,'smart-teacher-results.csv')">⬇ تصدير CSV</button></div>
  ${recent.length?`<div class="st-v2-table-wrap"><table class="st-v2-table"><thead><tr><th>الطالب</th><th>الامتحان</th><th>المجموعة</th><th>الدرجة</th><th>التاريخ</th></tr></thead><tbody>${recent.map(x=>`<tr><td>${esc(x.u?.name||'طالب')}</td><td>${esc(x.e.name||'—')}</td><td>${esc(G(x.e.g)?.title||'—')}</td><td><b class="${score(x.e,x.s)>=50?'st-v2-good':'st-v2-low'}">${score(x.e,x.s)}%</b></td><td>${new Date(x.s.d||Date.now()).toLocaleDateString('ar-EG')}</td></tr>`).join('')}</tbody></table></div>`:`<div class="st-v2-empty"><span>▤</span><b>لا توجد نتائج لعرضها بعد</b><p>ستظهر النتائج هنا بمجرد توفر تسليمات مرتبطة بحسابك.</p></div>`}</div>
  <div class="st-v2-actions"><button class="b" onclick="go('dash')">⌂ الرئيسية</button>${role==='teacher'?`<button class="b s" onclick="go('studio')">＋ إنشاء امتحان</button><button class="b s" onclick="go('ai')">✦ مساعد الذكاء الاصطناعي</button>`:''}${role==='student'?`<button class="b s" onclick="go('rec')">عرض سجل الدرجات</button>`:''}${role==='parent'?`<button class="b s" onclick="go('set')">إعدادات الحساب</button>`:''}</div></section>`;
}
function stAdmin(){
 const m=me();if(!m||m.role!=='admin')return `<div class="card"><h2>غير مصرح بالوصول</h2><p>هذه الصفحة مخصصة لحساب إدارة معتمد من جهة الخادم.</p><button class="b" onclick="go('dash')">العودة للرئيسية</button></div>`;
 const users=S.u.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'ar'));
 const roleCounts={};users.forEach(u=>roleCounts[u.role]=(roleCounts[u.role]||0)+1);
 window.__stV2AdminRows=[['الاسم','الدور','البريد الإلكتروني','الهاتف'],...users.map(u=>[u.name||'',stRoleLabel(u.role),u.email||'',u.phone||''])];
 return `<section class="st-v2-page"><div class="st-v2-hero"><div><span class="st-v2-eyebrow">ADMIN CONSOLE</span><h2>إدارة المنصة</h2><p>نظرة عامة على الحسابات والمجموعات والامتحانات. ومن أدوات الإدارة بالأسفل تتحكم في الحسابات والمظهر والبيانات.</p></div><div class="st-v2-hero-icon">⚙</div></div>
 <div class="st-v2-status"><span class="st-v2-status-dot ${ONLINE?'online':''}"></span><b>${ONLINE?'اتصال البيانات نشط':'حالة الاتصال غير مؤكدة'}</b><small>حالة المزامنة: ${ONLINE?'متصل':'لم يتم تأكيد الاتصال'}</small></div>
 <div class="st-v2-kpis">${[[S.u.length,'إجمالي الحسابات'],[S.g.length,'المجموعات'],[S.e.length,'الامتحانات'],[S.s.length,'التسليمات']].map((x,i)=>`<article class="st-v2-kpi"><span>${['♙','▦','▤','✓'][i]}</span><b>${x[0]}</b><small>${x[1]}</small></article>`).join('')}</div>
 <div class="card st-v2-card"><div class="row"><h3>الحسابات حسب الدور</h3><button class="b s" onclick="stCsv(window.__stV2AdminRows,'smart-teacher-users.csv')">⬇ تصدير قائمة الحسابات</button></div><div class="st-v2-role-grid">${Object.entries(roleCounts).map(([r,n])=>`<div><b>${n}</b><span>${stRoleLabel(r)}</span></div>`).join('')||'<p class="mut">لا توجد حسابات.</p>'}</div></div>
 <div class="card st-v2-card"><h3>دليل الحسابات</h3><p class="mut">عرض فقط. إنشاء أو تعديل أدوار المستخدمين يجب أن يتم عبر إجراء موثوق في الخادم، وليس من خلال كود المتصفح.</p><div class="st-v2-table-wrap"><table class="st-v2-table"><thead><tr><th>الاسم</th><th>الدور</th><th>البريد</th><th>الهاتف</th></tr></thead><tbody>${users.slice(0,100).map(u=>`<tr><td>${esc(u.name||'—')}</td><td>${esc(stRoleLabel(u.role))}</td><td>${esc(u.email||'—')}</td><td>${esc(u.phone||'—')}</td></tr>`).join('')}</tbody></table></div>${users.length>100?`<p class="mut">يتم عرض أول 100 حساب فقط.</p>`:''}</div></section>`;
}

function R(){th();const m=me(),P=V.p;
const uq=m&&unr()?' ('+unr()+')':'',nb0=m?S.n.filter(n=>n.to===m.id&&!n.r).length:0,dk=document.documentElement.dataset.theme==='dark';
$('#hx').innerHTML=''+(m?`<button class="bl" onclick="go('notes')" aria-label="الإشعارات" title="الإشعارات">🔔${nb0?`<em>${nb0}</em>`:''}</button>`:'')+`<button onclick="S.dark=!${dk};save();R()" aria-label="تغيير المظهر" title="تغيير المظهر">${dk?'☀️':'🌙'}</button>`+(m?`<button class="st-account-head" onclick="go('set',undefined,'account')" aria-label="الحساب" title="إدارة الحساب">👤 <span>الحساب</span></button>`:'');
const it=m?(m.role==='admin'?[['dash','🏠','الرئيسية'],['admin','🛡️','الإدارة'],['chats','💬','الشاتات'+uq],['set','⚙️','الإعدادات']]:m.role==='teacher'?[['dash','🏠','الرئيسية'],['chats','💬','الشاتات'+uq],['ai','🤖','الذكاء'],['set','⚙️','الإعدادات']]:[['dash','🏠','الرئيسية'],['chats','💬','الشاتات'+uq],['ai','🤖','الذكاء'],['board','🏆','الشرف'],['set','⚙️','الإعدادات']]):[['dash','🏠','الرئيسية',''],['dash','🔑','دخول','login'],['dash','✨','حساب جديد','reg']];
$('#bn').innerHTML=it.map(x=>{const on=m?(x[0]===P||(x[0]==='chats'&&P==='pm')||(x[0]==='dash'&&['group','studio','exam','review','grade'].includes(P))):(x[3]||'')===(V.a||'');return `<button class="${on?'on':''}" onclick="go('${x[0]}',${m?'undefined':`'${x[3]}'`})"><span>${x[1]}</span>${x[2]}</button>`}).join('');
$('#app').innerHTML=OTP?otpScreen():!m?auth():({dash,group,studio,exam,rec,board,set,notes,pm,chats,review,grade,reports:stReports,admin:stAdmin,ai:aipage})[P]();const w=$('#wb');if(w)w.scrollTop=1e9;if(Q)fl();document.documentElement.style.setProperty('--hh',($('header')?.offsetHeight||60)+'px')}
function fl(){const q=Q.trim().toLowerCase();document.querySelectorAll('[data-gt]').forEach(e=>e.style.display=e.dataset.gt.includes(q)?'':'none')}
function confetti(){const c=['#4f46e5','#7c3aed','#ec4899','#f59e0b','#16a34a'];for(let i=0;i<60;i++){const d=document.createElement('i');d.className='cf';d.style.cssText=`left:${Math.random()*100}%;background:${c[i%5]};animation-delay:${Math.random()}s`;document.body.appendChild(d);setTimeout(()=>d.remove(),4000)}}
