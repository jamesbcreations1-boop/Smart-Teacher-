/* ▓▓ 03-auth-screens.js — شاشات الدخول والتسجيل ونسيت كلمة المرور (OTP) و v13.3
   بيتحمّل بعد: 02-ui-base.js  |  وبعده: 04-page-dashboard.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ---------- auth ---------- */
function landing(){const F=[['🤖','أسئلة بالذكاء الاصطناعي','ولّد اختيارات وصح/خطأ وأكمل من نص أو صورة أو PDF أو Word'],['⏱️','امتحانات بمؤقت','تسليم تلقائي وحماية من الغش'],['✅','تصحيح فوري','وإعادة تصحيح تلقائية عند تعديل الإجابات'],['🎓','شهادات تقدير','شهادة صورة جاهزة للتحميل'],['📊','تحليلات ذكية','الغائبون وأكثر الأسئلة خطأً'],['💬','شات واتساب','شات المجموعات والخاص بإشعارات فورية'],['🤖','SHANANOO AI','مساعد ذكي يلخّص ويشرح من نص أو صورة'],['🏆','لوحة الشرف','تنافس صحي وتحفيز'],['⭐','نقاط ومستويات','XP وشارات تحفّز الطالب']],n=(a)=>`<div class="card stc"><div class="big">${a[0]}</div><span class="mut">${a[1]}</span></div>`;
return `<section class="hero"><i class="sh s1"></i><i class="sh s2"></i><i class="sh s3"></i><i class="fe" style="--x:8%;--y:14%">📚</i><i class="fe" style="--x:86%;--y:20%;--d:1s">🧪</i><i class="fe" style="--x:14%;--y:70%;--d:2s">📐</i><i class="fe" style="--x:80%;--y:68%;--d:3s">🚀</i><i class="fe" style="--x:50%;--y:6%;--d:4s">⭐</i><div class="hc">${ART}<span class="pill" style="background:#ffffff26;color:#fff">✨ منصة تعليمية بالذكاء الاصطناعي</span><h1>علّم أذكى.. وتعلّم أسرع</h1><p>أنشئ امتحانات من أي ملف في ثوانٍ، وصحّح تلقائياً، وتابع تقدّم طلابك لحظة بلحظة.</p><button class="b hb" style="background:#fff;color:var(--pri)" onclick="go('dash','reg')">ابدأ مجاناً</button><button class="b s hb" onclick="go('dash','login')">تسجيل الدخول</button></div></section>
<h2 class="ct">كل ما تحتاجه في مكان واحد</h2><div class="grid">${F.map((f,i)=>`<div class="card"><div class="ic" style="background:hsl(${i*47} 80% 55% / .18)">${f[0]}</div><h3>${f[1]}</h3><p class="mut">${f[2]}</p></div>`).join('')}</div>
<h2 class="ct">ابدأ في 3 خطوات</h2><div class="grid">${['أنشئ حسابك وفعّله','أنشئ مجموعة وشارك الكود','ولّد امتحانك وانشره'].map((t,i)=>`<div class="card stc"><div class="big">${i+1}</div><b>${t}</b></div>`).join('')}</div>
<div class="hero" style="margin-top:20px"><div class="hc"><h2>جاهز تبدأ؟</h2><button class="b hb" style="background:#fff;color:var(--pri)" onclick="go('dash','reg')">أنشئ حسابك الآن</button></div></div>`}
function strong(v){let n=0;if(v.length>=6)n++;if(v.length>=10)n++;if(/\d/.test(v)&&/[a-zA-Z\u0600-\u06FF]/.test(v))n++;if(/[^\w\s]/.test(v))n++;$('#sb').style.width=n*25+'%'}
let RR='student',RF={};
const newPc=()=>{let c;do{c=String(Math.floor(1e5+Math.random()*9e5))}while(S.u.some(x=>x.pc===c));return c};
const SJL='<datalist id="sjl">'+['اللغة العربية','اللغة الإنجليزية','الرياضيات','العلوم','الفيزياء','الكيمياء','الأحياء','التاريخ','الجغرافيا','الدراسات الاجتماعية','الحاسب الآلي','اللغة الفرنسية','التربية الدينية'].map(x=>`<option value="${x}">`).join('')+'</datalist>';
const fi=(id,l,o={})=>`<label class="fl"><span>${l}</span><input id="${id}" ${o.cls?`class="${o.cls}"`:''} placeholder="${o.ph||''}" value="${esc(RF[id]||'')}" oninput="RF.${id}=this.value${o.on?';'+o.on:''}" ${o.t?`type="${o.t}"`:''} ${o.im?`inputmode="${o.im}"`:''} ${o.ml?`maxlength="${o.ml}"`:''} ${o.ac?`autocomplete="${o.ac}"`:''} ${o.dir?`dir="${o.dir}"`:''} ${o.li?`list="${o.li}"`:''}></label>`;
const setRR=r=>{RR=r;RF.ps=1;R()},mail=e=>String(e).replace(/^(.).*(@.*)$/,'$1•••$2');
function lookPc(v){const el=$('#pcv');if(!el)return;const c=String(v).replace(/\D/g,'');if(c.length<6){el.className='hint';el.textContent='';return}const s=S.u.find(x=>x.role==='student'&&x.pc===c);el.className='hint '+(s?'ok':'er');el.textContent=s?'✅ تم العثور على حساب: '+s.name.split(' ')[0]:'❌ الكود غير صحيح'}
function regForm(){const tabs=[['student','🎓','طالب'],['parent','👨‍👩‍👧','ولي أمر'],['teacher','👨‍🏫','مدرس']].map(x=>`<button type="button" class="${RR===x[0]?'on':''}" onclick="setRR('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('');
const acct=fi('em','البريد الإلكتروني',{ph:'name@gmail.com',t:'email',dir:'ltr',ac:'email',im:'email'})+fi('pw','كلمة المرور',{ph:'6 أحرف على الأقل',t:'password',ac:'new-password',on:'strong(this.value)'})+'<div class="sbar"><i id="sb"></i></div>'+fi('cp','تأكيد كلمة المرور',{t:'password',ac:'new-password'});let f='';
if(RR==='parent'&&(RF.ps||1)===1)f=`<p class="mut">ادخل اسمك وكود ولي الأمر الذي يظهر عند ابنك في <b>حسابي</b></p>`+fi('nm','اسمك',{ph:'الاسم الكامل',ac:'name'})+fi('pc','كود ولي الأمر',{ph:'••••••',im:'numeric',ml:6,cls:'pcin',ac:'off',on:'lookPc(this.value)'})+`<div id="pcv" class="hint"></div><button class="b" style="width:100%" onclick="parentNext()">التالي ←</button>`;
else if(RR==='parent'){const k=U(RF.pcId);f=`<div class="chip">👨‍👩‍👧 ${esc(RF.nm)} — ولي أمر <b>${esc(k?k.name:'')}</b></div><p class="mut">آخر خطوة: بريدك وكلمة المرور لتدخل بهما لاحقاً، وسنرسل لك كود تأكيد على البريد.</p>`+acct+`<button class="b" style="width:100%" onclick="signup()">إرسال كود التأكيد ✉️</button><button class="b s" style="width:100%" onclick="RF.ps=1;R()">→ رجوع</button>`}
else f=fi('nm','الاسم الكامل',{ac:'name'})+fi('ph','رقم الموبايل',{ph:'01xxxxxxxxx',im:'tel',dir:'ltr',ac:'tel'})+(RR==='teacher'?fi('sj','المادة التي تدرّسها',{ph:'مثال: الرياضيات',li:'sjl'})+SJL:fi('pp','رقم ولي الأمر (اختياري)',{ph:'للتواصل من المدرس',im:'tel',dir:'ltr'}))+acct+`<button class="b" style="width:100%" onclick="signup()">إرسال كود التأكيد ✉️</button>`;
return `<div class="rtabs">${tabs}</div>${f}`}
function otpScreen(){const o=OTP,st=o.busy?'جارٍ إرسال الكود إلى':o.sent?'أرسلنا كود التأكيد (6 أرقام) إلى بريدك':o.p?'⚠️ وضع تجريبي — خدمة البريد غير مربوطة بعد، الكود: <b class="pcode" style="font-size:24px">'+o.p+'</b> للبريد':'لم يتم الإرسال، اضغط إعادة إرسال للبريد';const title=o.cpw?'تأكيد تغيير كلمة المرور عبر Gmail':o.verifyMail?'تأكيد بريد Gmail':o.fg?'استرجاع كلمة المرور':'تأكيد البريد الإلكتروني';const action=o.cpw?'تأكيد وتغيير كلمة المرور':o.verifyMail?'تأكيد البريد الإلكتروني':o.fg?'تغيير كلمة المرور':'تأكيد وإنشاء الحساب';
return `<div class="card auth st-otp-card" style="max-width:460px;margin:20px auto"><div class="st-gmail-mark" aria-hidden="true">✉️</div><h2>${title}</h2><p class="mut">${st} <b dir="ltr">${esc(mail(o.u.email))}</b><br><small>الكود صالح 15 دقيقة — راجع Spam أو البريد غير الهام لو لم يظهر</small></p><input id="op" class="pcin" placeholder="أدخل رمز التحقق المكوّن من 6 أرقام" inputmode="numeric" maxlength="6" autocomplete="one-time-code">${o.fg?'<label class="fl"><span>كلمة المرور الجديدة</span><input id="np" type="password" placeholder="8 أحرف على الأقل" autocomplete="new-password"></label><label class="fl"><span>تأكيد كلمة المرور</span><input id="np2" type="password" autocomplete="new-password"></label>':''}<button class="b" style="width:100%" onclick="verify()">${action}</button><a class="b s st-gmail-link" href="https://mail.google.com/" target="_blank" rel="noopener noreferrer">📨 فتح Gmail</a><button class="b s" style="width:100%" onclick="resend()">إعادة إرسال الكود</button><button class="b s" style="width:100%" onclick="OTP=null;R()">رجوع</button></div>`}
function auth(){if(OTP)return otpScreen();if(!V.a)return landing();const a=V.a;
if(a==='fg')return `<div class="card auth" style="max-width:440px;margin:24px auto"><h2>🔑 نسيت كلمة المرور؟</h2><p class="mut">اكتب بريدك وسنرسل لك كود تأكيد لتعيين كلمة مرور جديدة.</p>${fi('fe','البريد الإلكتروني',{t:'email',dir:'ltr',im:'email',ph:'name@gmail.com'})}<button class="b" style="width:100%" onclick="forgot()">إرسال الكود ✉️</button><button class="b s" style="width:100%" onclick="go('dash','login')">رجوع لتسجيل الدخول</button></div>`;
if(a==='reg')return `<div class="card auth" style="max-width:460px;margin:24px auto"><h2>✨ إنشاء حساب</h2>${regForm()}<button class="b s" style="width:100%" onclick="go('dash','login')">عندي حساب بالفعل</button></div>`;
return `<div class="card auth" style="max-width:440px;margin:24px auto"><h2>👋 تسجيل الدخول</h2>${fi('em','البريد أو رقم الموبايل',{dir:'ltr',ac:'username'})}${fi('pw','كلمة المرور',{t:'password',ac:'current-password'})}<button class="b" style="width:100%" onclick="login()">دخول</button><button class="b s" style="width:100%" onclick="go('dash','reg')">إنشاء حساب جديد</button><p class="mut"><a href="#" onclick="go('dash','fg');return false">نسيت كلمة المرور؟</a></p></div>`}
async function sendOtp(){const o=OTP;if(!o)return;if(o.srv)return sendOtpSrv(o);o.busy=1;o.p='';o.sent=0;R();const code=String(100000+crypto.getRandomValues(new Uint32Array(1))[0]%900000),M=CFG.EMAIL||{};o.h=await hp(code+'|'+o.u.email);o.exp=Date.now()+9e5;o.tries=0;o.last=Date.now();
try{if(CFG.OTP_URL){const r=await fetch(CFG.OTP_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:o.u.email,name:o.u.name,code,purpose:o.cpw?'change_password':o.verifyMail?'verify_email':o.fg?'reset':'signup'})});if(!r.ok)throw 0;o.sent=1}
else if(M.SERVICE&&M.TEMPLATE&&M.KEY){const r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:M.SERVICE,template_id:(o.fg?(M.TEMPLATE_RESET||M.TEMPLATE):M.TEMPLATE),user_id:M.KEY,template_params:{to_email:o.u.email,email:o.u.email,user_email:o.u.email,reply_to:o.u.email,to_name:o.u.name,name:o.u.name,user_name:o.u.name,code,otp:code,passcode:code,message:code,app_name:'المعلم الذكي',expires:'15',time:'15 دقيقة'}})});if(!r.ok){let t='';try{t=await r.text()}catch(_){}throw new Error(r.status+' '+t)}o.sent=1}else o.p=code}
catch(e){console.error('EmailJS error:',e);const m=String(e&&e.message||'');toast('تعذر إرسال الإيميل'+(m?' ('+m.slice(0,90)+')':'')+' — اضغط إعادة إرسال')}o.busy=0;if(OTP===o)R()}
function resend(){const w=60-(Date.now()-(OTP.last||0))/1e3;if(w>0)return toast('انتظر '+Math.ceil(w)+' ثانية قبل إعادة الإرسال');sendOtp()}
async function parentNext(){const n=(RF.nm||'').trim(),c=(RF.pc||'').replace(/\D/g,'');if(n.length<3)return toast('اكتب اسمك');if(c.length!==6)return toast('كود ولي الأمر 6 أرقام');if(Date.now()<LT)return toast('محاولات كثيرة، انتظر '+Math.ceil((LT-Date.now())/1e3)+' ثانية');const r=await api('/parent-lookup?code='+encodeURIComponent(c),{auth:false,timeout:10000});if(!r||!r.ok){lockFail();return toast('الكود غير صحيح — اطلبه من ابنك (حسابي)')}LF=0;lockOk();RF.pcId=r.id;RF.ps=2;R()}
async function signup(){window.__stPw=RF.pw||'';if(RR==='parent'&&(RF.ps||1)===1)return parentNext();const v=k=>(RF[k]||'').trim(),pw=RF.pw||'',em=v('em').toLowerCase(),u={id:uid(),name:v('nm'),email:em,phone:v('ph'),pw:'',role:RR,pp:v('pp'),sj:v('sj'),ok:1,pv:1,ev:1};
if(u.name.length<3)return toast('اكتب الاسم الكامل');if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em))return toast('اكتب بريداً إلكترونياً صحيحاً');
if(u.role!=='parent'&&!/^(\+?20|0)?1[0125]\d{8}$/.test(u.phone.replace(/[\s-]/g,'')))return toast('رقم موبايل مصري صحيح مطلوب');if(u.pp&&!/^(\+?20|0)?1[0125]\d{8}$/.test(u.pp.replace(/[\s-]/g,'')))return toast('رقم ولي الأمر غير صحيح');
if(u.role==='teacher'&&!u.sj)return toast('اكتب المادة التي تدرّسها');if(pw.length<6)return toast('كلمة المرور 6 أحرف على الأقل');if(pw!==(RF.cp||''))return toast('كلمتا المرور غير متطابقتين');

let link=null;if(u.role==='parent'){link=RF.pcId;if(!link)return toast('أكمل ربط حساب الطالب أولاً')}if(u.role==='student')u.pc=newPc();
u.pw=await hp(pw);OTP={u,link,busy:1,pw};sendOtp()}
async function verify(){const o=OTP,c=($('#op').value||'').trim();if(!o||o.busy)return;if(!o.h)return toast('لم يُرسل الكود بعد، اضغط إعادة إرسال');if(Date.now()>o.exp)return toast('انتهت صلاحية الكود، اضغط إعادة إرسال');
let np='';if(o.fg){np=$('#np')?.value||'';if(np.length<8)return toast('كلمة المرور 8 أحرف على الأقل');if(np!==($('#np2')?.value||''))return toast('كلمتا المرور غير متطابقتين')}
if(o.srv)return verifySrv(o,c,np);if(++o.tries>5){o.h='';return toast('محاولات كثيرة، اطلب كوداً جديداً')}if(await hp(c+'|'+o.u.email)!==o.h)return toast('الكود غير صحيح (متبقي '+(5-o.tries)+' محاولات)');await pull();
if(o.cpw){const u=S.u.find(x=>x.id===o.u.id&&x.email===o.u.email);if(!u){OTP=null;R();return toast('تعذر العثور على الحساب، سجّل الدخول مجدداً')}u.pw=o.nextPw;OTP=null;save();R();return toast('تم تغيير كلمة المرور بعد التحقق من رمز البريد ✅')}
if(o.verifyMail){const u=S.u.find(x=>x.id===o.u.id&&x.email===o.u.email);if(!u){OTP=null;R();return toast('تعذر العثور على الحساب')}u.ev=1;u.emailVerified=1;OTP=null;save();go('set',undefined,'account');return toast('تم تأكيد البريد الإلكتروني بنجاح ✅')}
if(o.fg){const u=S.u.find(x=>x.id===o.u.id&&x.email===o.u.email);if(!u){OTP=null;R();return toast('الحساب غير موجود أو تغيّرت بياناته')}u.pw=await hp(np);OTP=null;save();if(o.accountReset){V={p:'set',t:'account'};R();return toast('تم تحديث كلمة المرور بنجاح ✅')}V={p:'dash',a:'login'};R();return toast('تم تغيير كلمة المرور ✅ سجّل دخولك')}
try{
 const rr=await api('/register',{method:'POST',auth:false,timeout:15000,body:{user:{...o.u,pw:undefined},password:o.pw||window.__stPw||'',link:o.link||null,parentCode:o.link?(RF.pc||''):null}});
 if(!rr||!rr.ok)throw Object.assign(new Error('register failed'),{status:409});
 if(window.firebase&&rr.token){LGN=1;try{await firebase.auth().signInWithCustomToken(rr.token);await idToken(true)}finally{LGN=0}}
 S.me=rr.uid;S.u=S.u.filter(x=>x.id!==o.u.id);S.u.push({...o.u,pw:undefined});OTP=null;RF={};save();await pull();window.__stPw='';V={p:'dash'};R();confetti();toast('أهلاً بيك! تم تأكيد بريدك وإنشاء الحساب 🎉');autoJoin();if(window.afterSignup)afterSignup()
}catch(e){return toast(e&&e.status===409?'البريد أو رقم الهاتف مستخدم بالفعل':e&&e.status===404?'خادم التسجيل غير محدَّث (المسار /register غير موجود) — انشر نسخة الـ Worker الأحدث':e&&e.status===400?'بيانات التسجيل غير صالحة'+((e.data&&(e.data.reason||e.data.error))?' ('+(e.data.reason||e.data.error)+')':''):'تعذر إنشاء الحساب'+((e&&e.data&&e.data.detail)?' — '+e.data.detail:(e&&e.status?' (خطأ '+e.status+')':' — تأكد من الإنترنت ومن رابط الـ Worker في firebase-config.js'))+'. جرّب تاني')}
}
let LF=0,LT=+(localStorage.getItem('stp_lt')||0)||0,JC='';function lockFail(){if(++LF>=5){const n=Math.min((+localStorage.getItem('stp_ln')||0)+1,20);try{localStorage.setItem('stp_ln',n)}catch(e){}LT=Date.now()+3e4*n;try{localStorage.setItem('stp_lt',LT)}catch(e){}LF=0}}const lockOk=()=>{try{localStorage.removeItem('stp_ln');localStorage.removeItem('stp_lt')}catch(e){}};const autoJoin=()=>{if(JC&&!isT()){const c=JC;JC='';join(c)}};
async function login(){
  if(LGN)return;
  if(Date.now()<LT)return toast('محاولات كثيرة، انتظر '+Math.ceil((LT-Date.now())/1e3)+' ثانية');
  const i=(RF.em||'').trim().toLowerCase(),pw=RF.pw||'';
  if(!i||!pw)return toast('اكتب البريد وكلمة المرور');
  LGN=1;
  const btn=document.querySelector('button[onclick="login()"]'),bt=btn&&btn.textContent;
  if(btn){btn.disabled=true;btn.textContent='⏳ جارٍ تسجيل الدخول…'}
  try{
    let r;
    try{r=await api('/login',{method:'POST',body:{id:i,password:pw},auth:false,timeout:20000})}
    catch(e){
      if(e.status===401){lockFail();const rs=e.data&&e.data.reason;return toast(rs==='no_user'?'الحساب ده مش مسجّل — راجع البريد أو رقم الموبايل':rs==='bad_pw'?'كلمة المرور غلط — لو نسيتها اضغط «نسيت كلمة المرور؟»':rs==='no_pw'?'الحساب ده مالوش كلمة مرور — اضغط «نسيت كلمة المرور؟» لتعيينها':'بيانات الدخول غير صحيحة')}
      if(e.status===429){const w=Math.min(+(e.data&&e.data.retry)||600,600);LT=Date.now()+w*1e3;try{localStorage.setItem('stp_lt',LT)}catch(x){}return toast('محاولات كثيرة، حاول بعد '+Math.ceil(w/60)+' دقيقة')}
      if(e.status===400)return toast('بيانات الدخول غير صالحة');
      return toast(apiErr(e));
    }
    if(!r||!r.ok||!r.token||!r.uid)return toast('رد غير متوقع من الخادم، حاول مرة أخرى');
    try{await firebase.auth().signInWithCustomToken(r.token)}
    catch(e){console.warn('custom token',e);return toast('تعذّر إنشاء جلسة آمنة ('+(e.code||e.message||'auth')+')')}
    await idToken(true);
    for(let k=0;k<20&&PL;k++)await new Promise(z=>setTimeout(z,250));
    await pull();
    let u=S.u.find(x=>x.id===r.uid);
    if(!u){await pull();u=S.u.find(x=>x.id===r.uid)}
    if(!u)return toast('تعذر تحميل بيانات حسابك، تحقق من الاتصال وحاول مرة أخرى');
    if(u.sus){
      if(u.sb==='admin')return toast('⛔ حسابك موقوف من الإدارة. تواصل مع الدعم لإعادة التفعيل');
      delete u.sus;delete u.sb;delete u.sd;toast('✅ أهلاً بعودتك — تم إعادة تفعيل حسابك');
    }
    if(r.upgrade&&u.pw!==r.upgrade)u.pw=r.upgrade;
    LF=0;lockOk();S.me=u.id;RF={};save();R();autoJoin();
  }catch(e){console.warn('login',e);toast(apiErr(e))}
  finally{LGN=0;if(!S.me)syncSession();if(btn){btn.disabled=false;btn.textContent=bt}}
}
async function forgot(){const e=(RF.fe||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e))return toast('اكتب بريدك الإلكتروني');OTP={u:{id:'',email:e,name:''},fg:1,srv:1,h:'srv',tries:0};sendOtp()}
/* ===== v13.3: استرجاع كلمة المرور من السيرفر (الكود بيتولّد ويتبعت ويتتحقق منه في الـ Worker) ===== */
async function sendOtpSrv(o){
  o.busy=1;o.sent=0;o.p='';R();
  try{
    const r=await api('/reset/start',{method:'POST',body:{email:o.u.email},auth:false,timeout:30000});
    o.sent=1;o.exp=(r&&r.exp)||Date.now()+9e5;o.last=Date.now();o.tries=0;o.h='srv';
  }catch(e){
    const er=e&&e.data&&e.data.error;
    if(er==='no_user'){OTP=null;R();return toast('مفيش حساب بالبريد ده — راجع البريد أو أنشئ حساب جديد')}
    if(er==='mail_not_configured'){OTP=null;R();return toast('خدمة إرسال الإيميل لسه مش متفعّلة على الـ Worker (متغيرات EMAILJS_*) — اتبع خطوات التفعيل')}
    if(er==='mail_failed'){OTP=null;R();return toast('فشل إرسال الإيميل من EmailJS'+((e.data&&e.data.detail)?' ('+String(e.data.detail).slice(0,80)+')':''))}
    toast(e&&e.status===404?'الـ Worker القديم لسه منشور — انشر worker.js الجديد (v13.3)':apiErr(e));
  }
  o.busy=0;if(OTP===o)R();
}
async function verifySrv(o,c,np){
  if(!/^\d{6}$/.test(c))return toast('اكتب الكود المكوّن من 6 أرقام');
  if(o.busy)return;o.busy=1;
  try{
    const r=await api('/reset/confirm',{method:'POST',body:{email:o.u.email,code:c,password:np},auth:false,timeout:30000});
    if(!r||!r.ok||!r.token)throw new Error('bad');
    LGN=1;try{await firebase.auth().signInWithCustomToken(r.token);await idToken(true)}finally{LGN=0}
    for(let k=0;k<20&&PL;k++)await new Promise(z=>setTimeout(z,250));
    await pull();
    let u=S.u.find(x=>x.id===r.uid);if(!u){await pull();u=S.u.find(x=>x.id===r.uid)}
    OTP=null;RF={};
    if(!u){V={p:'dash',a:'login'};R();return toast('تم تغيير كلمة المرور ✅ سجّل دخولك بالجديدة')}
    try{typeof lockOk==='function'&&lockOk()}catch(x){}S.me=u.id;save();V=o.accountReset?{p:'set',t:'account'}:{p:'dash'};R();toast('تم تغيير كلمة المرور ✅ وتم تسجيل دخولك');autoJoin();
  }catch(e){
    o.busy=0;const er=e&&e.data&&e.data.error;
    if(er==='bad_code')return toast('الكود غير صحيح'+(e.data&&e.data.left>=0?' (متبقي '+e.data.left+' محاولات)':''));
    if(er==='expired'||e.status===410)return toast('انتهت صلاحية الكود، اضغط إعادة إرسال');
    if(er==='too_many_tries'||e.status===429)return toast('محاولات كثيرة، اطلب كوداً جديداً');
    return toast(apiErr(e));
  }
  o.busy=0;
}
