/* ▓▓ 20-layer-reports-tools.js — إضافات v11: تقارير وأدوات
   بيتحمّل بعد: 13-page-records-board-settings.js  |  وبعده: 21-layer-extras-v12.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [01] إضافات v11 (تقارير وأدوات)
   ========================================================================== */
/* ===== SmartTeacher extensions v11 — كل ميزة في قسم مستقل ===== */
(()=>{
const K=k=>'stx_'+k+'_'+S.me,ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(K(k)))??d}catch(e){return d}},sv=(k,v)=>{try{localStorage.setItem(K(k),JSON.stringify(v))}catch(e){}};
const mine=u=>S.s.filter(s=>s.u===u&&E(s.e)).sort((a,b)=>a.d-b.d),sc=s=>score(E(s.e),s),fmt=d=>new Date(d).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'});

/* ===== FEATURE 1: الشارات والإنجازات ===== */
const BD=[['first','🌱','البداية','سلّم أول امتحان',c=>c.n>=1,c=>c.n*100],['five','📚','مثابر','سلّم 5 امتحانات',c=>c.n>=5,c=>c.n*20],['ten','🏛️','خبير','سلّم 10 امتحانات',c=>c.n>=10,c=>c.n*10],
['pass3','🔥','سلسلة نجاح','نجاح في 3 امتحانات متتالية (50%+)',c=>c.st>=3,c=>c.st*33],['pass5','⚡','لا يُوقَف','5 نجاحات متتالية',c=>c.st>=5,c=>c.st*20],['perfect','💯','العلامة الكاملة','احصل على 100%',c=>c.max>=100,c=>c.max],
['top','🎯','متفوق','متوسط 85%+ في 3 امتحانات على الأقل',c=>c.n>=3&&c.avg>=85,c=>Math.min(c.n/3,1)*c.avg],['comeback','💪','عودة قوية','حسّن درجتك 20 نقطة عن امتحانك السابق',c=>c.cb,c=>0],
['days','📅','منتظم','حل امتحانات في 3 أيام مختلفة',c=>c.days>=3,c=>c.days*33],['star','⭐','جامع المفضلة','احفظ 5 أسئلة للمراجعة',c=>c.bm>=5,c=>c.bm*20]];
function ctx(u){const ss=mine(u),v=ss.map(sc);let run=0,st=0,cb=0;v.forEach((x,i)=>{run=x>=50?run+1:0;st=Math.max(st,run);if(i&&x-v[i-1]>=20)cb=1});return{n:v.length,st,cb,max:Math.max(0,...v),avg:v.length?v.reduce((a,b)=>a+b,0)/v.length:0,days:new Set(ss.map(s=>new Date(s.d).toDateString())).size,bm:u===S.me?ld('bm',[]).length:0}}
const earned=u=>{const c=ctx(u);return BD.filter(b=>b[4](c))};
badges=u=>earned(u).map(b=>b[1]+' '+b[2]);
function bdCheck(){if(!S.me||isT())return;const got=ld('bd',{}),nw=earned(S.me).filter(b=>!got[b[0]]);if(!nw.length)return;nw.forEach(b=>got[b[0]]=Date.now());sv('bd',got);toast('🏅 شارة جديدة: '+nw.map(b=>b[1]+' '+b[2]).join(' ، '));confetti()}
const bdHTML=()=>{const c=ctx(S.me);return `<div class="bdg">${BD.map(b=>{const ok=b[4](c);return `<div class="bdc ${ok?'on':''}"><div class="bi">${ok?b[1]:'🔒'}</div><b>${b[2]}</b><small>${b[3]}</small>${ok?'':`<div class="bar"><i style="width:${Math.min(100,Math.round(b[5](c)))}%"></i></div>`}</div>`}).join('')}</div>`};
const _sub=submit;submit=function(a){_sub(a);setTimeout(bdCheck,700)};

/* ===== FEATURE 2: المفضلة وبنك الأخطاء + التدريب السريع ===== */
const bmk=()=>ld('bm',[]),isBm=(e,q)=>bmk().some(x=>x.e===e&&x.q===q);
window.bmT=(e,q,b)=>{const a=bmk(),i=a.findIndex(x=>x.e===e&&x.q===q);if(i<0)a.push({e,q,t:Date.now()});else a.splice(i,1);sv('bm',a);if(b)b.classList.toggle('on',i<0);toast(i<0?'⭐ تم الحفظ للمراجعة':'تمت الإزالة من المفضلة');bdCheck()};
const star=(e,q)=>`<button class="bmk ${isBm(e,q)?'on':''}" title="حفظ للمفضلة" onclick="bmT('${e}','${q}',this)">⭐ <span>حفظ للمراجعة</span></button>`;
const _exam=exam;exam=function(){const h=_exam();if(typeof h!=='string'||!h)return h;const P='<div class="card"><b>';
if(V.t==='res'){const e=E(V.a);return h.split(P).map((p,i)=>i?P+(e.q[i-1]?p.replace('</b>','</b>'+star(e.id,e.q[i-1].id)):p):p).join('')}
if(CUR)return h.split(P).map((p,i)=>{const m=i&&p.match(/CUR\.a\['([^']+)'\]/);return i?P+(m?p.replace('</b>','</b>'+star(CUR.e,m[1])):p):p}).join('');return h};
const wrong=()=>{const out=[],seen=new Set();mine(S.me).reverse().forEach(s=>{if(seen.has(s.e))return;seen.add(s.e);const e=E(s.e);e.q.forEach(q=>{if(!isOk(q,s))out.push({e,q,s})})});return out};
const saved=()=>bmk().map(x=>{const e=E(x.e),q=e&&e.q.find(y=>y.id===x.q);return q?{e,q,s:S.s.filter(s=>s.e===e.id&&s.u===S.me)[0]}:null}).filter(Boolean);
const qcard=(x,rm)=>{const{e,q,s}=x;return `<div class="card"><small class="mut">${esc(e.name)}</small><br><b>${esc(q.q)}</b>${s?`<br><span style="color:var(--bad)">إجابتك: ${esc(s.a[q.id]||'—')}</span>`:''}<br>الصحيح: <b>${esc(ans(q))}</b>${q.x?`<p class="mut">${esc(q.x)}</p>`:''}<div class="msg" id="x${q.id}" style="display:none"></div>${s?`<button class="b s" onclick="explain('${e.id}','${q.id}')">🤖 اشرح لي</button>`:''}${rm?`<button class="b s" onclick="bmT('${e.id}','${q.id}');R()">🗑 إزالة</button>`:star(e.id,q.id)}</div>`};
let PR=null;
window.prNext=()=>{const pool=[...wrong(),...saved()];if(!pool.length){PR=null;toast('لا توجد أسئلة للتدريب بعد');return R()}const x=pool[Math.floor(Math.random()*pool.length)],q=x.q;PR={q,e:x.e,o:q.t==='fib'?null:(q.t==='tf'?['صح','خطأ']:q.o.slice().sort(()=>Math.random()-.5)),r:null,n:PR?PR.n:0,ok:PR?PR.ok:0};R()};
window.prA=v=>{if(!PR||PR.r!==null)return;const val=typeof v==='number'?PR.o[v]:($('#pri').value||''),ok=isOk(PR.q,{a:{[PR.q.id]:val}});PR.r=ok?1:0;PR.n++;if(ok){PR.ok++;confetti()}R()};
const prHTML=()=>{if(!PR)return `<div class="card" style="text-align:center"><div class="big">🎯</div><p class="mut">تدريب سريع على الأسئلة التي أخطأت فيها أو حفظتها</p><button class="b" onclick="prNext()">ابدأ التدريب</button></div>`;
return `<div class="card"><div class="row"><span class="pill">✔ ${PR.ok} / ${PR.n}</span><small class="mut">${esc(PR.e.name)}</small></div><h3>${esc(PR.q.q)}</h3>${PR.r===null?(PR.o?PR.o.map((o,i)=>`<button class="opt prb" onclick="prA(${i})">${esc(o)}</button>`).join(''):`<input id="pri" placeholder="إجابتك"><button class="b" onclick="prA()">تأكيد</button>`):`<p style="color:var(--${PR.r?'ok':'bad'});font-weight:700">${PR.r?'✔ إجابة صحيحة!':'✘ غير صحيحة'}</p>${PR.r?'':`<p>الصحيح: <b>${esc(ans(PR.q))}</b></p>`}<button class="b" onclick="prNext()">السؤال التالي ←</button>`}</div>`};
const _rec=rec;rec=function(){if(isT()||!me())return _rec();const t=['bd','wr','bm','pr'].includes(V.t)?V.t:'gr',T=[['gr','📜','الدرجات'],['bd','🏅','إنجازاتي'],['wr','❌','أخطائي'],['bm','⭐','المفضلة'],['pr','🎯','تدريب']];let b;
if(t==='bd')b=`<h3>${earned(S.me).length} / ${BD.length} شارة</h3>${bdHTML()}`;else if(t==='wr')b=wrong().map(x=>qcard(x)).join('')||emp('ممتاز! لا توجد أخطاء 🎉');else if(t==='bm')b=saved().map(x=>qcard(x,1)).join('')||emp('اضغط ⭐ بجوار أي سؤال لحفظه هنا');else if(t==='pr')b=prHTML();else b=_rec();
return `<div class="tabs">${T.map(x=>`<button class="${t===x[0]?'on':''}" onclick="go('rec',undefined,'${x[0]}')">${x[1]} ${x[2]}</button>`).join('')}</div><button class="b" style="margin-bottom:12px" onclick="rpt()">📄 تقرير الأداء (PDF)</button>${b}`};

/* ===== FEATURE 3: تقرير الأداء PDF ===== */
window.rpt=()=>{const m=me(),ss=mine(m.id),v=ss.map(sc),n=v.length,avg=n?Math.round(v.reduce((a,b)=>a+b,0)/n):0,best=Math.max(0,...v),pass=n?Math.round(v.filter(x=>x>=50).length/n*100):0,bd=earned(m.id),w=wrong().length;
const last=v.slice(-3),prev=v.slice(-6,-3),tr=last.length&&prev.length?(last.reduce((a,b)=>a+b,0)/last.length-prev.reduce((a,b)=>a+b,0)/prev.length):0,txt=!n?'لا توجد امتحانات بعد.':tr>=5?'📈 أداؤك في تحسّن مستمر، واصل!':tr<=-5?'📉 هناك تراجع بسيط مؤخراً، راجع أخطاءك وتدرّب عليها.':'➡️ أداؤك مستقر، حاول رفع المتوسط بمراجعة الأسئلة الخاطئة.';
const pts=v.map((x,i)=>`${v.length>1?20+i*(560/(v.length-1)):300},${140-x*1.2}`).join(' ');
const rows=ss.map(s=>{const e=E(s.e),g=G(e.g),p=sc(s);return `<tr><td>${esc(e.name)}</td><td>${esc(g?g.title:'')}</td><td>${new Date(s.d).toLocaleDateString('ar-EG')}</td><td><div class="b"><i style="width:${p}%"></i></div></td><td><b>${p}%</b></td></tr>`}).join('');
const h=`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>تقرير أداء - ${esc(m.name)}</title><style>body{font-family:Cairo,Tahoma,sans-serif;margin:0;padding:28px;color:#0f1b33}h1{margin:0}.hd{background:linear-gradient(135deg,#0a2a57,#0b57b8);color:#fff;border-radius:16px;padding:22px;margin-bottom:18px}.g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px}.c{border:1px solid #e1e7f1;border-radius:12px;padding:12px;text-align:center}.c b{display:block;font-size:26px;color:#0b57b8}table{width:100%;border-collapse:collapse}td,th{padding:8px;border-bottom:1px solid #e1e7f1;text-align:right;font-size:13px}th{background:#f4f7fb}.b{background:#e1e7f1;border-radius:6px;height:8px;width:120px}.b i{display:block;height:8px;border-radius:6px;background:#2e9e57}.p{background:#eef4ff;border-radius:20px;padding:4px 10px;margin:3px;display:inline-block;font-size:13px}@media print{body{padding:10px}}</style><body><div class="hd"><h1>📊 تقرير الأداء الدراسي</h1><div>${esc(m.name)} • ${new Date().toLocaleDateString('ar-EG')} • المستوى ${Math.floor(xp(m.id)/100)+1} (${xp(m.id)} XP)</div></div><div class="g"><div class="c"><b>${n}</b>امتحان</div><div class="c"><b>${avg}%</b>المتوسط</div><div class="c"><b>${best}%</b>أعلى درجة</div><div class="c"><b>${pass}%</b>نسبة النجاح</div></div><p><b>${txt}</b> ${w?`لديك ${w} سؤال خاطئ للمراجعة.`:''}</p>${n>1?`<svg viewBox="0 0 600 150" style="width:100%;height:150px;background:#f8fafd;border-radius:12px"><polyline fill="none" stroke="#0b57b8" stroke-width="3" points="${pts}"/></svg>`:''}<h3>سجل الدرجات</h3><table><tr><th>الامتحان</th><th>المجموعة</th><th>التاريخ</th><th></th><th>الدرجة</th></tr>${rows}</table><h3>🏅 الشارات (${bd.length})</h3>${bd.map(b=>`<span class="p">${b[1]} ${b[2]}</span>`).join('')||'—'}<script>setTimeout(()=>print(),500)<\/script>
<!-- SmartTeacher v2.0: role-aware reports, read-only admin console, CSV export, parent-link sync, responsive design and accessibility. -->
</body></html>`;
const w2=open('','_blank');if(w2){w2.document.write(h);w2.document.close()}else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([h],{type:'text/html'}));a.download='تقرير-الأداء.html';a.click()}};

/* ===== FEATURE 4: الوضع الليلي/النهاري (محفوظ في localStorage) ===== */
const TK='stx_theme';try{const t=localStorage.getItem(TK);if(t==='dark')S.dark=true;else if(t==='light')S.dark=false}catch(e){}
window.thT=()=>{const dk=document.documentElement.dataset.theme==='dark';document.documentElement.classList.add('tt');S.dark=!dk;try{localStorage.setItem(TK,dk?'light':'dark')}catch(e){}save();R();setTimeout(()=>document.documentElement.classList.remove('tt'),450)};
try{matchMedia('(prefers-color-scheme:dark)').addEventListener('change',()=>{if(!localStorage.getItem(TK)){delete S.dark;R()}})}catch(e){}
const _R=R;R=function(){_R();const b=[...document.querySelectorAll('#hx button')].find(x=>/^[☀🌙]/.test(x.textContent.trim()));if(b){b.onclick=window.thT;b.title='تبديل الوضع الليلي/النهاري';b.setAttribute('aria-label','تبديل الثيم')}let mt=document.querySelector('meta[name=theme-color]');if(!mt){mt=document.createElement('meta');mt.name='theme-color';document.head.appendChild(mt)}mt.content=document.documentElement.dataset.theme==='dark'?'#0c1a30':'#0a2a57'};

/* ===== FEATURE 5: التنبيهات الذكية والمواعيد ===== */
function remind(){if(!S.me||isT())return;const first=ld('rm',null)===null,done=ld('rm',{}),now=Date.now();let ch=0;
const add=(k,t,q)=>{if(done[k])return;done[k]=now;ch=1;if(q)return;notify(S.me,t,k);if(window.Notification&&Notification.permission==='granted')try{new Notification('المعلم الذكي',{body:t})}catch(x){}};
myG().forEach(g=>S.e.filter(e=>e.g===g.id&&e.pub&&!S.s.some(s=>s.e===e.id&&s.u===S.me)).forEach(e=>{const st=e.start&&new Date(e.start),en=e.end&&new Date(e.end);if(en&&en<now)return;
if(!st||st<=now)add('n'+e.id,'📝 امتحان جديد: '+e.name,first);
if(en&&en-now<864e5)add('d'+e.id,'⏰ ينتهي موعد «'+e.name+'» خلال 24 ساعة');
if(st&&st>now&&st-now<864e5)add('s'+e.id,'📅 يبدأ «'+e.name+'» خلال 24 ساعة')}));if(ch)sv('rm',done)}
const upcoming=()=>{const now=Date.now(),o=[];myG().forEach(g=>S.e.filter(e=>e.g===g.id&&e.pub&&!S.s.some(s=>s.e===e.id&&s.u===S.me)).forEach(e=>{const st=e.start&&new Date(e.start),en=e.end&&new Date(e.end);if(st&&st>now)o.push({e,t:'يبدأ',d:+st});else if(en&&en>now)o.push({e,t:'ينتهي',d:+en});else if(!en)o.push({e,t:'متاح الآن',d:0})}));return o.sort((a,b)=>(a.d||9e15)-(b.d||9e15)).slice(0,4)};
window.ntf=()=>{if(window.enablePush)enablePush();else Notification.requestPermission().then(()=>R())};
const _dash=dash;dash=function(){const h=_dash();if(isT()||!me())return h;const wk=mine(S.me).filter(s=>Date.now()-s.d<6048e5).length,e=earned(S.me),up=upcoming(),
w=`<div class="card"><div class="row"><h3>🎯 لوحتي</h3><span><button class="b s" onclick="rpt()">📄 تقرير PDF</button></span></div><small class="mut">الهدف الأسبوعي: ${Math.min(wk,3)} / 3 امتحانات</small><div class="bar"><i style="width:${Math.min(100,wk/3*100)}%"></i></div><p style="margin:10px 0 4px"><a href="#" onclick="go('rec',undefined,'bd');return false">🏅 شاراتي (${e.length}/${BD.length})</a> ${e.slice(0,8).map(b=>`<span title="${b[2]}" style="font-size:22px">${b[1]}</span>`).join(' ')||'<span class="mut">سلّم أول امتحان لتحصل على شارتك الأولى</span>'}</p>${up.length?`<h3 style="margin-top:12px">⏰ مواعيد قادمة</h3>${up.map(x=>`<div class="row"><span>${esc(x.e.name)}</span><span class="pill">${x.t}${x.d?' '+fmt(x.d):''}</span></div>`).join('')}`:''}${window.Notification&&Notification.permission==='default'?`<button class="b s" style="margin-top:10px" onclick="ntf()">🔔 فعّل إشعارات المتصفح</button>`:''}</div>`,i=h.indexOf('<div class="card"><h3>🔗 انضم لمجموعة</h3>');return i<0?h+w:h.slice(0,i)+w+h.slice(i)};

bdCheck();remind();setInterval(remind,3e4);R();
})();
