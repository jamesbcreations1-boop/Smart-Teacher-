/* ▓▓ 21-layer-extras-v12.js — إضافات v12
   بيتحمّل بعد: 20-layer-reports-tools.js  |  وبعده: 22-layer-community.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [02] إضافات v12
   ========================================================================== */
/* ===== SmartTeacher v12 — مميزات إضافية (كل قسم مستقل) ===== */
(()=>{
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem('stx_'+k+'_'+S.me))??d}catch(e){return d}},sv=(k,v)=>{try{localStorage.setItem('stx_'+k+'_'+S.me,JSON.stringify(v))}catch(e){}};
const win=h=>{const w=open('','_blank');if(w){w.document.write(h);w.document.close()}else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([h],{type:'text/html'}));a.download='report.html';a.click()}};
const CSS='<style>body{font-family:Cairo,Tahoma,sans-serif;padding:26px;color:#0f1b33}.hd{background:linear-gradient(135deg,#0a2a57,#0b57b8);color:#fff;border-radius:16px;padding:20px;margin-bottom:16px}table{width:100%;border-collapse:collapse;margin-bottom:18px}td,th{padding:8px;border-bottom:1px solid #e1e7f1;text-align:right;font-size:13px}th{background:#f4f7fb}</style>';

/* ===== 1) استكمال الامتحان بعد التحديث + حماية الخروج ===== */
setInterval(()=>{try{if(CUR&&S.me)localStorage.setItem('stx_cur_'+S.me,JSON.stringify(CUR))}catch(e){}},2000);
addEventListener('beforeunload',e=>{if(CUR&&V.p==='exam'){e.preventDefault();e.returnValue=''}});
const _s=submit;submit=function(a){const id=S.me;_s(a);try{localStorage.removeItem('stx_cur_'+id)}catch(e){}};
let expired=0;try{const c=JSON.parse(localStorage.getItem('stx_cur_'+S.me)||'null');if(c)if(S.me&&!isT()&&E(c.e)&&!S.s.some(s=>s.e===c.e&&s.u===S.me)){CUR=c;V={p:'exam',a:c.e};expired=c.end&&c.end<=Date.now()}else localStorage.removeItem('stx_cur_'+S.me)}catch(e){}

/* ===== 2) سلسلة الأيام + الترتيب ===== */
function streak(){const t=new Date().toDateString(),y=new Date(Date.now()-864e5).toDateString(),d=ld('stk',{n:0,l:''});if(d.l!==t){d.n=d.l===y?d.n+1:1;d.l=t;sv('stk',d)}return d.n}
function rank(){const ids=new Set();myG().forEach(g=>g.st.forEach(x=>{if(x.s==='ok')ids.add(x.u)}));const a=[...ids].map(u=>[u,xp(u)]).sort((a,b)=>b[1]-a[1]),i=a.findIndex(x=>x[0]===S.me);return i<0?null:[i+1,a.length]}

/* ===== 6) لوحات الرئيسية ===== */
const _d=dash;dash=function(){const h=_d();if(!me())return h;
if(isT())return h;
const r=rank(),w=`<div class="grid" style="grid-template-columns:repeat(2,1fr)"><div class="card stc"><div class="big">🔥 ${streak()}</div><span class="mut">أيام متتالية</span></div><div class="card stc"><div class="big">${r?'#'+r[0]:'—'}</div><span class="mut">ترتيبك${r?' من '+r[1]:''}</span></div></div>`,i=h.indexOf('<div class="card"><h3>🔗 انضم لمجموعة</h3>');return i<0?h+w:h.slice(0,i)+w+h.slice(i)};

/* ===== 7) جولة تعريفية للمستخدم الجديد ===== */
function tour(){if(!S.me||ld('tour',0))return;const st=me().role==='parent'?[['👋','أهلاً بك يا ولي الأمر','تابع درجات أبنائك أولاً بأول'],['📊','تنبيهات وتقارير','يصلك تنبيه عند كل امتحان وتقرير PDF'],['🌐','المجتمع','يمكنك القراءة والمتابعة فقط']]:me().role==='assistant'?[['🧑‍🏫','أهلاً بك يا مساعد','شارك كودك مع المدرس ليضيفك لمجموعته'],['🛡️','أشرف على المجموعة','راقب الشات وأرسل الإعلانات واقبل طلبات الانضمام'],['🌐','صفحتك في المجتمع','حسابك موثّق بعلامة ✔ خضراء']]:isT()?[['👋','أهلاً بك يا مدرس','أنشئ مجموعة وشارك كودها مع طلابك'],['📝','أنشئ امتحاناً','ولّده بالذكاء الاصطناعي من ملف أو نص ثم انشره'],['📢','تواصل مع طلابك','تابع النتائج وصدّرها من صفحة كل امتحان']]:[['👋','أهلاً بك!','انضم لمجموعة مدرسك بالكود من الصفحة الرئيسية'],['🏅','اجمع الشارات','سلّم امتحاناتك واكسب XP وشارات'],['🎯','راجع أخطاءك','احفظ الأسئلة بـ ⭐ وتدرّب عليها من "سجلي"']];let i=0;const o=document.createElement('div');o.className='tour';document.body.appendChild(o);
const end=()=>{o.remove();sv('tour',1)},d=()=>{const[x,t,p]=st[i];o.innerHTML=`<div class="card"><div class="big">${x}</div><h2>${t}</h2><p class="mut">${p}</p><div>${st.map((_,j)=>`<i class="dot ${j===i?'on':''}"></i>`).join('')}</div><button class="b" id="tn">${i<st.length-1?'التالي':'ابدأ'}</button><button class="b s" id="ts">تخطي</button></div>`;$('#tn').onclick=()=>{++i<st.length?d():end()};$('#ts').onclick=end};d()}

/* ===== 8) حجم الخط + إظهار كلمة المرور + زر للأعلى + Enter ===== */
localStorage.removeItem('stx_fs');document.documentElement.style.fontSize='';
const _R=R;R=function(){_R();document.querySelectorAll('input[type=password]').forEach(i=>{if(i.parentNode.className==='pw')return;const w=document.createElement('span'),b=document.createElement('button');w.className='pw';b.type='button';b.className='eye';b.textContent='👁';b.onclick=()=>{i.type=i.type==='password'?'text':'password'};i.before(w);w.append(i,b)})};
const up=document.createElement('button');up.className='fab';up.textContent='↑';up.onclick=()=>scrollTo({top:0,behavior:'smooth'});document.body.appendChild(up);addEventListener('scroll',()=>up.classList.toggle('on',scrollY>500),{passive:true});
document.addEventListener('keydown',e=>{if(e.key!=='Enter'||me())return;const i=e.target.id;if(i==='op'||i==='np2')verify();else if(i==='fe')forgot();else if(i==='pc')parentNext();else if(V.a==='reg'&&i==='cp')signup();else if(i==='pw'&&V.a!=='reg')login()});

/* ===== إصلاح صفحة الذكاء الاصطناعي (مهلة + عدم التعليق) ===== */
const _f=window.fetch.bind(window);window.fetch=(u,o={})=>{const url=String(u&&u.url||u);if(/groq\.com|pollinations\.ai/.test(url)&&!o.signal){const c=new AbortController();setTimeout(()=>c.abort(),url.includes('/models')?8000:20000);o={...o,signal:c.signal}}return _f(u,o)};
const _ai=ai;ai=async function(p,f,jn){let t;const r=await Promise.race([_ai(p,f,jn),new Promise(res=>{t=setTimeout(()=>{ERM='انتهت المهلة، تحقق من الإنترنت وحاول مرة أخرى';res(null)},30000)})]);clearTimeout(t);return r};
const hd=$('header');if(hd&&window.ResizeObserver)new ResizeObserver(()=>document.documentElement.style.setProperty('--hh',hd.offsetHeight+'px')).observe(hd);

R();tour();if(expired)submit(1);
})();
