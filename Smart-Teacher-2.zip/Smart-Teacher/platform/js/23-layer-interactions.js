/* ▓▓ 23-layer-interactions.js — v15: لمسات تفاعلية
   بيتحمّل بعد: 22-layer-community.js  |  وبعده: 24-layer-verification-parents.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [04] v15: لمسات تفاعلية
   ========================================================================== */
/* ===== v15: لمسات تفاعلية (ripple + اهتزاز خفيف) ===== */
document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('.b,.qa button,.acts button,.tabs button');if(!b)return;const r=b.getBoundingClientRect();b.style.setProperty('--rx',e.clientX-r.left+'px');b.style.setProperty('--ry',e.clientY-r.top+'px');b.classList.remove('rip');void b.offsetWidth;b.classList.add('rip');try{navigator.vibrate&&navigator.vibrate(8)}catch(x){}},{passive:true});
