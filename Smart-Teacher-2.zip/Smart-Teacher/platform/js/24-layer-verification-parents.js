/* ▓▓ 24-layer-verification-parents.js — v17: التحقق وأولياء الأمور
   بيتحمّل بعد: 23-layer-interactions.js  |  وبعده: 25-layer-error-safety-net.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [05] v17: التحقق وأولياء الأمور
   ========================================================================== */
/* ===== SmartTeacher v17 — التحقق بجوجل + أولياء الأمور + تفاصيل إضافية ===== */
(()=>{
if(!COLS.includes('pl'))COLS.push('pl');if(!S.pl)S.pl=[];
const isP=()=>{const m=me();return !!m&&m.role==='parent'},now=()=>Date.now(),sc=s=>score(E(s.e),s),avgOf=v=>v.length?Math.round(v.reduce((a,b)=>a+b,0)/v.length):0;
const SV='<svg class="vb" viewBox="0 0 24 24"><title>ولي أمر موثّق</title><defs><linearGradient id="sg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f6fa"/><stop offset="1" stop-color="#9aa5b6"/></linearGradient></defs><circle cx="12" cy="12" r="11" fill="url(#sg)"/><path d="M7 12.5l3.2 3.2L17 9" stroke="#3b4658" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const greet=()=>{const h=new Date().getHours();return h>=5&&h<12?'صباح الخير':h>=18||h<5?'مساء الخير':'أهلاً'};
const pav=(u,z=40)=>`<span class="avt ${u&&u.role==='parent'?'pv':''}" style="width:${z}px;height:${z}px;font-size:${z/2.2}px;cursor:default">${u&&/^(data:image\/|https:\/\/[a-z0-9.-]*googleusercontent\.com\/)/.test(u.av||'')?`<img src="${u.av}" alt="">`:esc((u?u.name:'؟').trim().charAt(0))}</span>`;
const win=h=>{const w=open('','_blank');if(w){w.document.write(h);w.document.close()}else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([h],{type:'text/html'}));a.download='report.html';a.click()}};

window.afterSignup=()=>linkSync();

/* ===== 2) ربط ولي الأمر (تلقائي بالرقم + كود الطالب) ===== */
const kids=pid=>S.pl.filter(x=>x.p===pid&&!x.x).map(x=>U(x.s)).filter(Boolean),pars=sid=>S.pl.filter(x=>x.s===sid&&!x.x).map(x=>U(x.p)).filter(Boolean);
function linkSync(){let ch=0;const P=S.u.filter(u=>u.role==='parent'&&u.ok),St=S.u.filter(u=>u.role==='student'&&u.pp);P.forEach(p=>St.forEach(s=>{if(wn(s.pp)&&wn(s.pp)===wn(p.phone)){const id=p.id+'_'+s.id;if(!S.pl.some(x=>x.id===id)){S.pl.push({id,p:p.id,s:s.id,d:now(),a:'auto',x:0});ch=1;notify(s.id,'👨‍👩‍👧 تم ربط ولي أمرك '+p.name+' بحسابك','pl'+p.id);notify(p.id,'✅ تم ربطك بحساب '+s.name,'pl'+s.id)}}}));if(ch){save();R()}}
const _p=pull;pull=async function(){await _p.apply(this,arguments);linkSync()};
const rc=()=>newPc();
const code=()=>{const m=me();if(!m.pc){m.pc=rc();save()}return m.pc};
window.pcNew=()=>{me().pc=rc();save();R();toast('تم تغيير الكود')};
window.pcCopy=()=>{try{navigator.clipboard.writeText(code())}catch(e){}toast('تم نسخ الكود')};
window.plOff=pid=>{const l=S.pl.find(x=>x.p===pid&&x.s===S.me);if(l){l.x=1;save();R();toast('تم فصل ولي الأمر')}};
window.plCode=()=>{const c=($('#plc').value||'').trim(),s=S.u.find(x=>x.role==='student'&&x.pc&&x.pc===c);if(!s)return toast('الكود غير صحيح');const id=S.me+'_'+s.id,l=S.pl.find(x=>x.id===id);if(l){if(!l.x)return toast('هذا الابن مرتبط بالفعل');l.x=0}else S.pl.push({id,p:S.me,s:s.id,d:now(),a:'code',x:0});notify(s.id,'👨‍👩‍👧 ولي الأمر '+me().name+' ربط حسابه بحسابك','pl'+S.me);save();R();toast('تم الربط مع '+s.name+' ✅')};

/* ===== 3) لوحة ولي الأمر (الدرجات فقط) ===== */
let PK=null;window.pkSel=id=>{PK=id;R()};
function childData(s){const gs=S.g.filter(g=>g.st.some(x=>x.u===s.id&&x.s==='ok')),es=S.e.filter(e=>e.pub&&gs.some(g=>g.id===e.g)),ss=S.s.filter(x=>x.u===s.id&&E(x.e)).sort((a,b)=>a.d-b.d),v=ss.map(sc),done=new Set(ss.map(x=>x.e)),t=now();return{gs,es,ss,v,avg:avgOf(v),best:Math.max(0,...v),missed:es.filter(e=>!done.has(e.id)&&e.end&&new Date(e.end)<t),last:ss.length?ss[ss.length-1].d:0}}
const ago2=t=>{if(!t)return 'لا يوجد';const m=(now()-t)/6e4;return m<60?'منذ '+Math.max(1,Math.floor(m))+' د':m<1440?'منذ '+Math.floor(m/60)+' س':'منذ '+Math.floor(m/1440)+' يوم'};
const spark=v=>v.length<2?'':`<svg class="spark" viewBox="0 0 300 70" preserveAspectRatio="none"><polyline fill="none" stroke="var(--pri)" stroke-width="3" stroke-linejoin="round" points="${v.map((x,i)=>`${10+i*(280/(v.length-1))},${62-x*.54}`).join(' ')}"/></svg>`;
const subj=(d)=>d.gs.map(g=>{const t=U(g.t),vv=d.ss.filter(x=>E(x.e).g===g.id).map(sc);return{n:(t&&t.sj)||g.title,a:vv.length?avgOf(vv):null,t}});
function kidCard(k,d){const sj=subj(d),al=[...d.missed.map(e=>`⏰ لم يسلّم «${esc(e.name)}» وانتهى موعده`),...d.ss.filter(x=>sc(x)<50).slice(-3).map(x=>`⚠️ درجة منخفضة في «${esc(E(x.e).name)}» (${sc(x)}%)`)];
return `<div class="card"><div class="row" style="justify-content:flex-start;gap:12px">${pav(k,56)}<div><h3 style="margin:0">${esc(k.name)}</h3><small class="mut">${d.gs.map(g=>esc(g.title)).join(' • ')||'غير منضم لمجموعة بعد'}</small></div></div></div>
<div class="grid" style="grid-template-columns:repeat(2,1fr)"><div class="card stc"><div class="big">${d.ss.length}/${d.es.length}</div><span class="mut">امتحانات مسلّمة</span></div><div class="card stc"><div class="big">${d.ss.length?d.avg+'%':'—'}</div><span class="mut">المتوسط</span></div><div class="card stc"><div class="big">${d.ss.length?d.best+'%':'—'}</div><span class="mut">أعلى درجة</span></div><div class="card stc"><div class="big" style="font-size:17px">${ago2(d.last)}</div><span class="mut">آخر امتحان</span></div></div>
${al.length?`<div class="card"><h3>🔔 تنبيهات</h3>${al.map(a=>`<p style="margin:6px 0">${a}</p>`).join('')}</div>`:''}
${d.v.length>1?`<div class="card"><h3>📈 تطور الدرجات</h3>${spark(d.v)}</div>`:''}
${sj.length?`<div class="card"><h3>📚 حسب المادة</h3>${sj.map(x=>`<div class="row"><span>${esc(x.n)}</span><b>${x.a===null?'—':x.a+'%'}</b></div><div class="bar"><i style="width:${x.a||0}%"></i></div>`).join('')}</div>`:''}
<div class="card"><h3>📜 الدرجات</h3>${d.ss.slice().reverse().map(s=>{const e=E(s.e),p=sc(s),g=G(e.g);return `<div class="gr"><div><b>${esc(e.name)}</b><br><small class="mut">${esc(g?g.title:'')} • ${new Date(s.d).toLocaleDateString('ar-EG')}</small></div><div class="gs ${p>=85?'a':p>=50?'b':'c'}">${p}%</div></div>`}).join('')||'<p class="mut">لا توجد درجات بعد</p>'}</div>
<div class="card"><h3>📞 تواصل مع المدرسين</h3>${sj.filter(x=>x.t).map(x=>`<a class="b s" style="margin:4px" target="_blank" rel="noopener" href="https://wa.me/${wn(x.t.phone)}">💬 ${esc(x.t.name)}</a>`).join('')||'<p class="mut">—</p>'}</div>
<button class="b" style="width:100%;margin-top:6px" onclick="prpt('${k.id}')">📄 تقرير أداء ${esc(k.name.split(' ')[0])} (PDF)</button>`}
function parentDash(){const m=me(),ks=kids(m.id),hero=`<div class="banner"><h2>${greet()} ${esc(m.name)} ${SV}</h2><span class="pill">ولي أمر موثّق</span><p>تابع مستوى أبنائك أولاً بأول</p></div>`,
link=`<div class="card"><h3>🔗 ربط ابن/ابنة بالكود</h3><p class="mut">اكتب الكود الظاهر في إعدادات حساب الطالب:</p><div class="row"><input id="plc" placeholder="كود الطالب (6 أرقام)" inputmode="numeric" maxlength="6"><button class="b" onclick="plCode()">ربط</button></div></div>`;
if(!ks.length)return hero+`<div class="card" style="text-align:center"><div class="big">👨‍👩‍👧</div><h3>لم يُربط أي حساب بعد</h3><p class="mut">اربط حسابك بكود ولي الأمر من ابنك (حسابي ← ولي الأمر).</p></div>`+link;
const k=ks.find(x=>x.id===PK)||ks[0];return hero+(ks.length>1?`<div class="tabs">${ks.map(x=>`<button class="${x.id===k.id?'on':''}" onclick="pkSel('${x.id}')">${esc(x.name.split(' ')[0])}</button>`).join('')}</div>`:'')+kidCard(k,childData(k))+link}
window.prpt=id=>{const k=U(id);if(!k)return;const d=childData(k),sj=subj(d);win(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>تقرير ${esc(k.name)}</title><style>body{font-family:Cairo,Tahoma,sans-serif;padding:26px;color:#0f1b33}.hd{background:linear-gradient(135deg,#0b2a66,#2563eb);color:#fff;border-radius:16px;padding:20px;margin-bottom:16px}table{width:100%;border-collapse:collapse;margin-bottom:16px}td,th{padding:8px;border-bottom:1px solid #e1e8f3;text-align:right;font-size:13px}th{background:#f1f5fb}.g{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}.c{border:1px solid #e1e8f3;border-radius:12px;padding:12px;text-align:center}.c b{display:block;font-size:24px;color:#2563eb}</style><body><div class="hd"><h1>📊 تقرير أداء الطالب</h1>${esc(k.name)} • ${new Date().toLocaleDateString('ar-EG')}</div><div class="g"><div class="c"><b>${d.ss.length}/${d.es.length}</b>امتحانات مسلّمة</div><div class="c"><b>${d.ss.length?d.avg+'%':'—'}</b>المتوسط</div><div class="c"><b>${d.ss.length?d.best+'%':'—'}</b>أعلى درجة</div></div><h3>حسب المادة</h3><table>${sj.map(x=>`<tr><td>${esc(x.n)}</td><td>${x.a===null?'—':x.a+'%'}</td></tr>`).join('')}</table><h3>الدرجات</h3><table><tr><th>الامتحان</th><th>التاريخ</th><th>الدرجة</th></tr>${d.ss.slice().reverse().map(s=>`<tr><td>${esc(E(s.e).name)}</td><td>${new Date(s.d).toLocaleDateString('ar-EG')}</td><td><b>${sc(s)}%</b></td></tr>`).join('')}</table>${d.missed.length?`<p>⏰ امتحانات فائتة: ${d.missed.map(e=>esc(e.name)).join('، ')}</p>`:''}<script>setTimeout(()=>print(),500)<\/script>
<!-- SmartTeacher v2.0: role-aware reports, read-only admin console, CSV export, parent-link sync, responsive design and accessibility. -->
</body></html>`)};
function pNav(){const bn=$('#bn');if(!bn)return;const it=[['dash','🏠','الرئيسية',['dash']],['soc','🌐','المجتمع',['soc','prof']],['set','⚙️','الإعدادات',['set','notes']]];bn.innerHTML=it.map(x=>`<button class="${x[3].includes(V.p)?'on':''}" onclick="go('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('')}
const _R=R;R=function(){if(isP()&&!['dash','soc','prof','set','notes'].includes(V.p))V={p:'dash'};_R();if(isP())pNav()};
/* إشعارات ولي الأمر */
const _s=submit;submit=function(a){const id=S.me;_s(a);setTimeout(()=>{const u=U(id);if(!u||u.role!=='student')return;const s=S.s.filter(x=>x.u===id&&E(x.e)).sort((a,b)=>b.d-a.d)[0];if(!s||s.d<now()-2e4)return;const p=sc(s);pars(id).forEach(par=>notify(par.id,(p<50?'⚠️ ':'📊 ')+u.name+' سلّم «'+E(s.e).name+'» ودرجته '+p+'%','sb'+s.id))},700)};
function pRemind(){if(!isP())return;let d={};try{d=JSON.parse(localStorage.getItem('stx_pr_'+S.me)||'{}')}catch(e){}let ch=0;kids(S.me).forEach(k=>childData(k).missed.forEach(e=>{if(new Date(e.end)<now()-7*864e5)return;const key='m'+k.id+e.id;if(!d[key]){d[key]=1;ch=1;notify(S.me,'⏰ '+k.name+' لم يسلّم «'+e.name+'» وانتهى موعده',key)}}));if(ch)localStorage.setItem('stx_pr_'+S.me,JSON.stringify(d))}

/* ===== 4) تفاصيل إضافية في الموقع ===== */
let DP=null;addEventListener('beforeinstallprompt',e=>{e.preventDefault();DP=e});
window.inst=()=>{if(DP){DP.prompt();DP=null}else toast('على الآيفون: زر المشاركة ← إضافة إلى الشاشة الرئيسية')};
window.shr=()=>{const u=location.href.split('?')[0];if(navigator.share)navigator.share({title:'المعلم الذكي',text:'منصة تعليمية بالذكاء الاصطناعي',url:u}).catch(()=>{});else{try{navigator.clipboard.writeText(u)}catch(e){}toast('تم نسخ رابط المنصة')}};
window.delAcc=async ()=>{const m=me();if(m.role==='teacher')return toast('لحذف حساب المدرس تواصل مع الدعم');if(!await ask('سيتم حذف حسابك وكل بياناتك نهائياً. متأكد؟'))return;const id=m.id,pid=new Set(S.f.filter(x=>x.u===id).map(x=>x.id));S.u=S.u.filter(x=>x.id!==id);S.f=S.f.filter(x=>x.u!==id);S.fc=S.fc.filter(x=>x.u!==id&&!pid.has(x.p));S.fl=S.fl.filter(x=>x.u!==id&&!pid.has(x.p));S.ff=S.ff.filter(x=>x.a!==id&&x.b!==id);S.pl=S.pl.filter(x=>x.p!==id&&x.s!==id);S.s=S.s.filter(x=>x.u!==id);S.n=S.n.filter(x=>x.to!==id);S.g.forEach(g=>{g.st=g.st.filter(x=>x.u!==id)});S.me=null;save();V={p:'dash'};R();toast('تم حذف الحساب')};
const _set=set;set=function(){let h=_set(),m=me(),ex='';h=h.replace('الإصدار 10','الإصدار 28');
if(m.role==='student'){ex+=`<div class="card"><h3>👨‍👩‍👧 ولي الأمر</h3><p class="mut">أعطِ هذا الكود لولي أمرك ليسجّل به حسابه ويتابع درجاتك:</p><div class="pcode">${code()}</div><div class="row"><button class="b s" onclick="pcCopy()">📋 نسخ</button><button class="b s" onclick="pcNew()">🔄 كود جديد</button></div>${pars(m.id).map(p=>`<div class="row" style="margin-top:10px"><span>${pav(p,30)} <b>${esc(p.name)}</b>${SV}</span><button class="b s" onclick="plOff('${p.id}')">فصل</button></div>`).join('')}</div>`}
ex+=`<div class="card"><button class="b s" style="width:100%;margin:4px 0" onclick="shr()">📤 شارك المنصة مع أصدقائك</button><button class="b s" style="width:100%;margin:4px 0" onclick="inst()">📲 ثبّت المنصة على موبايلك</button></div>`;
const mk='<p class="mut" style="text-align:center">';return h.includes(mk)?h.replace(mk,ex+mk):h+ex};
const _x=exam;exam=function(){const h=_x();if(typeof h==='string'&&V.t==='res'&&me()&&me().role==='student'){const e=E(V.a),all=S.s.filter(x=>x.e===e.id),mn=all.find(x=>x.u===S.me);if(mn&&all.length>1){const a=all.map(x=>score(e,x)),my=score(e,mn),c=`<div class="card row"><span>📊 متوسط الزملاء <b>${avgOf(a)}%</b></span><span>🏅 ترتيبك <b>${a.filter(x=>x>my).length+1}</b> من ${all.length}</span></div>`,i=h.indexOf('<div class="card"><b>');return i<0?h+c:h.slice(0,i)+c+h.slice(i)}}return h};
const _d=dash;dash=function(){if(isP())return parentDash();let h=_d();const m=me();if(!m||typeof h!=='string')return h;const g=greet();if(g!=='أهلاً')h=h.replace('أهلاً',g);
if(m.role==='student'){const ps=pars(m.id),a='<div class="card"><h3>🔗 انضم لمجموعة</h3>',i=h.indexOf(a),c=`<div class="card row"><span>👨‍👩‍👧 ولي الأمر: ${ps.length?ps.map(p=>`<b>${esc(p.name)}</b>${SV}`).join('، ')+' <span class="pill">مرتبط</span>':'<span class="mut">لم يرتبط بعد</span>'}</span><button class="b s" onclick="go('set')">الكود</button></div>`;h=i<0?h+c:h.slice(0,i)+c+h.slice(i)}return h};
linkSync();pRemind();setInterval(()=>{linkSync();pRemind()},6e4);R();
})();
