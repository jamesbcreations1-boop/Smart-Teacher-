/* ▓▓ 25-layer-error-safety-net.js — v19: شبكة أمان الأخطاء
   بيتحمّل بعد: 24-layer-verification-parents.js  |  وبعده: 26-layer-v20.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [06] v19: شبكة أمان الأخطاء
   ========================================================================== */
/* v19: شبكة أمان — أي خطأ غير متوقع يظهر كرسالة بدل ما يتجمّد التطبيق بصمت */
(()=>{let last=0;const warn=()=>{if(Date.now()-last<5e3)return;last=Date.now();try{toast('حصل خطأ غير متوقع — حدّث الصفحة لو استمر')}catch(e){}};
addEventListener('error',e=>{if(e&&e.message&&!/ResizeObserver|Script error/.test(e.message))warn()});
addEventListener('unhandledrejection',e=>{if(e&&e.reason)warn()});})();
