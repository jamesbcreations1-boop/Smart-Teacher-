/* ▓▓ 26-layer-v20.js — v20: إضافات متفرقة
   بيتحمّل بعد: 25-layer-error-safety-net.js  |  وبعده: 27-layer-exam-protection.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [07] v20
   ========================================================================== */
/* ===== v20 إضافات (لا تلمس CFG أو المفاتيح) ===== */
function aiDelCur(){const o=AIS(),c=o.c.find(x=>x.id===o.cur);if(!c)return toast('افتح محادثة أولاً لحذفها');aiDel(c.id)}
async function aiClearAll(){const o=AIS();if(!o.c.length)return toast('لا توجد محادثات');if(!await ask('حذف كل المحادثات ('+o.c.length+')؟'))return;o.c=[];o.cur=null;AIO=0;cache();R();toast('تم حذف كل المحادثات')}
function aiExport(){const o=AIS(),c=o.c.find(x=>x.id===o.cur);if(!c||!c.ms.length)return toast('لا توجد محادثة للتصدير');const t=c.ms.map(x=>(x.r==='u'?'أنا: ':'SHANANOO AI: ')+x.t).join('\n\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+t],{type:'text/plain'}));a.download=(c.t||'chat')+'.txt';a.click()}
const grow=t=>{t.style.height='auto';t.style.height=Math.min(t.scrollHeight,120)+'px'};
document.addEventListener('input',e=>{if(e.target.id==='aiq')grow(e.target)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&typeof AIO!=='undefined'&&AIO){AIO=0;R()}});
(function(){const nb=document.createElement('div');nb.className='net';nb.textContent='📡 لا يوجد اتصال — التغييرات هتتحفظ وتتزامن لما يرجع النت';document.body.appendChild(nb);const u=()=>nb.classList.toggle('on',!navigator.onLine);addEventListener('online',()=>{u();try{pull();push()}catch(e){}});addEventListener('offline',u);u();
const _R=R;R=function(){_R.apply(this,arguments);try{const n=S.me?S.n.filter(x=>x.to===S.me&&!x.r).length:0;document.title=(n?'('+n+') ':'')+(window.__nm?window.__nm():'Smart Teacher — المعلم الذكي');const t=$('#aiq');if(t)grow(t)}catch(e){}}})();
