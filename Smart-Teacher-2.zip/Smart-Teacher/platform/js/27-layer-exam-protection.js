/* ▓▓ 27-layer-exam-protection.js — v21: حماية الامتحان
   بيتحمّل بعد: 26-layer-v20.js  |  وبعده: 28-layer-builtin-features.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [08] v21: حماية الامتحان
   ========================================================================== */
/* ===== v21: حماية الامتحان + ميزات (لا تلمس CFG أو المفاتيح) ===== */
const X20K='stexam',x20_live=()=>!!(CUR&&CUR.end&&S.me&&V.p==='exam'&&V.t!=='res');
function x20_save(){try{if(x20_live())localStorage.setItem(X20K,JSON.stringify({e:CUR.e,u:S.me,a:CUR.a,vc:CUR.vc||0}));else localStorage.removeItem(X20K)}catch(e){}}
['input','change'].forEach(v=>document.addEventListener(v,()=>{if(x20_live())x20_save()}));
function x20_ov(){let o=document.getElementById('x20vw');if(!o){o=document.createElement('div');o.id='x20vw';document.body.appendChild(o)}return o}
function x20_clear(){if(CUR&&CUR.wt){clearInterval(CUR.wt);CUR.wt=0}const o=document.getElementById('x20vw');if(o)o.classList.remove('on')}
function x20_leave(why){if(!x20_live())return;CUR.vr=why;submit(1)}
const _x20sub=submit;submit=function(auto){if(!CUR)return;const vc=CUR.vc||0,why=CUR.vr||'',e=E(CUR.e),n0=S.s.length;x20_clear();_x20sub(auto);try{localStorage.removeItem(X20K);if(document.fullscreenElement)document.exitFullscreen()}catch(er){}
if(S.s.length>n0&&(vc||why)){const s=S.s[S.s.length-1],t=G(e.g)?.t,nt=S.n[0];s.vc=vc;s.vr=why;if(nt&&nt.to===t)nt.txt+=' ⚠️ '+(vc?'مخالفات '+vc+' — ':'')+why;save()}};
const x20_ok=()=>document.hasFocus()&&!document.hidden&&innerWidth>=(CUR.w0||0)*.8&&(!CUR.fs||!!document.fullscreenElement);
async function x20_warn(why){if(!x20_live()||CUR.busy||CUR.wt)return;CUR.vc=(CUR.vc||0)+1;CUR.vr=why;x20_save();if(CUR.vc>=3)return x20_leave('3 مخالفات: '+why);let n=10;const o=x20_ov(),draw=()=>{o.innerHTML=`<div class="card"><div style="font-size:48px">⚠️</div><h2>تحذير ${CUR.vc}/3</h2><p>${why}.<br>اقفل الشاشة التانية وارجع للامتحان خلال <b>${n}</b> ثواني وإلا هيتسلّم الامتحان تلقائياً.</p></div>`};draw();o.classList.add('on');alarm();try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){}
CUR.wt=setInterval(()=>{if(!x20_live()){x20_clear();return}if(x20_ok()){x20_clear();toast('✅ رجعت للامتحان — المخالفات: '+CUR.vc+'/3');return}if(--n<=0)x20_leave(why+' ولم يُغلقها');else draw()},1000)}
document.addEventListener('visibilitychange',()=>{if(document.hidden)x20_leave('غادر الامتحان (فتح تطبيق أو تبويب آخر)')});
addEventListener('pagehide',()=>{if(x20_live()){x20_leave('أغلق الامتحان أو حدّث الصفحة');try{wr()}catch(e){}}});
addEventListener('blur',()=>setTimeout(()=>{if(x20_live()&&!CUR.busy&&!document.hasFocus()&&!document.hidden)x20_warn('فتحت شاشة أو نافذة أخرى')},500));
addEventListener('resize',()=>{if(x20_live()&&CUR.w0&&innerWidth<CUR.w0*.75)x20_warn('صغّرت نافذة الامتحان (شاشة مقسومة)')});
document.addEventListener('fullscreenchange',()=>{if(x20_live()&&CUR.fs&&!document.fullscreenElement)x20_warn('خرجت من وضع ملء الشاشة')});
['copy','cut','paste','contextmenu'].forEach(v=>document.addEventListener(v,e=>{if(x20_live())e.preventDefault()}));
const _x20go=go;go=function(p){if(x20_live()&&p!=='exam'){x20_leave('خرج من صفحة الامتحان');return}return _x20go.apply(this,arguments)};
const _x20cs=confSub;confSub=function(){if(CUR)CUR.busy=1;try{_x20cs()}finally{if(CUR)CUR.busy=0}};
const _x20st=start;start=async function(id){const e=E(id);if(e&&!e.hw&&!S.s.some(s=>s.e===id&&s.u===S.me)&&!await ask('🔒 قواعد الامتحان:\n• الخروج من الامتحان = تسليم فوري\n• فتح شاشة أو نافذة أخرى = تحذير ثم تسليم تلقائي\n• تحديث الصفحة أو إغلاقها = تسليم تلقائي\n\nمستعد تبدأ؟'))return;_x20st(id);if(x20_live()){CUR.w0=innerWidth;x20_save();try{document.documentElement.requestFullscreen&&document.documentElement.requestFullscreen().then(()=>{if(CUR)CUR.fs=1}).catch(()=>{})}catch(er){}}};
function x20_recover(t){let d=null;try{d=JSON.parse(localStorage.getItem(X20K)||'null')}catch(e){}if(!d||CUR||S.me!==d.u)return;const e=E(d.e);if(!e){if(t<8)setTimeout(()=>x20_recover(t+1),1500);return}try{localStorage.removeItem(X20K)}catch(er){}if(S.s.some(s=>s.e===d.e&&s.u===d.u))return;const w='خرج من الامتحان أو حدّث الصفحة';S.s.push({id:uid(),e:d.e,u:d.u,a:d.a||{},d:Date.now(),vc:d.vc||0,vr:w});const g=G(e.g);if(g){g.act=Date.now();notify(g.t,`${U(d.u)?.name||'طالب'} سلّم ${e.name} ⚠️ (${w})`,undefined,'review|'+e.id)}save();toast('تم تسليم امتحانك تلقائياً لأنك خرجت منه');go('exam',e.id,'res')}
setTimeout(()=>x20_recover(0),900);
/* ملخص ذكي بعد الامتحان */
const _x20res=result;result=function(e){const h=_x20res(e);return h?h+'<div class="card"><h3>🤖 ملخص ذكي لأدائك</h3><div id="sm20" class="mut">جارٍ التحليل…</div></div>':h};
let X20B=0;const X20F=new Set();
async function x20_sum(){const e=E(V.a),s=e&&S.s.find(x=>x.e===e.id&&x.u===S.me),el=document.getElementById('sm20');if(!s||!el)return;S.sm=S.sm||{};if(S.sm[s.id]){el.innerHTML=mdl(S.sm[s.id]);return}const bad=e.q.filter(q=>!isOk(q,s));if(!bad.length){el.innerHTML='🌟 كل إجاباتك صحيحة — كمّل على نفس المستوى!';return}if(X20B||X20F.has(s.id))return;X20B=1;el.innerHTML='<span class="dots"><i></i><i></i><i></i></span> SHANANOO AI بيحلّل أداءك…';
const a=await ai('أنت مدرس ودود. حلّل أداء طالب في امتحان «'+e.name+'» ودرجته '+score(e,s)+'%. الأسئلة الخاطئة:\n'+bad.slice(0,8).map(q=>'- '+q.q+' | إجابته: '+(s.a[q.id]||'لم يجب')+' | الصحيح: '+ans(q)).join('\n')+'\nاكتب بالعربية المبسّطة وباختصار: ١) نقاط القوة ٢) نقاط الضعف ٣) خطة مذاكرة لـ 3 أيام ٤) جملة تشجيع.');X20B=0;if(a){S.sm[s.id]=a;cache()}else X20F.add(s.id);const e2=document.getElementById('sm20');if(e2)e2.innerHTML=a?mdl(a):'تعذّر التحليل الآن — جرّب زر 🤖 اشرح لي تحت كل سؤال.'}
/* بنك الأسئلة */
const _x20studio=studio;studio=function(){const h=_x20studio();S.qb=S.qb||[];return h+`<div class="card"><div class="row"><h3>📚 بنك الأسئلة (${S.qb.length})</h3><button class="b s" onclick="x20_qbSave()">💾 احفظ أسئلة الامتحان في البنك</button></div>${S.qb.slice(0,40).map((x,i)=>`<div class="x20r"><span>${esc(x.q.slice(0,70))}</span><span><button class="b s" onclick="x20_qbAdd(${i})">➕</button><button class="b s" onclick="x20_qbDel(${i})">🗑</button></span></div>`).join('')||'<p class="mut">احفظ أسئلتك هنا وأعد استخدامها في أي امتحان.</p>'}</div>`};
window.x20_qbSave=()=>{if(!D||!D.q.length)return toast('ضيف أسئلة أولاً');S.qb=S.qb||[];let n=0;D.q.forEach(q=>{if(!S.qb.some(x=>x.q===q.q)){S.qb.unshift(JSON.parse(JSON.stringify(q)));n++}});cache();toast('تم حفظ '+n+' سؤال في البنك');R()};
window.x20_qbAdd=i=>{const q=S.qb[i];if(!D||!q)return;if(D.q.some(x=>x.id===q.id||x.q===q.q))return toast('السؤال موجود في الامتحان');D.q.push(JSON.parse(JSON.stringify(q)));toast('تمت الإضافة');R()};
window.x20_qbDel=async i=>{if(await ask('حذف السؤال من البنك؟')){S.qb.splice(i,1);cache();R()}};
/* تحليلات المدرس + إعلانات + ملخص ولي الأمر */
function x20_an(){const gs=S.g.filter(g=>g.t===S.me),es=S.e.filter(e=>gs.some(g=>g.id===e.g)),sb=S.s.filter(s=>es.some(e=>e.id===s.e));if(!gs.length)return '';
const bc=`<div class="card"><h3>📣 إعلان لمجموعة</h3><select id="bcg">${gs.map(g=>`<option value="${g.id}">${esc(g.title)}</option>`).join('')}</select><textarea id="bct" rows="2" placeholder="اكتب الإعلان أو التنبيه…"></textarea><button class="b" onclick="x20_bc()">إرسال للطلاب</button></div>`;if(!sb.length)return bc;
const qs=[];es.forEach(e=>{const ss=sb.filter(s=>s.e===e.id);if(ss.length)e.q.forEach(q=>qs.push({q:q.q,e:e.name,w:Math.round(ss.filter(s=>!isOk(q,s)).length/ss.length*100)}))});qs.sort((a,b)=>b.w-a.w);
const sc=sb.map(s=>score(E(s.e),s)),bk=[['أقل من 50',x=>x<50],['50 – 64',x=>x>=50&&x<65],['65 – 84',x=>x>=65&&x<85],['85 فأعلى',x=>x>=85]].map(([l,f])=>[l,sc.filter(f).length]),mx=Math.max(1,...bk.map(x=>x[1])),nw=Date.now(),late=[];
gs.forEach(g=>es.filter(e=>e.g===g.id&&e.pub&&e.end&&new Date(e.end)<nw).forEach(e=>gStu(g).forEach(x=>{if(!S.s.some(s=>s.e===e.id&&s.u===x.u))late.push({u:x.u,e})})));
const ch=sb.filter(s=>s.vr);
return bc+`<div class="card"><h3>📊 تحليلات متقدمة</h3><b>توزيع الدرجات</b>${bk.map(([l,n])=>`<div class="x20r"><span style="width:84px">${l}</span><div class="bar"><i style="width:${n/mx*100}%"></i></div><b>${n}</b></div>`).join('')}<br><b>أصعب الأسئلة</b>${qs.slice(0,5).map(x=>`<div class="x20r"><span>${esc(x.q.slice(0,60))} <small class="mut">${esc(x.e)}</small></span><b style="color:var(--bad)">${x.w}% أخطأوا</b></div>`).join('')}${late.length?'<br><b>⏰ لم يسلّموا بعد انتهاء الموعد</b>'+late.slice(0,8).map(x=>`<div class="x20r"><span>${esc(U(x.u)?.name)} <small class="mut">${esc(x.e.name)}</small></span><button class="b s" onclick="notify('${x.u}','⏰ لسه ما سلّمتش «${esc(x.e.name).replace(/'/g,"\\'")}» — كلّم مدرسك')&&0;toast('تم التنبيه')">🔔 نبّهه</button></div>`).join(''):''}${ch.length?'<br><b>⚠️ تسليمات بمخالفات</b>'+ch.slice(-6).reverse().map(s=>`<div class="x20r"><span>${esc(U(s.u)?.name)} <small class="mut">${esc(E(s.e).name)} — ${esc(s.vr)}</small></span><button class="b s" onclick="go('grade','${s.id}')">مراجعة</button></div>`).join(''):''}</div>`}
window.x20_bc=()=>{const g=G($('#bcg').value),t=$('#bct').value.trim();if(!g||!t)return toast('اكتب نص الإعلان');gStu(g).forEach(x=>notify(x.u,'📣 '+g.title+': '+t));$('#bct').value='';toast('تم الإرسال لـ '+gStu(g).length+' طالب')};
function x20_wkText(k){const w=Date.now()-6048e5,ss=S.s.filter(s=>s.u===k.id&&s.d>w&&E(s.e)),v=ss.map(s=>score(E(s.e),s));return `📊 تقرير ${k.name} هذا الأسبوع\n• امتحانات مُسلَّمة: ${ss.length}\n• المتوسط: ${avg(v)}%\n`+(v.length?'• أفضل درجة: '+Math.max(...v)+'%':'• لم يسلّم أي امتحان هذا الأسبوع')+'\n• نقاط XP: '+xp(k.id)}
function x20_wk(){const ks=typeof kids==='function'?kids(S.me):[];if(!ks||!ks.length)return '';return `<div class="card"><h3>📩 ملخص الأسبوع</h3>${ks.map(k=>`<div class="chip" style="white-space:pre-line">${esc(x20_wkText(k))}</div><button class="b s" onclick="x20_share('${k.id}')">📲 مشاركة الملخص</button>`).join('')}</div>`}
window.x20_share=id=>{const k=U(id),t=x20_wkText(k);if(navigator.share)navigator.share({text:t}).catch(()=>{});else{navigator.clipboard?.writeText(t);toast('تم نسخ الملخص')}};
const _x20d=dash;dash=function(){const h=_x20d();try{const m=me();if(!m)return h;return m.role==='teacher'?h+x20_an():m.role==='parent'?h+x20_wk():h}catch(e){return h}};
const _x20R=R;R=function(){_x20R.apply(this,arguments);try{document.body.classList.toggle('inexam',x20_live());if(V.p==='exam'&&V.t==='res')x20_sum()}catch(e){}};
