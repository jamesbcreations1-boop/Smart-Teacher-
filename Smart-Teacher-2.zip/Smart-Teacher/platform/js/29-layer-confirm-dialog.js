/* ▓▓ 29-layer-confirm-dialog.js — v25: نافذة التأكيد
   بيتحمّل بعد: 28-layer-builtin-features.js  |  وبعده: 30-layer-excel-files.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [10] v25: نافذة التأكيد
   ========================================================================== */
/* v25: نافذة تأكيد داخلية بدل confirm() الأصلي (اللي بيتعطل في كثير من المتصفحات) */
window.ask=function(msg){return new Promise(res=>{const bg=document.createElement('div');bg.className='askbg';bg.setAttribute('role','dialog');bg.setAttribute('aria-modal','true');
const bx=document.createElement('div');bx.className='askbx';const p=document.createElement('div');p.textContent=msg;const r=document.createElement('div');r.className='row';
const no=document.createElement('button');no.className='b s';no.textContent='إلغاء';const ok=document.createElement('button');ok.className='b';ok.textContent='تأكيد';
r.append(no,ok);bx.append(p,r);bg.append(bx);document.body.append(bg);
const done=v=>{document.removeEventListener('keydown',k,true);bg.remove();res(v)};
const k=e=>{if(e.key==='Escape'){e.preventDefault();done(false)}};
document.addEventListener('keydown',k,true);no.onclick=()=>done(false);ok.onclick=()=>done(true);bg.onclick=e=>{if(e.target===bg)done(false)};ok.focus()})};
