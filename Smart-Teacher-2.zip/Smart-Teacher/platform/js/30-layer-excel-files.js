/* ▓▓ 30-layer-excel-files.js — v26: ملفات Excel
   بيتحمّل بعد: 29-layer-confirm-dialog.js  |  وبعده: 31-layer-announcements-2fa-katex.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [11] v26: ملفات Excel
   ========================================================================== */
/* ============================================================
   v26 — دفعة أولى من التحسينات المطلوبة (راجع رسالة التسليم)
   يضيف فقط — لا يعدّل أي دالة أصلية، بل يغلّفها (نفس أسلوب v20-25)
   ============================================================ */

/* ---------- 1) اعتراض الطالب على سؤال + مراجعة جماعية للمدرس ---------- */
S.d = S.d || [];
if (typeof COLS !== 'undefined' && !COLS.includes('d')) COLS.push('d');

function x26_disputeForm(eid){
  const e = E(eid);
  if (!e) return '';
  const mine = S.d.filter(x => x.e === eid && x.u === S.me);
  return `<div class="card">
    <h3>⚠️ عندك اعتراض على سؤال؟</h3>
    <select id="x26q">${e.q.map((q,i)=>`<option value="${q.id}">${i+1}. ${esc((q.q||'').slice(0,40))}</option>`).join('')}</select>
    <textarea id="x26r" rows="2" placeholder="اكتب سبب اعتراضك..."></textarea>
    <button class="b s" style="width:100%" onclick="x26_sendDispute('${eid}')">إرسال الاعتراض</button>
    ${mine.length?`<div class="mut" style="margin-top:8px">اعتراضاتك: ${mine.map(d=>`<span class="tag">${d.status==='open'?'⏳ قيد المراجعة':d.status==='rejected'?'✘ مرفوض':'✅ تم التصحيح'}</span>`).join(' ')}</div>`:''}
  </div>`;
}

window.x26_sendDispute = function(eid){
  const sel = $('#x26q'), ta = $('#x26r');
  if (!sel || !ta) return;
  const q = sel.value, r = (ta.value||'').trim();
  if (!r) return toast('اكتب سبب الاعتراض أولاً');
  const e = E(eid);
  if (!e) return;
  S.d.push({id:uid(), e:eid, q, u:S.me, reason:r, d:Date.now(), status:'open'});
  const g = G(e.g);
  if (g) notify(g.t, `⚠️ ${me().name} اعترض على سؤال في ${e.name}`);
  save();
  ta.value = '';
  toast('تم إرسال اعتراضك للمدرس');
  R();
};

window.x26_disputesModal = function(eid){
  const e = E(eid);
  if (!e) return;
  const list = S.d.filter(x => x.e === eid).sort((a,b) => b.d - a.d);
  const body = list.map(d => {
    const q = e.q.find(x => x.id === d.q), stu = U(d.u);
    return `<div class="card">
      <b>${esc(stu?.name||'طالب')}</b> <span class="mut">${new Date(d.d).toLocaleString('ar-EG')}</span>
      <p>السؤال: ${esc(q?.q||'—')}</p>
      <p>السبب: ${esc(d.reason)}</p>
      ${d.status==='open' ? `<div class="row">
          <button class="b" onclick="x26_resolve('${d.id}','all')">✔ صحّح للجميع</button>
          <button class="b s" onclick="x26_resolve('${d.id}','one')">✔ صحّح له فقط</button>
          <button class="b s" onclick="x26_resolve('${d.id}','reject')">✘ رفض</button>
        </div>` : `<span class="tag">${d.status==='fixed-all'?'✅ تم التصحيح للجميع':d.status==='fixed-one'?'✅ تم التصحيح له':'✘ مرفوض'}</span>`}
    </div>`;
  }).join('') || '<p class="mut">لا توجد اعتراضات</p>';
  x22_m('⚠️ اعتراضات الطلاب', body);
};

window.x26_resolve = function(did, action){
  const d = S.d.find(x => x.id === did);
  if (!d) return;
  const e = E(d.e);
  if (!e) return;
  if (action === 'reject'){
    d.status = 'rejected';
  } else {
    const subs = action === 'all' ? S.s.filter(x => x.e === d.e) : S.s.filter(x => x.e === d.e && x.u === d.u);
    subs.forEach(s => { s.ov = s.ov || {}; s.ov[d.q] = true; });
    d.status = action === 'all' ? 'fixed-all' : 'fixed-one';
    notify(d.u, `✅ تمت مراجعة اعتراضك على سؤال في ${e.name}`);
  }
  save();
  x22_x();
  toast('تم الحفظ');
  R();
};

const _x26res = result;
result = function(e){
  const h = _x26res(e);
  if (!h || !e) return h;
  const s = S.s.find(x => x.e === e.id && x.u === S.me);
  if (!s) return h;
  return h + x26_disputeForm(e.id);
};

const _x26rev = review;
review = function(){
  let h = _x26rev();
  if (!h) return h;
  const e = E(V.a);
  if (!e) return h;
  const open = S.d.filter(x => x.e === e.id && x.status === 'open');
  let extra = `<button class="b s" onclick="x26_xlsx('${e.id}')">📊 Excel</button>`;
  if (open.length) extra += `<button class="b" style="background:var(--bad)" onclick="x26_disputesModal('${e.id}')">⚠️ اعتراضات (${open.length})</button>`;
  return h.replace('</div>', extra + '</div>');
};

const _x26grade = grade;
grade = function(){
  let h = _x26grade();
  if (!h) return h;
  const s = S.s.find(x => x.id === V.a);
  if (s && (s.vc || s.vr)){
    const badge = `<div class="card" style="border-color:var(--bad)"><b>⚠️ مخالفات أثناء الامتحان:</b> ${s.vc||0} — ${esc(s.vr||'')}</div>`;
    h = h.replace('<div class="card stc">', badge + '<div class="card stc">');
  }
  return h;
};

/* ---------- 2) كشف سرعة الإجابة غير الطبيعية (يُلحق بنظام المخالفات الحالي) ---------- */
const X26_SPEED_THRESHOLD_SEC = 3; /* متوسط أقل من هذا يعتبر مريب — عدّله حسب طبيعة أسئلتك */
const _x26sub = submit;
submit = function(auto){
  try{
    if (CUR && CUR.end){
      const e = E(CUR.e);
      if (e && e.q && e.q.length >= 5 && e.dur){
        const startTime = CUR.end - e.dur*60000;
        const answered = e.q.filter(q => String(CUR.a[q.id]||'').trim()).length;
        const elapsedSec = (Date.now() - startTime) / 1000;
        const avgSec = answered ? elapsedSec/answered : 0;
        if (answered >= 5 && avgSec < X26_SPEED_THRESHOLD_SEC){
          CUR.vc = (CUR.vc||0) + 1;
          CUR.vr = (CUR.vr ? CUR.vr+' + ' : '') + `سرعة إجابة غير طبيعية (~${avgSec.toFixed(1)} ث/سؤال)`;
        }
      }
    }
  }catch(err){}
  return _x26sub(auto);
};

/* ---------- 3) تصدير النتائج Excel حقيقي (بجانب CSV الموجود) ---------- */
window.x26_xlsx = function(eid){
  if (typeof XLSX === 'undefined') return toast('تعذر تحميل مكتبة Excel — تأكد من الاتصال بالإنترنت وحاول مجدداً');
  const e = E(eid);
  if (!e) return;
  const subs = S.s.filter(x => x.e === eid).sort((a,b) => b.d - a.d);
  const rows = subs.map(s => ({
    'الاسم': U(s.u)?.name || '—',
    'الدرجة %': score(e, s),
    'تاريخ التسليم': new Date(s.d).toLocaleString('ar-EG'),
    'المخالفات': s.vc || 0,
    'سبب المخالفة': s.vr || '',
    'الحالة': s.ov ? 'معدّل يدوياً' : 'تلقائي'
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'النتائج');
  XLSX.writeFile(wb, (e.name||'نتائج') + '.xlsx');
};

/* ---------- 4) حد يومي لاستخدام الذكاء الاصطناعي للطلاب (المدرس بلا حدود) ---------- */
const X26_AI_DAILY_LIMIT = 20; /* قابل للتعديل من هنا */
S.rl = S.rl || {};
function x26_today(){ return new Date().toISOString().slice(0,10); }
function x26_aiCount(){
  const r = S.rl[S.me];
  if (!r || r.d !== x26_today()) return 0;
  return r.n;
}
function x26_aiBump(){
  const d = x26_today(), r = S.rl[S.me];
  if (!r || r.d !== d) S.rl[S.me] = {d, n:1};
  else r.n++;
  cache();
}
const _x26ai = ai;
ai = async function(prompt, file, json){
  if (S.me && typeof isT === 'function' && !isT() && me()?.role !== 'admin'){
    if (x26_aiCount() >= X26_AI_DAILY_LIMIT){
      toast(`⏳ وصلت للحد اليومي لاستخدام الذكاء الاصطناعي (${X26_AI_DAILY_LIMIT} مرة). جرّب تاني بكرة أو اسأل مدرسك.`);
      return null;
    }
    x26_aiBump();
  }
  return _x26ai(prompt, file, json);
};
