/* ▓▓ 32-layer-assistant-community.js — v28: المساعد والمجتمع
   بيتحمّل بعد: 31-layer-announcements-2fa-katex.js  |  وبعده: 33-layer-error-monitor.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [13] v28: المساعد والمجتمع
   ========================================================================== */
/* ===== v28: واجهة المساعد الكاملة + المجتمع الموثّق + ثبات وأداء ===== */
(function(){
const isA=()=>{const m=me();return !!m&&m.role==='assistant'};
const myAG=()=>S.g.filter(g=>(g.as||[]).includes(S.me));
const pend=g=>g.st.filter(x=>x.s==='pend').length;
const VA='<svg class="vb" viewBox="0 0 24 24"><title>مساعد مدرس موثّق</title><circle cx="12" cy="12" r="11" fill="#16a34a"/><path d="M7 12.5l3.2 3.2L17 9" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const OKP=['dash','chats','ai','soc','prof','set','notes','pm'];

/* رسائل جديدة للمساعد (شات المجموعات + الخاص) */
function unrA(){if(!isA())return 0;const ids=new Set(myAG().map(g=>g.id));
  return S.m.filter(x=>x.u!==S.me&&ids.has(x.g)&&(x.d||0)>rdk('g'+x.g)).length+S.p.filter(x=>x.b===S.me&&(x.d||0)>rdk('p'+x.a)).length}

/* شريط التنقل الثابت للمساعد في كل الصفحات */
function aNav(){const bn=$('#bn');if(!bn||!isA())return;const u=unrA(),P=V.p;
  const it=[['dash','🏠','مهامي',['dash']],['chats','💬','الشاتات'+(u?' ('+u+')':''),['chats','pm']],['ai','🤖','الذكاء',['ai']],['soc','🌐','المجتمع',['soc','prof']],['set','⚙️','الإعدادات',['set','notes']]];
  bn.innerHTML=it.map(x=>`<button class="${x[3].includes(P)?'on':''}" onclick="${x[0]==='soc'?"ST.tab='all';":''}go('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('')}

/* شبكة أمان للعرض: لو حصل خطأ في أي صفحة ما تتحولش لشاشة فاضية */
let FB=0;
function safe(e){console.error('R failed',e);const a=$('#app');if(!a||Date.now()-FB<1500)return;FB=Date.now();
  a.innerHTML=`<div class="card x28fb"><div class="big">⚠️</div><h3>حصلت مشكلة بسيطة في عرض الصفحة</h3><p class="mut">بياناتك محفوظة. ارجع للرئيسية أو حدّث الصفحة.</p><button class="b" onclick="go('dash')">🏠 الرئيسية</button><button class="b s" onclick="location.reload()">🔄 تحديث</button></div>`}
const _R=R;
R=function(){
  if(isA()&&!OKP.includes(V.p))V={p:'dash'};
  try{_R.apply(this,arguments)}catch(e){safe(e)}
  try{if(isA())aNav()}catch(e){console.warn(e)}
};

/* رئيسية المساعد: بانر + إحصائيات + كود + صلاحيات + المجموعات */
x27_asDash=function(){
  const m=me(),gs=myAG(),c=x27_ac(m),h=new Date().getHours(),gr=h>=5&&h<12?'صباح الخير':h>=18||h<5?'مساء الخير':'أهلاً';
  const stu=new Set();gs.forEach(g=>gStu(g).forEach(x=>stu.add(x.u)));
  const pd=gs.reduce((n,g)=>n+pend(g),0),un=unrA(),box=(n,l)=>`<div class="card stc"><div class="big">${n}</div><span class="mut">${l}</span></div>`;
  return `<div class="card banner x27as"><h2>${gr} ${esc(m.name)} ${VA}</h2><span class="pill">🧑‍🏫 مساعد مدرس موثّق</span><p class="mut">${gs.length?'تشرف على '+gs.length+' مجموعة':'بانتظار إضافتك لمجموعة'}</p></div>`
  +`<div class="grid x28st">${box(gs.length,'📚 مجموعات')}${box(stu.size,'🧑‍🎓 طلاب')}${box(pd,'⏳ طلبات انضمام')}${box(un,'💬 رسائل جديدة')}</div>`
  +`<h3>📚 مهامي (${gs.length} مجموعة)</h3>`+(gs.length>4?`<input class="srch" placeholder="🔍 ابحث عن مجموعة…" value="${esc(Q)}" oninput="Q=this.value;fl()">`:'')
  +(gs.map(g=>{const t=U(g.t),p=pend(g),nw=S.m.filter(x=>x.g===g.id&&x.u!==S.me&&(x.d||0)>rdk('g'+g.id)).length;
    return `<div class="card x27as row" data-gt="${esc(g.title.toLowerCase())}"><div><b>${esc(g.title)}</b><br><span class="mut">👨‍🏫 ${esc(t?.name||'')} • ${gStu(g).length} طالب${p?` • ⏳ ${p} طلب انضمام`:''} • الشات: ${g.chatOff?'🔇 موقوف':'🟢 مفتوح'}</span></div><button class="b" onclick="x27_asOpen('${g.id}')">إشراف${nw?' ('+nw+')':''}</button></div>`}).join('')
    ||`<div class="card mut">لم يضفك أي مدرس لمجموعة بعد — أعطِ المدرس الكود بالأسفل ليضيفك من «إعدادات المجموعة ← مساعدو المدرس».</div>`)
  +`<div class="card x27as" style="text-align:center"><h3>🔑 كود المساعد الخاص بك</h3><div class="pcode">${c}</div><button class="b" onclick="navigator.clipboard?.writeText('${c}');toast('تم نسخ الكود')">نسخ الكود</button><p class="mut">أعطِ هذا الكود للمدرس ليضيفك من «إعدادات المجموعة ← مساعدو المدرس».</p></div>`
  +`<div class="card x27as"><h3>✅ صلاحياتي</h3>${PERMS.map(p=>`<span class="pill">${p}</span>`).join('')}<p class="mut">المدرس الأصلي هو المسؤول الأساسي عن المجموعة.</p></div>`
};

/* نافذة الإشراف: تتعلّم كمقروءة + قائمة الطلاب + نزول لآخر رسالة */
const _ao=x27_asOpen;
x27_asOpen=function(id){
  const g=G(id);if(!g||!isAs(g))return;
  S.rd=S.rd||{};S.rd['g'+id]=Date.now();cache();
  _ao(id);
  try{
    const box=document.querySelector('#x22m .x22c');if(!box)return;
    const wb=box.querySelector('.wb');if(wb)wb.scrollTop=1e9;
    const act=g.st.filter(x=>x.s==='ok'||x.s==='sus');
    box.insertAdjacentHTML('beforeend',`<details class="x28sl"><summary>🧑‍🎓 الطلاب (${act.length})</summary>${g.st.map(x=>{const u=U(x.u);return u?`<div class="row x28r"><span>${x.s==='pend'?'⏳':x.s==='sus'?'⛔':'✅'} ${esc(u.name)}</span><button class="b s" onclick="x22_x();prof('${u.id}')">👤 صفحته</button></div>`:''}).join('')||'<p class="mut">لا يوجد طلاب بعد</p>'}</details>`);
  }catch(e){console.warn(e)}
};

/* شاتات المساعد: مجموعاته (تفتح نافذة الإشراف) + الرسائل الخاصة */
const _ch=chats;
chats=function(){
  if(!isA())return _ch();
  const m=me(),gr=[],pr=[];
  myAG().forEach(g=>{const ms=S.m.filter(x=>x.g===g.id),l=ms[ms.length-1];
    gr.push({k:g.id,n:g.cn||g.title,img:g.img,sub:l?`${l.u===S.me?'أنت':esc(U(l.u)?.name||'')}: ${esc(l.t).slice(0,40)}`:'لا توجد رسائل بعد',d:l?.d||0,un:ms.filter(x=>x.u!==S.me&&(x.d||0)>rdk('g'+g.id)).length,go:`x27_asOpen('${g.id}')`})});
  const peers=new Set();S.p.forEach(x=>{if(x.a===m.id)peers.add(x.b);if(x.b===m.id)peers.add(x.a)});myAG().forEach(g=>peers.add(g.t));
  peers.forEach(id=>{const o=U(id);if(!o)return;const ms=S.p.filter(x=>(x.a===m.id&&x.b===id)||(x.a===id&&x.b===m.id)),l=ms[ms.length-1];
    pr.push({k:id,n:o.name,sub:l?`${l.a===S.me?'أنت: ':''}${esc(l.t).slice(0,40)}`:(o.role==='teacher'?'ابدأ محادثة مع المدرس':'ابدأ المحادثة'),d:l?.d||0,un:ms.filter(x=>x.a===id&&x.d>rdk('p'+id)).length,go:`go('pm','${id}')`})});
  const so=(a,b)=>b.d-a.d;
  return `<h2>💬 الشاتات</h2><input class="srch" placeholder="🔍 ابحث في الشاتات…" value="${esc(Q)}" oninput="Q=this.value;fl()"><h3>👥 المجموعات</h3>${gr.length?`<div class="card" style="padding:0">${gr.sort(so).map(crow).join('')}</div>`:emp('لا توجد مجموعات')}<h3>✉️ الرسائل الخاصة</h3>${pr.length?`<div class="card" style="padding:0">${pr.sort(so).map(crow).join('')}</div>`:emp('لا توجد رسائل')}`
};

/* الإشعار بيفتح نافذة الإشراف مباشرة للمساعد */
const _on=openN;
openN=function(id){const x=S.n.find(y=>y.id===id);
  if(x&&isA()){const k=x.k||'';if(k[0]==='g'&&G(k.slice(1))&&isAs(G(k.slice(1)))){x.r=1;save();go('chats');setTimeout(()=>x27_asOpen(k.slice(1)),0);return}}
  return _on(id)};

/* كود المساعد كمان في صفحة الإعدادات */
const _set=set;
set=function(){const h=_set();if(!isA())return h;const c=x27_ac(me());
  return h+`<div class="card x27as" style="text-align:center"><h3>🔑 كود المساعد</h3><div class="pcode">${c}</div><button class="b" onclick="navigator.clipboard?.writeText('${c}');toast('تم نسخ الكود')">نسخ الكود</button></div>`};

/* ثبات الشبكة: أي طلب لقاعدة البيانات يتقفل بعد 25 ثانية بدل ما المزامنة تفضل معلّقة */
const _fx=window.fetch;
window.fetch=function(u,o){
  try{const url=String((u&&u.url)||u);
    if(/firebaseio\.com/.test(url)&&!(o&&o.signal)&&typeof AbortController==='function'){const c=new AbortController();setTimeout(()=>{try{c.abort()}catch(e){}},25000);o=Object.assign({},o,{signal:c.signal})}}catch(e){}
  return _fx.call(this,u,o)};
addEventListener('offline',()=>toast('📴 انقطع الاتصال — تعديلاتك هتتحفظ وتتزامن أول ما يرجع النت'));
addEventListener('online',()=>{toast('✅ رجع الاتصال — بنزامن بياناتك');try{pull().then(()=>qpush())}catch(e){}});

R();
})();
