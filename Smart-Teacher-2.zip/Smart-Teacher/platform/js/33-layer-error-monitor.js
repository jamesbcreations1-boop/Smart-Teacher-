/* ▓▓ 33-layer-error-monitor.js — مراقب أخطاء تشخيصي
   بيتحمّل بعد: 32-layer-assistant-community.js  |  وبعده: 34-layer-admin-panel-themes-materials.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [14] مراقب أخطاء تشخيصي
   ========================================================================== */
/* مراقب أخطاء تشخيصي خفيف: لا يوقف المنصة ولا يرسل بيانات لأي جهة. */
(function () {
  'use strict';
  var KEY = '__ST_QA_ERRORS__';
  function record(kind, message, source, line) {
    try {
      var list = Array.isArray(window[KEY]) ? window[KEY] : (window[KEY] = []);
      list.push({
        kind: String(kind || 'error').slice(0, 30),
        message: String(message || 'Unknown error').slice(0, 300),
        source: String(source || '').slice(0, 200),
        line: Number(line) || 0,
        time: new Date().toISOString()
      });
      if (list.length > 50) list.splice(0, list.length - 50);
    } catch (_) {}
  }
  window.addEventListener('error', function (e) {
    record('error', e.message, e.filename, e.lineno);
  });
  window.addEventListener('unhandledrejection', function (e) {
    var reason = e.reason;
    record('unhandledrejection', reason && (reason.message || reason) || 'Promise rejected');
  });
})();
