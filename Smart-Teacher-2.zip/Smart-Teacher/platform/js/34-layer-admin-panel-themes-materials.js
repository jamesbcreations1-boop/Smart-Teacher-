/* ▓▓ 34-layer-admin-panel-themes-materials.js — v40: لوحة الإدارة + المظهر + الثيمات + المواد
   بيتحمّل بعد: 33-layer-error-monitor.js  |  وبعده: 35-layer-objections-notifications.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [15] v40: لوحة الإدارة + المظهر + الثيمات + المواد
   ========================================================================== */
(()=>{
const ROLES=['teacher','student','parent','assistant'];
const CATS={gen:['📢','إعلان عام','#2563eb'],exam:['📝','امتحانات','#7c3aed'],event:['📅','مواعيد وفعاليات','#0d9488'],win:['🏆','إنجازات وتكريم','#d97706'],tip:['💡','نصائح ومواد','#16a34a'],urgent:['🚨','عاجل','#dc2626']};
const NS={q:'',cat:'all',f:'all',open:new Set(),form:0,edit:null};
const jget=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'')||d}catch(e){return d}};
const rk=()=>'st_nr_'+S.me,bk=()=>'st_nb_'+S.me;
const readSet=()=>new Set(jget(rk(),[])),saved=()=>new Set(jget(bk(),[]));
const putSet=(k,s)=>{try{localStorage.setItem(k,JSON.stringify([...s].slice(-400)))}catch(e){}};
const ago2=t=>{const s=(Date.now()-t)/1e3;return s<60?'الآن':s<3600?'منذ '+Math.floor(s/60)+' دقيقة':s<86400?'منذ '+Math.floor(s/3600)+' ساعة':new Date(t).toLocaleDateString('ar-EG',{day:'numeric',month:'long',year:'numeric'})};
const adm=m=>!!m&&m.role==='admin',canPost=m=>!!m&&(m.role==='teacher'||adm(m));
function inG(g,m){const ok=x=>x.s==='ok'||x.s==='sus';
 if(m.role==='teacher')return g.t===m.id;
 if(m.role==='student')return (g.st||[]).some(x=>x.u===m.id&&ok(x));
 if(m.role==='assistant')return (g.as||[]).includes(m.id);
 if(m.role==='parent'){const ks=(S.pl||[]).filter(x=>x.p===m.id&&!x.x).map(x=>x.s);return (g.st||[]).some(x=>ks.includes(x.u)&&ok(x))}
 return false}
function vis(n,m){if(!m)return false;if(adm(m)||n.by===m.id)return true;
 if(n.ex&&Date.parse(n.ex)+864e5<Date.now())return false;
 const a=n.a||'all';if(a==='all')return true;
 if(ROLES.includes(a))return m.role===a;
 if(a==='mine')return m.role!=='teacher'&&S.g.some(g=>g.t===n.by&&inG(g,m));
 if(a.startsWith('g:')){const g=G(a.slice(2));return !!g&&inG(g,m)}
 return false}
const list=m=>(S.nw||[]).filter(n=>vis(n,m)).sort((a,b)=>(b.p||0)-(a.p||0)||b.d-a.d);
const unreadN=m=>{if(!m)return 0;const r=readSet();return list(m).filter(n=>!r.has(n.id)&&n.by!==m.id).length};
const audLabel=n=>{const a=n.a||'all';if(a==='all')return 'الجميع';if(a==='mine')return 'طلابي وأولياء أمورهم';if(a.startsWith('g:'))return 'مجموعة: '+(G(a.slice(2))?.cn||G(a.slice(2))?.title||'—');return ({teacher:'المعلمون',student:'الطلاب',parent:'أولياء الأمور',assistant:'المساعدون'})[a]||'الجميع'};
const rcount=n=>Object.values(n.r||{}).reduce((a,o)=>a+Object.keys(o||{}).length,0);
function card(n,m){const c=CATS[n.c]||CATS.gen,r=readSet(),sv=saved(),open=NS.open.has(n.id),long=(n.b||'').length>220,un=!r.has(n.id)&&n.by!==m.id,au=U(n.by),own=n.by===m.id||adm(m),exp=n.ex&&Date.parse(n.ex)+864e5<Date.now();
 const body=esc(open||!long?n.b:n.b.slice(0,220)+'…').replace(/\n/g,'<br>');
 const rx=['👍','❤️','🎉'].map(e=>{const o=(n.r||{})[e]||{},k=Object.keys(o).length;return `<button class="stn-rx ${o[m.id]?'on':''}" onclick="stN.react('${n.id}','${e}')">${e}${k?` <b>${k}</b>`:''}</button>`}).join('');
 return `<article class="stn-card ${n.p?'pin':''} ${un?'unread':''} ${n.c==='urgent'?'urg':''}" style="--nc:${c[2]}" id="n-${n.id}">
 <div class="stn-top"><span class="stn-cat">${c[0]} ${c[1]}</span>${n.p?'<span class="stn-pin">📌 مثبّت</span>':''}${un?'<span class="stn-new">جديد</span>':''}${exp?'<span class="stn-exp">منتهي</span>':''}<span class="stn-time">${ago2(n.d)}</span></div>
 <h3>${esc(n.t)}</h3><p>${body}</p>
 ${long?`<button class="stn-more" onclick="stN.toggle('${n.id}')">${open?'عرض أقل ▲':'اقرأ المزيد ▼'}</button>`:''}
 <div class="stn-meta">✍️ ${esc(au?.name||'الإدارة')} · 👥 ${esc(audLabel(n))}${n.ex?' · ⏳ حتى '+esc(n.ex):''}</div>
 <div class="stn-act"><div class="stn-rxs">${rx}</div><div class="stn-tools">
 <button title="حفظ" class="${sv.has(n.id)?'on':''}" onclick="stN.save('${n.id}')">${sv.has(n.id)?'🔖':'📑'}</button>
 <button title="مشاركة" onclick="stN.share('${n.id}')">📤</button>
 ${own?`<button title="تثبيت" onclick="stN.pin('${n.id}')">📌</button><button title="تعديل" onclick="stN.edit('${n.id}')">✏️</button><button title="حذف" onclick="stN.del('${n.id}')">🗑️</button>`:''}</div></div></article>`}
function items(m){let a=list(m);const r=readSet(),sv=saved(),q=NS.q.trim().toLowerCase();
 if(NS.cat!=='all')a=a.filter(n=>n.c===NS.cat);
 if(NS.f==='unread')a=a.filter(n=>!r.has(n.id)&&n.by!==m.id);
 if(NS.f==='saved')a=a.filter(n=>sv.has(n.id));
 if(NS.f==='mine')a=a.filter(n=>n.by===m.id);
 if(q)a=a.filter(n=>((n.t||'')+' '+(n.b||'')).toLowerCase().includes(q));return a}
function listHtml(m){const a=items(m);return a.length?a.map(n=>card(n,m)).join(''):`<div class="card stn-empty"><div style="font-size:42px">📭</div><h3>لا توجد أخبار هنا</h3><p class="mut">${NS.q||NS.cat!=='all'||NS.f!=='all'?'جرّب تغيير البحث أو التصنيف.':canPost(m)?'ابدأ بنشر أول خبر لطلابك.':'سيظهر هنا كل جديد من مدرسيك والإدارة.'}</p></div>`}
function form(m){const e=Object.assign({},NS.edit?(S.nw||[]).find(x=>x.id===NS.edit):null,NS.dr||{});
 const gs=S.g.filter(g=>g.t===m.id).map(g=>`<option value="g:${g.id}" ${e?.a==='g:'+g.id?'selected':''}>مجموعة: ${esc(g.cn||g.title||'')}</option>`).join('');
 const aud=adm(m)?[['all','الجميع'],['teacher','المعلمون'],['student','الطلاب'],['parent','أولياء الأمور'],['assistant','المساعدون']].map(x=>`<option value="${x[0]}" ${(e?.a||'all')===x[0]?'selected':''}>${x[1]}</option>`).join(''):`<option value="mine" ${(e?.a||'mine')==='mine'?'selected':''}>كل طلابي وأولياء أمورهم</option>${gs}`;
 return `<div class="card stn-form" oninput="stN.dr()" onchange="stN.dr()"><h3>${e?'✏️ تعديل الخبر':'📝 خبر جديد'}</h3>
 <input id="stn-t" maxlength="120" placeholder="عنوان الخبر" value="${esc(e?.t||'')}">
 <textarea id="stn-b" rows="5" maxlength="2000" placeholder="اكتب تفاصيل الخبر هنا…">${esc(e?.b||'')}</textarea>
 <div class="stn-fr"><label>التصنيف<select id="stn-c">${Object.entries(CATS).map(([k,v])=>`<option value="${k}" ${(e?.c||'gen')===k?'selected':''}>${v[0]} ${v[1]}</option>`).join('')}</select></label>
 <label>موجّه إلى<select id="stn-a">${aud}</select></label>
 <label>ينتهي في (اختياري)<input type="date" id="stn-x" value="${esc(e?.ex||'')}"></label></div>
 <label class="stn-chk"><input type="checkbox" id="stn-p" ${e?.p?'checked':''}> 📌 تثبيت أعلى الصفحة</label>
 <div class="row" style="justify-content:flex-end"><button class="b s" onclick="stN.cancel()">إلغاء</button><button class="b" onclick="stN.submit()">${e?'حفظ التعديل':'نشر الخبر'}</button></div></div>`}
function page(m){const L=list(m),un=unreadN(m);
 return `<div class="stn-page"><div class="stn-hero"><div><span class="st-eyebrow">SMART NEWS</span><h2>📰 أخبار المنصة</h2><p>${L.length} خبر${un?` · <b>${un} غير مقروء</b>`:' · كل شيء مقروء ✅'}</p></div>
 <div class="stn-hbtn">${un?'<button class="b s" onclick="stN.readAll()">✔️ تعليم الكل كمقروء</button>':''}${canPost(m)?'<button class="b" onclick="stN.newf()">➕ خبر جديد</button>':''}</div></div>
 ${NS.form&&canPost(m)?form(m):''}
 <input class="srch" id="stn-q" placeholder="🔍 ابحث في الأخبار…" value="${esc(NS.q)}" oninput="stN.search(this.value)">
 <div class="stn-chips">${[['all','كل التصنيفات']].concat(Object.entries(CATS).map(([k,v])=>[k,v[0]+' '+v[1]])).map(x=>`<button class="${NS.cat===x[0]?'on':''}" onclick="stN.cat('${x[0]}')">${x[1]}</button>`).join('')}</div>
 <div class="stn-chips sm">${[['all','كل الأخبار'],['unread','غير مقروء'],['saved','🔖 المحفوظة']].concat(canPost(m)?[['mine','✍️ منشوراتي']]:[]).map(x=>`<button class="${NS.f===x[0]?'on':''}" onclick="stN.flt('${x[0]}')">${x[1]}</button>`).join('')}</div>
 <div id="stn-list">${listHtml(m)}</div></div>`}
const refl=()=>{const m=me(),l=$('#stn-list');if(l&&m)l.innerHTML=listHtml(m)};
const w=window.stN={
 search(v){NS.q=v;refl()},dr(){NS.dr={t:$('#stn-t').value,b:$('#stn-b').value,c:$('#stn-c').value,a:$('#stn-a').value,ex:$('#stn-x').value,p:$('#stn-p').checked?1:0}},cat(c){NS.cat=c;R()},flt(f){NS.f=f;R()},
 toggle(id){NS.open.has(id)?NS.open.delete(id):NS.open.add(id);const r=readSet();r.add(id);putSet(rk(),r);const m=me(),n=(S.nw||[]).find(x=>x.id===id),el=$('#n-'+id);if(el&&n){el.outerHTML=card(n,m)}},
 readAll(){const r=readSet();list(me()).forEach(n=>r.add(n.id));putSet(rk(),r);R()},
 newf(){NS.form=1;NS.edit=null;NS.dr=null;R();scrollTo({top:0,behavior:'smooth'})},cancel(){NS.form=0;NS.edit=null;NS.dr=null;R()},
 edit(id){NS.form=1;NS.edit=id;NS.dr=null;R();scrollTo({top:0,behavior:'smooth'})},
 react(id,e){const m=me(),n=(S.nw||[]).find(x=>x.id===id);if(!n)return;n.r=n.r||{};n.r[e]=n.r[e]||{};n.r[e][m.id]?delete n.r[e][m.id]:n.r[e][m.id]=1;if(!Object.keys(n.r[e]).length)delete n.r[e];if(!Object.keys(n.r).length)delete n.r;save();const el=$('#n-'+id);if(el)el.outerHTML=card(n,m)},
 save(id){const s=saved();s.has(id)?s.delete(id):s.add(id);putSet(bk(),s);toast(s.has(id)?'🔖 تم حفظ الخبر':'تمت إزالة الخبر من المحفوظات');const n=(S.nw||[]).find(x=>x.id===id),el=$('#n-'+id);if(NS.f==='saved')refl();else if(el&&n)el.outerHTML=card(n,me())},
 async share(id){const n=(S.nw||[]).find(x=>x.id===id);if(!n)return;const t=`📰 ${n.t}\n\n${n.b}\n\n— المعلم الذكي (Smart Teacher)`;try{if(navigator.share)await navigator.share({title:n.t,text:t});else{await navigator.clipboard.writeText(t);toast('تم نسخ الخبر 📋')}}catch(e){}},
 pin(id){const n=(S.nw||[]).find(x=>x.id===id);if(!n)return;n.p=n.p?0:1;save();R();toast(n.p?'📌 تم التثبيت':'تم إلغاء التثبيت')},
 async del(id){if(!await (window.ask?ask('حذف هذا الخبر نهائياً؟'):confirm('حذف هذا الخبر نهائياً؟')))return;S.nw=(S.nw||[]).filter(x=>x.id!==id);save();R();toast('تم حذف الخبر')},
 submit(){const m=me(),t=$('#stn-t').value.trim(),b=$('#stn-b').value.trim();if(t.length<3)return toast('اكتب عنواناً واضحاً للخبر');if(b.length<5)return toast('اكتب تفاصيل الخبر');
  const o={t,b,c:$('#stn-c').value,a:$('#stn-a').value,p:$('#stn-p').checked?1:0,ex:$('#stn-x').value||undefined};
  if(NS.edit){const n=S.nw.find(x=>x.id===NS.edit);if(!n)return;Object.keys(o).forEach(k=>o[k]===undefined?delete n[k]:n[k]=o[k]);n.u=Date.now();toast('✅ تم تحديث الخبر')}
  else{const n=Object.assign({id:uid(),by:m.id,d:Date.now()},o);Object.keys(n).forEach(k=>n[k]===undefined&&delete n[k]);S.nw=S.nw||[];S.nw.unshift(n);
   S.u.filter(u=>u.id!==m.id&&u.role!=='admin'&&vis(n,u)).slice(0,300).forEach(u=>{S.n.unshift({id:uid(),to:u.id,txt:'📰 خبر جديد: '+t.slice(0,70),k:'nw',r:0,d:Date.now()})});toast('🎉 تم نشر الخبر')}
  NS.form=0;NS.edit=null;NS.dr=null;save();R()}};
/* fix: notifications for news open the news page */
if(typeof openN==='function'){const _o=openN;openN=function(id){const x=S.n.find(y=>y.id===id);if(x&&x.k==='nw'){x.r=1;save();go('news');return}return _o.apply(this,arguments)}}
/* About / developer */
window.stAbout=()=>`<div class="st-settings-hero st-about-hero"><div class="st-brand">ST</div><div><h2>Smart Teacher · المعلم الذكي</h2><p>المنصة التعليمية المتكاملة — الإصدار 1.0</p></div></div>
<div class="card"><h3>🌟 عن المنصة</h3><p>منصة عربية متكاملة تجمع المدرس والطالب وولي الأمر ومساعد المدرس والإدارة في مكان واحد: امتحانات ذكية، تصحيح فوري، متابعة وتقارير، شاتات، مساعد ذكاء اصطناعي، وأخبار وإعلانات لحظية.</p></div>
<div class="card stn-dev"><div class="stn-dev-av">OE</div><div class="stn-dev-in"><span class="st-eyebrow">DEVELOPER</span><h3>مطوّر منصة Smart Teacher</h3><div class="stn-dev-name">Omar Essam Elshanab</div><div class="stn-dev-ar">عمر عصام الشنب</div><p class="mut">صمّم وطوّر المنصة بشغف ليخدم المعلمين والطلاب وأولياء الأمور، وبيشتغل باستمرار على تطويرها وإضافة المميزات الجديدة. 💙</p><div class="stn-dev-tags"><span>Full-Stack Developer</span><span>Founder · Smart Teacher</span></div></div></div>
<div class="card"><h3>✨ مميزات المنصة</h3><div class="stn-feat">${[['📰','أخبار وإعلانات بتصنيفات وتثبيت وتفاعل'],['📝','امتحانات تلقائية بأنواع أسئلة متعددة'],['🤖','SHANANOO AI مساعد ذكي بالعربي والإنجليزي'],['📊','تقارير أداء لحظية لولي الأمر والمدرس'],['💬','شاتات للمجموعات ومحادثات خاصة'],['🏆','لوحة شرف ومجتمع للطلاب'],['🔐','تحقق بخطوتين وأمان للحساب'],['🌙','وضع ليلي وتصميم متجاوب للموبايل']].map(x=>`<div><span>${x[0]}</span>${x[1]}</div>`).join('')}</div></div>
<div class="card"><h3>🆕 ما الجديد في 1.0</h3><ul class="stn-new-l"><li>قسم الأخبار الكامل مع الإشعارات والبحث والمحفوظات</li><li>شريط آخر الأخبار في الصفحة الرئيسية</li><li>هوية بصرية وألوان موحّدة لكل الأدوار</li><li>زر الرجوع لأعلى وتحسينات الأداء والوصول</li></ul></div>
`;
/* render hook */
const _R=R;
R=function(){let m=me();
 if(m&&m.sus&&m.sb==='admin'){S.me=null;V={p:'dash'};save();m=null;setTimeout(()=>toast('⛔ تم إيقاف حسابك من الإدارة'),60)}

 if(m&&V.p==='stadm'&&!(adm(m)||ADMOK())){V={p:'dash'}}
 if(m&&(V.p==='news'||V.p==='stadm')){const keep=V;V={p:'dash'};try{_R.apply(this,arguments)}finally{V=keep}
  if(!$('#x27g')){const a=$('#app');if(a){a.innerHTML=keep.p==='news'?page(m):admPage(m);a.classList.add('an');setTimeout(()=>a.classList.remove('an'),500)}document.querySelectorAll('#bn button').forEach(b=>b.classList.remove('on'))}}
 else _R.apply(this,arguments);
 try{post();fixSet()}catch(e){console.warn('v40',e)}};
function post(){const m=me(),hx=$('#hx'),app=$('#app');
 if(m&&hx&&!hx.querySelector('.stn-btn')){const un=unreadN(m),b=document.createElement('button');b.className='stn-btn'+(V.p==='news'?' on':'');b.setAttribute('aria-label','الأخبار');b.innerHTML='📰'+(un?`<em>${un>9?'9+':un}</em>`:'');b.onclick=()=>go('news');hx.prepend(b)}
 if(m&&app&&V.p==='dash'&&!$('#stn-strip')&&!$('#x27g')){const L=list(m).slice(0,3);if(L.length){const r=readSet();app.insertAdjacentHTML('afterbegin',`<div class="card stn-strip" id="stn-strip"><div class="row"><h3>📰 آخر الأخبار</h3><button class="b s" onclick="go('news')">عرض الكل ←</button></div>${L.map(n=>{const c=CATS[n.c]||CATS.gen;return `<div class="stn-mini" style="--nc:${c[2]}" onclick="go('news')"><span>${c[0]}</span><div><b>${n.p?'📌 ':''}${esc(n.t)}</b><small>${ago2(n.d)}${!r.has(n.id)&&n.by!==m.id?' · <i>جديد</i>':''}</small></div></div>`}).join('')}</div>`)}}
 if(app&&!$('#stn-credit')&&!document.body.classList.contains('inexam'))app.insertAdjacentHTML('beforeend','<div class="stn-credit" id="stn-credit">Smart Teacher v1.0 · تطوير <b>Omar Essam Elshanab</b></div>');
 if(V.p==='news'&&m){const r=readSet();list(m).forEach(n=>r.add(n.id));putSet(rk(),r)}
}
/* ===== account: suspend / delete (self + admin) ===== */
const US=(k,f)=>{if(Array.isArray(S[k]))S[k]=S[k].filter(f)};
function purgeUser(id){const u=U(id);if(!u)return;
 if(u.role==='teacher'){const gi=new Set(S.g.filter(g=>g.t===id).map(g=>g.id)),ei=new Set(S.e.filter(e=>gi.has(e.g)).map(e=>e.id));US('s',x=>!ei.has(x.e));US('k',x=>!ei.has(x.id));US('e',e=>!gi.has(e.g));US('m',x=>!gi.has(x.g));US('g',g=>!gi.has(g.id))}
 const pid=new Set((S.f||[]).filter(x=>x.u===id).map(x=>x.id));
 US('u',x=>x.id!==id);US('f',x=>x.u!==id);US('fc',x=>x.u!==id&&!pid.has(x.p));US('fl',x=>x.u!==id&&!pid.has(x.p));US('ff',x=>x.a!==id&&x.b!==id);US('pl',x=>x.p!==id&&x.s!==id);US('s',x=>x.u!==id);US('n',x=>x.to!==id);US('p',x=>x.a!==id&&x.b!==id);US('m',x=>x.u!==id);US('nw',x=>x.by!==id);
 S.g.forEach(g=>{g.st=(g.st||[]).filter(x=>x.u!==id);if(g.as)g.as=g.as.filter(a=>a!==id)})}

/* ---- إنشاء حساب من لوحة الإدارة: بيتكتب مباشرة في القاعدة بتوكن الأدمن (من غير ما الـ Worker يتغيّر).
   كلمة المرور بتتخزن بالهاش القديم 'h:…' والـ Worker بيحوّلها لـ PBKDF2 أول ما صاحب الحساب يدخل ---- */
const ADM_PW=()=>Array.from(crypto.getRandomValues(new Uint8Array(10)),b=>'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b%55]).join('');
const ADM_ROLES=[['student','🎓 طالب'],['teacher','👨‍🏫 مدرس'],['assistant','🧑‍🏫 مدرس مساعد'],['parent','👪 ولي أمر']];
async function admMake(u,password){
  const em=String(u.email||'').trim().toLowerCase(),ph=String(u.phone||'').trim(),name=String(u.name||'').trim();
  if(!name)throw{dup:'اكتب الاسم'};
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em))throw{dup:'البريد الإلكتروني غير صحيح'};
  if(!ADM_ROLES.some(r=>r[0]===u.role))throw{dup:'نوع الحساب غير صحيح'};
  if(S.u.some(x=>(x.email||'').toLowerCase()===em))throw{dup:'البريد ده مستخدم بالفعل'};
  if(ph&&u.role!=='parent'&&S.u.some(x=>x.role===u.role&&x.phone===ph))throw{dup:'رقم الموبايل ده مستخدم بنفس نوع الحساب'};
  const pw=password||ADM_PW(),id=uid(),rec={id,name,email:em,phone:ph,role:u.role,ok:1,pv:1,ev:1,by:'admin'};if(u.sj)rec.sj=String(u.sj).trim().slice(0,60);
  const tk=await idToken(true),rr=await fetch(DB+'/db/u/'+encodeURIComponent(id)+'.json?auth='+tk,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({...rec,pw:await hp(pw)})});
  if(!rr.ok)throw new Error('db '+rr.status);
  S.u.push(rec);aud&&aud('إنشاء حساب '+name+' ('+u.role+')');return{rec,pw}}
const askc=t=>window.ask?ask(t):Promise.resolve(confirm(t));
function modal(h){const bg=document.createElement('div');bg.className='askbg';bg.innerHTML='<div class="askbx" role="dialog" aria-modal="true">'+h+'</div>';bg.onclick=e=>{if(e.target===bg)bg.remove()};document.body.appendChild(bg);return bg}
const outNow=t=>{S.me=null;V={p:'dash'};save();R();toast(t)};
window.stAcc={
 async suspend(){const m=me();if(!m||!await askc('هيتم إيقاف حسابك مؤقتاً وتسجيل خروجك. تقدر ترجّعه في أي وقت بمجرد تسجيل الدخول بنفس البريد وكلمة المرور. متأكد؟'))return;m.sus=1;m.sb='self';m.sd=Date.now();outNow('⏸️ تم إيقاف حسابك — سجّل دخول لإعادة تفعيله')},
 del(){const m=me();if(!m)return;const t=m.role==='teacher';const bg=modal(`<h3>🗑️ حذف الحساب نهائياً</h3><p class="mut">${t?'سيتم حذف كل مجموعاتك وامتحاناتك ورسائلها ونتائج طلابك فيها.':'سيتم حذف بياناتك ودرجاتك ومشاركاتك.'} لا يمكن التراجع عن هذا الإجراء.</p><input type="password" id="stdp" placeholder="كلمة المرور الحالية" autocomplete="current-password"><input id="stdw" placeholder="اكتب كلمة «حذف» للتأكيد"><div class="row"><button class="b s" id="stdx">إلغاء</button><button class="b r" id="stdo">حذف نهائي</button></div>`);
  bg.querySelector('#stdx').onclick=()=>bg.remove();
  bg.querySelector('#stdo').onclick=async()=>{const pw=bg.querySelector('#stdp').value,w=bg.querySelector('#stdw').value.trim();if(w!=='حذف')return toast('اكتب كلمة «حذف» للتأكيد');const h=await hp(pw);if(!pw||!(m.pw===pw||m.pw===h))return toast('كلمة المرور غير صحيحة');bg.remove();purgeUser(m.id);outNow('تم حذف حسابك نهائياً')}}};
window.delAcc=()=>{go('set',undefined,'account');setTimeout(()=>$('#st-danger')?.scrollIntoView({behavior:'smooth',block:'center'}),120)};
const dangerCard=()=>`<div class="card st-danger" id="st-danger"><h3>⚙️ إدارة حالة الحساب</h3><div class="st-dz"><div><b>⏸️ إيقاف الحساب مؤقتاً</b><p class="mut">يختفي حسابك ولا تستطيع استخدامه حتى تسجّل الدخول مرة أخرى، وبياناتك تبقى محفوظة.</p></div><button class="b s" onclick="stAcc.suspend()">إيقاف</button></div><div class="st-dz del"><div><b>🗑️ حذف الحساب نهائياً</b><p class="mut">يحذف حسابك وكل بياناتك ولا يمكن استرجاعها.</p></div><button class="b r" onclick="stAcc.del()">حذف</button></div></div>`;
if(typeof login==='function'){const _l=login;login=async function(){try{const i=(RF.em||'').trim().toLowerCase(),pw=RF.pw||'';if(i&&pw){const h=await hp(pw),u=S.u.find(x=>(x.email===i||(typeof wn==='function'&&wn(x.phone)&&wn(x.phone)===wn(i)))&&x.pw&&(x.pw===pw||x.pw===h));if(u&&u.sus){if(u.sb==='admin')return toast('⛔ حسابك موقوف من الإدارة. تواصل مع الدعم لإعادة التفعيل');delete u.sus;delete u.sb;delete u.sd;save();toast('✅ أهلاً بعودتك — تم إعادة تفعيل حسابك')}}}catch(e){}return _l.apply(this,arguments)}}
/* admin: manage accounts */
let admRows=us=>us.length?us.map(u=>`<div class="st-ar"><div class="st-ai"><b>${esc(u.name||'—')}</b><small>${esc(stRoleLabel(u.role))} · <span dir="ltr">${esc(u.email||u.phone||'')}</span></small></div>${u.sus?`<span class="tag st-sus">${u.sb==='self'?'موقوف (بطلبه)':'موقوف'}</span>`:''}<div class="st-ab"><button class="b s" onclick="stA.sus('${u.id}')">${u.sus?'▶️ تفعيل':'⏸️ إيقاف'}</button><button class="b r" onclick="stA.del('${u.id}')">🗑️</button></div></div>`).join(''):'<p class="mut">لا نتائج</p>';
let admList=()=>{const q=(NS.aq||'').trim().toLowerCase(),a=S.u.filter(u=>u.role!=='admin'&&(!q||((u.name||'')+' '+(u.email||'')+' '+(u.phone||'')).toLowerCase().includes(q)));return admRows(a.slice(0,50))+(a.length>50?`<p class="mut">يظهر أول 50 من ${a.length} — استخدم البحث</p>`:'')};
window.stA={q(v){NS.aq=v;const l=$('#st-adm-list');if(l)l.innerHTML=admList()},
 sus(id){const u=U(id);if(!(adm(me())||ADMOK())||!u||u.role==='admin'||id===S.me)return;if(u.sus){delete u.sus;delete u.sb;delete u.sd;toast('تم تفعيل الحساب')}else{u.sus=1;u.sb='admin';u.sd=Date.now();toast('تم إيقاف الحساب')}save();stA.q(NS.aq||'')},
 async del(id){const u=U(id);if(!(adm(me())||ADMOK())||!u||u.role==='admin')return;if(id===S.me)return toast('لا يمكنك حذف حسابك من هنا');if(!await askc('حذف حساب «'+u.name+'» نهائياً مع بياناته؟'))return;purgeUser(id);save();stA.q(NS.aq||'');toast('تم حذف الحساب')}};
if(typeof stAdmin==='function'){const _sa=stAdmin;stAdmin=function(){let h=_sa.apply(this,arguments);if(typeof h!=='string'||!adm(me()))return h;h=h.replace('ADMIN CONSOLE','ADMIN CONSOLE').replace('ومن أدوات الإدارة بالأسفل تتحكم في الحسابات والمظهر والبيانات.','يمكنك إيقاف الحسابات أو حذفها من قسم «إدارة الحسابات» بالأسفل.');return h+`<div class="card" id="st-adm-users"><h3>👥 إدارة الحسابات</h3><input class="srch" placeholder="🔍 ابحث بالاسم أو البريد أو الهاتف…" value="${esc(NS.aq||'')}" oninput="stA.q(this.value)"><div id="st-adm-list">${admList()}</div></div>`}}
/* settings layout: parent code at top of account tab, direct jump from dashboard */
window.stGoCode=()=>{NS.focus=1;go('set',undefined,'account')};
function fixSet(){const m=me();if(!m)return;
 if(m.role==='parent'){document.querySelectorAll('#hx button').forEach(b=>{if(b.textContent.includes('🔎'))b.remove()});document.querySelectorAll('#app .card').forEach(c=>{const t=c.querySelector('h3')?.textContent||'';if(/أدواتي|اللغة المفضلة للذكاء/.test(t))c.remove()});document.querySelectorAll('#app button[onclick*="go(\'ai\')"]').forEach(b=>b.remove())}
 if(V.p==='dash')document.querySelectorAll('button[onclick="go(\'set\')"]').forEach(b=>{if(b.textContent.trim()==='الكود')b.setAttribute('onclick','stGoCode()')});
 if(V.p!=='set')return;const tab=V.t||'preferences',pc=document.querySelector('.pcode')?.closest('.card'),sh=document.querySelector('button[onclick="shr()"]')?.closest('.card'),host=document.querySelector('.st-settings-content');
 if(sh)sh.style.display=tab==='about'?'':'none';
 if(pc){pc.id='stn-pcard';if(tab==='account'){if(host){const f=host.firstElementChild;if(f&&f!==pc&&f.nextElementSibling!==pc)f.after(pc)}pc.style.display=''}else pc.style.display='none'}
 if(tab==='account'&&['teacher','student','assistant'].includes(m.role)&&!$('#st-admgate'))(host||$('#app')).insertAdjacentHTML('beforeend',gateCard());
 if(tab==='account'&&!$('#st-logout'))(host||$('#app')).insertAdjacentHTML('beforeend','<div class="card" id="st-logout"><h3>🚪 تسجيل الخروج</h3><p class="mut">اخرج من حسابك على الجهاز ده. بياناتك محفوظة وتقدر ترجع تدخل في أي وقت.</p><button class="b s" onclick="S.me=null;save();go(\'dash\')">تسجيل الخروج</button></div>');if(tab==='account'&&m.role!=='admin'&&!$('#st-danger')){(host||$('#app')).insertAdjacentHTML('beforeend',dangerCard())}
 if(tab==='account'&&NS.focus&&pc){NS.focus=0;pc.classList.add('st-flash');setTimeout(()=>pc.scrollIntoView({behavior:'smooth',block:'center'}),80);setTimeout(()=>pc.classList.remove('st-flash'),2600)}}
/* performance: المزامنة الذكية بقت جوه pull() نفسها (ETag لكل collection + collections الصفحة الحالية فقط) */

/* ===== admin entry (passcode) ===== */
const AH={s:'fd1d664078ea55cad7f764911f6b4b88af49e672c3326b8e6fd62b5082c1398e',c:'1ytd716bfk2'};
const cy=s=>{let a=3735928559,b=1103547991;for(let i=0;i<s.length;i++){const x=s.charCodeAt(i);a=Math.imul(a^x,2654435761);b=Math.imul(b^x,1597334677)}a=Math.imul(a^a>>>16,2246822507)^Math.imul(b^b>>>13,3266489909);b=Math.imul(b^b>>>16,2246822507)^Math.imul(a^a>>>13,3266489909);return(4294967296*(2097151&b)+(a>>>0)).toString(36)};
async function passOk(p){const t='stadm|'+p;try{if(crypto?.subtle){const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,'0')).join('')===AH.s}}catch(e){}return cy(t)===AH.c}
function ADMOK(){try{return sessionStorage.getItem('st_adm')==='1'}catch(e){return false}}
const gateCard=()=>`<div class="card" id="st-admgate"><h3>🛡️ دخول الإدارة</h3><p class="mut">مخصص للمشرف العام للمنصة فقط. تحتاج الرقم السري للدخول.</p><button class="b" onclick="stAdmG.open()">${ADMOK()?'🛡️ فتح لوحة الإدارة':'🔐 دخول الإدارة'}</button></div>`;
window.stAdmG={
 open(){if(ADMOK())return go('stadm');
  const f=jget('st_adm_f',{n:0,t:0});if(f.n>=5&&Date.now()-f.t<3e5)return toast('⛔ محاولات كثيرة خاطئة — حاول بعد 5 دقائق');
  const bg=modal(`<h3>🛡️ دخول الإدارة</h3><p class="mut">أدخل الرقم السري</p><input type="password" id="stap" placeholder="الرقم السري" autocomplete="off"><div class="row"><button class="b s" id="stax">إلغاء</button><button class="b" id="stao">دخول</button></div>`);
  const inp=bg.querySelector('#stap');setTimeout(()=>inp.focus(),60);bg.querySelector('#stax').onclick=()=>bg.remove();
  const go2=async()=>{const g=jget('st_adm_f',{n:0,t:0});if(g.n>=5&&Date.now()-g.t<3e5){bg.remove();return toast('⛔ محاولات كثيرة خاطئة — حاول بعد 5 دقائق')}
   if(await passOk(inp.value)){try{sessionStorage.setItem('st_adm','1');localStorage.removeItem('st_adm_f')}catch(e){}bg.remove();toast('🛡️ تم الدخول إلى وضع الإدارة');go('stadm')}
   else{const n=(Date.now()-g.t<3e5?g.n:0)+1;try{localStorage.setItem('st_adm_f',JSON.stringify({n,t:Date.now()}))}catch(e){}inp.value='';toast('❌ الرقم السري غير صحيح'+(n>=5?' — تم إيقاف المحاولات 5 دقائق':''))}};
  bg.querySelector('#stao').onclick=go2;inp.onkeydown=e=>{if(e.key==='Enter')go2()}},
 exit(){try{sessionStorage.removeItem('st_adm')}catch(e){}toast('تم الخروج من وضع الإدارة');go('dash')}};
function admPage(m){const old=m.role,bar=`<div class="card st-admbar"><div><b>🛡️ وضع الإدارة</b><small class="mut"> — جلسة مؤقتة تنتهي بإغلاق التطبيق</small></div><button class="b s" onclick="stAdmG.exit()">🚪 خروج من الإدارة</button></div>`;let h='';if(old!=='admin')m.role='admin';try{h=typeof stAdmin==='function'?stAdmin():''}finally{m.role=old}return bar+h}
if(typeof window.x22_pal==='function'){const _p=window.x22_pal;window.x22_pal=function(){if(me()?.role==='parent')return;return _p.apply(this,arguments)}}

/* ===== v1.0: config store, admin suite, widgets, appearance ===== */
const cfg=id=>(S.cf||[]).find(x=>x.id===id);
const setCfg=(id,o)=>{S.cf=S.cf||[];const x=cfg(id);x?Object.assign(x,o):S.cf.push(Object.assign({id},o));save()};
const dl=(name,txt,type)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:type||'application/json'}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)};
const dstr=()=>new Date().toISOString().slice(0,10);
const sha=async t=>{try{if(crypto?.subtle){const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}return ''};
passOk=async function(p){const t='stadm|'+p,c=cfg('admpw'),hx=await sha(t);if(c)return hx?c.h===hx:cy(t)===c.c;return hx?hx===AH.s:cy(t)===AH.c};
const pct=s=>{try{const v=score(E(s.e),s);return typeof v==='number'&&isFinite(v)?v:null}catch(e){return null}};
const avgOf=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length):null;
const rnd=()=>{const a='abcdefghjkmnpqrstuvwxyz23456789';let r='';for(let i=0;i<8;i++)r+=a[Math.floor(Math.random()*a.length)];return r};
function purgeGroup(id){const ei=new Set(S.e.filter(e=>e.g===id).map(e=>e.id));US('s',x=>!ei.has(x.e));US('k',x=>!ei.has(x.id));US('e',e=>e.g!==id);US('m',x=>x.g!==id);US('g',g=>g.id!==id)}
const canA=()=>adm(me())||ADMOK();
/* ---- admin tabs ---- */
const ATABS=[['o','📈 تحليلات'],['p','🔬 متقدم'],['u','👥 الحسابات'],['g','📚 المجموعات'],['b','📣 البث'],['d','🎨 المظهر'],['f','🧩 الأقسام'],['t','✏️ النصوص'],['l','🧾 السجل'],['m','🧰 البيانات'],['s','🔐 الأمان']];
NS.at='o';NS.ar='all';
const tile=(i,l,v)=>`<div class="st-tile"><span>${i}</span><b>${v}</b><small>${l}</small></div>`;
function tabO(){const d0=new Date();d0.setHours(0,0,0,0);const days=[...Array(7)].map((_,i)=>d0.getTime()-(6-i)*864e5),cn=days.map(t=>S.s.filter(s=>s.d>=t&&s.d<t+864e5).length),mx=Math.max(1,...cn);
 const sc=S.s.map(pct).filter(x=>x!==null),by={};S.s.forEach(s=>{const v=pct(s);if(v!==null)(by[s.u]=by[s.u]||[]).push(v)});
 const top=Object.entries(by).map(([u,a])=>[u,avgOf(a),a.length]).sort((a,b)=>b[1]-a[1]||b[2]-a[2]).slice(0,5);
 const gt=S.g.slice().sort((a,b)=>(b.st||[]).length-(a.st||[]).length).slice(0,5);
 return `<div class="st-tiles">${tile('👥','الحسابات',S.u.length)}${tile('📝','التسليمات',S.s.length)}${tile('🎯','متوسط الدرجات',sc.length?avgOf(sc)+'%':'—')}${tile('⛔','حسابات موقوفة',S.u.filter(u=>u.sus).length)}</div>
 <h4>📅 التسليمات آخر 7 أيام</h4><div class="st-bars">${cn.map((v,i)=>`<div><i style="height:${Math.max(4,v/mx*80)}px"></i><b>${v}</b><small>${new Date(days[i]).toLocaleDateString('ar-EG',{weekday:'short'})}</small></div>`).join('')}</div>
 <h4>🏆 أفضل الطلاب</h4>${top.length?top.map((t,i)=>`<div class="st-ar"><b>${i+1}.</b><div class="st-ai"><b>${esc(U(t[0])?.name||'—')}</b><small>${t[2]} تسليم</small></div><span class="tag">${t[1]}%</span></div>`).join(''):'<p class="mut">لا بيانات بعد</p>'}
 <h4>📚 أكبر المجموعات</h4>${gt.length?gt.map(g=>`<div class="st-ar"><div class="st-ai"><b>${esc(g.title||'—')}</b><small>${esc(U(g.t)?.name||'')}</small></div><span class="tag">${(g.st||[]).length} طالب</span></div>`).join(''):'<p class="mut">لا مجموعات</p>'}`}
function tabU(){const rs=[['all','الكل'],['teacher','المعلمون'],['student','الطلاب'],['parent','أولياء الأمور'],['assistant','المساعدون'],['sus','الموقوفون']];
 return `<button class="b" style="width:100%;margin-bottom:10px" onclick="stA.newAcc()">➕ إنشاء حساب جديد (طالب / مدرس / مدرس مساعد / ولي أمر)</button><button class="b s" style="width:100%;margin-bottom:10px" onclick="stA.bulk()">📥 استيراد حسابات كتير مرة واحدة</button><div class="stn-chips sm">${rs.map(r=>`<button class="${NS.ar===r[0]?'on':''}" onclick="stA.rf('${r[0]}')">${r[1]}</button>`).join('')}</div><input class="srch" placeholder="🔍 ابحث بالاسم أو البريد أو الهاتف…" value="${esc(NS.aq||'')}" oninput="stA.q(this.value)"><div id="st-adm-list">${admList()}</div><button class="b s" style="margin-top:8px" onclick="stA.csv()">⬇️ تصدير الحسابات CSV</button>`}
function tabG(){return S.g.length?S.g.map(g=>`<div class="st-ar"><div class="st-ai"><b>${esc(g.title||'—')} ${g.lock?'🔒':''}</b><small>${esc(U(g.t)?.name||'—')} · ${(g.st||[]).length} طالب · ${S.e.filter(e=>e.g===g.id).length} امتحان · <span dir="ltr">${esc(g.code||'')}</span></small></div><div class="st-ab"><button class="b s" onclick="stA.glock('${g.id}')">${g.lock?'🔓':'🔒'}</button><button class="b r" onclick="stA.gdel('${g.id}')">🗑️</button></div></div>`).join(''):'<p class="mut">لا توجد مجموعات</p>'}
function tabB(){const b=cfg('banner')||{};return `<h4>📢 شريط إعلان أعلى المنصة</h4><p class="mut">يظهر لكل المستخدمين فوق كل الصفحات.</p><textarea id="sbt" rows="2" maxlength="240" placeholder="مثال: صيانة مجدولة الجمعة 10 مساءً">${esc(b.t||'')}</textarea><div class="row"><select id="sbk"><option value="info" ${b.k!=='warn'?'selected':''}>📣 معلومة</option><option value="warn" ${b.k==='warn'?'selected':''}>⚠️ تنبيه</option></select><button class="b s" onclick="stA.bnr(0)">إيقاف الشريط</button><button class="b" onclick="stA.bnr(1)">نشر الشريط</button></div>${b.on&&b.t?'<p class="mut">✅ الشريط الحالي مفعّل</p>':''}
 <h4>🔔 إشعار مباشر لفئة</h4><textarea id="sbn" rows="2" maxlength="200" placeholder="نص الإشعار…"></textarea><div class="row"><select id="sba"><option value="all">الجميع</option><option value="teacher">المعلمون</option><option value="student">الطلاب</option><option value="parent">أولياء الأمور</option><option value="assistant">المساعدون</option></select><button class="b" onclick="stA.bc()">إرسال</button></div>`}
function tabM(){const kb=Math.round(JSON.stringify(S).length/1024);return `<div class="st-tiles">${tile('💾','حجم البيانات',kb+' KB')}${tile('📚','مجموعات',S.g.length)}${tile('📝','امتحانات',S.e.length)}${tile('💬','رسائل',S.m.length)}</div>
 <div class="st-dz"><div><b>⬇️ نسخة احتياطية</b><p class="mut">ملف JSON بكل بيانات المنصة (يحتوي على بيانات الحسابات — احفظه في مكان آمن).</p></div><button class="b" onclick="stA.bk()">تحميل</button></div>
 <div class="st-dz"><div><b>⬆️ استعادة نسخة</b><p class="mut">يستبدل بيانات المنصة الحالية بمحتوى الملف.</p></div><button class="b s" onclick="$('#strf').click()">اختيار ملف</button><input type="file" id="strf" accept=".json,application/json" hidden onchange="stA.rs(this)"></div>
 <div class="st-dz"><div><b>🧹 تنظيف البيانات</b><p class="mut">يحذف الإشعارات المقروءة القديمة (+30 يوماً) والبيانات اليتيمة والأخبار المنتهية.</p></div><button class="b s" onclick="stA.cl()">تنظيف</button></div>`}
function tabS(){const c=cfg('admpw');return `<h4>🔑 تغيير الرقم السري للإدارة</h4><p class="mut">الرقم الحالي: ${c?'مخصّص (آخر تغيير '+new Date(c.u).toLocaleDateString('ar-EG')+')':'الافتراضي'} — يُطبَّق على كل الأجهزة.</p><input type="password" id="spc" placeholder="الرقم السري الحالي" autocomplete="off"><input type="password" id="spn" placeholder="الرقم الجديد (6 أحرف على الأقل)" autocomplete="off"><input type="password" id="spr" placeholder="تأكيد الرقم الجديد" autocomplete="off"><button class="b" onclick="stA.pc()">💾 حفظ الرقم الجديد</button>
 <p class="mut">⚠️ احفظ الرقم الجديد؛ لو نسيته يلزم تعديل إعداد <code>cf</code> يدوياً في Firebase.</p>${ADMOK()?'<div class="st-dz"><div><b>🚪 إنهاء وضع الإدارة</b></div><button class="b s" onclick="stAdmG.exit()">خروج</button></div>':''}`}
const admBody=()=>({x:tabX,c:tabC,n:tabN,w:tabW,o:tabO,u:tabU,g:tabG,b:tabB,m:tabM,d:tabD,th:tabTH,p:tabP,f:tabF,t:tabT,l:tabL,s:tabS,sub:()=>window.stSub?window.stSub.tab():''}[NS.at]||(window.stTabs&&window.stTabs[NS.at])||tabO)();
const admTools=()=>`<div class="card" id="st-admtools"><h3>🛠️ أدوات الإدارة</h3><div class="stn-chips">${ATABS.map(t=>`<button class="${NS.at===t[0]?'on':''}" onclick="stA.tab('${t[0]}')">${t[1]}</button>`).join('')}</div><div id="st-admbody">${admBody()}</div></div>`;
const rb=()=>{const e=$('#st-admtools');if(e)e.outerHTML=admTools()};
admList=function(){const q=(NS.aq||'').trim().toLowerCase(),r=NS.ar||'all',a=S.u.filter(u=>u.role!=='admin'&&(r==='all'||(r==='sus'?u.sus:u.role===r))&&(!q||((u.name||'')+' '+(u.email||'')+' '+(u.phone||'')).toLowerCase().includes(q)));return admRows(a.slice(0,50))+(a.length>50?`<p class="mut">يظهر أول 50 من ${a.length} — استخدم البحث</p>`:'')};
Object.assign(window.stA,{
 tab(t){NS.at=t;rb()},rf(r){NS.ar=r;rb()},
 csv(){if(!canA())return;const rows=[['الاسم','الدور','البريد','الهاتف','الحالة'],...S.u.filter(u=>u.role!=='admin').map(u=>[u.name,stRoleLabel(u.role),u.email,u.phone,u.sus?'موقوف':'نشط'])];dl('accounts-'+dstr()+'.csv','\ufeff'+rows.map(r=>r.map(c=>'"'+String(c||'').replace(/"/g,'""')+'"').join(',')).join('\n'),'text/csv')},
 glock(id){if(!canA())return;const g=G(id);if(!g)return;g.lock=g.lock?0:1;save();rb();toast(g.lock?'تم قفل المجموعة':'تم فتح المجموعة')},
 async gdel(id){if(!canA())return;const g=G(id);if(!g||!await askc('حذف مجموعة «'+g.title+'» وكل امتحاناتها ورسائلها؟'))return;purgeGroup(id);save();rb();toast('تم حذف المجموعة')},
 bnr(on){if(!canA())return;const t=$('#sbt').value.trim();if(on&&!t)return toast('اكتب نص الشريط');setCfg('banner',{on:on?1:0,t,k:$('#sbk').value});try{sessionStorage.removeItem('st_bd')}catch(e){}R();toast(on?'📢 تم نشر الشريط':'تم إيقاف الشريط')},
 bc(){if(!canA())return;const t=$('#sbn').value.trim(),a=$('#sba').value;if(t.length<3)return toast('اكتب نص الإشعار');const us=S.u.filter(u=>u.role!=='admin'&&(a==='all'||u.role===a)).slice(0,500);us.forEach(u=>S.n.unshift({id:uid(),to:u.id,txt:'📣 '+t,r:0,d:Date.now()}));save();$('#sbn').value='';toast('تم إرسال الإشعار إلى '+us.length+' مستخدم')},
 bk(){if(!canA())return;const data={};COLS.forEach(c=>data[c]=S[c]||[]);dl('smart-teacher-backup-'+dstr()+'.json',JSON.stringify({app:'smart-teacher',v:'4.1',t:Date.now(),data}));toast('⬇️ تم تحميل النسخة الاحتياطية')},
 rs(inp){if(!canA())return;const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=async()=>{try{const d=JSON.parse(r.result).data;if(!d||!Array.isArray(d.u))throw 0;if(!await askc('سيتم استبدال كل بيانات المنصة الحالية بمحتوى هذه النسخة. متأكد؟'))return;COLS.forEach(c=>{if(Array.isArray(d[c]))S[c]=d[c]});save();R();toast('✅ تمت استعادة النسخة')}catch(e){toast('❌ ملف غير صالح')}};r.readAsText(f)},
 cl(){if(!canA())return;const n0=JSON.stringify(S).length,cut=Date.now()-30*864e5;US('n',x=>!(x.r&&x.d<cut));US('nw',x=>!(x.ex&&Date.parse(x.ex)+30*864e5<Date.now()));const gi=new Set(S.g.map(g=>g.id));US('e',e=>gi.has(e.g));const ei=new Set(S.e.map(e=>e.id));US('s',x=>ei.has(x.e));US('k',x=>ei.has(x.id));US('m',x=>!x.g||gi.has(x.g));const ui=new Set(S.u.map(u=>u.id));S.g.forEach(g=>{g.st=(g.st||[]).filter(x=>ui.has(x.u))});save();rb();toast('🧹 تم التنظيف — وُفّر '+Math.max(0,Math.round((n0-JSON.stringify(S).length)/1024))+' KB')},
 async pw(id){if(!canA())return;const u=U(id);if(!u||u.role==='admin'||!await askc('إنشاء كلمة مرور مؤقتة جديدة لـ «'+u.name+'»؟'))return;
  let t=ADM_PW();try{const tk=await idToken(true),r=await fetch(DB+'/db/u/'+encodeURIComponent(id)+'/pw.json?auth='+tk,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(await hp(t))});if(!r.ok)throw new Error('db '+r.status)}catch(e){return toast('تعذر تغيير كلمة المرور ('+(e&&e.message||'خطأ')+') — سجّل خروج وادخل بحساب الإدارة تاني')}
  if(!t)return toast('تعذر تغيير كلمة المرور');
  aud&&aud('تغيير كلمة مرور '+u.name);const bg=modal(`<h3>🔑 كلمة المرور المؤقتة</h3><p class="mut">سلّمها لـ ${esc(u.name)} وانصحه بتغييرها بعد الدخول (الإعدادات ← الحساب):</p><div class="pcode" dir="ltr" style="font-size:26px;text-align:center;letter-spacing:2px">${t}</div><div class="row"><button class="b s" id="sx1">نسخ</button><button class="b" id="sx2">تم</button></div>`);bg.querySelector('#sx1').onclick=()=>navigator.clipboard?.writeText(t).then(()=>toast('تم النسخ'));bg.querySelector('#sx2').onclick=()=>bg.remove()},

 bulk(){if(!canA())return;
  const bg=modal(`<h3>📥 استيراد حسابات (لصق قائمة)</h3><p class="mut">سطر لكل حساب بالشكل ده (الموبايل والتخصص اختياريين):<br><span dir="ltr" style="display:block;text-align:left">الاسم, البريد, الموبايل, النوع, التخصص</span>النوع: طالب / مدرس / مساعد / ولي أمر. لو سبته فاضي هياخد النوع اللي تختاره تحت.</p>
   <label>النوع الافتراضي</label><select id="bk-r">${ADM_ROLES.map(r=>`<option value="${r[0]}">${r[1]}</option>`).join('')}</select>
   <textarea id="bk-t" rows="8" dir="auto" placeholder="أحمد علي, ahmed@mail.com, 01012345678, طالب&#10;سارة محمد, sara@mail.com, , مدرس, رياضيات"></textarea>
   <div class="row" style="margin-top:10px"><button class="b" id="bk-ok">إنشاء الحسابات</button><button class="b s" id="bk-x">إلغاء</button></div><div id="bk-out"></div>`);
  const g=i=>bg.querySelector('#'+i);g('bk-x').onclick=()=>bg.remove();
  const MAP={'طالب':'student','student':'student','مدرس':'teacher','معلم':'teacher','teacher':'teacher','مساعد':'assistant','مدرس مساعد':'assistant','assistant':'assistant','ولي أمر':'parent','ولي امر':'parent','ولي':'parent','parent':'parent'};
  g('bk-ok').onclick=async()=>{const lines=g('bk-t').value.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);if(!lines.length)return toast('الصق القائمة الأول');if(lines.length>200)return toast('الحد الأقصى 200 حساب في المرة');
   const btn=g('bk-ok');btn.disabled=true;const out=[],dflt=g('bk-r').value;let okn=0;
   for(const ln of lines){const c=ln.split(/[,،;\t]/).map(x=>x.trim());const rl=c[3]?(MAP[c[3].toLowerCase()]||''):dflt;
    try{if(!rl)throw{dup:'نوع غير مفهوم «'+c[3]+'»'};const {rec,pw}=await admMake({name:c[0],email:c[1],phone:c[2]||'',role:rl,sj:c[4]||''});okn++;out.push({ok:1,n:rec.name,e:rec.email,r:rl,p:pw})}
    catch(e){out.push({ok:0,n:c[0]||ln,e:c[1]||'',m:e&&e.dup?e.dup:'خطأ ('+(e&&e.message||'')+')'})}}
   const rows=out.map(o=>o.ok?`<tr><td>✅</td><td>${esc(o.n)}</td><td dir="ltr">${esc(o.e)}</td><td dir="ltr"><b>${esc(o.p)}</b></td></tr>`:`<tr><td>❌</td><td>${esc(o.n)}</td><td colspan="2">${esc(o.m)}</td></tr>`).join('');
   g('bk-out').innerHTML=`<p class="mut">تم إنشاء <b>${okn}</b> من ${lines.length}. حمّل الملف دلوقتي — كلمات المرور مش هتظهر تاني.</p><div style="overflow:auto;max-height:200px"><table class="tbl" style="width:100%;font-size:12px"><tbody>${rows}</tbody></table></div><div class="row" style="margin-top:8px"><button class="b" id="bk-dl">⬇️ تحميل الحسابات الجديدة (CSV)</button></div>`;
   g('bk-dl').onclick=()=>{const csv='\ufeffالاسم,البريد,كلمة المرور,النوع\n'+out.filter(o=>o.ok).map(o=>[o.n,o.e,o.p,o.r].map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='new-accounts.csv';document.body.appendChild(a);a.click();a.remove()};
   btn.disabled=false;btn.textContent='إنشاء حسابات تانية';try{await pull('all')}catch(e){}R()}},
 newAcc(){if(!canA())return;const RL=[['student','🎓 طالب'],['teacher','👨‍🏫 مدرس'],['assistant','🧑‍🏫 مدرس مساعد'],['parent','👪 ولي أمر']];
  const bg=modal(`<h3>➕ إنشاء حساب جديد</h3><p class="mut">الحساب بيتفعّل فوراً (من غير كود تأكيد) ويقدر يدخل بالإيميل وكلمة المرور.</p>
   <label>نوع الحساب</label><select id="na-r">${RL.map(r=>`<option value="${r[0]}">${r[1]}</option>`).join('')}</select>
   <label>الاسم</label><input id="na-n" placeholder="الاسم الكامل" maxlength="80">
   <label>البريد الإلكتروني</label><input id="na-e" type="email" dir="ltr" placeholder="name@example.com">
   <label>رقم الموبايل (اختياري)</label><input id="na-p" type="tel" dir="ltr" placeholder="01xxxxxxxxx">
   <div id="na-sjw"><label>التخصص / المادة (اختياري)</label><input id="na-s" placeholder="مثال: رياضيات" maxlength="60"></div>
   <label>كلمة المرور (سيبها فاضية وهنولّدها)</label><div class="row"><input id="na-w" dir="ltr" placeholder="6 أحرف على الأقل" style="flex:1"><button class="b s" type="button" id="na-g">🎲 توليد</button></div>
   <div class="row" style="margin-top:10px"><button class="b" id="na-ok">إنشاء الحساب</button><button class="b s" id="na-x">إلغاء</button></div>`);
  const g=i=>bg.querySelector('#'+i),sj=()=>{g('na-sjw').style.display=['teacher','assistant'].includes(g('na-r').value)?'':'none'};g('na-r').onchange=sj;sj();
  g('na-g').onclick=()=>{g('na-w').value=ADM_PW()};
  g('na-x').onclick=()=>bg.remove();
  g('na-ok').onclick=async()=>{const body={user:{role:g('na-r').value,name:g('na-n').value.trim(),email:g('na-e').value.trim(),phone:g('na-p').value.trim(),sj:g('na-s').value.trim()},password:g('na-w').value.trim()||undefined};
   if(!body.user.name)return toast('اكتب الاسم');if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(body.user.email))return toast('اكتب بريد إلكتروني صحيح');if(body.password&&body.password.length<6)return toast('كلمة المرور 6 أحرف على الأقل');
   const btn=g('na-ok');btn.disabled=true;
   try{const {rec,pw}=await admMake(body.user,body.password);bg.remove();
     const L=RL.find(x=>x[0]===body.user.role)[1];
     const b2=modal(`<h3>✅ تم إنشاء الحساب</h3><p class="mut">${esc(L)} — ${esc(body.user.name)}</p><div class="pcode" dir="ltr" style="text-align:center">${esc(body.user.email)}<br>${esc(pw)}</div><p class="mut">سلّم البيانات دي للمستخدم (الإيميل + كلمة المرور). كلمة المرور مش هتظهر تاني.</p><div class="row"><button class="b s" id="na-c">نسخ</button><button class="b" id="na-d">تم</button></div>`);
     b2.querySelector('#na-c').onclick=()=>navigator.clipboard?.writeText(body.user.email+'\n'+pw).then(()=>toast('تم النسخ'));b2.querySelector('#na-d').onclick=()=>b2.remove();
     try{await pull('all')}catch(e){}R()}
   catch(e){btn.disabled=false;toast(e&&e.dup?e.dup:'تعذر إنشاء الحساب ('+(e&&e.message||'خطأ')+') — سجّل خروج وادخل بحساب الإدارة تاني')}}},
 role(id){if(!canA())return;const u=U(id);if(!u||u.role==='admin')return;const bg=modal(`<h3>🔄 تغيير دور «${esc(u.name)}»</h3><select id="srl">${['student','parent','teacher','assistant'].map(r=>`<option value="${r}" ${u.role===r?'selected':''}>${stRoleLabel(r)}</option>`).join('')}</select><div class="row"><button class="b s" id="sx1">إلغاء</button><button class="b" id="sx2">حفظ</button></div>`);bg.querySelector('#sx1').onclick=()=>bg.remove();bg.querySelector('#sx2').onclick=()=>{u.role=bg.querySelector('#srl').value;save();bg.remove();rb();toast('تم تغيير الدور')}},
 async pc(){if(!canA())return;const c=$('#spc').value,n=$('#spn').value,r=$('#spr').value;if(!await passOk(c))return toast('❌ الرقم الحالي غير صحيح');if(n.length<6)return toast('الرقم الجديد قصير (6 أحرف على الأقل)');if(n!==r)return toast('التأكيد غير مطابق');setCfg('admpw',{h:await sha('stadm|'+n),c:cy('stadm|'+n),u:Date.now()});rb();toast('✅ تم تغيير الرقم السري')}});
admRows=us=>us.length?us.map(u=>`<div class="st-ar"><div class="st-ai"><b>${esc(u.name||'—')}</b><small>${esc(stRoleLabel(u.role))} · <span dir="ltr">${esc(u.email||u.phone||'')}</span></small></div>${u.sus?`<span class="tag st-sus">${u.sb==='self'?'موقوف (بطلبه)':'موقوف'}</span>`:''}<div class="st-ab"><button class="b s" title="إيقاف/تفعيل" onclick="stA.sus('${u.id}')">${u.sus?'▶️':'⏸️'}</button><button class="b s" title="كلمة مرور مؤقتة" onclick="stA.pw('${u.id}')">🔑</button><button class="b s" title="تغيير الدور" onclick="stA.role('${u.id}')">🔄</button><button class="b r" title="حذف" onclick="stA.del('${u.id}')">🗑️</button></div></div>`).join(''):'<p class="mut">لا نتائج</p>';
const _sa2=stAdmin;stAdmin=function(){let h=_sa2.apply(this,arguments);return typeof h==='string'?h.replace(/<div class="card" id="st-adm-users">[\s\S]*$/,admTools()):h};
window.stW={bd(){const b=cfg('banner');try{sessionStorage.setItem('st_bd',b?.t||'')}catch(e){}$('#st-banner')?.remove()}};
/* ---- appearance ---- */

/* ---- global site appearance (admin-controlled, synced to everyone) ---- */
const ROLEDEF={teacher:['#2563eb','#0ea5e9','👨‍🏫 المعلم'],student:['#7c3aed','#ec4899','🎓 الطالب'],parent:['#059669','#14b8a6','👪 ولي الأمر'],assistant:['#d97706','#f59e0b','🛡️ المساعد'],admin:['#be123c','#e11d48','⚙️ المدير'],guest:['#4f46e5','#06b6d4','👋 الزائر']};
const FONTS={'':['افتراضي',''],cairo:['Cairo','Cairo'],tajawal:['Tajawal','Tajawal'],almarai:['Almarai','Almarai'],ibm:['IBM Plex Sans Arabic','IBM+Plex+Sans+Arabic']};
const HEX=/^#[0-9a-fA-F]{6}$/;
const siteCfg=()=>{const b=Object.assign({roles:{},dk:'auto',fs:1,rad:0,font:'',nm:'',css:'',cp:0,rm:0,bgl:'',bgd:''},cfg('site')||{});return window.__sprev||b};
function siteCSS(st){let c='';const R=st.roles||{};
 for(const r in ROLEDEF){const v=R[r];if(!v||!HEX.test(v[0])||!HEX.test(v[1]))continue;const p=v[0],q=v[1];
  const sel=r==='guest'?`:root:root:root:root[data-role=guest],:root:root:root:root:not([data-role])`:`:root:root:root:root[data-role=${r}]`;
  const dsel=r==='guest'?`:root:root:root:root[data-theme=dark][data-role=guest],:root:root:root:root[data-theme=dark]:not([data-role])`:`:root:root:root:root[data-theme=dark][data-role=${r}]`;
  c+=`${sel}{--pri:${p}!important;--pri2:${q}!important;--hd:color-mix(in srgb,${p} 55%,#0b1020)!important;--rc:${p}!important;--sh:${p}33!important;--soft:color-mix(in srgb,${p} 12%,var(--card))!important}`;
  c+=`${dsel}{--pri:color-mix(in srgb,${p} 70%,#fff)!important;--pri2:color-mix(in srgb,${q} 70%,#fff)!important;--hd:color-mix(in srgb,${p} 28%,#05080f)!important;--rc:color-mix(in srgb,${p} 70%,#fff)!important;--soft:color-mix(in srgb,${p} 18%,var(--card))!important}`}
 c+=`.st-v2-hero{background:linear-gradient(125deg,var(--hd),var(--pri) 70%,var(--pri2))!important}`;
 if(HEX.test(st.bgl||''))c+=`:root:root:root:root:not([data-theme=dark]){--bg:${st.bgl}!important}`;
 if(HEX.test(st.bgd||''))c+=`:root:root:root:root[data-theme=dark]{--bg:${st.bgd}!important}`;
 const rad=+st.rad;if(rad>0){c+=`.card,.st-v2-kpi,.st-tile,.st-v2-hero{border-radius:${rad}px!important}button.b,input,select,textarea{border-radius:${Math.max(6,rad-6)}px!important}`}
 const f=FONTS[st.font];if(f&&f[1])c+=`body,button,input,select,textarea{font-family:'${f[0]}',system-ui,sans-serif!important}`;
 return c+featCSS()}
function siteExtras(st){
 const f=FONTS[st.font];let l=$('#st-font');
 if(f&&f[1]){if(!l){l=document.createElement('link');l.id='st-font';l.rel='stylesheet';document.head.appendChild(l)}const h='https://fonts.googleapis.com/css2?family='+f[1]+':wght@400;600;700;800&display=swap';if(l.href!==h)l.href=h}else if(l)l.remove();
 let chose=false;try{chose=!!localStorage.getItem('stx_theme')}catch(e){}
 if(!chose){const want=st.dk==='dark'?true:st.dk==='light'?false:undefined;if(S.dark!==want){S.dark=want;try{th()}catch(e){}}}
 try{const nm=st.nm?st.nm.trim():'';document.title=(nm||'Smart Teacher — المعلم الذكي');const cr=$('#stn-credit');if(cr&&nm)cr.innerHTML=esc(nm)+' · تطوير <b>Omar Essam Elshanab</b>'}catch(e){}}
window.__nm=()=>{const n=(siteCfg().nm||'').trim();return n||'Smart Teacher — المعلم الذكي'};
const PRESETS={blue:['#2563eb','#0ea5e9'],teal:['#0d9488','#14b8a6'],purple:['#7c3aed','#ec4899'],rose:['#e11d48','#fb7185'],amber:['#d97706','#f59e0b'],green:['#16a34a','#4ade80']};
function tabD(){const st=siteCfg(),R=st.roles||{};
 const rows=Object.entries(ROLEDEF).map(([r,d])=>{const v=R[r]||[d[0],d[1]];return `<div class="st-dz"><div><b>${d[2]}</b></div><div class="row" style="align-items:center;gap:8px"><label class="mut" style="font-size:12px">أساسي</label><input type="color" style="width:44px;height:36px;padding:2px;flex:none;cursor:pointer;border-radius:10px" id="sd-${r}-a" value="${v[0]}" oninput="stA.dprev()"><label class="mut" style="font-size:12px">ثانوي</label><input type="color" style="width:44px;height:36px;padding:2px;flex:none;cursor:pointer;border-radius:10px" id="sd-${r}-b" value="${v[1]}" oninput="stA.dprev()"></div></div>`}).join('');
 const sw=Object.entries(PRESETS).map(([k,v])=>`<button style="background:linear-gradient(135deg,${v[0]},${v[1]})" aria-label="${k}" onclick="stA.dpre('${k}')"></button>`).join('');
 return `<h4>🎨 ألوان المنصة (بتتطبّق على كل المستخدمين)</h4><p class="mut">لون كل دور لوحده، أو اختار لوناً موحّداً لكل الأدوار. التغيير بيظهر قدامك فوراً وما بيتحفظ إلا لما تضغط «حفظ».</p>
 <div class="st-sw" style="margin:6px 0 10px">${sw}</div>${rows}
 <h4>🖼️ الخلفية</h4><div class="st-dz"><div><b>خلفية النهار / الليل</b><p class="mut">سيبها فاضية للافتراضي</p></div><div class="row" style="align-items:center;gap:8px"><input type="color" style="width:44px;height:36px;padding:2px;flex:none;cursor:pointer;border-radius:10px" id="sd-bgl" value="${HEX.test(st.bgl)?st.bgl:'#f4f6fb'}" oninput="stA.dprev(1)"><input type="color" style="width:44px;height:36px;padding:2px;flex:none;cursor:pointer;border-radius:10px" id="sd-bgd" value="${HEX.test(st.bgd)?st.bgd:'#0a1020'}" oninput="stA.dprev(1)"></div></div>
 <h4>📐 الشكل</h4>
 <div class="st-dz"><div><b>استدارة الكروت</b><p class="mut">0 = الافتراضي</p></div><input type="range" style="width:140px;flex:none;padding:0" id="sd-rad" min="0" max="32" value="${+st.rad||0}" oninput="stA.dprev()"></div>
 <div class="st-dz"><div><b>حجم الخط والعناصر</b></div><select id="sd-fs" onchange="stA.dprev()">${[.9,.95,1,1.05,1.1,1.2].map(v=>`<option value="${v}" ${(+st.fs||1)===v?'selected':''}>${Math.round(v*100)}%</option>`).join('')}</select></div>
 <div class="st-dz"><div><b>الخط</b></div><select id="sd-font" onchange="stA.dprev()">${Object.entries(FONTS).map(([k,v])=>`<option value="${k}" ${st.font===k?'selected':''}>${v[0]}</option>`).join('')}</select></div>
 <div class="st-dz"><div><b>الوضع الافتراضي</b><p class="mut">لمن لم يختر المستخدم بنفسه</p></div><select id="sd-dk" onchange="stA.dprev()">${[['auto','تلقائي'],['light','نهاري'],['dark','ليلي']].map(o=>`<option value="${o[0]}" ${st.dk===o[0]?'selected':''}>${o[1]}</option>`).join('')}</select></div>
 <div class="st-dz"><div><b>📐 عرض مضغوط للجميع</b></div><label class="st-switch"><input type="checkbox" id="sd-cp" ${st.cp?'checked':''} onchange="stA.dprev()"><span></span></label></div>
 <div class="st-dz"><div><b>🐢 تقليل الحركة للجميع</b></div><label class="st-switch"><input type="checkbox" id="sd-rm" ${st.rm?'checked':''} onchange="stA.dprev()"><span></span></label></div>
 <h4>🏷️ اسم المنصة</h4><input id="sd-nm" maxlength="40" placeholder="Smart Teacher — المعلم الذكي" value="${esc(st.nm||'')}" oninput="stA.dprev(1)">
 <h4>🧩 CSS مخصّص (متقدم)</h4><p class="mut">أي تعديل تصميم إضافي بيتطبّق على كل الصفحات.</p><textarea id="sd-css" rows="5" dir="ltr" style="font-family:monospace" placeholder=".card{box-shadow:none}" oninput="stA.dprev(1)">${esc(st.css||'')}</textarea>
 <div class="row" style="margin-top:10px"><button class="b s" onclick="stA.dreset()">↩️ رجوع للافتراضي</button><button class="b" onclick="stA.dsave()">💾 حفظ للجميع</button></div>`}
const dRead=()=>{const g=id=>document.getElementById(id),roles={};
 for(const r in ROLEDEF){const a=g('sd-'+r+'-a'),b=g('sd-'+r+'-b');if(!a||!b)continue;if(a.value.toLowerCase()!==ROLEDEF[r][0]||b.value.toLowerCase()!==ROLEDEF[r][1])roles[r]=[a.value,b.value]}
 const bl=g('sd-bgl'),bd=g('sd-bgd'),b0=siteCfg();
 return {roles,dk:g('sd-dk').value,fs:+g('sd-fs').value||1,rad:+g('sd-rad').value||0,font:g('sd-font').value,nm:g('sd-nm').value.slice(0,40),css:g('sd-css').value.replace(/[<>]/g,'').slice(0,6000),cp:g('sd-cp').checked?1:0,rm:g('sd-rm').checked?1:0,bgl:window.__bgTouched&&bl?bl.value:(b0.bgl||''),bgd:window.__bgTouched&&bd?bd.value:(b0.bgd||''),tmv:b0.tmv||null}};

const ACC={blue:['#2563eb','#0ea5e9','#14306b'],teal:['#0d9488','#14b8a6','#0b3b3a'],purple:['#7c3aed','#ec4899','#3b1a82'],rose:['#e11d48','#fb7185','#4c0a1f'],amber:['#d97706','#f59e0b','#6b3a07'],green:['#16a34a','#4ade80','#14532d']};
const ui=()=>Object.assign({ac:'auto',fs:1,cp:0,rm:0},jget('st_ui',{}));
function applyUI(){const u=ui(),st=siteCfg();let c=siteCSS(st);
 {const z=Math.round((st.fs||1)*u.fs*100)/100;if(z!==1)c+=`main#app{zoom:${z}}`}
 if(u.cp||st.cp)c+='.card{padding:11px 13px!important;margin-bottom:8px!important}';
 if(u.rm||st.rm)c+='*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}';
 let el=$('#st-ui');if(!el){el=document.createElement('style');el.id='st-ui'}document.body.appendChild(el);el.textContent=c+(st.css||'');siteExtras(st)}
const uiSet=o=>{try{localStorage.setItem('st_ui',JSON.stringify(Object.assign(ui(),o)))}catch(e){}applyUI();const c=$('#st-uicard');if(c)c.outerHTML=uiCard()};
const uiCard=()=>{const u=ui(),sw=[['auto','تلقائي','linear-gradient(135deg,var(--hd),var(--pri))']].concat(Object.entries(ACC).map(([k,v])=>[k,'',v[0]]));
 return `<div class="card" id="st-uicard"><h3>🎨 تخصيص العرض</h3><p class="mut">ألوان وشكل المنصة بيتحكم فيها المدير من لوحة الإدارة.</p>
 <div class="st-dz"><div><b>🔠 حجم الخط والعناصر</b><p class="mut">${Math.round(u.fs*100)}%</p></div><div class="row"><button class="b s" onclick="stUI.fs(-.05)">A−</button><button class="b s" onclick="stUI.fs(.05)">A+</button></div></div>
 <div class="st-dz"><div><b>📐 عرض مضغوط</b><p class="mut">مسافات أقل لعرض معلومات أكتر</p></div><label class="st-switch"><input type="checkbox" ${u.cp?'checked':''} onchange="stUI.set({cp:+this.checked})"><span></span></label></div>
 <div class="st-dz"><div><b>🐢 تقليل الحركة</b><p class="mut">يخفف التأثيرات ويسرّع الأجهزة الضعيفة</p></div><label class="st-switch"><input type="checkbox" ${u.rm?'checked':''} onchange="stUI.set({rm:+this.checked})"><span></span></label></div></div>`};
window.stUI={set:uiSet,fs(d){uiSet({fs:Math.min(1.3,Math.max(.85,Math.round((ui().fs+d)*100)/100))})}};

Object.assign(window.stA,{
 dprev(bg){if(!document.getElementById('sd-dk'))return;if(bg===1&&(document.activeElement||{}).id&&/^sd-bg/.test(document.activeElement.id))window.__bgTouched=1;window.__sprev=null;window.__sprev=dRead();applyUI()},
 dpre(k){const v=PRESETS[k];if(!v)return;const o={};for(const r in ROLEDEF)o[r]=v;window.__sprev=Object.assign(dRead(),{roles:o});applyUI();for(const r in ROLEDEF){const a=document.getElementById('sd-'+r+'-a'),b=document.getElementById('sd-'+r+'-b');if(a)a.value=v[0];if(b)b.value=v[1]}},
 dsave(){if(!canA())return;const o=dRead();window.__sprev=null;window.__bgTouched=0;cset('site',o,'تعديل مظهر المنصة');window.__ssg=JSON.stringify(cfg('site'));applyUI();rb();toast('✅ تم حفظ المظهر لكل المستخدمين')},
 async dreset(){if(!canA()||!await askc('الرجوع لمظهر المنصة الافتراضي لكل المستخدمين؟'))return;window.__sprev=null;window.__bgTouched=0;cset('site',{roles:{},dk:'auto',fs:1,rad:0,font:'',nm:'',css:'',cp:0,rm:0,bgl:'',bgd:'',tmv:null},'رجوع المظهر للافتراضي');window.__ssg=JSON.stringify(cfg('site'));applyUI();rb();toast('تم الرجوع للافتراضي')}});
{const _tb=window.stA.tab;window.stA.tab=function(t){window.__sprev=null;window.__bgTouched=0;applyUI();_tb(t)}}
/* ---- export my data ---- */
window.stAcc.exp=()=>{const m=me();if(!m)return;const u=Object.assign({},m);delete u.pw;dl('my-data-'+dstr()+'.json',JSON.stringify({user:u,groups:S.g.filter(g=>inG(g,m)).map(g=>({title:g.title,code:g.code})),submissions:S.s.filter(s=>s.u===m.id),notifications:S.n.filter(n=>n.to===m.id)},null,1));toast('📦 تم تحميل بياناتك')};
/* ---- hook into render ---- */
const _post=post;post=function(){_post();const m=me(),app=$('#app');
 {const sg=JSON.stringify([cfg('site'),cfg('feat'),cfg('perm'),cfg('brand')]);if(!window.__sprev&&sg!==window.__ssg){window.__ssg=sg;applyUI()}}
 {const t=$('#st-admtools'),h=document.querySelector('.st-v2-hero');if(t&&h&&h.nextElementSibling!==t)h.after(t)}
 const bn=cfg('banner');if(app&&bn&&bn.on&&bn.t&&bnOk()&&!$('#st-banner')&&!document.body.classList.contains('inexam')){let d='';try{d=sessionStorage.getItem('st_bd')}catch(e){}if(d!==bn.t)app.insertAdjacentHTML('afterbegin',`<div class="st-banner ${bn.k==='warn'?'warn':''}" id="st-banner"><span>${bn.k==='warn'?'⚠️':'📣'}</span><div>${esc(bn.t)}</div><button aria-label="إغلاق" onclick="stW.bd()">✕</button></div>`)}
};
const _fix=fixSet;fixSet=function(){_fix();const m=me();if(!m||V.p!=='set')return;const tab=V.t||'preferences',host=document.querySelector('.st-settings-content');
 if(tab==='preferences'&&host&&!$('#st-uicard'))host.insertAdjacentHTML('beforeend',uiCard());
 if(tab==='account'&&m.role!=='admin'&&!$('#st-exp')){const d=$('#st-danger');if(d)(d.querySelector('h3')||d).insertAdjacentHTML(d.querySelector('h3')?'afterend':'afterbegin','<div class="st-dz" id="st-exp"><div><b>📦 تصدير بياناتي</b><p class="mut">نسخة من بياناتك ودرجاتك وإشعاراتك بصيغة JSON.</p></div><button class="b s" onclick="stAcc.exp()">تحميل</button></div>')}};

/* ===== v3: features switches, texts, logo, audit log, themes, schedule, analytics, assistant perms ===== */
const FEAT=[['soc','🌐 المجتمع'],['chats','💬 الشاتات'],['board','🏆 لوحة الشرف'],['ai','🤖 الذكاء الاصطناعي'],['cert','🎓 الشهادات'],['reg','✨ التسجيل الجديد']];
const PERM=[['mute','🔇 منع/السماح بالشات'],['del','🗑 حذف الرسائل'],['send','💬 إرسال رسائل'],['ann','📣 إرسال إعلانات'],['acc','✅ قبول/رفض طلبات الانضمام']];
const fOn=k=>(cfg('feat')||{})[k]!==0,pOn=k=>(cfg('perm')||{})[k]!==0;
function featCSS(){let c='';const M={soc:["[onclick*=\"go('soc'\"]","[onclick*=\"go('prof'\"]","[onclick*=\"prof(\"]"],chats:["[onclick*=\"go('chats'\"]","[onclick*=\"go('pm'\"]"],board:["[onclick*=\"go('board'\"]"],ai:["[onclick*=\"go('ai'\"]"],cert:["[onclick*=\"cert(\"]"],reg:["[onclick*=\"go('dash','reg')\"]"]};
 for(const k in M)if(!fOn(k))c+=M[k].join(',')+'{display:none!important}';
 const P={mute:['[onclick*="x27_asMute("]'],del:['[onclick*="x27_asDel("]'],send:['[onclick*="x27_asSend("]','#x27am'],ann:['[onclick*="x27_asAnn("]','#x27aa'],acc:['[onclick*="stu("][onclick*="x27_asOpen"]']};
 for(const k in P)if(!pOn(k))c+=P[k].join(',')+'{display:none!important}';return c}
/* config write with audit + undo snapshot */
function aud(m,x){const a=cfg('audit')||{l:[]},l=(a.l||[]).slice();l.unshift(Object.assign({t:Date.now(),u:(me()&&me().name)||'مدير',m},x||{}));l.forEach((e,i)=>{if(i>=15&&e.prev!==undefined)delete e.prev});setCfg('audit',{l:l.slice(0,80)})}
function cset(id,o,label){let pv=JSON.stringify(cfg(id)||null);if(pv.length>40000)pv=undefined;setCfg(id,o);aud(label||('تعديل '+id),pv===undefined?{}:{id,prev:pv})}
const bnOk=()=>{const q=cfg('bsch')||{},n=Date.now(),f=q.f?Date.parse(q.f):0,e=q.e?Date.parse(q.e):0;return !(f&&n<f)&&!(e&&n>e)};
/* text replacements + logo */
function applyTxt(){const l=((cfg('txt')||{}).l||[]).filter(r=>r&&r[0]&&!String(r[1]).includes(r[0]));if(!l.length)return;const adm=$('#st-admtools');
 ['#app','#hx','#bn'].forEach(sel=>{const root=$(sel);if(!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;const hit=[];while(n=w.nextNode()){const p=n.parentElement;if(!p||/^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(p.tagName)||(adm&&adm.contains(p)))continue;hit.push(n)}
  hit.forEach(n=>{let v=n.nodeValue,ch=0;l.forEach(r=>{if(v.includes(r[0])){v=v.split(r[0]).join(r[1]);ch=1}});if(ch)n.nodeValue=v});
  root.querySelectorAll('[placeholder]').forEach(i=>{if(adm&&adm.contains(i))return;let v=i.getAttribute('placeholder');l.forEach(r=>{if(v.includes(r[0]))v=v.split(r[0]).join(r[1])});i.setAttribute('placeholder',v)})})}
function applyBrand(){const g=(cfg('brand')||{}).logo;if(!g)return;document.querySelectorAll('header .lg img,.lgc img,img[alt="Smart Teacher"]').forEach(i=>{if(i.src!==g)i.src=g});const f=document.querySelector('link[rel~=icon]');if(f&&f.href!==g)f.href=g}
/* ---- tabs ---- */
function tabF(){return `<h4>🧩 تشغيل وإيقاف الأقسام</h4><p class="mut">القسم الموقوف بيختفي من القوائم ومن الدخول المباشر عند كل المستخدمين (المدير مستثنى).</p>${FEAT.map(f=>`<div class="st-dz"><div><b>${f[1]}</b></div><label class="st-switch"><input type="checkbox" ${fOn(f[0])?'checked':''} onchange="stA.fset('${f[0]}',this.checked)"><span></span></label></div>`).join('')}
 <h4>🛡️ صلاحيات المساعد</h4><p class="mut">تحدد المساعد يقدر يعمل إيه جوه المجموعات اللي بيشرف عليها.</p>${PERM.map(f=>`<div class="st-dz"><div><b>${f[1]}</b></div><label class="st-switch"><input type="checkbox" ${pOn(f[0])?'checked':''} onchange="stA.pset('${f[0]}',this.checked)"><span></span></label></div>`).join('')}`}
const txRead=()=>{const a=[...document.querySelectorAll('.txf')],b=[...document.querySelectorAll('.txn')];if(a.length)NS.tx=a.map((x,i)=>[x.value,b[i]?b[i].value:''])};
function tabT(){if(!NS.tx)NS.tx=((cfg('txt')||{}).l||[]).map(x=>x.slice());const hasL=!!(cfg('brand')||{}).logo;
 return `<h4>🖼️ شعار المنصة</h4><div class="st-dz"><div><b>رفع شعار جديد</b><p class="mut">بيتحوّل لمربع 160px تلقائياً ويظهر مكان الشعار وأيقونة التبويب.</p></div><div class="row"><button class="b s" onclick="document.getElementById('sd-logo').click()">اختيار صورة</button>${hasL?'<button class="b r" onclick="stA.logo0()">إزالة</button>':''}<input type="file" id="sd-logo" accept="image/*" hidden onchange="stA.logo(this)"></div></div>
 <h4>✏️ تعديل نصوص المنصة</h4><p class="mut">اكتب النص زي ما بيظهر بالظبط، وبعده النص الجديد. بيتطبق على كل الصفحات (ما عدا لوحة الإدارة نفسها عشان تفضل واضحة ليك).</p>
 ${NS.tx.map((r,i)=>`<div class="row" style="gap:6px;margin-bottom:6px"><input class="txf" value="${esc(r[0])}" placeholder="النص الأصلي" style="flex:1"><input class="txn" value="${esc(r[1])}" placeholder="النص الجديد" style="flex:1"><button class="b r" onclick="stA.txdel(${i})">✕</button></div>`).join('')||'<p class="mut">لا توجد تعديلات بعد</p>'}
 <div class="row"><button class="b s" onclick="stA.txadd()">➕ إضافة</button><button class="b" onclick="stA.txsave()">💾 حفظ للجميع</button></div>`}
function tabL(){const l=(cfg('audit')||{}).l||[];return `<h4>🧾 سجل نشاط الإدارة</h4><p class="mut">آخر ${l.length} عملية. التراجع متاح لتعديلات الإعدادات الحديثة.</p>${l.map((e,i)=>`<div class="st-ar"><div class="st-ai"><b>${esc(e.m)}</b><small>${esc(e.u||'')} · ${new Date(e.t).toLocaleString('ar-EG')}${e.undone?' · ↩️ تم التراجع':''}</small></div>${e.prev!==undefined&&!e.undone?`<button class="b s" onclick="stA.undo(${i})">↩️ تراجع</button>`:''}</div>`).join('')||'<p class="mut">السجل فاضي</p>'}${l.length?'<button class="b r" style="margin-top:8px" onclick="stA.audClr()">مسح السجل</button>':''}`}
function tabP(){let h='';const row=(a,b,t)=>`<div class="st-ar"><div class="st-ai"><b>${esc(a)}</b><small>${esc(b)}</small></div>${t?`<span class="tag">${t}</span>`:''}</div>`;
 try{const st={};S.s.forEach(x=>{const e=E(x.e);if(!e||!e.q)return;e.q.forEach(q=>{const k=e.id+'|'+q.id,o=st[k]=st[k]||{e,q,n:0,w:0};o.n++;try{if(!isOk(q,x))o.w++}catch(_){}})});
  const hd=Object.values(st).filter(o=>o.n>=2&&o.w>0).sort((a,b)=>b.w/b.n-a.w/a.n||b.n-a.n).slice(0,8);
  h+=`<h4>🧗 أصعب الأسئلة</h4>${hd.map(o=>row((o.q.q||'').toString().slice(0,70),(o.e.name||o.e.title||'امتحان')+' · '+o.n+' إجابة',Math.round(o.w/o.n*100)+'% أخطأوا')).join('')||'<p class="mut">محتاج تسليمات أكتر (سؤال أجاب عليه طالبين على الأقل)</p>'}`}catch(e){h+='<p class="mut">تعذّر حساب الأسئلة</p>'}
 try{const by={};S.s.forEach(x=>{const v=pct(x);if(v!==null)(by[x.u]=by[x.u]||[]).push(v)});
  const lo=Object.entries(by).filter(([u,a])=>a.length>=2).map(([u,a])=>[u,avgOf(a),a.length]).filter(r=>r[1]<70).sort((a,b)=>a[1]-b[1]).slice(0,8);
  h+=`<h4>📉 طلاب محتاجين متابعة</h4>${lo.map(r=>row(U(r[0])?.name||'—',r[2]+' تسليم',r[1]+'%')).join('')||'<p class="mut">لا يوجد طلاب متوسطهم تحت 70%</p>'}`}catch(e){}
 try{const last={};S.s.forEach(x=>{last[x.u]=Math.max(last[x.u]||0,x.d||0)});const cut=Date.now()-14*864e5;
  const ia=S.u.filter(u=>u.role==='student'&&!u.sus&&(last[u.id]||0)<cut);
  h+=`<h4>💤 طلاب غير نشطين (14 يوم+)</h4>${ia.slice(0,10).map(u=>row(u.name||'—',last[u.id]?'آخر تسليم '+new Date(last[u.id]).toLocaleDateString('ar-EG'):'لم يسلّم أي امتحان')).join('')||'<p class="mut">كل الطلاب نشطين 👏</p>'}${ia.length>10?`<p class="mut">و${ia.length-10} آخرين</p>`:''}`}catch(e){}
 try{const ps=S.e.map(e=>{const g=G(e.g),n=g?gStu(g).length:0,c=new Set(S.s.filter(x=>x.e===e.id).map(x=>x.u)).size;return {e,n,c}}).filter(o=>o.n>0).sort((a,b)=>a.c/a.n-b.c/b.n).slice(0,6);
  h+=`<h4>📋 أقل الامتحانات مشاركة</h4>${ps.map(o=>row(o.e.name||o.e.title||'امتحان',o.c+' من '+o.n+' طالب',Math.round(o.c/o.n*100)+'%')).join('')||'<p class="mut">لا امتحانات بعد</p>'}`}catch(e){}
 return h}
/* ---- extend existing tabs ---- */
const _tD=tabD;tabD=function(){const T=(cfg('themes')||{}).l||[];return `<h4>🎭 ثيمات محفوظة</h4><p class="mut">احفظ المظهر الحالي باسم وبدّل بينه وبين غيره بضغطة (مثلاً «رمضان» أو «امتحانات»).</p>${T.map((t,i)=>`<div class="st-ar"><div class="st-ai"><b>${esc(t.n)}</b></div><div class="st-ab"><button class="b s" onclick="stA.thapply(${i})">تطبيق</button><button class="b r" onclick="stA.thdel(${i})">🗑️</button></div></div>`).join('')}<div class="row" style="margin:6px 0 4px"><input id="sth-n" maxlength="24" placeholder="اسم الثيم" style="flex:1"><button class="b s" onclick="stA.thsave()">💾 حفظ الحالي كثيم</button></div>`+_tD()};
const _tB=tabB;tabB=function(){const q=cfg('bsch')||{},sc=`<h4>⏰ جدولة الشريط</h4><p class="mut">اختياري — الشريط بيظهر بس بين الوقتين (بتوقيت جهازك). سيبهم فاضيين للعرض المستمر.</p><div class="row" style="align-items:center"><label class="mut">من</label><input type="datetime-local" id="sbf" value="${esc(q.f||'')}"><label class="mut">إلى</label><input type="datetime-local" id="sbe" value="${esc(q.e||'')}"></div>`;return _tB().replace('<h4>🔔 إشعار مباشر لفئة</h4>',sc+'<h4>🔔 إشعار مباشر لفئة</h4>')};
/* ---- actions ---- */
const PEND=[];
Object.assign(window.stA,{
 fset(k,on){if(!canA())return;const f=FEAT.find(x=>x[0]===k);cset('feat',{[k]:on?1:0},(on?'تشغيل ':'إيقاف ')+'قسم '+f[1]);window.__ssg='';applyUI()},
 pset(k,on){if(!canA())return;const f=PERM.find(x=>x[0]===k);cset('perm',{[k]:on?1:0},(on?'السماح للمساعد: ':'منع المساعد من: ')+f[1]);window.__ssg='';applyUI()},
 txadd(){txRead();NS.tx.push(['','']);rb()},txdel(i){txRead();NS.tx.splice(i,1);rb()},
 txsave(){if(!canA())return;txRead();const l=NS.tx.filter(r=>r[0].trim()).map(r=>[r[0],r[1]]);cset('txt',{l},'تعديل نصوص المنصة ('+l.length+')');NS.tx=null;R();toast('✅ تم حفظ النصوص')},
 logo(inp){if(!canA())return;const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=c.height=160;const x=c.getContext('2d'),k=Math.min(im.width,im.height);x.drawImage(im,(im.width-k)/2,(im.height-k)/2,k,k,0,0,160,160);let d=c.toDataURL('image/webp',.85);if(d.indexOf('data:image/webp')!==0)d=c.toDataURL('image/png');if(d.length>70000)d=c.toDataURL('image/jpeg',.7);cset('brand',{logo:d},'تغيير شعار المنصة');applyUI();applyBrand();rb();toast('✅ تم تغيير الشعار')};im.onerror=()=>toast('❌ صورة غير صالحة');im.src=r.result};r.readAsDataURL(f)},
 logo0(){if(!canA())return;cset('brand',{logo:''},'إزالة شعار المنصة');rb();toast('تمت إزالة الشعار — حدّث الصفحة')},
 thsave(){if(!canA())return;const n=($('#sth-n').value||'').trim();if(!n)return toast('اكتب اسم الثيم');const o=dRead(),l=((cfg('themes')||{}).l||[]).filter(t=>t.n!==n);if(l.length>=12)return toast('الحد الأقصى 12 ثيم');l.push({n,s:o});cset('themes',{l},'حفظ ثيم «'+n+'»');rb();toast('✅ تم حفظ الثيم')},
 thapply(i){if(!canA())return;const t=((cfg('themes')||{}).l||[])[i];if(!t)return;window.__sprev=null;cset('site',Object.assign({roles:{},dk:'auto',fs:1,rad:0,font:'',nm:'',css:'',cp:0,rm:0,bgl:'',bgd:'',tmv:null},t.s),'تطبيق ثيم «'+t.n+'»');window.__ssg='';applyUI();rb();toast('🎭 تم تطبيق «'+t.n+'»')},
 thdel(i){if(!canA())return;const l=((cfg('themes')||{}).l||[]).slice(),t=l.splice(i,1)[0];cset('themes',{l},'حذف ثيم «'+(t&&t.n)+'»');rb()},
 undo(i){if(!canA())return;const a=cfg('audit'),e=a&&a.l[i];if(!e||e.prev===undefined||e.undone)return;const p=JSON.parse(e.prev);S.cf=(S.cf||[]).filter(x=>x.id!==e.id);if(p)S.cf.push(p);e.undone=1;save();aud('تراجع: '+e.m);window.__ssg='';window.__sprev=null;applyUI();R();toast('↩️ تم التراجع')},
 audClr(){if(!canA())return;setCfg('audit',{l:[]});rb()}});
{const _tb2=window.stA.tab;window.stA.tab=function(t){if(t==='t')NS.tx=null;_tb2(t)}}
/* audit wrappers for admin actions (log only when state really changed) */
{const W=(name,snap,msg)=>{const o=window.stA[name];if(typeof o!=='function')return;window.stA[name]=function(){const a=arguments,nm=((U(a[0])||{}).name)||((G(a[0])||{}).title)||'',b=snap(a[0]);const r=o.apply(this,a);Promise.resolve(r).then(()=>{try{if(snap(a[0])!==b)aud(msg(nm,a[0]))}catch(e){}});return r}};
 W('sus',id=>U(id)?.sus?1:0,(n,id)=>(U(id)?.sus?'إيقاف':'تفعيل')+' حساب «'+n+'»');
 W('del',id=>U(id)?1:0,n=>'حذف حساب «'+n+'»');
 W('pw',id=>U(id)?.pw||'',n=>'كلمة مرور مؤقتة لـ «'+n+'»');
 W('glock',id=>G(id)?.lock?1:0,(n,id)=>(G(id)?.lock?'قفل':'فتح')+' مجموعة «'+n+'»');
 W('gdel',id=>G(id)?1:0,n=>'حذف مجموعة «'+n+'»');
 W('bnr',()=>JSON.stringify(cfg('banner')||0),()=>'تعديل شريط الإعلان');
 W('bc',()=>S.n.length,()=>'إرسال إشعار جماعي');
 W('cl',()=>JSON.stringify(S).length,()=>'تنظيف البيانات');
 W('pc',()=>(cfg('admpw')||{}).u||0,()=>'تغيير الرقم السري للإدارة');
 const _r=window.stA.role;window.stA.role=function(id){const u=U(id);if(u)PEND.push({id,old:u.role,t:Date.now()});return _r.apply(this,arguments)};
 const _bn=window.stA.bnr;window.stA.bnr=function(on){const f=($('#sbf')||{}).value||'',e=($('#sbe')||{}).value||'';const r=_bn.apply(this,arguments);if(f||e||cfg('bsch')){cset('bsch',{f,e},'جدولة شريط الإعلان');R()}return r}}
/* feature gates */
{const _go=go;go=function(p,a,t){const m=me(),ex=m&&(m.role==='admin'||ADMOK()),off={soc:'soc',prof:'soc',chats:'chats',pm:'chats',board:'board',ai:'ai'};
  if(!ex&&off[p]&&!fOn(off[p])){toast('هذا القسم متوقف مؤقتاً من الإدارة');return _go('dash')}
  if(p==='dash'&&a==='reg'&&!fOn('reg')){toast('التسجيل الجديد متوقف حالياً');return _go('dash','login')}
  return _go.apply(this,arguments)};
 try{if(typeof signup==='function'){const _s=signup;signup=function(){if(!fOn('reg')){toast('التسجيل الجديد متوقف حالياً');return}return _s.apply(this,arguments)}}}catch(e){}
 try{if(typeof cert==='function'){const _c=cert;cert=function(){if(!fOn('cert')&&!(me()&&me().role==='admin')){toast('الشهادات متوقفة مؤقتاً');return}return _c.apply(this,arguments)}}}catch(e){}
 const blk=k=>{const m=me();return m&&m.role==='assistant'&&!pOn(k)};
 [['x27_asMute','mute'],['x27_asDel','del'],['x27_asSend','send'],['x27_asAnn','ann'],['stu','acc']].forEach(([n,k])=>{const o=window[n];if(typeof o!=='function')return;window[n]=function(){if(blk(k)){toast('الإدارة أوقفت هذه الصلاحية للمساعدين');return}return o.apply(this,arguments)}})}
/* render hook */
{const _p3=post;post=function(){_p3();try{applyBrand();applyTxt();if(!bnOk())$('#st-banner')?.remove();
  for(let i=PEND.length-1;i>=0;i--){const q=PEND[i],u=U(q.id);if(!u||Date.now()-q.t>3e5){PEND.splice(i,1);continue}if(u.role!==q.old){aud('تغيير دور «'+(u.name||'')+'» إلى '+stRoleLabel(u.role));PEND.splice(i,1)}}}catch(e){}};
 window.__bk=bnOk();setInterval(()=>{try{const k=bnOk();if(k!==window.__bk){window.__bk=k;if(!document.body.classList.contains('inexam')&&!document.activeElement?.matches('input,textarea'))R()}}catch(e){}},6e4)}

/* ===== v4: files for materials, vision-based file reading, safe question generation ===== */
{const st=document.createElement('style');st.id='st-v4css';st.textContent='.mfile{border:1px solid var(--bd);border-radius:14px;padding:10px;margin-top:10px}.mfile img.mimg{width:100%;max-height:420px;object-fit:contain;border-radius:10px;display:block;margin-bottom:8px;background:var(--soft,#0001);cursor:zoom-in}.mfile .mn{font-weight:700;word-break:break-all;margin-bottom:6px}.mfile .row{gap:8px;flex-wrap:wrap}.pdfv canvas{width:100%;height:auto;display:block;margin:0 0 8px;border-radius:8px;background:#fff}.mtx{white-space:pre-wrap;line-height:1.9}';document.head.appendChild(st)}
const FMAX=6*1024*1024,PDFV=8;
const fUrl=id=>withAuth(DB+'/files/'+id+'.json'),FC=new Map();
const rdURL=f=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>no(new Error('read'));r.readAsDataURL(f)});
async function fPut(id,o){await AUTH_READY;const r=await fetch(fUrl(id),{method:'PUT',body:JSON.stringify(o)});if(!r.ok)throw new Error('HTTP '+r.status)}
async function fGet(id){if(FC.has(id))return FC.get(id);await AUTH_READY;const r=await fetch(fUrl(id));if(!r.ok)throw new Error('HTTP '+r.status);const o=await r.json();if(!o||!o.d)throw new Error('missing');FC.set(id,o);return o}
async function fDel(id){try{await AUTH_READY;await fetch(fUrl(id),{method:'DELETE'})}catch(e){}FC.delete(id)}
/* v12: كشف دوال تخزين الملفات للنطاق العام — كتلة المجتمع وux-fixes.js خارج هذا الـIIFE ولازم يشوفوها */
window.fPut=fPut;window.fGet=fGet;window.fDel=fDel;window.FC=FC;
const toBlob=async o=>await (await fetch(o.d)).blob();
/* --- reading sources (text / docx / PDF / images) --- */
const TRP='انسخ كل النص والمحتوى العلمي الظاهر في هذه الصورة بدقة وبالترتيب (مع المعادلات والجداول إن وجدت)، وإن كان فيها رسم أو شكل علمي فصِفه في سطر. تجاهل أرقام الهواتف والإعلانات وأسماء الصفحات. بدون أي مقدمة أو تعليق. إذا كانت الصورة فارغة أو غير مقروءة اكتب فقط: [غير مقروء]';
async function pdfSource(f){if(!window.pdfjsLib)return {text:'',imgs:[],note:'تعذّر تحميل قارئ PDF — تأكد من الإنترنت وحدّث الصفحة'};
 pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
 const d=await pdfjsLib.getDocument({data:await f.arrayBuffer()}).promise;let txt='';const N=Math.min(d.numPages,40);
 for(let i=1;i<=N;i++)txt+=(await(await d.getPage(i)).getTextContent()).items.map(x=>x.str).join(' ')+'\n';
 const c=txt.replace(/\s+/g,' ').trim(),ar=(c.match(/[\u0600-\u06FF]/g)||[]).length,la=(c.match(/[A-Za-z]/g)||[]).length;
 /* scanned PDFs have no text; Arabic text layers often come out scrambled -> read the pages visually instead */
 const vis=c.length<40*Math.min(d.numPages,3)||ar>la*.3;
 if(!vis)return {text:c,imgs:[],note:''};
 const M=Math.min(d.numPages,PDFV),imgs=[];
 for(let i=1;i<=M;i++){const p=await d.getPage(i),v0=p.getViewport({scale:1}),sc=Math.min(2,1400/Math.max(v0.width,v0.height)),v=p.getViewport({scale:sc}),cv=document.createElement('canvas');cv.width=Math.round(v.width);cv.height=Math.round(v.height);await p.render({canvasContext:cv.getContext('2d'),viewport:v}).promise;const b=await new Promise(r=>cv.toBlob(r,'image/jpeg',.82));imgs.push(new File([b],'p'+i+'.jpg',{type:'image/jpeg'}))}
 return {text:'',imgs,note:d.numPages>M?`تمت قراءة أول ${M} صفحات فقط من ${d.numPages}`:''}}
async function readSource(fs,typed){let text=typed||'',imgs=[],note='';
 for(const f of fs){const n=f.name.toLowerCase();
  if(f.type.startsWith('image/')){imgs.push(f);continue}
  if(n.endsWith('.pdf')){try{const r=await pdfSource(f);text+='\n'+r.text;imgs.push(...r.imgs);if(r.note)note=r.note}catch(e){console.warn(e);note='تعذّرت قراءة ملف PDF'}continue}
  text+='\n'+await fileText(f)}
 let tr='';
 if(imgs.length){const hold=AIH;AIH=[];try{const parts=[];for(let i=0;i<imgs.length;i++){toast(`قراءة ${i+1} من ${imgs.length}…`);let t=(await ai(TRP,imgs[i]))||'';t=String(t).trim();if(t.length>15&&!/^\[?\s*غير مقروء\s*\]?$/.test(t))parts.push(t)}tr=parts.join('\n\n')}finally{AIH=hold}}
 return {text:(text+'\n'+tr).trim(),note}}
/* --- question validation (drops meta / malformed questions) --- */
const META=/(في|من|عن|بهذه|بالصورة|على)\s*(ال)?(صورة|ملف)|النص المستخرج|المستخرج|الصورة المرفقة|جودة (ال)?(صورة|نص)|أخطاء (إملائية|طباعية)|OCR/;
const nrm=x=>String(x??'').replace(/\s+/g,' ').trim();
function cleanQs(r){if(!Array.isArray(r))return [];const seen=new Set(),out=[];
 for(const q of r){if(!q||typeof q!=='object')continue;const t=['mcq','tf','fib'].includes(q.t)?q.t:'mcq',qq=nrm(q.q);if(qq.length<8||META.test(qq)||seen.has(qq))continue;
  if(t==='mcq'){const o=[...new Set((Array.isArray(q.o)?q.o:[]).map(nrm).filter(Boolean))];const a=nrm(q.a),hit=o.find(x=>x===a)||o.find(x=>x.toLowerCase()===a.toLowerCase());if(o.length<3||!hit||o.some(x=>META.test(x)))continue;seen.add(qq);out.push({t,q:qq,o,a:hit,x:nrm(q.x)})}
  else if(t==='tf'){const a=nrm(q.a).toLowerCase(),v=/^(صح|صحيح|true|t|نعم)$/.test(a)?'صح':/^(خطأ|خطا|خاطئ|false|f|لا)$/.test(a)?'خطأ':'';if(!v)continue;seen.add(qq);out.push({t,q:qq,o:[],a:v,x:nrm(q.x)})}
  else{const a=nrm(q.a);if(!a)continue;seen.add(qq);out.push({t:'fib',q:qq,o:[],a,x:nrm(q.x)})}}
 return out}
window.genQ=async function(){if(genQ.busy)return;const fs=[...(($('#qf')||{}).files||[])],n=Math.max(1,Math.min(30,+($('#qn')||{}).value||5)),typed=(($('#qs')||{}).value||'').trim();
 if(!typed&&!fs.length)return toast('أضف نصاً أو ملفاً أو صورة');genQ.busy=1;
 try{toast('جارٍ قراءة المحتوى…');const s=await readSource(fs,typed);
  if(s.text.length<40){toast('لم أستطع قراءة محتوى دراسي واضح من الملف — جرّب صورة أوضح أو الصق النص');return}
  if(s.note)toast(s.note);toast('جارٍ توليد الأسئلة…');
  const r=await ai(`أنت معلم خبير. أنشئ ${n} أسئلة امتحان من المحتوى التعليمي التالي فقط (خليط من "mcq" اختيار من متعدد و"tf" صح/خطأ و"fib" أكمل).\nقواعد صارمة:\n- كل سؤال يختبر معلومة أو مفهوماً موجوداً فعلاً في المحتوى.\n- ممنوع أي سؤال عن الملف أو الصورة أو وضوح النص أو الأخطاء الإملائية أو طريقة الاستخراج أو أرقام الهواتف أو أسماء المدرسين أو الإعلانات. تجاهل أي نص غير تعليمي.\n- إجابة mcq تطابق حرفياً أحد الخيارات الأربعة، وخيار واحد فقط صحيح.\n- اللغة: نفس لغة المحتوى (عربي أو إنجليزي).\n- إذا كان المحتوى غير تعليمي أو غير كافٍ أعد [].\nأعد JSON فقط: مصفوفة عناصرها {"t":"mcq|tf|fib","q":"نص السؤال","o":["4 خيارات لـ mcq فقط"],"a":"الإجابة (لـ tf: صح أو خطأ)","x":"شرح قصير"}.\nالمحتوى:\n`+s.text.slice(0,12000)+(me().sj?'\n(المادة: '+me().sj+')':''),null,1);
  if(r==null)return;const qs=cleanQs(r);
  if(!qs.length){toast('لم أنجح في توليد أسئلة صالحة من هذا المحتوى — جرّب محتوى أوضح أو أكثر');return}
  qs.forEach(q=>D.q.push({id:uid(),t:q.t,q:q.q,o:q.o,a:q.a,x:q.x}));toast(`✅ تمت إضافة ${qs.length} سؤال — راجع الأسئلة قبل النشر`);keepD();R()
 }catch(e){console.warn(e);toast('حدث خطأ أثناء التوليد، حاول مجدداً')}finally{genQ.busy=0}};
/* --- materials --- */
const isImgM=m=>/^image\//.test(m||''),isPdfM=(m,n)=>m==='application/pdf'||/\.pdf$/i.test(n||'');
const szTxt=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
function matFiles(x,t){const fl=x.fls||[];if(!fl.length)return '';if(!t&&x.md==='sum')return '';
 return fl.map(f=>`<div class="mfile" data-f="${f.id}" data-img="${isImgM(f.m)?1:''}"><div class="mn">${isImgM(f.m)?'🖼️':isPdfM(f.m,f.n)?'📕':'📄'} ${esc(f.n)} <span class="mut">${szTxt(f.s||0)}</span></div>${isImgM(f.m)?'<div class="mph mut">جارٍ تحميل الصورة…</div>':''}<div class="row"><button class="b" onclick="matDl('${f.id}')">⬇️ تنزيل على الهاتف</button></div></div>`).join('')}
window.matTab=function(g,t){let h='';
 if(t)h+=`<div class="card"><h3>إضافة مادة</h3><input id="mt" placeholder="عنوان المادة"><textarea id="mb" rows="4" placeholder="اكتب أو الصق نص الدرس (اختياري)"></textarea><input type="file" id="mf" multiple accept=".pdf,.docx,.txt,.md,image/*"><p class="mut">يمكنك رفع أكثر من ملف أو صورة. الحد 6MB للملف (الصور بتتصغّر تلقائياً).</p><h4>ما الذي يظهر للطلاب؟</h4><div class="row" style="gap:12px;margin-bottom:8px"><label><input type="radio" name="mm" value="file" checked style="width:auto"> الملف كامل</label><label><input type="radio" name="mm" value="sum" style="width:auto"> تلخيص فقط</label><label><input type="radio" name="mm" value="both" style="width:auto"> الاثنين</label></div><button class="b" id="mbtn" onclick="addMat('${g.id}')">💾 نشر المادة</button></div>`;
 h+=g.mat.map(x=>{const old=!x.fls&&!x.md,showSum=x.sum&&(t||x.md!=='file'),txt=x.tx!==undefined?x.tx:'';
  return `<div class="card"><div class="row"><h3>${esc(x.t)}</h3>${t?`<button class="b r" onclick="matDel('${g.id}','${x.id}')">🗑</button>`:''}</div>${x.by?`<span class="pill">👨‍🏫 أ/ ${esc(x.by)}${x.sj?' • مدرس '+esc(x.sj):''}</span>`:''}${showSum?`<div class="msg"><b>ملخص SHANANOO AI:</b><br>${esc(x.sum).replace(/\n/g,'<br>')}</div>`:''}${txt&&(t||x.md!=='sum')?`<div class="mtx">${esc(txt)}</div>`:''}${old?`<p class="mut">${esc(x.b||'').slice(0,300)}</p>`:''}${matFiles(x,t)}${t&&x.b?`<button class="b s" style="margin-top:10px" onclick="PRE=G('${g.id}').mat.find(y=>y.id=='${x.id}').b;D=null;go('studio','${g.id}')">📝 ولّد امتحان منها</button>`:''}</div>`}).join('')||emp('لا توجد مواد بعد');
 return h};
window.matLoad=function(){document.querySelectorAll('.mfile[data-img="1"]:not([data-ok])').forEach(async el=>{el.dataset.ok='1';try{const o=await fGet(el.dataset.f),ph=el.querySelector('.mph');if(ph){const im=document.createElement('img');im.className='mimg';im.alt='معاينة مصغرة للملف '+(el.querySelector('.mn')?.innerText||'');im.loading='lazy';im.decoding='async';im.style.cursor='default';im.src=o.d;ph.replaceWith(im)}}catch(e){const ph=el.querySelector('.mph');if(ph)ph.textContent='تعذّر تحميل الصورة — تحقق من الاتصال';el.dataset.ok=''}})};
window.matDl=async function(id){try{toast('جارٍ التجهيز…');const o=await fGet(id),b=await toBlob(o),f=new File([b],o.n,{type:o.m});
 const ios=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
 if(ios&&navigator.share&&navigator.canShare&&navigator.canShare({files:[f]})){try{await navigator.share({files:[f],title:o.n});toast('تم فتح خيارات حفظ الملف ومشاركته');return}catch(e){if(e&&e.name==='AbortError')return}}
 const u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=o.n;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);toast(ios?'إذا لم يبدأ الحفظ، افتح الملف من خيارات المشاركة واختر «حفظ في الملفات»':'⬇️ بدأ التنزيل')}catch(e){console.warn(e);toast('تعذّر تنزيل الملف — تحقق من الاتصال ثم حاول مرة أخرى')}};
window.matView=async function(id){try{x22_m('📄 عرض الملف','<div class="pdfv" id="pdfv"><p class="mut">جارٍ التحميل…</p></div>');const o=await fGet(id),host=document.getElementById('pdfv');if(!host)return;
 if(isImgM(o.m)){host.innerHTML=`<img src="${o.d}" alt="" style="width:100%;border-radius:10px;display:block"><div class="row" style="margin-top:8px"><button class="b" onclick="matDl('${id}')">⬇️ تنزيل</button></div>`;return}
 if(isPdfM(o.m,o.n)){if(!window.pdfjsLib){host.innerHTML='<p class="mut">تعذّر تحميل عارض PDF — جرّب التنزيل</p>';return}
  pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const d=await pdfjsLib.getDocument({data:await (await toBlob(o)).arrayBuffer()}).promise,MX=60;host.innerHTML='';
  for(let i=1;i<=Math.min(d.numPages,MX);i++){if(!document.getElementById('pdfv'))return;const p=await d.getPage(i),w=host.clientWidth||360,v0=p.getViewport({scale:1}),v=p.getViewport({scale:(w/v0.width)*Math.min(2,devicePixelRatio||1.5)}),c=document.createElement('canvas');c.width=Math.round(v.width);c.height=Math.round(v.height);host.appendChild(c);await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise}
  host.insertAdjacentHTML('beforeend',`${d.numPages>MX?`<p class="mut">تم عرض أول ${MX} صفحة — نزّل الملف لمشاهدته كاملاً.</p>`:''}<div class="row"><button class="b" onclick="matDl('${id}')">⬇️ تنزيل</button></div>`);return}
 host.innerHTML=`<p class="mut">لا يمكن عرض هذا النوع داخل المنصة.</p><button class="b" onclick="matDl('${id}')">⬇️ تنزيل</button>`}catch(e){console.warn(e);const h=document.getElementById('pdfv');if(h)h.innerHTML='<p class="mut">تعذّر عرض الملف — جرّب التنزيل</p>'}};
window.matDel=async function(gid,id){if(!isT())return;const g=G(gid),x=g&&g.mat.find(y=>y.id===id);if(!x||!await ask('حذف هذه المادة وملفاتها نهائياً؟'))return;(x.fls||[]).forEach(f=>fDel(f.id));g.mat=g.mat.filter(y=>y.id!==id);g.act=Date.now();save();R();toast('تم حذف المادة')};
window.addMat=async function(gid){const g=G(gid);if(!g||!isT()||addMat.busy)return;const fs=[...(($('#mf')||{}).files||[])],typed=(($('#mb')||{}).value||'').trim(),mode=(document.querySelector('input[name=mm]:checked')||{}).value||'file',ti=(($('#mt')||{}).value||'').trim()||(fs[0]&&fs[0].name.replace(/\.[^.]+$/,''))||'مادة';
 if(!typed&&!fs.length)return toast('أضف نصاً أو ملفاً');
 for(const f of fs)if(!isImgM(f.type)&&f.size>FMAX)return toast('الملف «'+f.name+'» أكبر من 6MB');
 addMat.busy=1;const btn=$('#mbtn');if(btn){btn.disabled=true;btn.textContent='⏳ جارٍ المعالجة…'}
 try{const fls=[];let bad=0,code=0;
  for(const f of fs){try{const im=isImgM(f.type),d=im?await shrink(f,1800):await rdURL(f);if(!d)throw new Error('read');
    const id=uid()+uid()+uid(),nm=im?f.name.replace(/\.[^.]+$/,'')+'.jpg':f.name,mt=im?'image/jpeg':(f.type||'application/octet-stream');
    await fPut(id,{n:nm,m:mt,d,t:Date.now()});fls.push({id,n:nm,m:mt,s:Math.round(d.length*.75)})}catch(e){bad++;const m=/HTTP (\d+)/.exec(e.message||'');if(m)code=+m[1];console.warn(e)}}
  if(bad)toast(code===401||code===403?'تعذّر رفع الملفات: قواعد Firebase لا تسمح بمسار files (راجع الإعدادات)':'تعذّر رفع '+bad+' ملف — تحقق من الاتصال');
  if(!fls.length&&!typed)return;
  let text=typed,sum='';
  if(mode!=='file'){toast('جارٍ قراءة المحتوى…');const s=await readSource(fs,typed);text=s.text;
   if(text.length<30){if(mode==='sum'){toast('لم أستطع قراءة محتوى واضح للتلخيص — اختر «الملف كامل» أو جرّب ملفاً أوضح');fls.forEach(f=>fDel(f.id));return}toast('تعذّر التلخيص (المحتوى غير واضح) — سيُنشر الملف فقط')}
   else{if(s.note)toast(s.note);toast('جارٍ التلخيص…');sum=(await ai('لخّص المحتوى التعليمي التالي في نقاط رئيسية واضحة ومنظمة للطلاب (بنفس لغة المحتوى)، وتجاهل أي أرقام تواصل أو إعلانات'+(me().sj?' (مادة '+me().sj+')':'')+':\n'+text.slice(0,12000)))||'';if(!sum&&mode==='sum'){toast('تعذّر التلخيص حالياً، حاول مجدداً');fls.forEach(f=>fDel(f.id));return}}}
  const md=!fls.length&&!sum?'file':(mode==='sum'&&!sum?'file':mode);
  g.mat.unshift({id:uid(),t:ti,tx:typed,b:(text||typed).slice(0,20000),by:me().name,sj:me().sj||'',fls,md,sum,d:Date.now()});g.act=Date.now();
  g.st.filter(s=>s.s==='ok').forEach(s=>notify(s.u,`مادة جديدة في ${g.title}: ${ti}`,undefined,'group|'+g.id+'|mat'));save();R();toast('✅ تم نشر المادة')
 }catch(e){console.warn(e);toast('حدث خطأ أثناء الحفظ، حاول مجدداً')}finally{addMat.busy=0;const b=$('#mbtn');if(b){b.disabled=false;b.textContent='💾 نشر المادة'}}};
{const _p4=post;post=function(){_p4();try{window.matLoad()}catch(e){}}}

/* ===== v6: لوحة إدارة موسّعة (امتحانات / شات / أخبار / إعدادات عامة / تعديل الحسابات والمجموعات) ===== */
const chk=(on,fn)=>`<label class="st-switch"><input type="checkbox" ${on?'checked':''} onchange="${fn}"><span></span></label>`;
const gT=id=>(G(id)||{}).title||'—';
const xList=()=>{const q=(NS.xq||'').trim().toLowerCase(),a=S.e.filter(e=>!q||(e.name||'').toLowerCase().includes(q)).slice(0,40);
 return a.map(e=>{const n=S.s.filter(s=>s.e===e.id).length;return `<div class="st-ar"><div class="st-ai"><b>${esc(e.name||'امتحان')} ${e.hw?'📚':''}</b><small>${esc(gT(e.g))} · ${esc((U((G(e.g)||{}).t)||{}).name||'')} · ${n} تسليم · ${e.pub?'منشور':'مسودة'}</small></div><div class="st-ab"><button class="b s" title="نشر/إخفاء" onclick="stA.xpub('${e.id}')">${e.pub?'👁️':'🙈'}</button><button class="b s" title="مسح كل التسليمات" onclick="stA.xrst('${e.id}')">🧽</button><button class="b r" onclick="stA.xdel('${e.id}')">🗑️</button></div></div>`}).join('')||'<p class="mut">لا امتحانات</p>'};
function tabX(){return `<h4>📝 كل الامتحانات والواجبات (${S.e.length})</h4><input class="srch" placeholder="🔍 ابحث باسم الامتحان…" value="${esc(NS.xq||'')}" oninput="stA.xq(this.value)"><div id="st-xl">${xList()}</div>`}
const cList=()=>{const q=(NS.cq||'').trim().toLowerCase(),a=S.m.filter(x=>!q||String(x.t||'').toLowerCase().includes(q)||((U(x.u)||{}).name||'').toLowerCase().includes(q)).slice(-40).reverse();
 return a.map(x=>`<div class="st-ar"><div class="st-ai"><b>${esc((U(x.u)||{}).name||'—')} <small class="mut">· ${esc(x.g?gT(x.g):'خاص')}</small></b><small>${esc(String(x.t||(x.im?'[صورة]':'')).slice(0,120))}</small></div><button class="b r" onclick="stA.mdel('${x.id}')">🗑️</button></div>`).join('')||'<p class="mut">لا رسائل</p>'};
function tabC(){return `<h4>💬 مراقبة الشات (آخر 40 رسالة)</h4><input class="srch" placeholder="🔍 ابحث في النص أو الاسم…" value="${esc(NS.cq||'')}" oninput="stA.cq(this.value)"><div id="st-cl">${cList()}</div><h4>🧹 مسح شات مجموعة</h4>${S.g.map(g=>`<div class="st-ar"><div class="st-ai"><b>${esc(g.title)}</b><small>${S.m.filter(x=>x.g===g.id).length} رسالة</small></div><button class="b r" onclick="stA.mclr('${g.id}')">مسح</button></div>`).join('')||'<p class="mut">لا مجموعات</p>'}`}
function tabN(){const a=S.nw||[];return `<h4>📰 الأخبار والإعلانات (${a.length})</h4>`+(a.map(n=>`<div class="st-ar"><div class="st-ai"><b>${esc(String(n.ti||n.t||n.title||n.h||'(بدون عنوان)').slice(0,80))}</b><small>${esc((U(n.by)||{}).name||'الإدارة')} · ${new Date(n.d||0).toLocaleDateString('ar-EG')}</small></div><button class="b r" onclick="stA.ndel('${n.id}')">🗑️</button></div>`).join('')||'<p class="mut">لا أخبار</p>')}
function tabW(){const mt=cfg('maint')||{};return `<h4>🚧 وضع الصيانة</h4><p class="mut">لما يتفعّل، كل المستخدمين (غير المدير) يشوفوا رسالة صيانة بدل المنصة.</p><div class="st-dz"><div><b>تفعيل وضع الصيانة</b></div>${chk(mt.on,"stA.mset(this.checked)")}</div><textarea id="smm" rows="2" maxlength="200" placeholder="رسالة الصيانة">${esc(mt.t||'')}</textarea><button class="b s" onclick="stA.mmsg()">💾 حفظ الرسالة</button>
<h4>➕ إضافة حساب يدوياً</h4><button class="b" onclick="stA.uadd()">إنشاء حساب جديد</button>
<h4>🩺 فحص سلامة البيانات</h4>${(()=>{const em={},dup=[];S.u.forEach(u=>{const k=(u.email||'').toLowerCase();if(k){em[k]=(em[k]||0)+1}});for(const k in em)if(em[k]>1)dup.push(k);const gi=new Set(S.g.map(g=>g.id)),ei=new Set(S.e.map(e=>e.id));
 const r=[['بريد مكرر',dup.length],['امتحانات بلا مجموعة',S.e.filter(e=>!gi.has(e.g)).length],['تسليمات يتيمة',S.s.filter(s=>!ei.has(s.e)).length],['حسابات بلا بريد/هاتف',S.u.filter(u=>!u.email&&!u.phone).length],['كلمات مرور غير مشفّرة',S.u.filter(u=>u.pw&&!String(u.pw).startsWith('h:')).length]];
 return r.map(x=>`<div class="st-ar"><div class="st-ai"><b>${x[0]}</b></div><span class="tag" style="${x[1]?'color:var(--bad)':''}">${x[1]}</span></div>`).join('')+'<p class="mut">المشاكل اليتيمة تُحل بـ «تنظيف» من تبويب البيانات.</p>'})()}`}
ATABS.push(['x','📝 الامتحانات'],['c','💬 الشات'],['n','📰 الأخبار'],['w','⚙️ عام']);
/* حسابات: زر تعديل */
const _ar=admRows;admRows=us=>_ar(us).replace(/<button class="b s" title="كلمة مرور مؤقتة"/g,'<button class="b s" title="تعديل البيانات" onclick="stA.ued(this.closest(\'.st-ar\').dataset.id)">✏️</button><button class="b s" title="كلمة مرور مؤقتة"');
const _al=admList;admList=function(){return _al().replace(/<div class="st-ar">(<div class="st-ai">[\s\S]*?stA\.sus\('([^']+)'\))/g,'<div class="st-ar" data-id="$2">$1')};
/* مجموعات: تعديل */
tabG=function(){return S.g.length?S.g.map(g=>`<div class="st-ar"><div class="st-ai"><b>${esc(g.title||'—')} ${g.lock?'🔒':''}</b><small>${esc((U(g.t)||{}).name||'—')} · ${(g.st||[]).length} طالب · ${S.e.filter(e=>e.g===g.id).length} امتحان · <span dir="ltr">${esc(g.code||'')}</span></small></div><div class="st-ab"><button class="b s" onclick="stA.ged('${g.id}')">✏️</button><button class="b s" onclick="stA.glock('${g.id}')">${g.lock?'🔓':'🔒'}</button><button class="b r" onclick="stA.gdel('${g.id}')">🗑️</button></div></div>`).join(''):'<p class="mut">لا توجد مجموعات</p>'};
Object.assign(window.stA,{
 xq(v){NS.xq=v;const l=$('#st-xl');if(l)l.innerHTML=xList()},cq(v){NS.cq=v;const l=$('#st-cl');if(l)l.innerHTML=cList()},
 xpub(id){if(!canA())return;const e=E(id);if(!e)return;e.pub=e.pub?0:1;aud((e.pub?'نشر':'إخفاء')+' امتحان «'+e.name+'»');save();rb()},
 async xrst(id){if(!canA())return;const e=E(id);if(!e||!await askc('مسح كل تسليمات «'+e.name+'» ليعيد الطلاب المحاولة؟'))return;US('s',s=>s.e!==id);aud('مسح تسليمات «'+e.name+'»');save();rb();toast('تم المسح')},
 async xdel(id){if(!canA())return;const e=E(id);if(!e||!await askc('حذف «'+e.name+'» نهائياً مع تسليماته؟'))return;US('s',s=>s.e!==id);US('k',k=>k.id!==id);US('e',x=>x.id!==id);aud('حذف امتحان «'+e.name+'»');save();rb();toast('تم الحذف')},
 mdel(id){if(!canA())return;US('m',x=>x.id!==id);save();$('#st-cl').innerHTML=cList();toast('تم حذف الرسالة')},
 async mclr(g){if(!canA()||!await askc('مسح كل رسائل مجموعة «'+gT(g)+'»؟'))return;US('m',x=>x.g!==g);aud('مسح شات «'+gT(g)+'»');save();rb()},
 async ndel(id){if(!canA()||!await askc('حذف هذا الخبر؟'))return;US('nw',x=>x.id!==id);aud('حذف خبر');save();rb()},
 mset(on){if(!canA())return;cset('maint',{on:on?1:0},(on?'تفعيل':'إيقاف')+' وضع الصيانة');R()},mmsg(){if(!canA())return;cset('maint',{t:$('#smm').value.trim()},'تعديل رسالة الصيانة');toast('✅ تم الحفظ')},
 ued(id){if(!canA())return;const u=U(id);if(!u||u.role==='admin')return;const bg=modal(`<h3>✏️ تعديل «${esc(u.name)}»</h3><input id="sue1" value="${esc(u.name||'')}" placeholder="الاسم"><input id="sue2" dir="ltr" value="${esc(u.email||'')}" placeholder="البريد"><input id="sue3" dir="ltr" value="${esc(u.phone||'')}" placeholder="الهاتف"><div class="row"><button class="b s" id="sx1">إلغاء</button><button class="b" id="sx2">حفظ</button></div>`);
  bg.querySelector('#sx1').onclick=()=>bg.remove();bg.querySelector('#sx2').onclick=()=>{const n=bg.querySelector('#sue1').value.trim(),e=bg.querySelector('#sue2').value.trim().toLowerCase(),p=bg.querySelector('#sue3').value.trim();
   if(n.length<3)return toast('الاسم قصير');if(e&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e))return toast('بريد غير صحيح');if(e&&S.u.some(x=>x.id!==id&&(x.email||'').toLowerCase()===e))return toast('البريد مستخدم لحساب آخر');
   u.name=n;u.email=e;u.phone=p;aud('تعديل بيانات «'+n+'»');save();bg.remove();rb();toast('✅ تم الحفظ')}},
 uadd(){if(!canA())return;const bg=modal(`<h3>➕ حساب جديد</h3><input id="sua1" placeholder="الاسم الكامل"><input id="sua2" dir="ltr" placeholder="البريد"><input id="sua3" dir="ltr" placeholder="الهاتف (اختياري)"><select id="sua4">${['student','parent','teacher','assistant'].map(r=>`<option value="${r}">${stRoleLabel(r)}</option>`).join('')}</select><input id="sua5" type="password" placeholder="كلمة المرور (6+)" autocomplete="new-password"><div class="row"><button class="b s" id="sx1">إلغاء</button><button class="b" id="sx2">إنشاء</button></div>`);
  bg.querySelector('#sx1').onclick=()=>bg.remove();bg.querySelector('#sx2').onclick=async()=>{const v=i=>bg.querySelector('#sua'+i).value.trim(),e=v(2).toLowerCase();if(v(1).length<3)return toast('الاسم قصير');if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e))return toast('بريد غير صحيح');if(v(5).length<6)return toast('كلمة المرور قصيرة');if(S.u.some(x=>(x.email||'').toLowerCase()===e))return toast('البريد مسجّل بالفعل');
   S.u.push({id:uid(),name:v(1),email:e,phone:v(3),pw:await hp(v(5)),role:v(4),ok:1,pv:1,ev:1});aud('إنشاء حساب «'+v(1)+'»');save();bg.remove();rb();toast('✅ تم إنشاء الحساب')}},
 ged(id){if(!canA())return;const g=G(id);if(!g)return;const bg=modal(`<h3>✏️ تعديل المجموعة</h3><input id="sg1" value="${esc(g.title||'')}"><select id="sg2">${S.u.filter(u=>u.role==='teacher').map(u=>`<option value="${u.id}" ${u.id===g.t?'selected':''}>${esc(u.name)}</option>`).join('')}</select><div style="max-height:180px;overflow:auto">${(g.st||[]).map(s=>`<div class="st-ar"><div class="st-ai"><b>${esc((U(s.u)||{}).name||'—')}</b></div><button class="b r" data-k="${s.u}">إزالة</button></div>`).join('')||'<p class="mut">لا طلاب</p>'}</div><div class="row"><button class="b s" id="sx1">إغلاق</button><button class="b" id="sx2">حفظ</button></div>`);
  bg.querySelector('#sx1').onclick=()=>bg.remove();bg.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{g.st=g.st.filter(s=>s.u!==b.dataset.k);aud('إزالة طالب من «'+g.title+'»');save();bg.remove();rb();toast('تمت الإزالة')});
  bg.querySelector('#sx2').onclick=()=>{const t=bg.querySelector('#sg1').value.trim();if(t.length<2)return toast('الاسم قصير');g.title=t;g.t=bg.querySelector('#sg2').value||g.t;aud('تعديل مجموعة «'+t+'»');save();bg.remove();rb();toast('✅ تم الحفظ')}}});
/* وضع الصيانة */
{const _p9=post;post=function(){_p9();try{const mt=cfg('maint');if(mt&&mt.on&&!canA()&&!$('#st-maint'))$('#app').innerHTML=`<div class="card" id="st-maint" style="text-align:center;padding:40px 16px"><div style="font-size:54px">🚧</div><h2>المنصة تحت الصيانة</h2><p class="mut">${esc(mt.t||'نعود قريباً، شكراً لصبركم.')}</p></div>`}catch(e){}}}

/* ==========================================================================
   [THEMES] محرّك ثيمات الألوان — ثيمات جاهزة + ثيمات مخصّصة من لوحة الإدارة
   - الثيم المفعّل بيتخزّن جوه إعداد "site" (حقل tmv) فبيتزامن مع كل المستخدمين.
   - الثيمات المخصّصة بتتخزّن في إعداد "cthemes" (حد أقصى 20).
   - كل ثيم = 8 ألوان؛ باقي الألوان (النص، الحدود، الوضع الليلي، لون الكتابة فوق
     الأزرار...) بتتحسب تلقائياً مع ضمان تباين مقروء.
   ========================================================================== */
const STH_PRESETS=[
 {id:'board',  e:'🏫',n:'السبورة (الافتراضي)',p:'#0f766e',s:'#115e59',a:'#e9b824',hd:'#0c1f1b',bgl:'#f2f5f1',bgd:'#0b1512',cdl:'#ffffff',cdd:'#13211d'},
 {id:'ocean',  e:'🌊',n:'المحيط',            p:'#2563eb',s:'#0ea5e9',a:'#f59e0b',hd:'#0b2a66',bgl:'#f1f5fb',bgd:'#0a1428',cdl:'#ffffff',cdd:'#111c36'},
 {id:'nile',   e:'⛵',n:'النيل',             p:'#0369a1',s:'#0891b2',a:'#fbbf24',hd:'#082f49',bgl:'#f0f7fb',bgd:'#07141c',cdl:'#ffffff',cdd:'#0e2230'},
 {id:'royal',  e:'👑',n:'الملكي',            p:'#7c3aed',s:'#ec4899',a:'#fbbf24',hd:'#2e1065',bgl:'#f6f3fc',bgd:'#120c24',cdl:'#ffffff',cdd:'#1b1336'},
 {id:'sunset', e:'🌅',n:'الغروب',            p:'#ea580c',s:'#f43f5e',a:'#facc15',hd:'#431407',bgl:'#fdf5ef',bgd:'#1a0f0a',cdl:'#ffffff',cdd:'#271712'},
 {id:'forest', e:'🌲',n:'الغابة',            p:'#15803d',s:'#22c55e',a:'#eab308',hd:'#0f2e1b',bgl:'#f1f7f2',bgd:'#0a140d',cdl:'#ffffff',cdd:'#12231a'},
 {id:'mint',   e:'🍃',n:'النعناع',           p:'#0d9488',s:'#14b8a6',a:'#fb923c',hd:'#063b36',bgl:'#effaf7',bgd:'#08171a',cdl:'#ffffff',cdd:'#0f2427'},
 {id:'rose',   e:'🌹',n:'الورد',             p:'#e11d48',s:'#fb7185',a:'#f59e0b',hd:'#4c0a1f',bgl:'#fdf2f4',bgd:'#1a0a0f',cdl:'#ffffff',cdd:'#2a1219'},
 {id:'candy',  e:'🍬',n:'الباستيل المرح',    p:'#db2777',s:'#8b5cf6',a:'#22d3ee',hd:'#4a0d33',bgl:'#fdf2f8',bgd:'#1a0b16',cdl:'#ffffff',cdd:'#2a1425'},
 {id:'gold',   e:'✨',n:'الذهبي الفاخر',     p:'#b45309',s:'#d97706',a:'#fcd34d',hd:'#1c1917',bgl:'#faf7f0',bgd:'#12100c',cdl:'#ffffff',cdd:'#1f1b16'},
 {id:'ramadan',e:'🌙',n:'رمضان',             p:'#b7791f',s:'#d69e2e',a:'#f6c453',hd:'#1a1a40',bgl:'#faf6ea',bgd:'#0e0f26',cdl:'#fffdf6',cdd:'#181a3a'},
 {id:'midnight',e:'🌌',n:'منتصف الليل',      p:'#6366f1',s:'#22d3ee',a:'#f472b6',hd:'#0b1020',bgl:'#eef0f8',bgd:'#070b16',cdl:'#ffffff',cdd:'#10162a'},
 {id:'graphite',e:'🩶',n:'الرمادي الاحترافي',p:'#334155',s:'#64748b',a:'#38bdf8',hd:'#0f172a',bgl:'#f1f5f9',bgd:'#0b1120',cdl:'#ffffff',cdd:'#141c2f'}
];
const STH_KEYS=['p','s','a','hd','bgl','bgd','cdl','cdd'];
const STH_LBL={p:'اللون الأساسي (الأزرار والروابط)',s:'اللون الثانوي',a:'لون التمييز (الخط تحت الهيدر)',hd:'لون الهيدر والبانر',bgl:'خلفية الوضع النهاري',bgd:'خلفية الوضع الليلي',cdl:'الكروت — نهاري',cdd:'الكروت — ليلي'};
const STH_MAX=20;
const sthHex=/^#[0-9a-fA-F]{6}$/;
const sthRGB=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const sthToHex=a=>'#'+a.map(v=>Math.round(Math.max(0,Math.min(255,v))).toString(16).padStart(2,'0')).join('');
const sthMix=(a,b,t)=>{const x=sthRGB(a),y=sthRGB(b);return sthToHex(x.map((v,i)=>v*(1-t)+y[i]*t))};
const sthLum=h=>{const c=sthRGB(h).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]};
const sthCR=(a,b)=>{const x=sthLum(a),y=sthLum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
const sthOn=h=>sthCR(h,'#ffffff')>=sthCR(h,'#0b1220')?'#ffffff':'#0b1220';
/* تنظيف ثيم قادم من أي مصدر (إعدادات/استيراد) — يرجّع null لو ناقص أو غير صالح */
function sthClean(t){if(!t||typeof t!=='object')return null;const o={id:String(t.id||'').replace(/[^\w-]/g,'').slice(0,24),n:String(t.n||'').replace(/[<>]/g,'').trim().slice(0,28),e:String(t.e||'🎨').slice(0,4)};
 for(const k of STH_KEYS){const v=String(t[k]||'').trim();if(!sthHex.test(v))return null;o[k]=v.toLowerCase()}
 return o}
const sthCustom=()=>((cfg('cthemes')||{}).l||[]).map(sthClean).filter(Boolean);
const sthFind=id=>STH_PRESETS.find(x=>x.id===id)||sthCustom().find(x=>x.id===id)||null;
const sthSaved=()=>{const p=window.__sprev;window.__sprev=null;try{return siteCfg()}finally{window.__sprev=p}};
/* المتغيّرات لكل وضع */
function sthVars(t,dk){
 const p=dk?sthMix(t.p,'#ffffff',.3):t.p,s=dk?sthMix(t.s,'#ffffff',.3):t.s,hd=dk?sthMix(t.hd,'#000000',.3):t.hd;
 const bg=dk?t.bgd:t.bgl,card=dk?t.cdd:t.cdl;
 const tx=dk?sthMix('#ffffff',t.p,.07):sthMix(t.hd,'#000000',.3);
 const mut=sthMix(tx,bg,.3),bd=sthMix(tx,bg,.86),inp=sthMix(bg,card,.5);
 return {p,s,a:t.a,hd,bg,card,tx,mut,bd,inp,onp:sthOn(p),onhd:sthOn(hd),ona:sthOn(t.a)}}
function sthCSS(raw){
 const t=sthClean(raw);if(!t)return '';
 const K=':root:root:root:root:root',B=K+' body ';
 const v=dk=>{const o=sthVars(t,dk);return `--pri:${o.p}!important;--pri2:${o.s}!important;--acc:${o.a}!important;--hd:${o.hd}!important;--rc:${o.p}!important;--bg:${o.bg}!important;--card:${o.card}!important;--inp:${o.inp}!important;--tx:${o.tx}!important;--mut:${o.mut}!important;--bd:${o.bd}!important;--sh:color-mix(in srgb,${o.p} ${dk?18:14}%,transparent)!important;--soft:color-mix(in srgb,${o.p} ${dk?18:12}%,${o.card})!important;--grad:linear-gradient(135deg,${o.p},${o.s})!important;--glow:none!important;--onp:${o.onp};--onhd:${o.onhd};--ona:${o.ona};--hdr:${o.hd}!important;--onhdr:${o.onhd};--hbtn:color-mix(in srgb,${o.onhd} 14%,transparent);--hbd:color-mix(in srgb,${o.onhd} 26%,transparent);--hdb:3px solid ${o.a}`};
 let c=`${K}:not([data-theme=dark]){${v(0)}}${K}[data-theme=dark]{${v(1)}}`;
 c+=`${B}header,${B}[data-role=teacher] header{background:var(--hd)!important;color:var(--onhd)!important;border-bottom:3px solid var(--acc)!important}`;
 c+=`${B}.hero,${B}.banner,${B}.card.banner{background:var(--hd)!important;color:var(--onhd)!important;border-bottom:4px solid var(--acc)!important}`;
 c+=`${B}.hero h1,${B}.hero h2,${B}.hero p,${B}.banner h2,${B}.banner .big{color:var(--onhd)!important}`;
 c+=`${B}.banner .pill{background:color-mix(in srgb,var(--onhd) 14%,transparent)!important;color:var(--onhd)!important}`;
 c+=`${B}button.b:not(.s):not(.g):not(.r){background:var(--pri)!important;color:var(--onp)!important}`;
 c+=`${B}.hero .b.hb:not(.s){background:var(--acc)!important;color:var(--ona)!important}`;
 c+=`${B}.bb.me{background:var(--pri)!important;color:var(--onp)!important}`;
 c+=`${B}input:focus,${B}select:focus,${B}textarea:focus{outline:3px solid color-mix(in srgb,var(--pri) 30%,transparent)!important;border-color:var(--pri)!important}`;
 return c}
/* ربط الثيم بمُولّد CSS الموقع (قبل ألوان الأدوار عشان تقدر تعدّل عليه) */
{const _sc=siteCSS;siteCSS=function(st){let c='';try{c=sthCSS(st&&st.tmv)}catch(e){console.warn('theme',e)}return c+_sc(st)}}
/* لون شريط المتصفح يتبع الثيم المفعّل */
function sthMeta(){try{const st=siteCfg(),t0=st&&st.tmv?sthClean(st.tmv):null;document.documentElement.toggleAttribute('data-tmv',!!t0);if(!st||!st.tmv)return;const t=sthClean(st.tmv);if(!t)return;const dk=document.documentElement.dataset.theme==='dark';let m=document.querySelector('meta[name=theme-color]');if(!m){m=document.createElement('meta');m.name='theme-color';document.head.appendChild(m)}m.content=sthVars(t,dk).hd}catch(e){}}
{const _Rt=R;R=function(){const r=_Rt.apply(this,arguments);sthMeta();return r}}
/* ---------------- واجهة لوحة الإدارة ---------------- */
const sthMini=t=>`<div class="sth-pv" aria-hidden="true"><div class="sth-h" style="background:${t.hd};border-bottom:3px solid ${t.a}"><i style="background:${t.a}"></i><i style="background:${sthMix(t.hd,'#ffffff',.25)}"></i></div><div class="sth-b"><div style="background:${t.bgl}"><span style="background:${t.cdl}"><u style="background:${t.p}"></u><u style="background:${t.s}"></u></span></div><div style="background:${t.bgd}"><span style="background:${t.cdd}"><u style="background:${sthMix(t.p,'#ffffff',.3)}"></u><u style="background:${sthMix(t.s,'#ffffff',.3)}"></u></span></div></div></div>`;
const sthCard=(t,cur,sel)=>`<button type="button" class="sth-card ${cur===t.id?'cur':''} ${sel===t.id?'sel':''}" onclick="stT.pv('${t.id}')" aria-label="${esc(t.n)}">${sthMini(t)}<b>${t.e||'🎨'} ${esc(t.n)}</b><small>${cur===t.id?'✅ المفعّل حالياً':sel===t.id?'👁️ معاينة':'اضغط للمعاينة'}</small></button>`;
function sthFormVals(t){return STH_KEYS.map(k=>`<label class="sth-f"><span>${STH_LBL[k]}</span><input type="color" id="sth-c-${k}" value="${t[k]}" oninput="stT.cprev()"></label>`).join('')}
function tabTH(){
 const st=sthSaved(),cur=(st.tmv&&sthClean(st.tmv))?(st.tmv.id||'custom'):'board',sel=window.__sthSel||null,C=sthCustom();
 const ed=window.__sthEd?C.find(x=>x.id===window.__sthEd):null,base=ed||(sel&&sthFind(sel))||sthFind(cur)||STH_PRESETS[0];
 const selT=sel?sthFind(sel):null;
 return `<h4>🎭 ثيمات جاهزة</h4><p class="mut">اضغط على أي ثيم تشوفه قدامك فوراً (معاينة عندك أنت بس)، ولما يعجبك اضغط «تطبيق للجميع» وهيتغيّر لكل المستخدمين — نهاري وليلي.</p>
 ${selT?`<div class="sth-bar"><div>👁️ معاينة: <b>${esc(selT.n)}</b> — لم تُحفظ بعد</div><div class="row"><button class="b s" onclick="stT.cancel()">إلغاء</button><button class="b" onclick="stT.apply('${selT.id}')">✅ تطبيق للجميع</button></div></div>`:''}
 <div class="sth-grid">${STH_PRESETS.map(t=>sthCard(t,cur,sel)).join('')}</div>
 <h4>🧑‍🎨 ثيماتك المخصّصة (${C.length}/${STH_MAX})</h4>
 ${C.length?`<div class="sth-grid">${C.map(t=>sthCard(t,cur,sel)).join('')}</div><div class="sth-list">${C.map(t=>`<div class="st-ar"><div class="st-ai"><b>${esc(t.n)}</b></div><div class="st-ab"><button class="b s" onclick="stT.edit('${t.id}')">✏️ تعديل</button><button class="b s" onclick="stT.dup('${t.id}')">📄 نسخ</button><button class="b s" onclick="stT.exp('${t.id}')">📤</button><button class="b r" onclick="stT.del('${t.id}')">🗑️</button></div></div>`).join('')}</div>`:'<p class="mut">لسه معندكش ثيمات مخصّصة — اعمل أول واحد من الأسفل 👇</p>'}
 <h4>${ed?'✏️ تعديل ثيم: '+esc(ed.n):'➕ إنشاء ثيم جديد'}</h4>
 <p class="mut">اختار الألوان وهتشوف التغيير مباشرة. تقدر تبدأ من ثيم جاهز وتعدّل عليه.</p>
 <div class="sth-form" id="sth-form">
  <input id="sth-n" maxlength="28" placeholder="اسم الثيم (مثال: ثيم المدرسة)" value="${esc(ed?ed.n:'')}">
  <select id="sth-from" onchange="stT.from(this.value)"><option value="">ابدأ من ثيم جاهز…</option>${STH_PRESETS.map(t=>`<option value="${t.id}">${t.e} ${esc(t.n)}</option>`).join('')}</select>
  <div class="sth-colors" id="sth-colors">${sthFormVals(base)}</div>
  <div class="sth-note" id="sth-note"></div>
  <div class="row"><button class="b s" onclick="stT.csave(0)">💾 ${ed?'حفظ التعديل':'حفظ الثيم'}</button><button class="b" onclick="stT.csave(1)">💾 حفظ وتطبيق للجميع</button>${ed?'<button class="b s" onclick="stT.edit(null)">إلغاء التعديل</button>':''}</div>
 </div>
 <h4>📥 استيراد ثيم</h4><div class="st-dz"><div><b>ملف ثيم (JSON)</b><p class="mut">استورد ثيم اتصدّر من منصة تانية أو من هنا.</p></div><button class="b s" onclick="document.getElementById('sth-imp').click()">اختيار ملف</button><input type="file" id="sth-imp" accept=".json,application/json" hidden onchange="stT.imp(this)"></div>
 <h4>↩️ الرجوع للافتراضي</h4><div class="st-dz"><div><b>ثيم السبورة الافتراضي</b><p class="mut">بيلغي أي ثيم مفعّل ويرجّع الشكل الأصلي لكل المستخدمين.</p></div><button class="b s" onclick="stT.reset()">رجوع للافتراضي</button></div>`}
/* قراءة الألوان الحالية من الفورم */
function sthRead(){const t={id:window.__sthEd||'',n:(document.getElementById('sth-n')||{}).value||'',e:'🎨'};for(const k of STH_KEYS){const el=document.getElementById('sth-c-'+k);t[k]=el?el.value:'#000000'}return t}
/* فحص منطقي للألوان — يرجّع رسالة تحذير أو '' */
function sthCheck(t){const w=[];if(sthLum(t.bgl)<.35)w.push('خلفية النهار غامقة قوي — خليها فاتحة');if(sthLum(t.bgd)>.22)w.push('خلفية الليل فاتحة قوي — خليها غامقة');if(sthLum(t.hd)>.45)w.push('لون الهيدر فاتح — الأفضل لون غامق');if(sthCR(t.p,t.bgl)<2.2)w.push('اللون الأساسي قريب من خلفية النهار');return w.join(' • ')}
function sthSetNote(t){const n=document.getElementById('sth-note');if(!n)return;const w=sthCheck(t);n.textContent=w?'⚠️ '+w:'✅ الألوان مناسبة';n.className='sth-note '+(w?'bad':'ok')}
function sthPrevT(t){window.__sprev=Object.assign({},sthSaved(),{tmv:t});window.__ssg='';applyUI();sthMeta()}
function sthNewId(){return 'c'+Date.now().toString(36)+Math.floor(Math.random()*36).toString(36)}
window.stT={
 pv(id){if(!canA())return;const t=sthFind(id);if(!t)return;window.__sthSel=id;window.__sthEd=null;sthPrevT(t);rb()},
 cancel(){window.__sthSel=null;window.__sprev=null;window.__ssg='';applyUI();rb()},
 apply(id){if(!canA())return;const t=sthFind(id);if(!t)return toast('الثيم غير موجود');
  const snap=Object.assign({},t);window.__sprev=null;window.__sthSel=null;
  cset('site',{roles:{},tmv:id==='board'?null:snap},'تطبيق ثيم ألوان «'+t.n+'»');window.__ssg='';applyUI();sthMeta();rb();toast('🎭 تم تطبيق «'+t.n+'» لكل المستخدمين')},
 reset(){if(!canA())return;window.__sprev=null;window.__sthSel=null;cset('site',{tmv:null},'رجوع ثيم الألوان للافتراضي');window.__ssg='';applyUI();rb();toast('تم الرجوع للثيم الافتراضي')},
 cprev(){if(!canA())return;const t=sthRead();window.__sthSel=null;sthSetNote(t);sthPrevT(t)},
 from(id){const t=sthFind(id);if(!t)return;STH_KEYS.forEach(k=>{const el=document.getElementById('sth-c-'+k);if(el)el.value=t[k]});stT.cprev()},
 edit(id){window.__sthEd=id||null;window.__sthSel=null;window.__sprev=null;window.__ssg='';applyUI();rb();if(id){const t=sthFind(id);if(t)sthPrevT(t);const f=document.getElementById('sth-form');if(f)f.scrollIntoView({behavior:'smooth',block:'center'})}},
 csave(applyNow){if(!canA())return;const t=sthRead();t.n=t.n.trim();if(!t.n)return toast('اكتب اسم الثيم الأول');
  const w=sthCheck(t);if(w&&/غامقة قوي|فاتحة قوي/.test(w))return toast('⚠️ '+w);
  let l=sthCustom();const ed=window.__sthEd;
  if(ed){const i=l.findIndex(x=>x.id===ed);if(i<0)return toast('الثيم غير موجود');t.id=ed;l[i]=t}
  else{if(l.length>=STH_MAX)return toast('الحد الأقصى '+STH_MAX+' ثيم — احذف ثيم قديم');if(l.some(x=>x.n===t.n))return toast('فيه ثيم بنفس الاسم — غيّر الاسم');t.id=sthNewId();l.push(t)}
  cset('cthemes',{l},(ed?'تعديل':'إنشاء')+' ثيم مخصّص «'+t.n+'»');window.__sthEd=null;window.__sprev=null;
  if(applyNow){window.__sthSel=null;stT.apply(t.id);return}
  window.__sthSel=t.id;sthPrevT(t);rb();toast('✅ تم حفظ الثيم — اضغط «تطبيق للجميع» لما تحب')},
 dup(id){if(!canA())return;const t=sthFind(id);if(!t)return;const l=sthCustom();if(l.length>=STH_MAX)return toast('الحد الأقصى '+STH_MAX+' ثيم');const c=Object.assign({},t,{id:sthNewId(),n:(t.n+' (نسخة)').slice(0,28)});l.push(c);cset('cthemes',{l},'نسخ ثيم «'+t.n+'»');rb();toast('📄 تم النسخ')},
 async del(id){if(!canA())return;const t=sthFind(id);if(!t)return;if(!await askc('حذف الثيم «'+t.n+'»؟'))return;
  const l=sthCustom().filter(x=>x.id!==id);cset('cthemes',{l},'حذف ثيم «'+t.n+'»');
  const st=sthSaved();if(st.tmv&&st.tmv.id===id)cset('site',{tmv:null},'إلغاء ثيم محذوف');
  window.__sthSel=null;window.__sthEd=null;window.__sprev=null;window.__ssg='';applyUI();rb();toast('🗑️ تم الحذف')},
 exp(id){const t=sthFind(id);if(!t)return;const o={};['n','p','s','a','hd','bgl','bgd','cdl','cdd'].forEach(k=>o[k]=t[k]);o.type='smart-teacher-theme';dl('theme-'+t.id+'.json',JSON.stringify(o,null,1))},
 imp(inp){if(!canA())return;const f=inp.files&&inp.files[0];inp.value='';if(!f)return;if(f.size>20000)return toast('الملف كبير — مش ملف ثيم');
  const r=new FileReader();r.onload=()=>{let o;try{o=JSON.parse(r.result)}catch(e){return toast('❌ ملف غير صالح')}
   const t=sthClean(Object.assign({id:'x'},o));if(!t||!t.n)return toast('❌ الملف ناقص ألوان أو اسم');
   const l=sthCustom();if(l.length>=STH_MAX)return toast('الحد الأقصى '+STH_MAX+' ثيم');t.id=sthNewId();l.push(t);cset('cthemes',{l},'استيراد ثيم «'+t.n+'»');window.__sthSel=t.id;sthPrevT(t);rb();toast('📥 تم الاستيراد — اضغط «تطبيق للجميع»')};r.readAsText(f)}
};
/* تسجيل التبويب بعد «المظهر» + تنظيف حالة المعاينة عند تغيير التبويب */
{const i=ATABS.findIndex(x=>x[0]==='d');if(!ATABS.some(x=>x[0]==='th'))ATABS.splice(i<0?ATABS.length:i,0,['th','🌈 الثيمات'])}
{const _tb=window.stA.tab;window.stA.tab=function(t){window.__sthSel=null;window.__sthEd=null;_tb(t)}}

window.__ST={cfg,setCfg,cset,aud,modal,NS,ATABS,canA,rb,dl,dstr};
applyUI();

R();
})();
