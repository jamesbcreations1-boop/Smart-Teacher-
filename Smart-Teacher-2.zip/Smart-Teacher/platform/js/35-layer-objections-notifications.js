/* ▓▓ 35-layer-objections-notifications.js — v5: الاعتراضات والإشعارات
   بيتحمّل بعد: 34-layer-admin-panel-themes-materials.js  |  وبعده: 36-layer-attendance-fees-eval.js
   ⚠ ما تغيّرش ترتيب الملفات في index.html — كل ملف بيعدّل اللي قبله. ▓▓ */
/* ==========================================================================
   [16] v5: الاعتراضات والإشعارات
   ========================================================================== */
(()=>{
/* ===== v5: مركز الاعتراضات + توجيه كل الإشعارات + حذف الامتحان + رفض/حذف الطلاب بإشعار + علامة المخالفات ===== */
const isTch=()=>me()?.role==='teacher',isAsst=()=>me()?.role==='assistant';
const eg=e=>e&&G(e.g);
S.d=S.d||[];
/* الاعتراضات التي يحق للمستخدم الحالي رؤيتها: المدرس صاحب المجموعة أو مساعدها */
const myDisputes=()=>{const m=me();if(!m)return[];return(S.d||[]).filter(d=>{const e=E(d.e),g=eg(e);if(!e||!g)return false;return m.role==='teacher'?g.t===m.id:m.role==='assistant'?(g.as||[]).includes(m.id):false})};
const openCount=()=>myDisputes().filter(d=>d.status==='open').length;
const STL={open:'⏳ قيد المراجعة',rejected:'✘ مرفوض','fixed-all':'✅ صُحّح للجميع','fixed-one':'✅ تم قبول اعتراضك'};
const qNo=(e,id)=>{const i=e.q.findIndex(q=>q.id===id);return i<0?'—':i+1};

/* ---------- 1) الإشعارات: كل إشعار يفتح الصفحة المناسبة ---------- */
const _nf=notify;
notify=function(to,txt,k,gt){
  const ex=k&&S.n.find(n=>n.to===to&&n.k===k&&!n.r);
  _nf(to,txt,k);
  if(gt){const x=ex||S.n[0];if(x&&x.to===to){x.gt=gt;save()}}
};
function route(gt){
  const [k,a,b]=String(gt).split('|');
  if(k==='group'&&G(a)){if(isAsst()){go('chats');setTimeout(()=>{try{x27_asOpen(a)}catch(e){}},0)}else go('group',a,b||undefined);return true}
  if(k==='asopen'&&G(a)){go('chats');setTimeout(()=>{try{x27_asOpen(a)}catch(e){}},0);return true}
  if(k==='review'&&E(a)&&isTch()){go('review',a);return true}
  if(k==='res'&&E(a)){go('exam',a,'res');return true}
  if(k==='disp'){go('disputes',a&&E(a)?a:undefined);return true}
  return false}
const _o5=openN;
openN=function(id){
  const x=S.n.find(y=>y.id===id);
  if(x){const k=x.k||'';
    if(x.gt){x.r=1;save();if(route(x.gt))return}
    const orig=(k[0]==='g'&&G(k.slice(1)))||(k[0]==='p'&&U(k.slice(1)));
    if(!orig){
      if(/^(np|lk|cm|sh)/.test(k)){x.r=1;save();try{ST.tab='all'}catch(e){}go('soc');return}
      if(/^fo/.test(k)&&U(k.slice(2))){x.r=1;save();prof(k.slice(2));return}
      if(/^(bt|pl|sb|sow)/.test(k)){x.r=1;save();go('dash');return}
    }
  }
  return _o5(id)};

/* ---------- 2) الاعتراضات: نموذج الطالب ---------- */
x26_disputeForm=function(eid){
  const e=E(eid);if(!e||e.pr)return'';
  const mine=(S.d||[]).filter(x=>x.e===eid&&x.u===S.me).sort((a,b)=>b.d-a.d);
  return `<div class="card"><h3>⚠️ عندك اعتراض على سؤال؟</h3>
  <select id="x26q">${e.q.map((q,i)=>`<option value="${q.id}">${i+1}. ${esc((q.q||'').slice(0,40))}</option>`).join('')}</select>
  <textarea id="x26r" rows="2" maxlength="500" placeholder="اكتب سبب اعتراضك (5 أحرف على الأقل)..."></textarea>
  <button class="b s" style="width:100%" onclick="x26_sendDispute('${eid}')">إرسال الاعتراض</button>
  ${mine.length?`<h3 style="margin-top:14px">اعتراضاتي</h3>${mine.map(d=>`<div class="card"><div class="row"><b>سؤال ${qNo(e,d.q)}</b><span class="tag">${STL[d.status]||d.status}</span></div><p class="mut">${esc(d.reason)}</p>${d.reply?`<p><b>رد المدرس:</b> ${esc(d.reply)}</p>`:''}${d.status==='open'?`<button class="b s" onclick="x5_withdraw('${d.id}')">سحب الاعتراض</button>`:''}</div>`).join('')}`:''}
  </div>`};
window.x26_sendDispute=function(eid){
  const sel=$('#x26q'),ta=$('#x26r');if(!sel||!ta)return;
  const e=E(eid);if(!e||e.pr)return;
  const q=sel.value,r=(ta.value||'').trim();
  if(r.length<5)return toast('اكتب سبب الاعتراض (5 أحرف على الأقل)');
  if(!S.s.some(s=>s.e===eid&&s.u===S.me))return toast('سلّم الامتحان أولاً');
  if((S.d||[]).some(d=>d.e===eid&&d.q===q&&d.u===S.me&&d.status==='open'))return toast('عندك اعتراض مفتوح على نفس السؤال');
  S.d.push({id:uid(),e:eid,q,u:S.me,reason:r,d:Date.now(),status:'open'});
  const g=G(e.g),t=`⚠️ ${me().name} اعترض على سؤال ${qNo(e,q)} في ${e.name}`;
  if(g){notify(g.t,t,'dp'+eid,'disp|'+eid);(g.as||[]).forEach(a=>notify(a,t,'dp'+eid,'disp|'+eid))}
  save();ta.value='';toast('تم إرسال اعتراضك للمدرس');R()};
window.x5_withdraw=async function(did){
  const d=(S.d||[]).find(x=>x.id===did);if(!d||d.u!==S.me||d.status!=='open')return;
  if(!await ask('سحب هذا الاعتراض؟'))return;
  S.d=S.d.filter(x=>x.id!==did);save();R()};

/* ---------- 3) الاعتراضات: صفحة المدرس/المساعد ---------- */
const X5={f:'open'};
window.x5_f=f=>{X5.f=f;R()};
window.x26_disputesModal=eid=>go('disputes',eid);
window.x26_resolve=function(did,action){
  const d=(S.d||[]).find(x=>x.id===did);if(!d||d.status!=='open')return;
  const e=E(d.e),g=eg(e);
  if(!e||!g||g.t!==S.me)return toast('قرار الاعتراض للمدرس فقط');
  const rp=($('#x5r_'+did)?.value||'').trim(),qi=qNo(e,d.q),now=Date.now();
  if(action==='reject'){d.status='rejected'}
  else{
    const subs=action==='all'?S.s.filter(x=>x.e===d.e):S.s.filter(x=>x.e===d.e&&x.u===d.u);
    subs.forEach(s=>{s.ov=s.ov||{};s.ov[d.q]=true});
    d.status=action==='all'?'fixed-all':'fixed-one';
    if(action==='all'){
      new Set(subs.map(s=>s.u)).forEach(u=>{if(u!==d.u)notify(u,`✏️ عدّل المدرس تصحيح سؤال ${qi} في «${e.name}» — راجع درجتك`,undefined,'res|'+e.id)});
      (S.d||[]).forEach(o=>{if(o!==d&&o.status==='open'&&o.e===d.e&&o.q===d.q){o.status='fixed-all';o.rd=now;o.by=S.me;o.reply=o.reply||'تم التصحيح للجميع'}});
    }
  }
  d.reply=rp;d.rd=now;d.by=S.me;
  notify(d.u,action==='reject'?`✘ تم رفض اعتراضك على سؤال ${qi} في «${e.name}»${rp?': '+rp:''}`:`✅ تم قبول اعتراضك على سؤال ${qi} في «${e.name}»${rp?': '+rp:''}`,undefined,'res|'+e.id);
  save();toast('تم الحفظ');R()};
function x5_card(d,canAct){
  const e=E(d.e),g=eg(e),q=e.q.find(x=>x.id===d.q),u=U(d.u),s=S.s.find(x=>x.e===d.e&&x.u===d.u),open=d.status==='open';
  let ca='';try{ca=ans(q)}catch(er){}
  const sa=s&&s.a?s.a[d.q]:'';
  return `<div class="card" style="border-inline-start:4px solid ${open?'var(--bad)':'#16a34a'}">
  <div class="row"><b>${esc(u?.name||'طالب')}</b><span class="tag">${STL[d.status]==='✅ تم قبول اعتراضك'?'✅ تم القبول':STL[d.status]||d.status}</span></div>
  <p class="mut">${esc(g?.title||'')} • ${esc(e.name)} • ${new Date(d.d).toLocaleString('ar-EG')}</p>
  <p><b>سؤال ${qNo(e,d.q)}:</b> ${esc(q?.q||'—')}</p>
  <p>إجابة الطالب: <b>${esc(sa||'(بدون إجابة)')}</b> — الإجابة المعتمدة: <b>${esc(ca||'—')}</b></p>
  <p><b>سبب الاعتراض:</b> ${esc(d.reason)}</p>
  ${open?(canAct?`<textarea id="x5r_${d.id}" rows="2" placeholder="رد على الطالب (اختياري)"></textarea>
  <div class="row"><button class="b" onclick="x26_resolve('${d.id}','all')">✔ صحّح للجميع</button><button class="b s" onclick="x26_resolve('${d.id}','one')">✔ صحّح له فقط</button><button class="b r" onclick="x26_resolve('${d.id}','reject')">✘ رفض</button></div>`:`<p class="mut">للمتابعة فقط — القرار للمدرس</p>`)+(s&&canAct?`<button class="b s" style="margin-top:6px" onclick="go('grade','${s.id}')">📄 فتح ورقة إجابته</button>`:''):(d.reply?`<p><b>الرد:</b> ${esc(d.reply)}</p>`:'')}
  </div>`}
function x5_page(){
  const m=me(),canAct=m.role==='teacher',ex=V.a&&E(V.a)?V.a:'';
  const all=myDisputes().filter(d=>!ex||d.e===ex).sort((a,b)=>b.d-a.d);
  const f=X5.f,nOpen=all.filter(d=>d.status==='open').length,nDone=all.length-nOpen;
  const L=all.filter(d=>f==='all'||(f==='open'?d.status==='open':d.status!=='open'));
  const back=ex?`go('group','${E(ex).g}','ex')`:`go('dash')`;
  const tab=(k,t)=>`<button class="b ${f===k?'':'s'}" onclick="x5_f('${k}')">${t}</button>`;
  return `<div class="row"><h2>⚠️ اعتراضات الطلاب</h2><button class="b s" onclick="${back}">رجوع</button></div>
  ${ex?`<p class="mut">امتحان: <b>${esc(E(ex).name)}</b> — <a href="#" onclick="go('disputes');return false">عرض كل الامتحانات</a></p>`:''}
  <div class="tabs">${tab('open','قيد المراجعة ('+nOpen+')')}${tab('done','تمت المعالجة ('+nDone+')')}${tab('all','الكل ('+all.length+')')}</div>
  ${L.map(d=>x5_card(d,canAct)).join('')||`<div class="card stc"><p class="mut">${f==='open'?'لا توجد اعتراضات بانتظار المراجعة 🎉':'لا توجد اعتراضات'}</p></div>`}`}

/* ---------- 4) حذف الامتحان ---------- */
window.x5_delE=async function(id){
  const e=E(id);if(!e||eg(e)?.t!==S.me)return;
  const n=S.s.filter(s=>s.e===id).length;
  if(!await ask(`حذف «${e.name}»${n?` وكل تسليمات الطلاب (${n}) واعتراضاتها`:''} نهائياً؟`))return;
  S.e=S.e.filter(x=>x.id!==id);S.s=S.s.filter(s=>s.e!==id);S.d=(S.d||[]).filter(d=>d.e!==id);S.k=S.k.filter(k=>k.id!==id);
  if(S.bt)S.bt=S.bt.filter(b=>b.e!==id);
  save();toast('تم حذف الامتحان');R()};

/* ---------- 5) إشعار الطالب عند الرفض / الإيقاف / الحذف من مجموعة ---------- */
const _stu=stu;
stu=function(gid,i,a){
  const g=G(gid),x=g&&g.st[i];
  if(x){
    if(a==='del')notify(x.u,x.s==='pend'?`✘ تم رفض طلب انضمامك إلى ${g.title}`:`تم حذفك من مجموعة ${g.title}`);
    else if(a==='sus')notify(x.u,`⏸ تم إيقافك مؤقتاً في مجموعة ${g.title}`);
  }
  return _stu(gid,i,a)};

/* ---------- 6) الرسم: صفحة الاعتراضات + حماية الاستوديو + إضافات DOM ---------- */
function x5_post(){
  const m=me(),A=$('#app');if(!m||!A||$('#x27g'))return;
  const staff=m.role==='teacher'||m.role==='assistant';
  if(!staff)return;
  if(V.p==='dash'){const n=openCount();if(n&&!$('#x5dc'))A.insertAdjacentHTML('afterbegin',`<div class="card" id="x5dc" style="border-color:var(--bad)"><div class="row"><div><h3>⚠️ اعتراضات الطلاب</h3><p class="mut">${n} اعتراض بانتظار المراجعة</p></div><button class="b" onclick="go('disputes')">مراجعة الاعتراضات</button></div></div>`)}
  if(V.p==='group'&&V.t==='ex'&&m.role==='teacher'){
    A.querySelectorAll('button[onclick^="editE("]').forEach(b=>{const id=(b.getAttribute('onclick').match(/editE\('([^']+)'/)||[])[1];if(!id||b.parentNode.querySelector('.x5del'))return;
      b.insertAdjacentHTML('afterend',`<button class="b r x5del" onclick="x5_delE('${id}')">🗑 حذف</button>`)});
    A.querySelectorAll('button[onclick^="go(\'review\'"]').forEach(b=>{const id=(b.getAttribute('onclick').match(/go\('review','([^']+)'/)||[])[1];if(!id||b.parentNode.querySelector('.x5dp'))return;
      const n=myDisputes().filter(d=>d.e===id&&d.status==='open').length;
      if(n)b.insertAdjacentHTML('afterend',`<button class="b x5dp" style="background:var(--bad)" onclick="go('disputes','${id}')">⚠️ اعتراضات (${n})</button>`)});
  }
  if(V.p==='review'&&m.role==='teacher'){
    A.querySelectorAll('button[onclick^="go(\'grade\'"]').forEach(b=>{const id=(b.getAttribute('onclick').match(/go\('grade','([^']+)'/)||[])[1],s=S.s.find(x=>x.id===id);
      if(!s||!s.vc||b.parentNode.querySelector('.x5vc'))return;
      b.insertAdjacentHTML('beforebegin',`<span class="tag x5vc" style="background:var(--bad);color:#fff" title="${esc(s.vr||'')}">⚠️ ${s.vc} مخالفة</span> `)});
  }
}
const _R5=R;
R=function(){
  const m=me();
  if(m&&V.p==='studio'&&m.role!=='teacher')V={p:'dash'};
  if(m&&V.p==='disputes'){
    if(m.role!=='teacher'&&m.role!=='assistant'){V={p:'dash'};return _R5.apply(this,arguments)}
    const keep=V;V={p:'dash'};try{_R5.apply(this,arguments)}finally{V=keep}
    const a=$('#app');if(a&&!$('#x27g')){a.innerHTML=x5_page();a.classList.add('an');setTimeout(()=>a.classList.remove('an'),500)}
    document.querySelectorAll('#bn button').forEach(b=>b.classList.remove('on'));
    return}
  _R5.apply(this,arguments);
  try{x5_post()}catch(e){console.warn('v5',e)}
};
R();
})();
