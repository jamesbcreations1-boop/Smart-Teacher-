/* ==========================================================================
   [PUSH] إشعارات الدفع عبر Firebase Cloud Messaging (FCM)
   لازم تتحمّل بعد app.js (عشان تستخدم CFG, DB, S, uid, toast, R, withAuth, AUTH_READY).
   قبل ما يشتغل لازم تملأ في app.js:
     1) CFG.FB.messagingSenderId
     2) CFG.VAPID_KEY
   (التفاصيل في ملف التعليمات المرفق)
   ========================================================================== */
(function(){
  let MSG=null;

  async function initMsg(){
    if(MSG)return MSG;
    if(!window.firebase||!firebase.messaging)return null;
    if(!CFG.FB.messagingSenderId||CFG.FB.messagingSenderId.indexOf('⚠️')===0)return null;
    if(!CFG.VAPID_KEY||CFG.VAPID_KEY.indexOf('⚠️')===0)return null;
    try{MSG=firebase.messaging();return MSG}catch(e){console.warn('fcm init failed',e);return null}
  }

  // يحفظ التوكن تحت fcm/{uid}/{عشوائي} عشان يدعم أكتر من جهاز لنفس المستخدم
  async function saveToken(tok){
    if(!tok||!S.me||!DB)return;
    try{
      await AUTH_READY;
      await fetch(withAuth(DB+'/fcm/'+S.me+'/'+uid()+Date.now().toString(36)+'.json'),{
        method:'PUT',
        body:JSON.stringify({t:tok,d:Date.now(),ua:(navigator.userAgent||'').slice(0,80)})
      });
    }catch(e){console.warn('fcm token save failed',e)}
  }

  // تفعيل الإشعارات: يُستدعى من زرار "🔔 فعّل إشعارات المتصفح" الموجود بالفعل (ntf)
  window.enablePush=async function(){
    if(!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window)){
      return toast('المتصفح الحالي لا يدعم إشعارات الـ Push');
    }
    try{
      const perm=await Notification.requestPermission();
      if(perm!=='granted')return toast('تم رفض إذن الإشعارات ❌');
      const reg=await navigator.serviceWorker.register('sw.js');
      const msg=await initMsg();
      if(!msg)return toast('⚠️ لازم تضيف messagingSenderId و VAPID_KEY في app.js أولاً');
      const tok=await msg.getToken({vapidKey:CFG.VAPID_KEY,serviceWorkerRegistration:reg});
      if(!tok)return toast('تعذّر الحصول على توكن الإشعارات');
      await saveToken(tok);
      toast('تم تفعيل الإشعارات 🔔');
      msg.onMessage(()=>{/* الإشعار داخل التطبيق بييجي أصلاً عن طريق المزامنة العادية */});
      if(window.R)R();
    }catch(e){console.warn('enablePush failed',e);toast('تعذّر تفعيل الإشعارات، جرّب تاني')}
  };

  // يُستدعى من notify() في app.js كل ما يتعمل إشعار جديد — بيحط طلب في طابور pq
  // ومنه الـ Cloud Function بترسل الإشعار الفعلي لصاحبه لو عنده توكن محفوظ
  window.pq=async function(to,txt){
    if(!DB||!to||!txt)return;
    try{
      await AUTH_READY;
      await fetch(withAuth(DB+'/pq/'+uid()+Date.now().toString(36)+'.json'),{
        method:'PUT',
        body:JSON.stringify({to,txt:String(txt).slice(0,200),d:Date.now()})
      });
    }catch(e){/* تجاهل: الإشعار داخل التطبيق هيشتغل عادي حتى لو الطابور فشل */}
  };
})();
