/* Smart Teacher — نظام اشتراكات المعلمين | subscriptions.js
   - المعلم: باقة مجانية محدودة / باقة مدفوعة بكل المزايا
   - الطالب وولي الأمر والمساعد: مجاني بالكامل
   - كل الإعدادات (الأسعار، رقم الدفع، الحدود، المنح، الكوبونات) من لوحة الإدارة ← تاب «الاشتراكات»
   - إيصال الدفع بيتراجع بالذكاء الاصطناعي ويتأكد إن التحويل على رقم المحفظة المحدد */
(()=>{
const B=window.__ST;
if(!B){console.warn('subscriptions: bridge missing');return}
const {cfg,setCfg,cset,aud,modal,NS,ATABS,canA,rb,dl,dstr}=B;
const DAY=864e5;
const DEF={on:1,fa:0,mp:100,yp:1000,cur:'ج.م',w:'01211590867',wn:'Omar Essam',auto:1,mc:70,tr:7,md:30,yd:365,
  lim:{g:1,st:15,ex:3,ai:5,exp:0}};
const C=()=>{const o=cfg('sub')||{};return Object.assign({},DEF,o,{lim:Object.assign({},DEF.lim,o.lim||{})})};
const fmtD=t=>new Date(t).toLocaleDateString('ar-EG',{year:'numeric',month:'short',day:'numeric'});
const left=t=>Math.max(0,Math.ceil((t-Date.now())/DAY));
const num=v=>{const n=Number(v);return isFinite(n)&&n>=0?n:0};
const ad=s=>String(s==null?'':s).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));

/* ---------- حالة اشتراك أي معلم ---------- */
function info(u){
  const c=C(),now=Date.now(),s=(u&&u.sub)||{};
  if(!c.on)return {pro:1,why:'off',until:0};
  if(c.fa>now)return {pro:1,why:'fa',until:c.fa};
  if(s.g===1||s.g>now)return {pro:1,why:'grant',until:s.g===1?0:s.g};
  if(s.exp>now)return {pro:1,why:'paid',until:s.exp};
  if(s.tr>now)return {pro:1,why:'trial',until:s.tr};
  return {pro:0,why:'free',until:0};
}
const mePro=()=>{const m=me();return !m||m.role!=='teacher'||canA()||info(m).pro};
const WHY={off:'الاشتراكات متوقفة',fa:'مجاني للجميع',grant:'مفعّل من الإدارة',paid:'مدفوع',trial:'تجربة مجانية',free:'مجانية'};

/* ---------- ترقية (مودال) ---------- */
function upsell(msg){
  const bg=modal(`<h3>💎 ميزة في الباقة المدفوعة</h3><p>${esc(msg)}</p><p class="mut">رقّي اشتراكك لفتح كل المزايا بدون حدود.</p><div class="row"><button class="b s" id="stsx">لاحقاً</button><button class="b" id="stso">💎 ترقية الآن</button></div>`);
  bg.querySelector('#stsx').onclick=()=>bg.remove();
  bg.querySelector('#stso').onclick=()=>{bg.remove();go('sub')};
}
const up=m=>{upsell(m);return false};

/* ---------- فحص الحدود ---------- */
function chk(kind){
  const m=me();if(!m||m.role!=='teacher'||mePro())return true;
  const L=C().lim;
  if(kind==='g'&&S.g.filter(g=>g.t===m.id).length>=L.g)return up(`الباقة المجانية تسمح بـ ${L.g} مجموعة فقط.`);
  if(kind==='ex'){const n=S.e.filter(e=>{const g=G(e.g);return g&&g.t===m.id}).length;if(n>=L.ex)return up(`الباقة المجانية تسمح بـ ${L.ex} امتحانات فقط.`)}
  if(kind==='exp'&&!L.exp)return up('تصدير التقارير متاح في الباقة المدفوعة.');
  return true;
}
function aiGate(){
  const m=me();if(!m||m.role!=='teacher'||window.__stBypass||mePro())return true;
  const L=C().lim.ai,d=new Date().toISOString().slice(0,10),q=(S.sbq=S.sbq||{}),r=q[m.id],n=r&&r.d===d?r.n:0;
  if(n>=L){upsell(L<=0?'الذكاء الاصطناعي متاح في الباقة المدفوعة.':`وصلت للحد اليومي للذكاء الاصطناعي في الباقة المجانية (${L} مرات).`);return false}
  q[m.id]={d,n:n+1};try{cache()}catch(e){}return true;
}

/* ---------- ربط الدوال الأصلية ---------- */
const wrap=(name,fn)=>{const o=window[name];if(typeof o!=='function')return;window[name]=fn(o)};
wrap('mkGroup',o=>function(){if(!chk('g'))return;return o.apply(this,arguments)});
wrap('saveE',o=>function(){try{if(D&&!S.e.some(e=>e.id===D.id)&&!chk('ex'))return}catch(e){}return o.apply(this,arguments)});
['stCsv','csv','csvE'].forEach(n=>wrap(n,o=>function(){if(!chk('exp'))return;return o.apply(this,arguments)}));
wrap('ai',o=>async function(){if(!aiGate())return null;return o.apply(this,arguments)});
wrap('join',o=>async function(c){
  const code=String(c||(document.querySelector('#jc')||{}).value||'').trim().toUpperCase(),g=S.g.find(x=>x.code===code);
  if(g&&!g.st.some(x=>x.u===S.me)){
    const t=U(g.t),L=C().lim.st;
    if(t&&t.role==='teacher'&&!info(t).pro&&g.st.length>=L){
      toast('⚠️ المجموعة وصلت للحد الأقصى لعدد الطلاب حالياً — تواصل مع المدرس');
      notify(g.t,`طالب حاول الانضمام لمجموعة «${g.title}» لكن الباقة المجانية وصلت للحد (${L} طالب). رقّي باقتك لقبول المزيد.`,'sublim'+g.id);
      return;
    }
  }
  return o.apply(this,arguments);
});
wrap('go',o=>function(p){
  if(p==='studio'&&me()&&me().role==='teacher'){
    try{const editing=D&&S.e.some(e=>e.id===D.id);if(!editing&&!chk('ex'))return}catch(e){}
  }
  return o.apply(this,arguments);
});

/* ---------- كوبونات ---------- */
const coupons=()=>((cfg('subc')||{}).l||[]);
function findCp(code){
  code=String(code||'').trim().toUpperCase();if(!code)return null;
  const x=coupons().find(k=>k.c===code);if(!x)return null;
  if(x.exp&&x.exp<Date.now())return null;
  if(x.max&&(x.used||0)>=x.max)return null;
  return x;
}
function calc(pl,cp){
  const c=C(),base=pl==='y'?c.yp:c.mp,pct=cp?Math.min(100,num(cp.pct)):0;
  return {base,pct,total:Math.max(0,Math.round(base*(100-pct)/100))};
}
const useCp=code=>{const l=coupons().map(x=>Object.assign({},x));const x=l.find(k=>k.c===code);if(x){x.used=(x.used||0)+1;setCfg('subc',{l})}};

/* ---------- قراءة الإيصال: رقم المحفظة / المبلغ / التاريخ ---------- */
function nrm(s){
  s=ad(s).replace(/[xX•●#٭*]/g,'*').replace(/[^\d*]/g,'');
  if(s.startsWith('20')&&s.length>=12)s='0'+s.slice(2);
  else if(!s.startsWith('0')&&s.length===10)s='0'+s;
  return s;
}
function numMatch(got,want){
  const g=nrm(got),w=nrm(want);if(!g)return null;
  const vis=(g.match(/\d/g)||[]).length;if(vis<6||g.length<8)return null;
  const L=Math.min(g.length,w.length);
  for(let i=1;i<=L;i++){const a=g[g.length-i],b=w[w.length-i];if(a==='*')continue;if(a!==b)return false}
  return true;
}
const toNum=v=>{const n=parseFloat(ad(v).replace(/[^\d.]/g,''));return isFinite(n)?n:null};
const cleanTx=t=>ad(t).replace(/[^A-Za-z0-9]/g,'').slice(0,40);

const PROMPT=(c,total)=>`You are a strict payment-receipt reader for Egyptian mobile wallets (Vodafone Cash, Orange, Etisalat, WE Pay), InstaPay and bank transfers.
Look at the image and extract the data. Return ONLY one JSON object, no markdown, no arrays, with exactly these keys:
is_receipt (boolean: true only if this is a real screenshot/photo of a money transfer receipt),
success (boolean: the transfer is shown as completed/successful),
recipient_number (string: the RECEIVING phone/wallet number exactly as printed, keep hidden digits as *; empty string if not visible),
recipient_name (string),
amount (number, the transferred amount),
currency (string),
date (string "yyyy-mm-dd hh:mm" if visible else ""),
transaction_id (string reference/transaction number if visible else ""),
sender (string),
suspicious (boolean: true if it looks edited, fake, cropped, or inconsistent),
confidence (integer 0-100: how sure you are about the extracted values),
notes (one short Arabic sentence).
Today is ${new Date().toISOString().slice(0,10)}. The expected receiver is ${c.w} and the expected amount is ${total}.`;

function judge(a,total,c){
  if(!a||typeof a!=='object')return {st:'rev',why:['تعذّر الفحص الآلي — محتاج مراجعة من الإدارة'],ai:null};
  const conf=Math.max(0,Math.min(100,toNum(a.confidence)||0)),amt=toNum(a.amount),tx=cleanTx(a.transaction_id),nm=numMatch(a.recipient_number,c.w);
  const ai={n:String(a.recipient_number||'').slice(0,30),nm:String(a.recipient_name||'').slice(0,40),a:amt,dt:String(a.date||'').slice(0,20),tx,cf:conf,nt:String(a.notes||'').slice(0,160),sp:!!a.suspicious,ok:nm===true};
  if(a.is_receipt===false)return {st:'no',why:['الصورة ليست إيصال تحويل واضح'],ai};
  if(nm===false)return {st:'no',why:[`رقم المستلم في الإيصال (${ai.n}) غير مطابق للرقم المطلوب`],ai};
  const why=[];let st='ok';
  if(nm===null){st='rev';why.push('لم أستطع قراءة رقم المستلم بوضوح')}
  if(a.success===false){st='rev';why.push('التحويل لا يظهر كعملية ناجحة')}
  if(amt===null){st='rev';why.push('لم أستطع قراءة المبلغ')}
  else if(amt<total){if(conf>=c.mc){return {st:'no',why:[`المبلغ المحوّل (${amt}) أقل من سعر الباقة (${total})`],ai}}st='rev';why.push('المبلغ يبدو أقل من المطلوب')}
  const t=Date.parse(String(a.date||'').replace(' ','T'));
  if(!isFinite(t)){st='rev';why.push('تاريخ العملية غير واضح')}
  else if(Date.now()-t>3*DAY||t-Date.now()>DAY){st='rev';why.push('تاريخ العملية قديم أو غير منطقي')}
  if(!tx){st='rev';why.push('رقم العملية غير ظاهر')}
  else if(cfg('fp_t_'+tx))return {st:'no',why:['رقم العملية مستخدم في طلب سابق'],ai};
  if(a.suspicious){st='rev';why.push('الإيصال يبدو معدّلاً أو مشبوهاً')}
  if(conf<c.mc){st='rev';why.push(`ثقة الفحص منخفضة (${conf}%)`)}
  return {st,why,ai};
}

/* ---------- صور ---------- */
async function shrinkImg(file,max=900,q=.65){
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=url});
    const draw=m=>{const k=Math.min(1,m/Math.max(img.width,img.height)),cv=document.createElement('canvas');
      cv.width=Math.max(1,Math.round(img.width*k));cv.height=Math.max(1,Math.round(img.height*k));cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height);return cv};
    let cv=draw(max),d=cv.toDataURL('image/jpeg',q);
    if(d.length>220000)d=cv.toDataURL('image/jpeg',.5);
    if(d.length>280000){cv=draw(700);d=cv.toDataURL('image/jpeg',.5)}
    return d;
  }finally{URL.revokeObjectURL(url)}
}
const dataToFile=(d,n)=>{const b=atob(d.split(',')[1]),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return new File([u],n||'receipt.jpg',{type:'image/jpeg'})};
async function hash(s){
  try{const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,'0')).join('').slice(0,24)}
  catch(e){let h=0;for(let i=0;i<s.length;i++)h=(Math.imul(31,h)+s.charCodeAt(i))|0;return 'x'+(h>>>0).toString(16)}
}
const safeImg=d=>typeof d==='string'&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(d)?d:'';

async function runAI(img,total){
  window.__stBypass=1;let a=null;
  try{a=await ai(PROMPT(C(),total),dataToFile(img),true)}catch(e){console.warn('receipt ai',e)}
  finally{window.__stBypass=0}
  if(Array.isArray(a))a=a[0];
  return a&&typeof a==='object'?a:null;
}

/* ---------- طلبات الدفع: تفعيل / رفض ---------- */
function setReq(u,rec,st,why){
  const s=(u.sub=u.sub||{}),l=(s.req||[]).filter(x=>x.id!==rec.id);
  l.unshift({id:rec.id,st,pl:rec.pl,d:rec.d,why:why||''});
  s.req=l.slice(0,6);
}
function release(rec){S.cf=(S.cf||[]).filter(x=>x.id!=='fp_h_'+rec.h&&!(rec.tx&&x.id==='fp_t_'+rec.tx))}
function approve(rec,by){
  const u=U(rec.u);if(!u)return false;
  const c=C(),cp=coupons().find(k=>k.c===rec.cp);
  let days=rec.pl==='y'?c.yd:c.md;if(cp&&cp.days)days+=num(cp.days);
  const now=Date.now(),s=(u.sub=u.sub||{});
  s.exp=Math.max(now,s.exp||0)+days*DAY;
  rec.st='ok';rec.by=by;rec.dd=now;rec.dy=days;rec.why='';
  setReq(u,rec,'ok');
  if(cp&&!rec.cu){rec.cu=1;useCp(cp.c)}
  notify(u.id,`✅ تم تفعيل اشتراكك لمدة ${days} يوم — صالح حتى ${fmtD(s.exp)}`,'subok'+rec.id);
  save();return true;
}
function reject(rec,why,by){
  const u=U(rec.u);
  rec.st='no';rec.by=by;rec.dd=Date.now();rec.why=why;
  release(rec);
  if(u){setReq(u,rec,'no',why);notify(u.id,`❌ تم رفض طلب الاشتراك: ${why}`,'subno'+rec.id)}
  save();
}

/* ---------- صفحة المعلم ---------- */
const PS={plan:'m',cp:null,file:null,busy:0,prev:null};

function reqChip(st){return ({ok:'<span class="tag ok">تم التفعيل</span>',no:'<span class="tag bad">مرفوض</span>',rev:'<span class="tag warn">قيد المراجعة</span>',pend:'<span class="tag warn">جارٍ الفحص</span>'})[st]||''}

function page(){
  const m=me(),c=C(),i=info(m),s=m.sub||{},L=c.lim,cp=PS.cp?findCp(PS.cp):null;
  const msg=({
    off:'الاشتراكات متوقفة حالياً — كل المزايا متاحة للجميع 🎉',
    fa:`المنصة مجانية للجميع حتى ${fmtD(i.until)} 🎉`,
    grant:i.until?`مفعّل مجاناً من الإدارة حتى ${fmtD(i.until)}`:'مفعّل مجاناً من الإدارة (دائم)',
    paid:`اشتراك مدفوع حتى ${fmtD(i.until)} (باقي ${left(i.until)} يوم)`,
    trial:`فترة تجربة مجانية حتى ${fmtD(i.until)} (باقي ${left(i.until)} يوم)`,
    free:'أنت على الباقة المجانية'})[i.why];
  const row=(a,b,d)=>`<tr><td>${a}</td><td>${b}</td><td><b>${d}</b></td></tr>`;
  const table=`<table class="stsub-tb"><thead><tr><th></th><th>مجانية</th><th>💎 مدفوعة</th></tr></thead><tbody>
    ${row('عدد المجموعات',L.g,'بلا حدود')}${row('طلاب كل مجموعة',L.st,'بلا حدود')}${row('عدد الامتحانات',L.ex,'بلا حدود')}
    ${row('الذكاء الاصطناعي يومياً',L.ai?L.ai+' مرات':'—','بلا حدود')}${row('تصدير التقارير (CSV)',L.exp?'✓':'✗','✓')}
    </tbody></table><p class="mut">الطلاب وأولياء الأمور ومساعد المدرس: مجاناً بالكامل دائماً.</p>`;
  const plans=['m','y'].map(p=>{const k=calc(p,cp),on=PS.plan===p;
    return `<button class="stsub-plan ${on?'on':''}" onclick="stSub.sel('${p}')"><small>${p==='m'?'شهري':'سنوي'}</small><b>${k.total} ${esc(c.cur)}</b>${k.pct?`<s>${k.base} ${esc(c.cur)}</s>`:''}<small>${p==='m'?c.md:c.yd} يوم</small></button>`}).join('');
  const k=calc(PS.plan,cp);
  const hist=(s.req||[]).length?`<h4>🧾 طلباتي</h4>${s.req.map(r=>`<div class="st-ar"><div class="st-ai"><b>${r.pl==='y'?'سنوي':'شهري'}</b><small>${fmtD(r.d)}${r.why?' — '+esc(r.why):''}</small></div>${reqChip(r.st)}${r.st==='no'&&(S.sp||[]).some(x=>x.id===r.id)?`<button class="b s" onclick="stSub.appeal('${r.id}')">طلب مراجعة</button>`:''}</div>`).join('')}`:'';
  const pay=!c.on?'':`<div class="card stsub-card"><h3>💳 ${i.why==='paid'?'تجديد الاشتراك':'الاشتراك'}</h3>
    <div class="stsub-plans">${plans}</div>
    <div class="row"><input id="stsub-cp" placeholder="كود خصم (اختياري)" value="${esc(PS.cp||'')}" style="flex:1"><button class="b s" onclick="stSub.cp()">تطبيق</button></div>
    ${PS.cp&&!cp?'<p class="mut" style="color:var(--bad)">الكود غير صالح أو منتهي</p>':cp?`<p class="mut">✅ تم تطبيق الكود: خصم ${cp.pct}%${cp.days?' + '+cp.days+' يوم هدية':''}</p>`:''}
    ${k.total>0?`<ol class="stsub-steps"><li>حوّل <b>${k.total} ${esc(c.cur)}</b> على رقم المحفظة:<div class="stsub-num"><b dir="ltr">${esc(c.w)}</b><button class="b s" onclick="stSub.copy()">نسخ</button></div>باسم: <b dir="ltr">${esc(c.wn)}</b></li>
      <li>صوّر إيصال التحويل (يظهر فيه رقم المستلم والمبلغ ورقم العملية)</li><li>ارفع الصورة هنا — الذكاء الاصطناعي بيراجعها ويفعّل اشتراكك تلقائياً</li></ol>
      <label class="b s stsub-up"><input type="file" accept="image/*" hidden onchange="stSub.pick(this)">📷 ${PS.file?'تغيير الصورة':'اختيار صورة الإيصال'}</label>
      ${PS.prev?`<img class="stsub-prev" src="${PS.prev}" alt="">`:''}`
      :'<p class="mut">الكود يغطي السعر بالكامل — اضغط للتفعيل بدون دفع.</p>'}
    <button class="b" ${PS.busy?'disabled':''} onclick="stSub.submit()" style="width:100%;margin-top:10px">${PS.busy?'⏳ جارٍ فحص الإيصال…':k.total>0?'✅ إرسال الإيصال':'🎁 تفعيل بالكود'}</button></div>`;
  return `<section class="st-v2-page stsub"><div class="card stsub-hero"><h2>💎 اشتراك المعلم</h2><span class="tag ${i.pro?'ok':'warn'}">${WHY[i.why]}</span><p>${msg}</p></div>
    <div class="card stsub-card"><h3>المقارنة بين الباقات</h3>${table}</div>${pay}${hist?`<div class="card stsub-card">${hist}</div>`:''}
    <div class="st-v2-actions"><button class="b" onclick="go('dash')">⌂ الرئيسية</button></div></section>`;
}

/* ---------- تنبيهات المعلم ---------- */
function banner(m){
  const c=C();if(!c.on)return '';
  const i=info(m),s=m.sub||{},last=(s.req||[])[0],box=(t,btn)=>`<div class="card stsub-ban"><span>${t}</span><button class="b s" onclick="go('sub')">${btn||'💎 الاشتراك'}</button></div>`;
  if(last&&last.st==='rev'&&Date.now()-last.d<3*DAY)return box('⏳ طلب اشتراكك قيد المراجعة من الإدارة','عرض');
  if(i.why==='free')return box(`⭐ باقتك مجانية (${c.lim.g} مجموعة · ${c.lim.st} طالب · ${c.lim.ex} امتحانات) — رقّي لفتح كل المزايا`,'💎 ترقية');
  if(i.why==='trial')return box(`🎁 فترة التجربة المجانية — باقي ${left(i.until)} يوم`,'💎 اشترك');
  if(i.why==='paid'&&left(i.until)<=5)return box(`⏳ اشتراكك ينتهي خلال ${left(i.until)} يوم`,'🔁 تجديد');
  if(i.why==='fa')return box(`🎉 المنصة مجانية للجميع حتى ${fmtD(i.until)}`,'تفاصيل');
  return '';
}
function ensure(m){
  const c=C(),s=m.sub||{};
  if(c.on&&c.tr>0&&s.tr===undefined){m.sub=Object.assign({},s,{tr:Date.now()+c.tr*DAY});save()}
}
function remind(m){
  const s=m.sub;if(!s||!s.exp)return;
  if(s.exp>Date.now()&&s.exp-Date.now()<3*DAY&&s.rm!==s.exp){s.rm=s.exp;notify(m.id,`⏳ اشتراكك ينتهي خلال ${left(s.exp)} يوم — جدّد من صفحة الاشتراك.`,'subrm');save()}
  else if(s.exp<Date.now()&&s.rx!==s.exp){s.rx=s.exp;notify(m.id,'انتهى اشتراكك المدفوع وتم الرجوع للباقة المجانية. جدّد لفتح كل المزايا.','subrx');save()}
}
function tail(m){
  try{
    if(!m||m.role!=='teacher'||!C().on)return;
    const hx=$('#hx');
    if(hx&&!hx.querySelector('.stsub-btn')&&!(V.p==='dash'&&document.querySelector('.stsub-ban'))){const b=document.createElement('button');b.className='stsub-btn'+(V.p==='sub'?' on':'');b.title='الاشتراك';b.setAttribute('aria-label','الاشتراك');b.textContent=info(m).pro?'💎':'⭐';b.onclick=()=>go('sub');hx.prepend(b)}
    if(V.p==='dash'){const a=$('#app');if(a&&!a.querySelector('.stsub-ban')){const h=banner(m);if(h){const d=document.createElement('div');d.innerHTML=h;a.prepend(d.firstElementChild)}}}
  }catch(e){console.warn('sub tail',e)}
}

/* ---------- تغليف R: صفحة الاشتراك + تنبيهات ---------- */
const _R=window.R;
window.R=function(){
  const m=me();
  if(m&&m.role==='teacher'){try{ensure(m);remind(m)}catch(e){console.warn(e)}}
  try{const t=ATABS.find(x=>x[0]==='sub');if(t){const n=(S.sp||[]).filter(x=>x.st==='rev').length;t[1]='💳 الاشتراكات'+(n?' ('+n+')':'')}}catch(e){}
  if(V.p==='sub'){
    if(!m||!(m.role==='teacher'||canA())){V={p:'dash'}}
    else{
      const keep=V;V={p:'dash'};
      try{_R.apply(this,arguments)}finally{V=keep}
      const a=$('#app');if(a)a.innerHTML=page();
      document.querySelectorAll('#bn button').forEach(b=>b.classList.remove('on'));
      tail(m);return;
    }
  }
  const r=_R.apply(this,arguments);tail(m);return r;
};

/* ---------- لوحة الإدارة: تاب الاشتراكات ---------- */
let AQ='';
const sw=(on,fn)=>`<label class="st-switch"><input type="checkbox" ${on?'checked':''} onchange="${fn}"><span></span></label>`;
const dz=(t,d,ctl)=>`<div class="st-dz"><div><b>${t}</b>${d?`<p class="mut">${d}</p>`:''}</div>${ctl}</div>`;
const val=id=>{const e=document.getElementById(id);return e?e.value:''};

function tabSet(){
  const c=C(),now=Date.now(),on=c.fa>now;
  return `${dz('تشغيل نظام الاشتراكات','لو مقفول: كل المعلمين بياخدوا كل المزايا مجاناً.',sw(c.on,`stSub.tog('on',this.checked)`))}
  <h4>🎉 مجاني للجميع</h4><p class="mut">${on?`مفعّل حتى ${fmtD(c.fa)} (باقي ${left(c.fa)} يوم)`:'غير مفعّل'}</p>
  <div class="stn-chips sm"><button onclick="stSub.fa(7)">أسبوع</button><button onclick="stSub.fa(30)">شهر</button><button onclick="stSub.fa(90)">3 شهور</button><button onclick="stSub.fa(365)">سنة</button>${on?'<button onclick="stSub.fa(0)" style="color:var(--bad)">إلغاء</button>':''}</div>
  <div class="row"><input type="date" id="ssfd"><button class="b s" onclick="stSub.faDate()">حتى تاريخ</button></div>
  <h4>💰 الأسعار</h4>
  <div class="row"><label class="fl"><span>الشهري</span><input id="ssm" type="number" min="0" value="${c.mp}"></label><label class="fl"><span>السنوي</span><input id="ssy" type="number" min="0" value="${c.yp}"></label><label class="fl"><span>العملة</span><input id="sscur" value="${esc(c.cur)}"></label></div>
  <div class="row"><label class="fl"><span>أيام الشهري</span><input id="ssmd" type="number" min="1" value="${c.md}"></label><label class="fl"><span>أيام السنوي</span><input id="ssyd" type="number" min="1" value="${c.yd}"></label><label class="fl"><span>تجربة مجانية (أيام)</span><input id="sstr" type="number" min="0" value="${c.tr}"></label></div>
  <h4>📲 بيانات استلام الدفع</h4>
  <div class="row"><label class="fl"><span>رقم المحفظة</span><input id="ssw" dir="ltr" value="${esc(c.w)}"></label><label class="fl"><span>الاسم</span><input id="ssn" dir="ltr" value="${esc(c.wn)}"></label></div>
  ${dz('تفعيل تلقائي بالذكاء الاصطناعي','لو الإيصال سليم (الرقم والمبلغ والتاريخ ورقم العملية) بيتفعل فوراً. لو مقفول كل الطلبات تيجي لك للمراجعة.',sw(c.auto,`stSub.tog('auto',this.checked)`))}
  <div class="row"><label class="fl"><span>أقل ثقة للتفعيل التلقائي %</span><input id="ssmc" type="number" min="30" max="100" value="${c.mc}"></label></div>
  <button class="b" style="margin-top:8px" onclick="stSub.save()">💾 حفظ الإعدادات</button>`;
}
function tabLim(){
  const L=C().lim;
  return `<p class="mut">حدود الباقة المجانية للمعلم (الباقة المدفوعة بلا حدود).</p>
  <div class="row"><label class="fl"><span>المجموعات</span><input id="sl_g" type="number" min="0" value="${L.g}"></label><label class="fl"><span>طلاب/مجموعة</span><input id="sl_st" type="number" min="0" value="${L.st}"></label></div>
  <div class="row"><label class="fl"><span>الامتحانات</span><input id="sl_ex" type="number" min="0" value="${L.ex}"></label><label class="fl"><span>AI يومياً (0 = ممنوع)</span><input id="sl_ai" type="number" min="0" value="${L.ai}"></label></div>
  ${dz('تصدير التقارير CSV','',sw(L.exp,`stSub.limTog(this.checked)`))}
  <button class="b" style="margin-top:8px" onclick="stSub.saveLim()">💾 حفظ الحدود</button>`;
}
function rowsTch(){
  const q=AQ.trim().toLowerCase(),a=S.u.filter(u=>u.role==='teacher'&&(!q||((u.name||'')+' '+(u.email||'')+' '+(u.phone||'')).toLowerCase().includes(q)));
  const rows=a.slice(0,40).map(u=>{const i=info(u);return `<div class="st-ar"><div class="st-ai"><b>${esc(u.name||'—')}</b><small>${esc(u.phone||u.email||'')} · ${WHY[i.why]}${i.until&&i.why!=='fa'?' حتى '+fmtD(i.until):''}${i.why==='grant'&&!i.until?' (دائم)':''}</small></div><div class="st-ab"><button class="b s" onclick="stSub.user('${u.id}')">إدارة</button></div></div>`}).join('');
  return `${rows||'<p class="mut">لا يوجد معلمون</p>'}${a.length>40?`<p class="mut">أول 40 من ${a.length} — استخدم البحث</p>`:''}`;
}
function tabTch(){return `<input class="srch" placeholder="🔍 ابحث عن معلم…" value="${esc(AQ)}" oninput="stSub.q(this.value)"><div id="stsub-tl">${rowsTch()}</div>`}
function tabReq(){
  const rk={rev:0,pend:1,ok:2,no:3},l=(S.sp||[]).slice().sort((a,b)=>(rk[a.st]??4)-(rk[b.st]??4)||(b.d||0)-(a.d||0)).slice(0,40);
  if(!l.length)return '<p class="mut">لا توجد طلبات دفع.</p>';
  return `<button class="b s" onclick="stSub.csv()">⬇️ تصدير CSV</button>`+l.map(r=>{
    const a=r.ai||{},img=safeImg(r.img),c=C();
    return `<div class="card stsub-rq"><div class="row"><b>${esc(r.un||'—')}</b>${reqChip(r.st)}</div>
    <small class="mut">${r.pl==='y'?'سنوي':'شهري'} · المطلوب ${r.amt} ${esc(c.cur)}${r.cp?' · كود '+esc(r.cp):''} · ${new Date(r.d).toLocaleString('ar-EG')}${r.by?' · بواسطة '+(r.by==='ai'?'الذكاء الاصطناعي':r.by==='coupon'?'كود':esc(r.by)):''}</small>
    ${img?`<img class="stsub-th" src="${img}" onclick="stSub.img('${r.id}')" alt="إيصال">`:''}
    ${r.ai?`<div class="stsub-ai"><small>🤖 المستلم: <b dir="ltr">${esc(a.n||'—')}</b> ${a.ok?'✅':'⚠️'} · المبلغ: <b>${a.a??'—'}</b> · العملية: <b dir="ltr">${esc(a.tx||'—')}</b> · التاريخ: ${esc(a.dt||'—')} · الثقة ${a.cf||0}%</small>${a.nt?`<small class="mut">${esc(a.nt)}</small>`:''}</div>`:''}
    ${r.why?`<small style="color:var(--bad)">${esc(r.why)}</small>`:''}
    ${r.st==='rev'||r.st==='pend'||r.st==='no'?`<div class="row" style="margin-top:6px">${r.st!=='no'?`<button class="b" onclick="stSub.ok('${r.id}')">✅ قبول</button>`:`<button class="b" onclick="stSub.ok('${r.id}')">✅ قبول رغم الرفض</button>`}${r.st!=='no'?`<button class="b r" onclick="stSub.no('${r.id}')">❌ رفض</button>`:''}${img?`<button class="b s" onclick="stSub.recheck('${r.id}')">🤖 إعادة الفحص</button>`:''}</div>`:''}</div>`}).join('');
}
function tabCp(){
  const l=coupons(),c=C();
  return `<h4>🎟️ إنشاء كود</h4><div class="row"><label class="fl"><span>الكود</span><input id="scc" dir="ltr" placeholder="مثال: WELCOME20"></label><label class="fl"><span>خصم %</span><input id="scp" type="number" min="0" max="100" value="20"></label></div>
  <div class="row"><label class="fl"><span>أيام هدية</span><input id="scd" type="number" min="0" value="0"></label><label class="fl"><span>أقصى استخدام (0 = بلا حد)</span><input id="scm" type="number" min="0" value="0"></label><label class="fl"><span>ينتهي في</span><input id="sce" type="date"></label></div>
  <button class="b" onclick="stSub.cpNew()">＋ إضافة</button><p class="mut">خصم 100% = تفعيل مجاني بدون دفع.</p>
  ${l.length?l.map(x=>`<div class="st-ar"><div class="st-ai"><b dir="ltr">${esc(x.c)}</b><small>خصم ${x.pct}%${x.days?' + '+x.days+' يوم':''} · استُخدم ${x.used||0}${x.max?'/'+x.max:''}${x.exp?' · ينتهي '+fmtD(x.exp):''}</small></div><button class="b r" onclick="stSub.cpDel('${esc(x.c)}')">حذف</button></div>`).join(''):'<p class="mut">لا توجد أكواد</p>'}`;
}
function tabStat(){
  const now=Date.now(),T=S.u.filter(u=>u.role==='teacher'),by={paid:0,trial:0,grant:0,free:0};
  T.forEach(u=>{const i=info(u);if(i.why==='paid')by.paid++;else if(i.why==='trial')by.trial++;else if(i.why==='grant')by.grant++;else by.free++});
  const ok=(S.sp||[]).filter(r=>r.st==='ok'&&r.by!=='coupon'),sum=a=>a.reduce((x,r)=>x+(r.amt||0),0),m30=ok.filter(r=>now-(r.dd||r.d)<30*DAY),c=C();
  const t=(i,l,v)=>`<div class="st-tile"><span>${i}</span><b>${v}</b><small>${l}</small></div>`;
  return `<div class="st-tiles">${t('👨‍🏫','معلمون',T.length)}${t('💎','مدفوع',by.paid)}${t('🎁','تجربة',by.trial)}${t('🆓','مجاني/منحة',by.free+'/'+by.grant)}</div>
  <div class="st-tiles">${t('💰','إيراد 30 يوم',sum(m30)+' '+esc(c.cur))}${t('📈','إجمالي الإيراد',sum(ok)+' '+esc(c.cur))}${t('⏳','بانتظار المراجعة',(S.sp||[]).filter(r=>r.st==='rev').length)}${t('🧾','كل الطلبات',(S.sp||[]).length)}</div>`;
}
const STABS=[['r','🧾 الطلبات'],['t','👨‍🏫 المعلمون'],['s','⚙️ الإعدادات'],['l','📏 الحدود'],['c','🎟️ الكوبونات'],['x','📊 إحصائيات']];
function adminTab(){
  if(!canA())return '';
  if(!NS.sbt)NS.sbt=(S.sp||[]).some(r=>r.st==='rev')?'r':'s';
  const body=({r:tabReq,t:tabTch,s:tabSet,l:tabLim,c:tabCp,x:tabStat}[NS.sbt]||tabSet)();
  const n=(S.sp||[]).filter(r=>r.st==='rev').length;
  return `<div class="stn-chips sm">${STABS.map(t=>`<button class="${NS.sbt===t[0]?'on':''}" onclick="stSub.st('${t[0]}')">${t[1]}${t[0]==='r'&&n?' ('+n+')':''}</button>`).join('')}</div>${body}`;
}
if(!ATABS.some(x=>x[0]==='sub')){const i=ATABS.findIndex(x=>x[0]==='u');ATABS.splice(i<0?ATABS.length:i,0,['sub','💳 الاشتراكات'])}

/* ---------- أزرار الصفحة والإدارة ---------- */
const ask=(title,ph,cb,def)=>{
  const bg=modal(`<h3>${title}</h3><textarea id="stsub-r" rows="2" placeholder="${esc(ph||'')}">${esc(def||'')}</textarea><div class="row"><button class="b s" id="stsx">إلغاء</button><button class="b" id="stso">تأكيد</button></div>`);
  bg.querySelector('#stsx').onclick=()=>bg.remove();
  bg.querySelector('#stso').onclick=()=>{const v=bg.querySelector('#stsub-r').value.trim();bg.remove();cb(v)};
};
const cmd=fn=>{if(canA())fn()};
window.stSub={
  tab:adminTab,_t:{numMatch,judge,calc,info,nrm},
  /* معلم */
  sel(p){PS.plan=p;R()},
  cp(){const v=(val('stsub-cp')||'').trim().toUpperCase();if(!v){PS.cp=null;return R()}PS.cp=v;if(!findCp(v))toast('الكود غير صالح أو منتهي');R()},
  copy(){const w=C().w;try{navigator.clipboard.writeText(w).then(()=>toast('تم نسخ الرقم'),()=>toast(w))}catch(e){toast(w)}},
  async pick(inp){
    const f=inp.files&&inp.files[0];if(!f)return;
    if(!/^image\//.test(f.type))return toast('اختر صورة فقط');
    try{PS.prev=await shrinkImg(f,420,.6);PS.file=f}catch(e){return toast('تعذّرت قراءة الصورة')}
    R();
  },
  async submit(){
    if(PS.busy)return;const m=me();if(!m||m.role!=='teacher')return;
    const c=C(),cp=PS.cp?findCp(PS.cp):null;
    if(PS.cp&&!cp)return toast('كود الخصم غير صالح');
    const k=calc(PS.plan,cp),s=m.sub||{},last=(s.req||[])[0];
    if(last&&((last.st==='rev'&&Date.now()-last.d<3*DAY)||(last.st==='pend'&&Date.now()-last.d<6e5)))return toast('عندك طلب قيد المراجعة بالفعل');
    if((s.req||[]).filter(r=>r.st==='no'&&Date.now()-r.d<DAY).length>=3)return toast('تم رفض عدة طلبات اليوم — حاول بكرة أو تواصل مع الإدارة');
    const rec={id:uid(),u:m.id,un:m.name||'',ph:m.phone||'',pl:PS.plan,amt:k.total,cp:cp?cp.c:'',d:Date.now(),st:'pend',img:'',h:''};
    if(k.total<=0){
      S.sp=S.sp||[];S.sp.push(rec);
      approve(rec,'coupon');toast('🎉 تم تفعيل الاشتراك');PS.cp=null;PS.file=null;PS.prev=null;return R();
    }
    if(!PS.file)return toast('ارفع صورة إيصال الدفع أولاً');
    PS.busy=1;R();
    try{
      const img=await shrinkImg(PS.file),h=await hash(img);
      if(cfg('fp_h_'+h)){toast('⚠️ هذا الإيصال مستخدم من قبل');return}
      rec.img=img;rec.h=h;
      S.sp=S.sp||[];S.sp.push(rec);
      setCfg('fp_h_'+h,{t:Date.now(),u:m.id,r:rec.id});
      setReq(m,rec,'pend');save();
      const a=await runAI(img,k.total),j=judge(a,k.total,c);
      rec.ai=j.ai||undefined;
      if(j.ai&&j.ai.tx)rec.tx=j.ai.tx;
      if(rec.tx)setCfg('fp_t_'+rec.tx,{t:Date.now(),u:m.id,r:rec.id});
      if(j.st==='ok'&&c.auto){approve(rec,'ai');toast('✅ تم التحقق وتفعيل اشتراكك!');confetti()}
      else if(j.st==='no'){reject(rec,j.why.join(' — '),'ai');toast('❌ '+j.why[0])}
      else{rec.st='rev';rec.why=j.why.join(' — ');setReq(m,rec,'rev',rec.why);
        S.u.filter(u=>u.role==='admin').forEach(u=>notify(u.id,`🧾 طلب اشتراك جديد من ${m.name} محتاج مراجعة`,'subrev'+rec.id));
        save();toast('🕒 تم استلام الإيصال وهيتراجع من الإدارة قريباً')}
      PS.file=null;PS.prev=null;PS.cp=null;
    }catch(e){console.warn('submit',e);toast('حصل خطأ أثناء إرسال الإيصال، حاول مرة أخرى')}
    finally{PS.busy=0;R()}
  },
  appeal(id){const r=(S.sp||[]).find(x=>x.id===id),m=me();if(!r||!m||r.u!==m.id||r.st!=='no')return;r.st='rev';r.why='طلب مراجعة يدوية من المعلم';setReq(m,r,'rev',r.why);save();toast('تم إرسال طلب مراجعة للإدارة');R()},
  /* إدارة */
  st(t){NS.sbt=t;rb()},
  q(v){AQ=v;const l=document.getElementById('stsub-tl');if(l)l.innerHTML=rowsTch()},
  tog(k,on){cmd(()=>{cset('sub',{[k]:on?1:0},(on?'تشغيل ':'إيقاف ')+(k==='on'?'نظام الاشتراكات':'التفعيل التلقائي'));rb();R()})},
  fa(d){cmd(()=>{cset('sub',{fa:d>0?Date.now()+d*DAY:0},d>0?`مجاني للجميع ${d} يوم`:'إلغاء المجاني للجميع');toast(d>0?'تم تفعيل «مجاني للجميع»':'تم الإلغاء');rb();R()})},
  faDate(){cmd(()=>{const v=val('ssfd');const t=v?new Date(v+'T23:59:59').getTime():0;if(!t||t<Date.now())return toast('اختر تاريخاً في المستقبل');cset('sub',{fa:t},'مجاني للجميع حتى '+v);toast('تم التفعيل');rb();R()})},
  save(){cmd(()=>{
    const w=ad(val('ssw')).replace(/\D/g,'');
    if(!/^(0)?1[0125]\d{8}$/.test(w))return toast('رقم المحفظة غير صحيح (رقم موبايل مصري)');
    const o={mp:num(val('ssm')),yp:num(val('ssy')),cur:val('sscur').trim()||'ج.م',md:Math.max(1,num(val('ssmd'))),yd:Math.max(1,num(val('ssyd'))),tr:Math.floor(num(val('sstr'))),
      w:w.startsWith('0')?w:'0'+w,wn:val('ssn').trim()||'Omar Essam',mc:Math.min(100,Math.max(30,num(val('ssmc'))||70))};
    cset('sub',o,'تعديل إعدادات الاشتراكات');toast('✅ تم الحفظ');rb();R();
  })},
  limTog(on){cmd(()=>{cset('sub',{lim:Object.assign({},C().lim,{exp:on?1:0})},'تعديل حدود الباقة المجانية');rb()})},
  saveLim(){cmd(()=>{
    const L=Object.assign({},C().lim,{g:Math.floor(num(val('sl_g'))),st:Math.floor(num(val('sl_st'))),ex:Math.floor(num(val('sl_ex'))),ai:Math.floor(num(val('sl_ai')))});
    cset('sub',{lim:L},'تعديل حدود الباقة المجانية');toast('✅ تم حفظ الحدود');rb();
  })},
  user(id){cmd(()=>{
    const u=U(id);if(!u)return;const i=info(u);
    const bg=modal(`<h3>👨‍🏫 ${esc(u.name||'')}</h3><p class="mut">الحالة: ${WHY[i.why]}${i.until&&i.why!=='fa'?' حتى '+fmtD(i.until):''}</p>
      <div class="row"><input id="stu-d" type="number" min="1" value="30" style="flex:1"><span class="mut">يوم</span></div>
      <div class="stn-chips sm"><button id="stu-1">🎁 منح مجاني لعدد الأيام</button><button id="stu-2">➕ إضافة أيام اشتراك</button><button id="stu-3">♾️ منح دائم</button></div>
      <div class="stn-chips sm"><button id="stu-4">🎁 تجربة جديدة</button><button id="stu-5" style="color:var(--bad)">⛔ إلغاء المنح والاشتراك</button><button id="stu-x">إغلاق</button></div>`);
    const d=()=>Math.max(1,Math.floor(num(bg.querySelector('#stu-d').value))||30);
    const go2=(k)=>{stSub.apply(id,k,d());bg.remove()};
    bg.querySelector('#stu-1').onclick=()=>go2('grant');bg.querySelector('#stu-2').onclick=()=>go2('add');bg.querySelector('#stu-3').onclick=()=>go2('perm');
    bg.querySelector('#stu-4').onclick=()=>go2('trial');bg.querySelector('#stu-5').onclick=()=>go2('clear');bg.querySelector('#stu-x').onclick=()=>bg.remove();
  })},
  apply(id,k,days){cmd(()=>{
    const u=U(id);if(!u)return;const s=(u.sub=Object.assign({},u.sub||{})),now=Date.now();let t='',n='';
    if(k==='grant'){s.g=now+days*DAY;t=`منح ${u.name} مجاناً ${days} يوم`;n=`🎁 منحتك الإدارة كل المزايا مجاناً لمدة ${days} يوم`}
    else if(k==='perm'){s.g=1;t=`منح ${u.name} مجاناً (دائم)`;n='🎁 منحتك الإدارة كل المزايا مجاناً بشكل دائم'}
    else if(k==='add'){s.exp=Math.max(now,s.exp||0)+days*DAY;t=`إضافة ${days} يوم لاشتراك ${u.name}`;n=`➕ تمت إضافة ${days} يوم لاشتراكك`}
    else if(k==='trial'){s.tr=now+days*DAY;t=`تجربة ${days} يوم لـ ${u.name}`;n=`🎁 تم تفعيل تجربة مجانية ${days} يوم`}
    else if(k==='clear'){s.g=0;s.exp=0;s.tr=0;t=`إلغاء منح واشتراك ${u.name}`;n='تم إلغاء اشتراكك/المنحة من الإدارة'}
    u.sub=s;aud(t);notify(u.id,n,'subadm'+now);save();toast('✅ تم');rb();
  })},
  ok(id){cmd(()=>{const r=(S.sp||[]).find(x=>x.id===id);if(!r)return;
    if(r.st==='no'){const h=r.h;if(h&&!cfg('fp_h_'+h))setCfg('fp_h_'+h,{t:Date.now(),u:r.u,r:r.id});if(r.tx&&!cfg('fp_t_'+r.tx))setCfg('fp_t_'+r.tx,{t:Date.now(),u:r.u,r:r.id})}
    if(approve(r,(me()&&me().name)||'مدير')){aud('قبول اشتراك '+(r.un||''));toast('✅ تم التفعيل');rb();R()}})},
  no(id){cmd(()=>{const r=(S.sp||[]).find(x=>x.id===id);if(!r)return;ask('❌ رفض الطلب','سبب الرفض (يظهر للمعلم)',v=>{reject(r,v||'تم الرفض من الإدارة',(me()&&me().name)||'مدير');aud('رفض اشتراك '+(r.un||''));toast('تم الرفض');rb();R()},'الإيصال غير مطابق')})},
  async recheck(id){cmd(async()=>{
    const r=(S.sp||[]).find(x=>x.id===id),img=r&&safeImg(r.img);if(!img)return;
    toast('🤖 جارٍ إعادة الفحص…');const a=await runAI(img,r.amt),j=judge(a,r.amt,C());
    if(j.ai){r.ai=j.ai;if(j.ai.tx)r.tx=j.ai.tx}save();toast(j.st==='ok'?'✅ الفحص: سليم':'⚠️ '+(j.why[0]||'يحتاج مراجعة'));rb()})},
  img(id){const r=(S.sp||[]).find(x=>x.id===id),img=r&&safeImg(r.img);if(!img)return;const bg=modal(`<img src="${img}" style="max-width:100%;border-radius:12px" alt="إيصال"><div class="row"><button class="b s" id="stsx">إغلاق</button></div>`);bg.querySelector('#stsx').onclick=()=>bg.remove()},
  cpNew(){cmd(()=>{
    const c=val('scc').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'');if(c.length<3)return toast('الكود 3 حروف/أرقام على الأقل');
    if(coupons().some(x=>x.c===c))return toast('الكود موجود بالفعل');
    const e=val('sce'),x={c,pct:Math.min(100,Math.floor(num(val('scp')))),days:Math.floor(num(val('scd'))),max:Math.floor(num(val('scm'))),used:0,exp:e?new Date(e+'T23:59:59').getTime():0};
    setCfg('subc',{l:[...coupons(),x]});aud('إنشاء كوبون '+c);toast('✅ تم إنشاء الكود');rb();
  })},
  cpDel(c){cmd(()=>{setCfg('subc',{l:coupons().filter(x=>x.c!==c)});aud('حذف كوبون '+c);rb()})},
  csv(){cmd(()=>{const rows=[['المعلم','الهاتف','الباقة','المبلغ','الحالة','بواسطة','التاريخ','رقم العملية'],...(S.sp||[]).map(r=>[r.un,r.ph,r.pl==='y'?'سنوي':'شهري',r.amt,r.st,r.by||'',new Date(r.d).toLocaleString('ar-EG'),(r.ai&&r.ai.tx)||''])];
    dl('payments-'+dstr()+'.csv','\ufeff'+rows.map(r=>r.map(c=>'"'+String(c==null?'':c).replace(/"/g,'""')+'"').join(',')).join('\n'),'text/csv')})}
};

/* ---------- تنسيق ---------- */
const css=document.createElement('style');css.id='stsub-css';
css.textContent=`.stsub-hero h2{margin:0 0 6px}.stsub-hero p{margin:8px 0 0}
.stsub-card{margin-top:12px}.stsub-tb{width:100%;border-collapse:collapse;font-size:14px}.stsub-tb th,.stsub-tb td{padding:8px 6px;border-bottom:1px solid var(--bd);text-align:center}.stsub-tb td:first-child,.stsub-tb th:first-child{text-align:start}
.stsub-plans{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:8px 0}
.stsub-plan{display:flex;flex-direction:column;align-items:center;gap:2px;padding:14px 8px;border:2px solid var(--bd);border-radius:14px;background:var(--card);color:var(--tx);cursor:pointer;font-family:inherit}
.stsub-plan.on{border-color:var(--pri);box-shadow:0 0 0 3px color-mix(in srgb,var(--pri) 20%,transparent)}.stsub-plan b{font-size:20px}.stsub-plan s{opacity:.55;font-size:13px}
.stsub-steps{padding-inline-start:20px;line-height:1.9}.stsub-num{display:flex;align-items:center;gap:10px;margin:6px 0}.stsub-num b{font-size:20px;letter-spacing:1px}
.stsub-up{display:inline-flex;cursor:pointer;margin-top:6px}.stsub-prev{display:block;max-width:100%;max-height:260px;margin:10px auto 0;border-radius:12px;border:1px solid var(--bd)}
.stsub-ban{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px;border:1px solid var(--pri)}
.stsub-btn{font-size:18px}.stsub-rq{margin-top:10px}.stsub-th{display:block;max-width:150px;max-height:150px;border-radius:10px;margin:8px 0;cursor:zoom-in;border:1px solid var(--bd)}
.stsub-ai{display:flex;flex-direction:column;gap:2px;padding:6px 8px;border-radius:10px;background:color-mix(in srgb,var(--pri) 8%,transparent)}
.tag.ok{background:#16a34a22;color:#15803d}.tag.bad{background:#dc262622;color:#b91c1c}.tag.warn{background:#f59e0b22;color:#b45309}`;
document.head.append(css);

try{if(me())R()}catch(e){console.warn('subscriptions init',e)}
})();
