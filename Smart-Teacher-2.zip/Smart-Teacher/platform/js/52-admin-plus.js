/* Smart Teacher — admin-plus.js
   1) تسجيل دخول الإدارة متعدد الخطوات (الاسم ← الرقم السري ← تاريخ الميلاد ← أول حرف من اسم الأم)
      — بيانات الدخول مش مكتوبة في الكود؛ المحفوظ بس هاش PBKDF2 للتركيبة كلها (بيتم التحقق منها مرة واحدة في الآخر)
   2) وضع إدارة مستقل (بدون قوائم الطلاب/المعلمين) + خروج تلقائي بعد خمول
   3) تابات جديدة: نظرة عامة / مراجعة المحادثات بالذكاء الاصطناعي (تلقائي أو يدوي) / النظام (صيانة + سجل الدخول) */
(()=>{
const B=window.__ST;
if(!B){console.warn('admin-plus: bridge missing');return}
const {cfg,setCfg,cset,aud,modal,NS,ATABS,canA,rb,dl,dstr}=B;
const DAY=864e5,HR=36e5;
const ADMIN_TITLE='إدارة سمارت تيتشر — Smart Teacher Admin';
const SALT='smart-teacher|admin|v1',ITER=100000,HASH='c033cc194d3ff8d5f0e8622ff84020e0f508534f9e6c29645e7bd5a86108aac8';
const enc=s=>new TextEncoder().encode(s),hex=u=>[...u].map(x=>x.toString(16).padStart(2,'0')).join('');
const ad=s=>String(s==null?'':s).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const num=v=>{const n=Number(v);return isFinite(n)&&n>=0?n:0};
const normAr=s=>String(s==null?'':s).replace(/[\u064B-\u0652\u0640]/g,'').replace(/\u0649/g,'\u064A').replace(/\s+/g,' ').trim();
const fmtT=t=>t?new Date(t).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'}):'—';

/* ===== SHA-256 / PBKDF2 (احتياطي لو crypto.subtle غير متاح) ===== */
const K=new Uint32Array(64),H0=new Uint32Array(8);
{const pr=[];for(let n=2;pr.length<64;n++){if(pr.every(p=>n%p))pr.push(n)}
 pr.forEach((p,i)=>{K[i]=Math.floor((Math.cbrt(p)%1)*4294967296)});
 pr.slice(0,8).forEach((p,i)=>{H0[i]=Math.floor((Math.sqrt(p)%1)*4294967296)})}
const ror=(x,n)=>(x>>>n)|(x<<(32-n));
function sha256(m){
  const l=m.length,nb=(l+9+63)>>6,buf=new Uint8Array(nb*64);buf.set(m);buf[l]=0x80;
  const dv=new DataView(buf.buffer);dv.setUint32(buf.length-4,(l*8)>>>0);dv.setUint32(buf.length-8,Math.floor(l/0x20000000));
  const h=new Uint32Array(H0),w=new Uint32Array(64);
  for(let o=0;o<buf.length;o+=64){
    for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
    for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(ror(a,7)^ror(a,18)^(a>>>3))+w[i-7]+(ror(b,17)^ror(b,19)^(b>>>10)))|0}
    let [a,b,c,d,e,f,g,hh]=h;
    for(let i=0;i<64;i++){
      const t1=(hh+(ror(e,6)^ror(e,11)^ror(e,25))+((e&f)^(~e&g))+K[i]+w[i])|0,t2=((ror(a,2)^ror(a,13)^ror(a,22))+((a&b)^(a&c)^(b&c)))|0;
      hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
    }
    h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;
  }
  const out=new Uint8Array(32),ov=new DataView(out.buffer);h.forEach((x,i)=>ov.setUint32(i*4,x));return out;
}
function hmac(key,msg){
  if(key.length>64)key=sha256(key);
  const ip=new Uint8Array(64+msg.length),op=new Uint8Array(96);
  for(let i=0;i<64;i++){const k=key[i]||0;ip[i]=k^0x36;op[i]=k^0x5c}
  ip.set(msg,64);op.set(sha256(ip),64);return sha256(op);
}
function pbkdf2js(pw,salt,iter){
  const s=new Uint8Array(salt.length+4);s.set(salt);s[s.length-1]=1;
  let u=hmac(pw,s);const t=new Uint8Array(u);
  for(let i=1;i<iter;i++){u=hmac(pw,u);for(let j=0;j<32;j++)t[j]^=u[j]}
  return t;
}
async function pbkdf2jsAsync(pw,salt,iter){
  const sl=new Uint8Array(salt.length+4);sl.set(salt);sl[sl.length-1]=1;
  let u=hmac(pw,sl);const t=new Uint8Array(u);
  for(let i=1;i<iter;i++){u=hmac(pw,u);for(let j=0;j<32;j++)t[j]^=u[j];if(i%2000===0)await new Promise(r=>setTimeout(r,0))}
  return t;
}
async function pbkdf2(str){
  try{
    if(window.crypto&&crypto.subtle){
      const k=await crypto.subtle.importKey('raw',enc(str),'PBKDF2',false,['deriveBits']);
      return hex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc(SALT),iterations:ITER},k,256)));
    }
  }catch(e){}
  return hex(await pbkdf2jsAsync(enc(str),enc(SALT),ITER));
}
function normDob(s){
  s=ad(s).trim();let m=s.match(/^(\d{1,2})\D+(\d{1,2})\D+(\d{4})$/),d,mo,y;
  if(m){d=+m[1];mo=+m[2];y=+m[3]}else if((m=s.match(/^(\d{4})\D+(\d{1,2})\D+(\d{1,2})$/))){y=+m[1];mo=+m[2];d=+m[3]}else return '';
  if(mo<1||mo>12||d<1||d>31)return '';
  const p=n=>String(n).padStart(2,'0');return `${y}-${p(mo)}-${p(d)}`;
}
async function verify(name,pw,dob,ini,hh,fav){
  const inp=[String(name||'').trim().toLowerCase(),String(pw||''),normDob(dob),String(ini||'').trim().toUpperCase(),ad(String(hh||'')).trim(),normAr(fav)].join('|');
  const h=await pbkdf2(inp);let d=0;if(h.length!==HASH.length)return false;
  for(let i=0;i<h.length;i++)d|=h.charCodeAt(i)^HASH.charCodeAt(i);return d===0;
}

/* ===== جلسة الإدارة ===== */
const isAdm=()=>{const m=me();return !!m&&m.role==='admin'};
const jget=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'')||d}catch(e){return d}};
function ensureRoot(){
  const u=S.u.find(x=>x.id==='admroot'&&x.role==='admin');
  return u||null;
}
function logAttempt(ok){
  try{const l=((cfg('admlog')||{}).l||[]).slice();l.unshift({t:Date.now(),ok:ok?1:0,ua:String(navigator.userAgent||'').slice(0,70)});setCfg('admlog',{l:l.slice(0,30)})}catch(e){}
}
function logout(msg){
  S.me=null;V={p:'dash'};try{sessionStorage.removeItem('st_adm');localStorage.removeItem('stad_keep');localStorage.removeItem('stad_imp')}catch(e){}
  save();R();if(msg)toast(msg);
}

/* ===== شاشة تسجيل الدخول ===== */
const STEPS=[
  {i:'👤',t:'اسم المسؤول',h:'اكتب اسمك',type:'text',ac:'off'},
  {i:'🔑',t:'الرقم السري',h:'اكتب الرقم السري',type:'password',ac:'off'},
  {i:'🎂',t:'تاريخ الميلاد',h:'يوم/شهر/سنة',type:'text',im:'numeric',ac:'off'},
  {i:'💐',t:'أول حرف من اسم الأم',h:'حرف واحد',type:'text',max:1,ac:'off'},
  {i:'🏠',t:'انتوا كام شخص في البيت؟',h:'اكتب رقم',type:'text',im:'numeric',ac:'off'},
  {i:'✨',t:'انت بتحب ايه؟',h:'اكتب إجابتك',type:'text',ac:'off'}
];
function openLogin(){
  if(document.getElementById('stad-ov'))return;
  const f=jget('stad_f',{n:0,t:0});
  if(f.t>Date.now())return toast('⛔ محاولات كثيرة — حاول بعد '+Math.ceil((f.t-Date.now())/6e4)+' دقيقة');
  const st={i:0,v:['','','','','',''],busy:0},ov=document.createElement('div');
  ov.id='stad-ov';ov.className='stad-ov';document.body.append(ov);
  const close=()=>{st.v=['','','','','',''];ov.remove()};
  const draw=(err)=>{
    const s=STEPS[st.i],last=st.i===STEPS.length-1;
    ov.innerHTML=`<div class="stad-box${err?' stad-shake':''}" role="dialog" aria-modal="true"><div class="stad-shield">🛡️</div><h2>دخول الإدارة</h2><p class="stad-sub">Smart Teacher Admin Panel</p>
      <div class="stad-dots">${STEPS.map((_,i)=>`<i class="${i<st.i?'ok':i===st.i?'on':''}"></i>`).join('')}</div>
      <label class="stad-l"><span class="stad-ic">${s.i}</span>${s.t}<small>الخطوة ${st.i+1} من ${STEPS.length}</small></label>
      <div class="stad-in"><input id="stad-i" type="${s.type}" placeholder="${s.h}" autocomplete="${s.ac}" ${s.im?`inputmode="${s.im}"`:''} ${s.max?`maxlength="${s.max}"`:''} dir="${st.i===2||st.i===3||st.i===1||st.i===4?'ltr':'auto'}" value="${esc(st.v[st.i])}">${st.i===1?'<button type="button" class="stad-eye" id="stad-eye" aria-label="إظهار">👁</button>':''}</div>
      <p class="stad-err">${err?esc(err):''}</p>
      <div class="stad-row">${st.i>0?'<button class="b s" id="stad-back">رجوع</button>':'<button class="b s" id="stad-x">إلغاء</button>'}<button class="b" id="stad-next" ${st.busy?'disabled':''}>${st.busy?'⏳ جارٍ التحقق…':last?'🔓 دخول':'التالي ◀'}</button></div></div>`;
    const inp=ov.querySelector('#stad-i');setTimeout(()=>inp&&inp.focus(),40);
    inp.oninput=()=>{st.v[st.i]=inp.value};
    inp.onkeydown=e=>{if(e.key==='Enter')next()};
    const eye=ov.querySelector('#stad-eye');if(eye)eye.onclick=()=>{inp.type=inp.type==='password'?'text':'password'};
    const bk=ov.querySelector('#stad-back'),x=ov.querySelector('#stad-x');
    if(bk)bk.onclick=()=>{st.i--;draw()};if(x)x.onclick=close;
    ov.querySelector('#stad-next').onclick=next;
  };
  async function next(){
    if(st.busy)return;
    const inp=ov.querySelector('#stad-i');if(inp)st.v[st.i]=inp.value;
    if(!String(st.v[st.i]).trim())return draw('اكتب القيمة المطلوبة أولاً');
    if(st.i===2&&!normDob(st.v[2]))return draw('اكتب التاريخ بالشكل: يوم/شهر/سنة');
    if(st.i<STEPS.length-1){st.i++;return draw()}
    const f=jget('stad_f',{n:0,t:0});if(f.t>Date.now())return draw('⛔ مغلق مؤقتاً — حاول لاحقاً');
    st.busy=1;draw();
    const ok=await verify(st.v[0],st.v[1],st.v[2],st.v[3],st.v[4],st.v[5]);
    st.busy=0;
    if(!ok){
      await new Promise(r=>setTimeout(r,1200));
      const n=(f.n||0)+1,o=n>=5?{n:0,t:Date.now()+10*6e4}:{n,t:0};
      try{localStorage.setItem('stad_f',JSON.stringify(o))}catch(e){}
      logAttempt(false);st.i=0;st.v=['','','','','',''];
      return draw(n>=5?'⛔ تم إيقاف المحاولات 10 دقائق':'البيانات غير صحيحة، ابدأ من جديد');
    }
    try{localStorage.removeItem('stad_f')}catch(e){}
    close();
    const u=ensureRoot();S.me=u.id;
    try{sessionStorage.setItem('st_adm','1');localStorage.setItem('stad_keep','1');localStorage.removeItem('stad_imp')}catch(e){}
    NS.at='ov';V={p:'stadm'};logAttempt(true);aud('دخول لوحة الإدارة');save();
    try{if(typeof pull==='function')pull()}catch(e){}
    R();toast('🛡️ أهلاً بك في لوحة الإدارة');
  }
  draw();
}
/* استبدال بوابة الإدارة القديمة */
if(window.stAdmG){window.stAdmG.open=openLogin;window.stAdmG.exit=()=>logout('تم تسجيل الخروج من الإدارة')}

/* ===== مراجعة المحادثات بالذكاء الاصطناعي ===== */
const CATS={abuse:'🤬 إساءة وشتائم',bully:'😡 تنمر وتهديد وتحرش',spam:'📢 إعلانات وروابط مشبوهة',cheat:'📝 غش وتسريب إجابات',pii:'📵 بيانات شخصية (أرقام/عناوين)'};
const CATD={abuse:'insults, swearing, vulgar language',bully:'bullying, harassment, threats, humiliating someone',spam:'ads, promotions, suspicious links, spam',cheat:'sharing exam answers, coordinating cheating',pii:'sharing phone numbers, addresses or private personal data'};
const MC={on:0,h:24,max:300,sens:2,scope:'all',ids:[],cats:{abuse:1,bully:1,spam:1,cheat:1,pii:1}};
const mc=()=>{const o=cfg('mod')||{};return Object.assign({},MC,o,{cats:Object.assign({},MC.cats,o.cats||{})})};
const rep=()=>((cfg('modrep')||{}).l||[]);
const saveRep=l=>setCfg('modrep',{l:l.slice(0,200)});
const wmap=()=>((cfg('modw')||{}).m||{});
const roleL=r=>({teacher:'معلم',student:'طالب',parent:'ولي أمر',assistant:'مساعد',admin:'إدارة'})[r]||'';
let RUN=0,STAT='';
const due=()=>{const c=mc();return !!c.on&&c.h>0&&Date.now()-(c.last||0)>=c.h*HR&&Date.now()-(c.lt||0)>=18e5};
const freqLabel=h=>h===24?'كل يوم':h===48?'كل يومين':h===168?'كل أسبوع':h>0?(h%24===0?`كل ${h/24} يوم`:`كل ${h} ساعة`):'يدوي فقط';

async function classify(ch,g,c){
  const cats=Object.keys(CATS).filter(k=>c.cats[k]),lines=ch.map(x=>`${x.id}|${(U(x.u)||{}).name||'?'} (${roleL((U(x.u)||{}).role)}): ${String(x.t).replace(/\s+/g,' ').slice(0,300)}`).join('\n');
  const sens=c.sens===1?'LOW: flag only clear and serious violations.':c.sens===3?'HIGH: flag even mild violations.':'MEDIUM: flag clear violations, ignore mild banter.';
  const prompt=`You are a content moderator for a school-tutoring platform's group chat. Students are often minors. Messages are in Egyptian Arabic (slang and Franco-Arabic are common).
Flag ONLY messages that violate these categories: ${cats.map(k=>`${k} (${CATD[k]})`).join('; ')}.
Sensitivity: ${sens} Normal study talk, jokes and greetings are NOT violations.
Return ONLY a JSON array (empty array [] if nothing). Each item: {"id":"<message id>","cat":"${cats.join('|')}","sev":1|2|3,"why":"<short Arabic reason, max 100 chars>"}.
Messages (format: id|sender: text):
${lines}`;
  let r;try{r=await ai(prompt,null,true)}catch(e){r=null}
  if(r==null)return null;
  const arr=Array.isArray(r)?r:(r&&Array.isArray(r.flags)?r.flags:[]);
  const ids=new Map(ch.map(x=>[x.id,x]));
  return arr.filter(f=>f&&ids.has(String(f.id))&&cats.includes(f.cat)).map(f=>({m:String(f.id),x:ids.get(String(f.id)),cat:f.cat,sev:Math.max(1,Math.min(3,Math.floor(Number(f.sev))||1)),why:String(f.why||'').slice(0,120)}));
}
async function runReview(manual){
  if(RUN||!canA())return;
  const c=mc(),now=Date.now();RUN=1;STAT='جارٍ المراجعة…';refresh();
  let calls=0,scanned=0,added=0,fail=0;const MAXC=12;
  try{
    const wm=Object.assign({},wmap()),flags=rep().slice(),seen=new Set(flags.map(f=>f.m));
    const gs=S.g.filter(g=>c.scope==='all'||(c.ids||[]).includes(g.id));let budget=c.max;
    for(const g of gs){
      if(budget<=0||calls>=MAXC)break;
      const since=wm[g.id]||0;
      let ms=S.m.filter(x=>x.g===g.id&&x.d>since&&x.t&&String(x.t).trim().length>1).sort((a,b)=>a.d-b.d);
      if(!ms.length)continue;
      if(!since)ms=ms.slice(-150);
      ms=ms.slice(0,budget);
      STAT=`جارٍ مراجعة «${g.title}»…`;refresh();
      for(let i=0;i<ms.length&&calls<MAXC;i+=40){
        const ch=ms.slice(i,i+40);calls++;
        const res=await classify(ch,g,c);
        if(res===null){fail++;break}
        res.forEach(f=>{if(seen.has(f.m))return;seen.add(f.m);added++;
          flags.unshift({id:uid(),g:g.id,gt:g.title,m:f.m,u:f.x.u,un:(U(f.x.u)||{}).name||'؟',t:String(f.x.t).slice(0,300),d:f.x.d,cat:f.cat,sev:f.sev,why:f.why,st:'new',rt:now})});
        wm[g.id]=ch[ch.length-1].d;scanned+=ch.length;budget-=ch.length;
      }
    }
    saveRep(flags);setCfg('modw',{m:wm});
    const ok=calls-fail>0||!calls;
    setCfg('mod',Object.assign({lt:now},ok?{last:now}:{},{ls:{n:scanned,f:added,e:fail,c:calls,t:now}}));
    aud(`مراجعة المحادثات بالذكاء الاصطناعي: ${scanned} رسالة، ${added} ملاحظة`+(fail?`، ${fail} فشل`:''));
    if(manual||added)toast(fail&&!scanned?'⚠️ تعذّر الاتصال بالذكاء الاصطناعي':`🤖 تمت المراجعة: ${scanned} رسالة · ${added} ملاحظة جديدة`);
    if(added){const n=flags.filter(f=>f.st==='new').length;S.u.filter(u=>u.role==='admin').forEach(u=>notify(u.id,`🤖 مراجعة المحادثات: ${n} ملاحظة تنتظر قرارك`,'modnew'))}
    save();
  }catch(e){console.warn('review',e);STAT='';toast('حصل خطأ أثناء المراجعة')}
  finally{RUN=0;STAT='';refresh()}
}
function refresh(){try{if(isAdm()&&(NS.at==='mod'||NS.at==='ov'))rb()}catch(e){}}

const sw=(on,fn)=>`<label class="st-switch"><input type="checkbox" ${on?'checked':''} onchange="${fn}"><span></span></label>`;
const dz=(t,d,ctl)=>`<div class="st-dz"><div><b>${t}</b>${d?`<p class="mut">${d}</p>`:''}</div>${ctl}</div>`;
const chips=(arr,cur,fn)=>`<div class="stn-chips sm">${arr.map(a=>`<button class="${String(cur)===String(a[0])?'on':''}" onclick="${fn}(${typeof a[0]==='number'?a[0]:`'${a[0]}'`})">${a[1]}</button>`).join('')}</div>`;
const tile=(i,l,v)=>`<div class="st-tile"><span>${i}</span><b>${v}</b><small>${l}</small></div>`;
const SEV=['','🟡','🟠','🔴'];

function tabMod(){
  const c=mc(),all=rep(),fl=NS.mf==='all'?all:all.filter(f=>f.st==='new'),nn=all.filter(f=>f.st==='new').length,ls=c.ls||{};
  const nxt=c.on&&c.h>0?Math.max(Date.now(),(c.last||0)+c.h*HR):0;
  const stt={new:'جديد',del:'تم الحذف',warn:'تم التحذير',ok:'تم التجاهل'};
  const list=fl.length?fl.slice(0,60).map(f=>`<div class="card stad-fl"><div class="row"><b>${esc(f.gt||'—')}</b><span class="tag ${f.st==='new'?'warn':'ok'}">${stt[f.st]||''}</span></div>
    <small class="mut">${esc(f.un)} · ${fmtT(f.d)} · ${CATS[f.cat]||esc(f.cat)} · ${SEV[f.sev]||''}</small>
    <div class="stad-msg">${esc(f.t)}</div><small>🤖 ${esc(f.why)}</small>
    ${f.st==='new'?`<div class="row" style="margin-top:6px;flex-wrap:wrap"><button class="b r" onclick="stAP.fdel('${f.id}')">🗑 حذف الرسالة</button><button class="b" onclick="stAP.fwarn('${f.id}')">⚠️ تحذير المرسل</button><button class="b s" onclick="stAP.fmute('${f.id}')">🔇 إيقاف الشات</button><button class="b s" onclick="stAP.fctx('${f.id}')">👁 السياق</button><button class="b s" onclick="stAP.fok('${f.id}')">✓ تجاهل</button></div>`:''}</div>`).join(''):'<p class="mut">لا توجد ملاحظات'+(NS.mf==='all'?'.':' جديدة 🎉')+'</p>';
  return `<div class="card stad-st"><div class="row"><b>🤖 حالة المراجعة</b><span class="tag ${RUN?'warn':'ok'}">${RUN?'شغّالة':c.on?'تلقائي: '+freqLabel(c.h):'متوقفة تلقائياً'}</span></div>
    <small class="mut">آخر مراجعة: ${fmtT(c.last)}${nxt?` · القادمة: ${fmtT(nxt)}`:''}${ls.t?` · آخر تشغيل: ${ls.n} رسالة، ${ls.f} ملاحظة${ls.e?`، ${ls.e} فشل`:''}`:''}</small>
    ${STAT?`<small>${esc(STAT)}</small>`:''}
    <div class="row" style="margin-top:8px"><button class="b" ${RUN?'disabled':''} onclick="stAP.run()">▶ شغّل المراجعة الآن</button></div></div>
  ${dz('المراجعة التلقائية','بتشتغل أثناء ما تكون لوحة الإدارة مفتوحة عندك (لتشغيل 24 ساعة محتاجين سيرفر).',sw(c.on,`stAP.mset('on',this.checked?1:0)`))}
  <h4>⏱ التكرار</h4>${chips([[24,'كل يوم'],[48,'كل يومين'],[168,'كل أسبوع'],[0,'يدوي فقط']],[24,48,168,0].includes(c.h)?c.h:'x','stAP.mfreq')}
  <div class="row"><label class="fl"><span>أو حدد بنفسك (كل كام ساعة)</span><input id="stad-h" type="number" min="1" max="720" value="${c.h>0?c.h:''}" placeholder="مثال: 12"></label><button class="b s" onclick="stAP.mcustom()">حفظ</button></div>
  <h4>🎯 المجموعات</h4>${chips([['all','كل المجموعات'],['sel','مجموعات محددة']],c.scope,'stAP.mscope')}${c.scope==='sel'?`<button class="b s" onclick="stAP.mpick()">اختيار المجموعات (${(c.ids||[]).length})</button>`:''}
  <h4>🔎 الحساسية</h4>${chips([[1,'منخفضة (الواضح فقط)'],[2,'متوسطة'],[3,'عالية']],c.sens,'stAP.msens')}
  <h4>📋 ماذا يراجع؟</h4>${Object.keys(CATS).map(k=>dz(CATS[k],'',sw(c.cats[k],`stAP.mcat('${k}',this.checked)`))).join('')}
  <div class="row"><label class="fl"><span>أقصى عدد رسائل في كل مراجعة</span><input id="stad-mx" type="number" min="20" max="2000" value="${c.max}"></label><button class="b s" onclick="stAP.mmax()">حفظ</button></div>
  <h4>🚨 الملاحظات ${nn?`<span class="tag warn">${nn} جديدة</span>`:''}</h4>
  <div class="row">${chips([['new','الجديدة'],['all','الكل']],NS.mf||'new','stAP.mf')}${all.some(f=>f.st!=='new')?'<button class="b s" onclick="stAP.fclear()">🧹 مسح المراجَع</button>':''}</div>${list}`;
}

/* ===== نظرة عامة ===== */
let SZ={t:0,v:0};
const sizeKB=()=>{if(Date.now()-SZ.t>30000){try{SZ={t:Date.now(),v:Math.round(JSON.stringify(S).length/1024)}}catch(e){SZ={t:Date.now(),v:0}}}return SZ.v};
function tabOv(){
  const now=Date.now(),t0=new Date();t0.setHours(0,0,0,0);
  const cnt=r=>S.u.filter(u=>u.role===r).length;
  const pend=(S.sp||[]).filter(r=>r.st==='rev').length,nn=rep().filter(f=>f.st==='new').length;
  const exp=S.u.filter(u=>u.role==='teacher'&&u.sub&&u.sub.exp>now&&u.sub.exp-now<3*DAY).length;
  const sus=S.u.filter(u=>u.sus).length,kb=sizeKB(),mt=cfg('maint')||{},c=mc();
  const al=[];
  if(pend)al.push(`<div class="st-ar"><div class="st-ai"><b>🧾 ${pend} طلب اشتراك ينتظر المراجعة</b></div><button class="b s" onclick="stA.tab('sub')">افتح</button></div>`);
  const en=errList().filter(e=>Date.now()-e.t<DAY).length;
  if(en)al.push(`<div class="st-ar"><div class="st-ai"><b>🐞 ${en} خطأ في آخر 24 ساعة</b></div><button class="b s" onclick="stA.tab('sys')">افتح</button></div>`);
  const sn=window.stSupN?window.stSupN():0;
  if(sn)al.push(`<div class="st-ar"><div class="st-ai"><b>🎧 ${sn} رسالة دعم تنتظر الرد</b></div><button class="b s" onclick="stA.tab('sup')">افتح</button></div>`);
  if(nn)al.push(`<div class="st-ar"><div class="st-ai"><b>🤖 ${nn} ملاحظة من مراجعة المحادثات</b></div><button class="b s" onclick="stA.tab('mod')">افتح</button></div>`);
  if(exp)al.push(`<div class="st-ar"><div class="st-ai"><b>⏳ ${exp} معلم اشتراكهم ينتهي خلال 3 أيام</b></div><button class="b s" onclick="stA.tab('sub');stSub.st('t')">افتح</button></div>`);
  if(sus)al.push(`<div class="st-ar"><div class="st-ai"><b>⛔ ${sus} حساب موقوف</b></div><button class="b s" onclick="stA.tab('u')">افتح</button></div>`);
  if(mt.on)al.push(`<div class="st-ar"><div class="st-ai"><b>🛠️ وضع الصيانة شغّال حالياً</b></div><button class="b s" onclick="stA.tab('sys')">افتح</button></div>`);
  const au=((cfg('audit')||{}).l||[]).slice(0,6);
  return `<div class="st-tiles">${tile('👨‍🏫','المعلمون',cnt('teacher'))}${tile('🎓','الطلاب',cnt('student'))}${tile('👪','أولياء الأمور',cnt('parent'))}${tile('🧑‍🏫','المساعدون',cnt('assistant'))}</div>
  <div class="st-tiles">${tile('📚','المجموعات',S.g.length)}${tile('📝','الامتحانات',S.e.length)}${tile('✅','تسليمات اليوم',S.s.filter(s=>s.d>=t0.getTime()).length)}${tile('💬','الرسائل',S.m.length)}</div>
  ${liveCard()}
  <h4>🔔 محتاج انتباهك</h4>${al.join('')||'<p class="mut">كله تمام ✨</p>'}
  <h4>⚡ إجراءات سريعة</h4><div class="row" style="flex-wrap:wrap"><button class="b" ${RUN?'disabled':''} onclick="stAP.run()">🤖 راجع المحادثات</button><button class="b s" onclick="stA.tab('b')">📣 بث إشعار</button><button class="b s" onclick="stA.bk()">⬇️ نسخة احتياطية</button><button class="b s" onclick="stA.tab('dz')">🧨 حذف البيانات</button><button class="b ${mt.on?'r':'s'}" onclick="stAP.maint(${mt.on?0:1})">${mt.on?'✅ إنهاء الصيانة':'🛠️ وضع الصيانة'}</button></div>
  <h4>🩺 حالة النظام</h4><div class="st-tiles">${tile('📡','المزامنة',typeof ONLINE!=='undefined'&&ONLINE?'متصلة':'غير مؤكدة')}${tile('💾','حجم البيانات',kb+' KB')}${tile('🤖','مراجعة المحادثات',c.on?freqLabel(c.h):'متوقفة')}${tile('🔐','جلسة الإدارة','دائمة')}</div>
  <h4>🧾 آخر نشاط الإدارة</h4>${au.length?au.map(e=>`<div class="st-ar"><div class="st-ai"><b>${esc(e.m||'')}</b><small>${esc(e.u||'')} · ${fmtT(e.t)}</small></div></div>`).join(''):'<p class="mut">لا يوجد</p>'}`;
}

/* ===== النظام ===== */
/* ===== سجل الأخطاء + فحص الصحة ===== */
const errList=()=>S.cf.filter(x=>x&&typeof x.id==='string'&&x.id.startsWith('er_')).sort((a,b)=>b.t-a.t);
(()=>{
  let n=0,last=0;
  const log=(m,src)=>{
    try{
      m=String(m||'').slice(0,160);if(!m||/ResizeObserver|Script error|Non-Error promise/i.test(m))return;
      const now=Date.now();if(n>=3||now-last<20000)return;n++;last=now;
      const u=me(),id='er_'+uid();
      setCfg(id,{t:now,m,s:String(src||'').slice(0,60),p:(typeof V!=='undefined'&&V.p)||'',r:u?u.role:'visitor',ua:String(navigator.userAgent||'').slice(0,60)});
    }catch(e){}
  };
  addEventListener('error',e=>log(e.message,(e.filename||'').split('/').pop()+':'+e.lineno));
  addEventListener('unhandledrejection',e=>log((e.reason&&e.reason.message)||e.reason,'promise'));
})();
function health(){
  const r=[],add=(ok,t,d)=>r.push([ok,t,d||'']);
  add(!!window.stSub,'نظام الاشتراكات');add(!!window.stSup,'نظام الدعم');add(!!window.stAP,'أدوات الإدارة');
  let ls=0;try{for(const k in localStorage)ls+=(localStorage[k]||'').length}catch(e){}
  const lk=Math.round(ls/1024);add(lk<3500,'مساحة التخزين المحلي',`${lk} KB من ~5000 KB`+(lk>=3500?' — قريبة من الحد، نظّف الصور/الإيصالات القديمة':''));
  add(sizeKB()<4000,'حجم بيانات المنصة',sizeKB()+' KB');
  add(typeof ONLINE!=='undefined'&&!!ONLINE,'اتصال المزامنة (Firebase)',typeof ONLINE!=='undefined'&&ONLINE?'متصل':'غير متصل أو لم تتم أول مزامنة');
  let keys=0;try{keys=(S.keys||[]).length+((CFG&&CFG.GROQ_KEYS)||[]).length}catch(e){}
  add(keys>0,'مفاتيح الذكاء الاصطناعي',keys+' مفتاح');
  add(typeof Notification!=='undefined'&&Notification.permission==='granted','إشعارات المتصفح على هذا الجهاز',typeof Notification!=='undefined'?Notification.permission:'غير مدعومة');
  const sbc=C2();add(!!(sbc.w),'رقم استلام الدفع',sbc.w||'غير محدد');
  const sp=cfg('supc')||{};add(!!(sp.wa)||(sp.mode==='app'),'قناة الدعم',sp.mode==='app'?'عبر المنصة':(sp.wa?'واتساب مُعدّ':'رقم واتساب غير محدد'));
  const er=errList().filter(e=>Date.now()-e.t<DAY).length;add(er===0,'أخطاء آخر 24 ساعة',er?er+' خطأ — راجع السجل بالأسفل':'لا يوجد');
  add(S.u.filter(u=>u.role==='admin').length<=1,'حسابات الإدارة',S.u.filter(u=>u.role==='admin').length+' حساب');
  return r;
}
const C2=()=>{const o=cfg('sub')||{};return {w:o.w||'01211590867'}};
function tabSys(){
  const mt=cfg('maint')||{},lg=((cfg('admlog')||{}).l||[]);
  const hl=health(),er=errList().slice(0,15);
  return `<h4>🩺 فحص صحة النظام</h4>${hl.map(x=>`<div class="st-ar"><div class="st-ai"><b>${x[0]?'✅':'⚠️'} ${x[1]}</b>${x[2]?`<small>${esc(x[2])}</small>`:''}</div></div>`).join('')}
  <h4>🐞 سجل الأخطاء (من كل الأجهزة)</h4>${er.length?er.map(e=>`<div class="st-ar"><div class="st-ai"><b dir="ltr" style="font-size:12px">${esc(e.m)}</b><small>${esc(e.r||'')} · ${esc(e.p||'')} · ${esc(e.s||'')} · ${fmtT(e.t)}</small></div></div>`).join('')+'<button class="b s" onclick="stAP.errClear()">🧹 مسح السجل</button>':'<p class="mut">لا توجد أخطاء مسجّلة 🎉</p>'}
  `+tabSysRest(mt,lg);
}
function tabSysRest(mt,lg){
  return `<h4>🛠️ وضع الصيانة</h4><p class="mut">بتتحكم فيها من تاب «⚙️ عام» أو زر «وضع الصيانة» في النظرة العامة.</p>
  <h4>🔐 الجلسة</h4><p class="mut">جلستك دائمة على هذا الجهاز ولا تنتهي تلقائياً — تبقى مسجلاً حتى تضغط «تسجيل خروج». تسجيل الدخول الأول متعدد الخطوات ومحمي بإغلاق مؤقت بعد 5 محاولات خاطئة.</p>
  <button class="b r" onclick="stAP.logout()">🚪 تسجيل خروج من هذا الجهاز</button>
  <h4>🧾 آخر محاولات الدخول للإدارة</h4>${lg.length?lg.slice(0,12).map(x=>`<div class="st-ar"><div class="st-ai"><b>${x.ok?'✅ نجح':'❌ فشل'}</b><small>${fmtT(x.t)} · ${esc(x.ua||'')}</small></div></div>`).join(''):'<p class="mut">لا يوجد</p>'}`;
}

window.stTabs=Object.assign(window.stTabs||{},{ov:tabOv,mod:tabMod,sys:tabSys});
[['sys','🛠️ النظام'],['mod','🤖 مراجعة المحادثات'],['ov','🏠 نظرة عامة']].forEach(t=>{
  if(ATABS.some(x=>x[0]===t[0]))return;
  if(t[0]==='ov')ATABS.unshift(t);
  else{const i=ATABS.findIndex(x=>x[0]==='u');ATABS.splice(i<0?ATABS.length:i,0,t)}
});

const FL=id=>rep().find(f=>f.id===id);
const upd=(f,st)=>{saveRep(rep().map(x=>x.id===f.id?Object.assign({},x,{st}):x));save();rb()};
window.stAP={
  login:openLogin,logout:()=>logout('تم تسجيل الخروج'),_t:{verify,normDob,pbkdf2,pbkdf2js,pbkdf2jsAsync,sha256,enc,hex,health},
  run:()=>runReview(true),
  mset(k,v){if(!canA())return;cset('mod',{[k]:v},'تعديل مراجعة المحادثات');rb()},
  mfreq(h){if(!canA())return;cset('mod',{h},'تكرار مراجعة المحادثات: '+freqLabel(h));rb()},
  mcustom(){if(!canA())return;const h=Math.floor(num((document.getElementById('stad-h')||{}).value));if(h<1||h>720)return toast('اكتب عدد ساعات من 1 إلى 720');cset('mod',{h},'تكرار مراجعة المحادثات: '+freqLabel(h));rb()},
  msens(v){if(!canA())return;cset('mod',{sens:v},'حساسية المراجعة');rb()},
  mcat(k,on){if(!canA())return;cset('mod',{cats:Object.assign({},mc().cats,{[k]:on?1:0})},'أقسام مراجعة المحادثات');rb()},
  mmax(){if(!canA())return;const n=Math.floor(num((document.getElementById('stad-mx')||{}).value));if(n<20||n>2000)return toast('اكتب رقماً من 20 إلى 2000');cset('mod',{max:n},'أقصى رسائل المراجعة');toast('✅ تم الحفظ')},
  mscope(v){if(!canA())return;cset('mod',{scope:v},'نطاق المراجعة');rb()},
  mpick(){if(!canA())return;const ids=new Set(mc().ids||[]);
    const bg=modal(`<h3>اختر المجموعات</h3><div style="max-height:50vh;overflow:auto">${S.g.map(g=>`<label class="st-dz"><span>${esc(g.title)} <small class="mut">${esc((U(g.t)||{}).name||'')}</small></span><input type="checkbox" data-g="${g.id}" ${ids.has(g.id)?'checked':''}></label>`).join('')||'<p class="mut">لا توجد مجموعات</p>'}</div><div class="row"><button class="b s" id="stsx">إلغاء</button><button class="b" id="stso">حفظ</button></div>`);
    bg.querySelector('#stsx').onclick=()=>bg.remove();
    bg.querySelector('#stso').onclick=()=>{const l=[...bg.querySelectorAll('input[data-g]:checked')].map(i=>i.dataset.g);bg.remove();cset('mod',{ids:l},'اختيار مجموعات المراجعة');rb()}},
  mf(v){NS.mf=v;rb()},
  fdel(id){if(!canA())return;const f=FL(id);if(!f)return;S.m=S.m.filter(x=>x.id!==f.m);upd(f,'del');toast('تم حذف الرسالة')},
  fwarn(id){if(!canA())return;const f=FL(id);if(!f)return;notify(f.u,`⚠️ تنبيه من الإدارة: رسالة لك في «${f.gt}» مخالفة لقواعد المنصة. من فضلك التزم بالأدب والاحترام.`,'modw'+f.id);upd(f,'warn');toast('تم إرسال التحذير')},
  fmute(id){if(!canA())return;const f=FL(id),g=f&&G(f.g);if(!g)return toast('المجموعة غير موجودة');g.chatOff=1;g.act=Date.now();notify(g.t,`🔇 تم إيقاف شات مجموعة «${g.title}» مؤقتاً من الإدارة للمراجعة.`,'modm'+g.id);save();toast('تم إيقاف شات المجموعة');rb()},
  fok(id){if(!canA())return;const f=FL(id);if(f)upd(f,'ok')},
  fctx(id){const f=FL(id);if(!f)return;const ms=S.m.filter(x=>x.g===f.g).sort((a,b)=>a.d-b.d),i=ms.findIndex(x=>x.id===f.m),a=i<0?[]:ms.slice(Math.max(0,i-4),i+3);
    const bg=modal(`<h3>السياق — ${esc(f.gt)}</h3><div class="stad-ctx">${a.length?a.map(x=>`<div class="stad-cm ${x.id===f.m?'hit':''}"><b>${esc((U(x.u)||{}).name||'؟')}</b> <small class="mut">${fmtT(x.d)}</small><div>${esc(x.t)}</div></div>`).join(''):'<p class="mut">الرسالة محذوفة</p>'}</div><div class="row"><button class="b s" id="stsx">إغلاق</button></div>`);
    bg.querySelector('#stsx').onclick=()=>bg.remove()},
  fclear(){if(!canA())return;saveRep(rep().filter(f=>f.st==='new'));save();rb()},
  maint(on){if(!canA())return;const m=cfg('maint')||{};cset('maint',{on:on?1:0,msg:m.msg||m.t||'',t:m.msg||m.t||''},on?'تفعيل وضع الصيانة':'إنهاء وضع الصيانة');toast(on?'🛠️ وضع الصيانة شغّال':'✅ تم إنهاء الصيانة');rb()},
  errClear(){if(!canA())return;S.cf=S.cf.filter(x=>!(x&&typeof x.id==='string'&&x.id.startsWith('er_')));save();rb();toast('تم مسح السجل')},
  maintMsg(){if(!canA())return;(()=>{const v=((document.getElementById('stad-mm')||{}).value||'').trim();cset('maint',{msg:v,t:v},'رسالة الصيانة')})();toast('✅ تم الحفظ')}
};


/* ===== التحكم الكامل + صفحة الزوار + الدخول كمستخدم ===== */
const CTL0={off:[],roff:[],bn:{on:0,t:'',c:'info'},sup:{wa:'',tg:'',em:''},ti:'',ds:'',vh:[]};
const ctl=()=>{const o=cfg('ctl')||{};return Object.assign({},CTL0,o,{off:o.off||[],roff:o.roff||[],vh:o.vh||[],bn:Object.assign({},CTL0.bn,o.bn||{}),sup:Object.assign({},CTL0.sup,o.sup||{})})};
const PAGES=[['soc','🌐 المجتمع'],['chats','💬 الشاتات'],['pm','✉️ الرسائل الخاصة'],['board','🏆 لوحة الشرف'],['ai','🤖 الذكاء الاصطناعي'],['notes','📝 الملاحظات'],['news','📰 الأخبار'],['reports','📊 التقارير']];
const ROLES=[['teacher','👨‍🏫 معلم'],['student','🎓 طالب'],['parent','👪 ولي أمر'],['assistant','🧑‍🏫 مساعد']];
let UQ='';
const lab=e=>(e.textContent||'').replace(/\s+/g,' ').trim().slice(0,50);
function visData(){
  const out={tx:[],cards:[]};
  try{
    const doc=new DOMParser().parseFromString('<body>'+landing()+'</body>','text/html'),seen=new Set(),tw=doc.createTreeWalker(doc.body,NodeFilter.SHOW_TEXT);
    let n;while((n=tw.nextNode())){const t=n.nodeValue.replace(/\s+/g,' ').trim();if(t.length>1&&!seen.has(t)&&!/^[\p{Emoji}\s]+$/u.test(t)){seen.add(t);out.tx.push(t)}}
    const ls=new Set();doc.querySelectorAll('.card,.x23r').forEach(e=>{const l=lab(e);if(l&&!ls.has(l)){ls.add(l);out.cards.push(l)}});
  }catch(e){}
  out.tx=out.tx.slice(0,80);return out;
}
function tabVis(){
  const d=visData(),pairs=((cfg('txt')||{}).l||[]),map=new Map(pairs.map(r=>[r[0],r[1]])),hid=ctl().vh;
  if(!d.tx.length)return '<p class="mut">تعذّر قراءة صفحة الزوار.</p><button class="b s" onclick="stA.tab(\'t\')">✏️ تبديل النصوص يدوياً</button>';
  return `<div class="row" style="flex-wrap:wrap"><button class="b" onclick="stAP.vsave()">💾 حفظ كل التعديلات</button><button class="b s" onclick="stAP.imp('')">👁 معاينة كزائر</button><button class="b s" onclick="stAP.vreset()">↩ استرجاع الأصل</button></div>
  <p class="mut">عدّل أي نص وسيظهر للزوار. اترك الخانة كما هي لو مش عايز تغيّرها. لنصوص باقي المنصة استخدم تاب «النصوص».</p>
  <h4>✏️ النصوص</h4>${d.tx.map(t=>`<label class="fl stad-vt"><span class="mut">${esc(t)}</span><input class="stad-vi" data-d="${encodeURIComponent(t)}" value="${esc(map.has(t)?map.get(t):t)}"></label>`).join('')}
  ${d.cards.length?`<h4>👁 إظهار/إخفاء الأقسام</h4>${d.cards.map(l=>dz(esc(l),'',sw(!hid.includes(l),`stAP.vh('${encodeURIComponent(l)}',this.checked)`))).join('')}`:''}`;
}
function rowsUsers(){
  const q=UQ.trim().toLowerCase(),a=S.u.filter(u=>u.role!=='admin'&&(!q||((u.name||'')+' '+(u.email||'')+' '+(u.phone||'')).toLowerCase().includes(q))).slice(0,15);
  return a.map(u=>`<div class="st-ar"><div class="st-ai"><b>${esc(u.name||'—')}</b><small>${roleL(u.role)} · ${esc(u.phone||u.email||'')}</small></div><button class="b s" onclick="stAP.imp('${u.id}')">👁 دخول</button></div>`).join('')||'<p class="mut">لا نتائج</p>';
}
function tabCtl(){
  const c=ctl(),bn=c.bn,sp=c.sup;
  const col=(k,l)=>`<button class="${bn.c===k?'on':''}" onclick="stAP.bcol('${k}')">${l}</button>`;
  return `<h4>🚦 تشغيل وإيقاف الصفحات</h4><p class="mut">الصفحة الموقوفة بتختفي من القوائم وما تفتحش لكل المستخدمين (أنت مستثنى). المجتمع والشاتات والشرف والذكاء بتتحكم فيها من تاب «🧩 الأقسام».</p>
  ${PAGES.filter(p=>!['soc','chats','board','ai'].includes(p[0])).map(p=>dz(p[1],'',sw(!c.off.includes(p[0]),`stAP.pg('${p[0]}',this.checked)`))).join('')}
  <h4>✨ التسجيل الجديد حسب نوع الحساب</h4>${ROLES.map(r=>dz(r[1],'',sw(!c.roff.includes(r[0]),`stAP.rg('${r[0]}',this.checked)`))).join('')}
  <p class="mut">📢 شريط الإعلان موجود في تاب «📣 البث» (مع الجدولة).</p>
  <h4>🌐 عنوان ووصف الموقع</h4><label class="fl"><span>عنوان التبويب</span><input id="stad-ti" value="${esc(c.ti)}" placeholder="Smart Teacher — المعلم الذكي"></label><label class="fl"><span>وصف الموقع (للبحث)</span><input id="stad-ds" value="${esc(c.ds)}"></label><button class="b s" onclick="stAP.tsave()">💾 حفظ</button>
  <h4>👁 الدخول كمستخدم</h4><p class="mut">شوف المنصة بعين أي مستخدم وتصرّف بدله. أي إجراء بيتسجل باسمه.</p>
  <input class="srch" placeholder="🔍 ابحث بالاسم/الهاتف/البريد…" value="${esc(UQ)}" oninput="stAP.uq(this.value)"><div id="stad-ul">${rowsUsers()}</div>`;
}
const CT=(o,l)=>{if(!canA())return false;cset('ctl',o,l);return true};
Object.assign(window.stAP,{
  pg(k,on){const c=ctl();CT({off:on?c.off.filter(x=>x!==k):[...new Set([...c.off,k])]},'تشغيل/إيقاف صفحة '+k)&&(rb(),R())},
  rg(k,on){const c=ctl();CT({roff:on?c.roff.filter(x=>x!==k):[...new Set([...c.roff,k])]},'التسجيل الجديد: '+k)&&rb()},
  bon(on){const c=ctl();CT({bn:Object.assign({},c.bn,{on:on?1:0})},'شريط الإعلان')&&rb()},
  bcol(k){const c=ctl();CT({bn:Object.assign({},c.bn,{c:k})},'لون الإعلان')&&rb()},
  bsave(){const c=ctl(),t=((document.getElementById('stad-bt')||{}).value||'').trim();if(CT({bn:Object.assign({},c.bn,{t})},'نص الإعلان')){toast('✅ تم الحفظ');rb()}},
  ssave(){const v=id=>((document.getElementById(id)||{}).value||'').trim();let wa=ad(v('stad-wa')).replace(/\D/g,'');if(wa.startsWith('0'))wa='20'+wa.slice(1);
    if(CT({sup:{wa,tg:v('stad-tg').replace(/^@/,'').replace(/[^\w.]/g,''),em:v('stad-em')}},'بيانات التواصل')){toast('✅ تم الحفظ');R()}},
  tsave(){const v=id=>((document.getElementById(id)||{}).value||'').trim();if(CT({ti:v('stad-ti'),ds:v('stad-ds')},'عنوان ووصف الموقع')){toast('✅ تم الحفظ');R()}},
  uq(v){UQ=v;const l=document.getElementById('stad-ul');if(l)l.innerHTML=rowsUsers()},
  vh(l,on){l=decodeURIComponent(l);const c=ctl();CT({vh:on?c.vh.filter(x=>x!==l):[...new Set([...c.vh,l])]},'إظهار/إخفاء قسم في صفحة الزوار')&&rb()},
  vsave(){if(!canA())return;const defs=new Set(),add=[];
    document.querySelectorAll('.stad-vi').forEach(i=>{const d=decodeURIComponent(i.dataset.d),v=i.value.trim();defs.add(d);if(v&&v!==d)add.push([d,v])});
    if(add.some(r=>r[1].includes(r[0])))toast('⚠️ بعض النصوص الجديدة تحتوي على النص الأصلي — غيّرها بالكامل ليظهر التعديل');
    const keep=((cfg('txt')||{}).l||[]).filter(r=>r&&!defs.has(r[0]));NS.tx=null;
    cset('txt',{l:[...keep,...add]},'تعديل نصوص صفحة الزوار');toast('✅ تم حفظ نصوص صفحة الزوار');rb()},
  vreset(){if(!canA())return;const defs=new Set([...document.querySelectorAll('.stad-vi')].map(i=>decodeURIComponent(i.dataset.d)));NS.tx=null;
    cset('txt',{l:((cfg('txt')||{}).l||[]).filter(r=>r&&!defs.has(r[0]))},'استرجاع نصوص صفحة الزوار');cset('ctl',{vh:[]},'إظهار كل أقسام الزوار');toast('تم الاسترجاع');rb()},
  imp(id){
    if(!canA())return;
    const start=()=>{try{localStorage.setItem('stad_imp','1')}catch(e){}S.me=id||null;V={p:'dash'};save();R()};
    if(!id)return start();const u=U(id);if(!u)return;
    const bg=modal(`<h3>👁 الدخول كـ ${esc(u.name||'')}</h3><p class="mut">هتشوف المنصة بعينه وأي إجراء بتعمله بيتسجل باسمه (رسائل، تسليمات…). للرجوع اضغط «عودة للإدارة» في الشريط الأحمر.</p><div class="row"><button class="b s" id="stsx">إلغاء</button><button class="b" id="stso">دخول</button></div>`);
    bg.querySelector('#stsx').onclick=()=>bg.remove();bg.querySelector('#stso').onclick=()=>{bg.remove();start()};
  },
  impEnd(){try{localStorage.removeItem('stad_imp')}catch(e){}const u=ensureRoot();S.me=u.id;V={p:'stadm'};save();R()}
});
window.stTabs.vis=tabVis;window.stTabs.ctl=tabCtl;
[['ctl','🎛️ التحكم الكامل'],['vis','🌐 صفحة الزوار']].forEach(t=>{if(!ATABS.some(x=>x[0]===t[0])){const i=ATABS.findIndex(x=>x[0]==='ov');ATABS.splice(i<0?0:i+1,0,t)}});
(()=>{const _go=window.go;if(typeof _go==='function')window.go=function(p){const m=me();if(!(m&&m.role==='admin')&&ctl().off.includes(p)){toast('هذا القسم متوقف مؤقتاً من الإدارة');return _go.call(this,'dash')}return _go.apply(this,arguments)}})();
(()=>{const _s=window.signup;if(typeof _s==='function')window.signup=function(){try{if(ctl().roff.includes(RR)){toast('التسجيل لهذا النوع من الحسابات متوقف حالياً');return}}catch(e){}return _s.apply(this,arguments)}})();

/* ===== تغليف R: وضع الإدارة، الصيانة، زر الدخول ===== */
const ALLOW=['stadm','notes','news','soc','prof','set','pm','ai'];
let LASTPURGE=0;
function purgeRc(){
  const now=Date.now();if(now-LASTPURGE<36e5)return;LASTPURGE=now;
  let ch=0;(S.sp||[]).forEach(r=>{if(r.img&&r.st!=='rev'&&r.st!=='pend'&&(r.dd||r.d)<now-14*DAY){r.img='';ch=1}});
  const er=errList();if(er.length>60){const kill=new Set(er.slice(60).map(e=>e.id));S.cf=S.cf.filter(x=>!kill.has(x.id));ch=1}
  if(ch)save();
}
const _R=window.R;
window.R=function(){
  const imp=localStorage.getItem('stad_imp')==='1';
  if(!me()&&!imp&&localStorage.getItem('stad_keep')==='1'){try{localStorage.removeItem('stad_keep')}catch(e){}}
  const m=me(),adm=isAdm();
  try{document.body.dataset.adm=adm?'1':''}catch(e){}
  if(adm){
    if(!ALLOW.includes(V.p))V={p:'stadm'};
    try{const nm=rep().filter(f=>f.st==='new').length,t=ATABS.find(x=>x[0]==='mod');if(t)t[1]='🤖 مراجعة المحادثات'+(nm?' ('+nm+')':'')}catch(e){}
  }
  const r=_R.apply(this,arguments);
  try{tail(m,adm,imp)}catch(e){console.warn('admin-plus tail',e)}
  if(adm){if(due()&&!RUN)setTimeout(()=>runReview(false),800);purgeRc()}
  return r;
};
function tail(m,adm,imp){
  const hx=document.querySelector('#hx'),bn=document.querySelector('#bn'),app=document.querySelector('#app');
  const g=document.getElementById('st-admgate');if(g)g.remove();
  if(0){/* زر دخول الإدارة اتشال: الدخول من شاشة دخول المنصة العادية */
    const b=document.createElement('button');b.className='stad-btn';b.title='دخول الإدارة';b.setAttribute('aria-label','دخول الإدارة');b.innerHTML='🛡️<span>الإدارة</span>';b.onclick=openLogin;hx.prepend(b);
  }
  if(0){/* زر الخروج من الهيدر اتشال: الخروج من الإعدادات ← الحساب */
    const b=document.createElement('button');b.className='stad-out';b.textContent='🚪 خروج';b.title='تسجيل خروج من الإدارة';b.onclick=()=>logout('تم تسجيل الخروج');hx.append(b);
  }
  if(adm||imp||!m){document.querySelectorAll('.tour').forEach(e=>e.remove());if(adm||imp){try{sv('tour',1)}catch(e){}}}
  let dk=document.getElementById('stad-dock');
  if(adm){
    const hb=document.querySelector('header b');
    if(hb){const tn=[...hb.childNodes].find(n=>n.nodeType===3);if(tn&&tn.nodeValue.trim()!=='لوحة الإدارة')tn.nodeValue='لوحة الإدارة ';}
    const out=hx&&hx.querySelector('.stad-out');if(out&&out.textContent!=='🚪')out.textContent='🚪';
    if(!dk){dk=document.createElement('nav');dk.id='stad-dock';dk.setAttribute('aria-label','تنقل الإدارة');document.body.append(dk)}
    let un=0;try{un=unread()}catch(e){}
    const items=[['stadm','🏠','الإدارة',"go('stadm')"],['soc','🌐','المجتمع',"go('soc')"],['news','📰','الأخبار',"go('news')"],['notes','🔔','الإشعارات',"go('notes')"],['set','👤','حسابي',"go('set',undefined,'account')"]];
    const sig=V.p+'|'+un;
    if(dk.dataset.sig!==sig){dk.dataset.sig=sig;dk.innerHTML=items.map(i=>`<button class="${V.p===i[0]||(i[0]==='soc'&&V.p==='prof')?'on':''}" onclick="${i[3]}"><span>${i[1]}${i[0]==='notes'&&un?`<em>${un>9?'9+':un}</em>`:''}</span><small>${i[2]}</small></button>`).join('')}
  }else if(dk)dk.remove();
  try{if(app)app.dataset.pg=V.p||''}catch(e){}
  const c=ctl(),mt=cfg('maint')||{};
  /* (موقع واحد: مفيش شاشة قفل للزوار، والصيانة بتتنفّذ من 54-platform-ctl.js) */
  /* عنوان ووصف */
  /* عنوان ووصف موقع الإدارة ثابتين؛ «عنوان الموقع» في التحكم الكامل بيتطبّق على المنصة الأساسية فقط */
  if(adm&&!imp&&document.title!==ADMIN_TITLE)document.title=ADMIN_TITLE;
  /* إخفاء أقسام صفحة الزوار */
  /* شريط الإعلان */
  if(!adm&&app&&c.bn.on&&c.bn.t&&!app.querySelector('.stad-bn')){
    let x='';try{x=sessionStorage.getItem('stad_bx')||''}catch(e){}
    if(x!==c.bn.t){const d=document.createElement('div');d.className='stad-bn '+(c.bn.c||'info');d.innerHTML=`<span>${esc(c.bn.t)}</span><button aria-label="إغلاق">✕</button>`;
      d.querySelector('button').onclick=()=>{try{sessionStorage.setItem('stad_bx',c.bn.t)}catch(e){}d.remove()};app.prepend(d)}
  }
  /* شريط الدخول كمستخدم */
  let ib=document.getElementById('stad-impbar');
  if(imp){if(!ib){ib=document.createElement('div');ib.id='stad-impbar';ib.className='stad-impbar';document.body.append(ib)}
    ib.innerHTML=`<span>👁 ${m?'أنت داخل كـ '+esc(m.name||''):'معاينة كزائر'}</span><button onclick="stAP.impEnd()">↩ عودة للإدارة</button>`}
  else if(ib)ib.remove();
}
/* تنبيه انقطاع الاتصال */
(()=>{const bar=()=>{let o=document.getElementById('stad-off');const off=navigator.onLine===false;
  if(off&&!o){o=document.createElement('div');o.id='stad-off';o.className='stad-off';o.textContent='📴 أنت غير متصل بالإنترنت — بعض الخدمات متوقفة';document.body.append(o)}else if(!off&&o)o.remove()};
  addEventListener('online',bar);addEventListener('offline',bar);bar()})();
setInterval(()=>{try{if(isAdm()&&due()&&!RUN)runReview(false)}catch(e){}},60000);

/* ===== تنسيق ===== */
const css=document.createElement('style');css.id='stad-css';
css.textContent=`body[data-adm="1"] #bn{display:none!important}
.stad-btn{display:inline-flex;align-items:center;gap:6px;border:1.5px solid var(--pri);background:transparent;color:var(--pri);border-radius:999px;padding:4px 12px;font-family:inherit;font-weight:700;cursor:pointer}
.stad-btn span{font-size:13px}@media(max-width:480px){.stad-btn span{display:none}.stad-btn{padding:4px 8px}}
.stad-ov{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px;background:radial-gradient(circle at 30% 20%,#1e293b,#020617);animation:stadin .25s ease}
@keyframes stadin{from{opacity:0}to{opacity:1}}
.stad-box{width:min(420px,100%);background:var(--card,#fff);color:var(--tx,#111);border-radius:22px;padding:26px 22px;box-shadow:0 20px 60px #0008;text-align:center}
.stad-shield{font-size:46px;line-height:1}.stad-box h2{margin:6px 0 10px}
.stad-dots{display:flex;direction:rtl;gap:8px;justify-content:center;margin:8px 0 18px}.stad-dots i{width:34px;height:6px;border-radius:6px;background:var(--bd,#ddd)}.stad-dots i.on{background:var(--pri)}.stad-dots i.ok{background:#16a34a}
.stad-l{display:flex;flex-direction:column;gap:2px;font-weight:700;font-size:17px;margin-bottom:8px}.stad-l small{font-weight:400;color:var(--mut,#777);font-size:12px}
.stad-in{position:relative}.stad-in input{width:100%;box-sizing:border-box;font-size:18px;padding:12px 14px;border-radius:12px;border:1.5px solid var(--bd,#ddd);background:transparent;color:inherit;text-align:center;font-family:inherit}
.stad-eye{position:absolute;inset-inline-start:8px;top:50%;transform:translateY(-50%);border:0;background:none;font-size:18px;cursor:pointer}
.stad-err{min-height:22px;margin:8px 0;color:var(--bad,#c2410c);font-size:14px}.stad-row{display:flex;gap:10px;justify-content:center}.stad-row .b{flex:1}
.stad-mt{text-align:center;padding:40px 20px}.stad-fl{margin-top:10px}.stad-msg{margin:6px 0;padding:8px 10px;border-radius:10px;background:color-mix(in srgb,var(--bad,#c2410c) 9%,transparent);word-break:break-word}
.stad-ctx{max-height:50vh;overflow:auto;display:flex;flex-direction:column;gap:6px}.stad-cm{padding:6px 10px;border-radius:10px;background:color-mix(in srgb,var(--pri) 7%,transparent)}.stad-cm.hit{outline:2px solid var(--bad,#c2410c)}`;
css.textContent+=`.askbx p,.askbx .stad-chk{margin:6px 0}body[data-adm="1"] header{background:linear-gradient(135deg,#0f172a,#1e3a8a 55%,#0e7490)!important;border-radius:0 0 22px 22px;padding:10px 14px;flex-wrap:nowrap;gap:8px;box-shadow:0 4px 18px #0004}
body[data-adm="1"] header b{font-size:17px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;display:flex;align-items:center;gap:8px}
body[data-adm="1"] header b .x23chip{display:none}
body[data-adm="1"] #hx{display:flex;gap:6px;align-items:center;flex:none}
body[data-adm="1"] #hx>button{display:none!important}
body[data-adm="1"] #hx>button.bl,body[data-adm="1"] #hx>button.stad-out,body[data-adm="1"] #hx>button[aria-label*="الثيم"],body[data-adm="1"] #hx>button[aria-label*="المظهر"]{display:inline-flex!important;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border-radius:12px;font-size:18px;position:relative}
#stad-dock{position:fixed;bottom:0;inset-inline:0;z-index:20;display:flex;background:var(--card,#fff);border-top:1px solid var(--bd,#ddd);padding:6px 6px calc(6px + env(safe-area-inset-bottom,0px));box-shadow:0 -4px 18px #0002}
#stad-dock button{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;background:none;border:0;color:var(--mut,#667);font:inherit;padding:5px 0;border-radius:12px;cursor:pointer}
#stad-dock button span{font-size:21px;position:relative;line-height:1}#stad-dock button small{font-size:11px}
#stad-dock button.on{color:var(--pri);background:color-mix(in srgb,var(--pri) 11%,transparent);font-weight:700}
#stad-dock em{position:absolute;top:-5px;inset-inline-end:-9px;background:#ef4444;color:#fff;border-radius:9px;font-size:10px;padding:1px 5px;font-style:normal}
body[data-adm="1"] #app{padding-bottom:92px}
body[data-adm="1"] .stn-chips:not(.sm){flex-wrap:wrap;overflow:visible}
body[data-adm="1"] .st-admbar,.x23mem{display:none!important}body[data-adm="1"] header button[onclick*="S.me=null"]{display:none}.stad-out{border:1px solid #fff8;background:transparent;color:#fff;border-radius:999px;padding:4px 12px;font-family:inherit;cursor:pointer}
.stad-bn{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 14px;border-radius:12px;margin-bottom:12px;font-weight:600}.stad-bn button{border:0;background:none;color:inherit;font-size:16px;cursor:pointer}.stad-bn.info{background:#dbeafe;color:#1e3a8a}.stad-bn.ok{background:#dcfce7;color:#14532d}.stad-bn.warn{background:#ffedd5;color:#7c2d12}
.stad-impbar{position:fixed;top:0;inset-inline:0;z-index:9998;background:#b91c1c;color:#fff;display:flex;justify-content:center;align-items:center;gap:12px;padding:6px 10px;font-weight:700}.stad-impbar button{border:0;border-radius:999px;padding:4px 12px;font-family:inherit;font-weight:700;cursor:pointer}
.stad-off{position:fixed;bottom:0;inset-inline:0;z-index:9997;background:#334155;color:#fff;text-align:center;padding:6px;font-size:14px}.stad-vt{margin:6px 0}.stad-vt .mut{font-size:12px}`;
document.head.append(css);

/* ===== مراقبة مباشرة (بتتحدّث لوحدها كل ما توصل بيانات جديدة من المنصة) ===== */
function liveCard(){
  const now=Date.now(),h1=now-HR,d1=now-DAY,online=typeof ONLINE!=='undefined'&&!!ONLINE;
  const s24=S.s.filter(x=>(x.d||0)>=d1).length,m1=S.m.filter(x=>(x.d||0)>=h1).length;
  const un=S.n.filter(n=>n.to===S.me&&!n.r).length,sup=window.stSupN?window.stSupN():0;
  return `<div class="card stad-live"><div class="row" style="justify-content:space-between;align-items:center"><b><i class="stad-pulse ${online?'on':''}"></i> مراقبة مباشرة</b><span class="tag ${online?'ok':'warn'}">${online?'المزامنة متصلة':'غير متصلة'}</span></div>
  <div class="st-tiles">${tile('✅','تسليمات آخر 24 ساعة',s24)}${tile('💬','رسائل آخر ساعة',m1)}${tile('🎧','دعم ينتظر الرد',sup)}${tile('🔔','إشعارات لك',un)}</div>
  <small class="mut">بتتحدّث تلقائياً مع المنصة · آخر تحديث ${new Date().toLocaleTimeString('ar-EG')}</small></div>`;
}
const liveSig=()=>[S.u.length,S.g.length,S.e.length,S.s.length,S.m.length,S.n.length,(S.sp||[]).length,(S.sup||[]).length,(S.sm||[]).length,(S.cf||[]).length,typeof ONLINE!=='undefined'&&ONLINE?1:0].join('.');
let LSIG='';
setInterval(()=>{try{
  if(!isAdm()||V.p!=='stadm'||document.hidden)return;
  if(document.activeElement&&document.activeElement.matches&&document.activeElement.matches('input,textarea,select'))return;
  if(document.querySelector('.askbg,#stad-ov'))return;
  const sg=liveSig();if(sg!==LSIG){LSIG=sg;rb()}
}catch(e){}},4000);

/* ===== حذف جميع بيانات المستخدمين من السيرفر ===== */
const WIPE_PATHS=['/db.json','/files.json','/pq.json','/fcm.json'];
function wipeCounts(){
  return [['👥','حسابات',S.u.filter(u=>u.role!=='admin').length],['📚','مجموعات',S.g.length],['📝','امتحانات',S.e.length],
          ['✅','تسليمات',S.s.length],['💬','رسائل',S.m.length],['🔔','إشعارات',S.n.length],
          ['🌐','منشورات',(S.p||[]).length],['📰','أخبار',(S.nw||[]).length],['🎧','تذاكر دعم',(S.sup||[]).length],['💳','طلبات اشتراك',(S.sp||[]).length]];
}
function tabDz(){
  const wc=wipeCounts();
  return `<div class="card stad-danger"><h3>🧨 حذف جميع بيانات المستخدمين</h3>
  <p>بيمسح <b>كل</b> حاجة على السيرفر نهائياً: الحسابات، المجموعات، الامتحانات، التسليمات، الرسائل، الإشعارات، الملفات، التذاكر، الإعدادات… وبعدها المنصة بتبدأ من الصفر.</p>
  <div class="st-tiles">${wc.slice(0,4).map(x=>tile(x[0],x[1],x[2])).join('')}</div>
  <div class="st-tiles">${wc.slice(4,8).map(x=>tile(x[0],x[1],x[2])).join('')}</div>
  <p class="mut">هتظهرلك رسالة تأكيد أولاً، ولازم توافق صراحةً قبل ما يبدأ الحذف. الأحسن تاخد نسخة احتياطية قبلها.</p>
  <div class="row" style="flex-wrap:wrap"><button class="b s" onclick="stA.bk()">⬇️ نسخة احتياطية الأول</button><button class="b r" onclick="stAP.wipe()">🧨 حذف كل البيانات من السيرفر</button></div></div>`;
}
async function delPath(p){
  const r=await fetch(withAuth(DB+p),{method:'DELETE'});
  if(!r.ok)throw new Error(p+' ← HTTP '+r.status);
}
async function wipeServer(){
  await AUTH_READY;
  try{for(const p of WIPE_PATHS)await delPath(p)}
  catch(e){
    /* لو قواعد Firebase مانعة الحذف من الجذر، نحذف كل مجموعة لوحدها */
    const cols=[...new Set([...COLS,'sup','sm'])];
    for(const c of cols)await delPath('/db/'+c+'.json');
    for(const p of WIPE_PATHS.slice(1)){try{await delPath(p)}catch(x){}}
  }
  /* تحقق إن السيرفر فعلاً فاضي */
  const checks=await Promise.all([...new Set([...COLS,'sup','sm'])].map(async c=>{try{const r=await fetch(withAuth(DB+'/db/'+c+'.json'));if(!r.ok)return false;const d=await r.json();return !d||!Object.keys(d).length}catch(e){return false}}));
  if(checks.some(x=>!x))throw new Error('تعذّر التحقق من حذف البيانات من الخادم');
}
function resetLocal(){
  COLS.forEach(c=>{S[c]=[]});
  S.rd={};S.n=[];S.pl=[];
  BASE={};
  try{Object.keys(localStorage).filter(k=>/^st_(nr|nb)_/.test(k)||k==='stad_imp').forEach(k=>localStorage.removeItem(k))}catch(e){}
  const u=ensureRoot();S.me=u.id;V={p:'stadm'};NS.at='ov';
  try{localStorage.setItem('stp',JSON.stringify(S));localStorage.setItem(BK,JSON.stringify(BASE))}catch(e){}
}
function openWipe(){
  if(!canA()||!isAdm())return;
  const wc=wipeCounts(),total=wc.reduce((a,x)=>a+x[2],0);
  const bg=modal(`<h3 style="color:#dc2626">🧨 تأكيد حذف كل البيانات</h3>
  <p><b>تحذير:</b> هيتم مسح <b>كل بيانات المنصة</b> من السيرفر نهائياً، ومفيش أي طريقة لاسترجاعها بعد كده (إلا من نسخة احتياطية).</p>
  <ul class="stad-wl">${wc.filter(x=>x[2]).map(x=>`<li>${x[0]} ${x[1]}: <b>${x[2]}</b></li>`).join('')||'<li>لا توجد بيانات ظاهرة حالياً</li>'}</ul>
  <label class="stad-chk"><input type="checkbox" id="stw-bk" checked> ⬇️ نزّل نسخة احتياطية قبل الحذف</label>
  <label class="stad-chk"><input type="checkbox" id="stw-ok"> أنا فاهم إن الحذف نهائي، وموافق على مسح كل البيانات (${total} عنصر)</label>
  <p class="stad-err" id="stw-st" aria-live="polite"></p>
  <div class="row"><button class="b s" id="stw-x">إلغاء</button><button class="b r" id="stw-go" disabled>🧨 نعم، احذف كل شيء</button></div>`);
  const ok=bg.querySelector('#stw-ok'),go=bg.querySelector('#stw-go'),st=bg.querySelector('#stw-st'),x=bg.querySelector('#stw-x');
  bg.onclick=null; /* مفيش إغلاق بالضغط بره أثناء العملية */
  ok.onchange=()=>{go.disabled=!ok.checked};
  x.onclick=()=>{if(!go.dataset.busy)bg.remove()};
  go.onclick=async()=>{
    if(go.dataset.busy||!ok.checked)return;
    go.dataset.busy='1';go.disabled=true;x.disabled=true;ok.disabled=true;st.style.color='';st.textContent='⏳ جارٍ الحذف من السيرفر…';
    try{
      if(bg.querySelector('#stw-bk').checked){try{window.stA.bk()}catch(e){}}
      await wipeServer();
      resetLocal();
      save();
      try{if(typeof push==='function')await push()}catch(e){}
      bg.remove();R();
      toast('✅ تم حذف كل البيانات من السيرفر');
      const done=modal(`<h3>✅ تم الحذف بنجاح</h3><p>السيرفر دلوقتي فاضي، وكل الأجهزة المفتوحة هتتصفّر تلقائياً خلال ثوانٍ.</p><p class="mut">ملحوظة: حساب الإدارة اتعاد إنشاؤه تلقائياً عشان إشعارات الدعم والاشتراكات تفضل توصلك.</p><div class="row"><button class="b" id="stw-d">تمام</button></div>`);
      done.querySelector('#stw-d').onclick=()=>done.remove();
    }catch(e){
      console.warn('wipe failed',e);
      go.dataset.busy='';go.disabled=false;x.disabled=false;ok.disabled=false;
      st.style.color='#dc2626';st.textContent='❌ فشل الحذف: '+String(e&&e.message||e)+' — راجع قواعد Firebase (Rules) وجرّب تاني.';
    }
  };
}

window.stTabs.dz=tabDz;
if(!ATABS.some(x=>x[0]==='dz'))ATABS.push(['dz','🧨 حذف البيانات']);
Object.assign(window.stAP,{wipe:openWipe});
(()=>{const o=window.stA&&window.stA.mmsg;if(typeof o==='function')window.stA.mmsg=function(){const r=o.apply(this,arguments);try{const v=((document.getElementById('smm')||{}).value||'').trim();const c=cfg('maint')||{};if(c.msg!==v)cset('maint',{msg:v,t:v},'رسالة الصيانة')}catch(e){}return r}})();

try{document.body.dataset.ready='1';R();if(location.hash.indexOf('#admin')===0&&!me())openLogin()}catch(e){console.warn('admin-plus init',e)}
})();
