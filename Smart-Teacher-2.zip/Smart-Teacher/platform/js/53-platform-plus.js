/* Smart Teacher — platform-plus.js
   1) الدعم الفني: زر في الإعدادات لكل المستخدمين (ما عدا الإدارة) — واتساب أو عبر المنصة أو الاثنين، والردود من لوحة الإدارة
   2) صفحة المجتمع: تحكم كامل في الشكل والأقسام والصلاحيات + إشراف على المنشورات
   3) ذاكرة الذكاء الاصطناعي لكل مستخدم بشكل منفصل (ملف المستخدم + معلومات ذكرها + المحادثات السابقة) */
(()=>{
const B=window.__ST;
if(!B){console.warn('platform-plus: bridge missing');return}
const {cfg,setCfg,cset,aud,modal,NS,ATABS,canA,rb}=B;
['sup','sm'].forEach(c=>{if(!COLS.includes(c))COLS.push(c);if(!S[c])S[c]=[]});
const fmtT=t=>t?new Date(t).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'}):'—';
const ad=s=>String(s==null?'':s).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const num=v=>{const n=Number(v);return isFinite(n)&&n>=0?n:0};
const isAdmin=()=>{const m=me();return !!m&&m.role==='admin'};
const ROLE={teacher:'معلم',student:'طالب',parent:'ولي أمر',assistant:'مساعد معلم',admin:'إدارة'};
const sw=(on,fn)=>`<label class="st-switch"><input type="checkbox" ${on?'checked':''} onchange="${fn}"><span></span></label>`;
const dz=(t,d,ctl)=>`<div class="st-dz"><div><b>${t}</b>${d?`<p class="mut">${d}</p>`:''}</div>${ctl}</div>`;
const chips=(arr,cur,fn)=>`<div class="stn-chips sm">${arr.map(a=>`<button class="${String(cur)===String(a[0])?'on':''}" onclick="${fn}('${a[0]}')">${a[1]}</button>`).join('')}</div>`;
const val=id=>{const e=document.getElementById(id);return e?e.value:''};
const hex=c=>/^#[0-9a-fA-F]{6}$/.test(String(c||''))?c:'';

/* ===== عزل بيانات الدعم: كل مستخدم يسحب تذاكره فقط، والإدارة تسحب الكل ===== */
window.stFilt=(c,r)=>{
  if(c!=='sup'&&c!=='sm')return r;
  const m=me();if((m&&m.role==='admin')||sessionStorage.getItem('st_adm')==='1')return r;
  const o={};for(const id in r){if(r[id]&&r[id].u===S.me)o[id]=r[id]}return o;
};

/* ===================== الدعم ===================== */
const SC0={on:1,mode:'both',wa:'',wel:'أهلاً بك 👋 استلمنا رسالتك وهنرد عليك في أقرب وقت.',qr:['أهلاً بك، تم استلام رسالتك وجاري العمل على حلها.','ممكن توضّح المشكلة أكتر أو ترسل صورة للشاشة؟','تم حل المشكلة — لو لسه موجودة قولّي وهساعدك.']};
const sc=()=>{const o=cfg('supc')||{};return Object.assign({},SC0,o,{qr:Array.isArray(o.qr)?o.qr:SC0.qr})};
const SUBJ=['مشكلة تقنية','حسابي','الاشتراك والدفع','اقتراح','شكوى','أخرى'];
const myT=()=>S.sup.filter(t=>t.u===S.me).sort((a,b)=>b.lu-a.lu);
const msgs=id=>S.sm.filter(x=>x.tk===id).sort((a,b)=>a.d-b.d);
const unreadUser=()=>myT().filter(t=>t.uu).length;
const supN=()=>S.sup.filter(t=>t.au&&t.st==='open').length;
window.stSupN=supN;
const admins=()=>S.u.filter(u=>u.role==='admin');
let LASTSEND=0,UV={tid:null,draft:'',subj:SUBJ[0],body:''};
const waLink=()=>{const c=sc(),m=me();if(!c.wa)return '';return 'https://wa.me/'+c.wa+'?text='+encodeURIComponent(`مرحباً، أنا ${m?m.name:''} (${m?ROLE[m.role]||'':''}) وعندي استفسار:\n`)};
const bubble=x=>`<div class="stsup-b ${x.f==='u'?'me':'ot'}${x.auto?' auto':''}"><div>${esc(x.t).replace(/\n/g,'<br>')}</div><small>${x.f==='a'?'🎧 الدعم · ':''}${fmtT(x.d)}</small></div>`;

function userOv(){
  let ov=document.getElementById('stsup-ov');
  if(!ov){ov=document.createElement('div');ov.id='stsup-ov';ov.className='stsup-ov';ov.onclick=e=>{if(e.target===ov)closeSup()};document.body.append(ov)}
  return ov;
}
function closeSup(){const o=document.getElementById('stsup-ov');if(o)o.remove();UV.tid=null}
const supSig=()=>UV.tid+'|'+myT().map(t=>t.id+t.lu+t.st+t.uu).join(',')+'|'+(UV.tid?msgs(UV.tid).length:0);
function drawSup(soft){
  const ov=document.getElementById('stsup-ov');if(!ov||!S.me)return;
  const sg=supSig();if(soft===true&&ov.dataset.sig===sg)return;ov.dataset.sig=sg;
  const c=sc(),t=UV.tid?S.sup.find(x=>x.id===UV.tid&&x.u===S.me):null;
  if(t){
    if(t.uu){t.uu=0;save()}
    ov.innerHTML=`<div class="stsup-bx"><div class="row"><button class="b s" id="stsup-bk">→ رجوع</button><b>${esc(t.s)}</b><button class="b s" id="stsup-x">✕</button></div>
      <div class="stsup-th" id="stsup-th">${msgs(t.id).map(bubble).join('')}</div>
      ${t.st==='open'?`<div class="row"><textarea id="stsup-r" rows="2" maxlength="1000" placeholder="اكتب ردك…">${esc(UV.draft)}</textarea><button class="b" id="stsup-s">إرسال</button></div>`:`<p class="mut" style="text-align:center">🔒 المحادثة مغلقة <button class="b s" id="stsup-re">إعادة فتح</button></p>`}</div>`;
    const th=ov.querySelector('#stsup-th');if(th)th.scrollTop=1e9;
    ov.querySelector('#stsup-bk').onclick=()=>{UV.tid=null;UV.draft='';drawSup()};
    const r=ov.querySelector('#stsup-r');if(r)r.oninput=()=>{UV.draft=r.value};
    const s=ov.querySelector('#stsup-s');if(s)s.onclick=()=>userReply(t.id);
    const re=ov.querySelector('#stsup-re');if(re)re.onclick=()=>{t.st='open';t.au=1;t.lu=Date.now();save();drawSup()};
  }else{
    const open=myT();
    ov.innerHTML=`<div class="stsup-bx"><div class="row"><b>🎧 الدعم</b><button class="b s" id="stsup-x">✕</button></div>
      ${c.mode!=='app'&&c.wa?`<a class="b stsup-wa" href="${waLink()}" target="_blank" rel="noopener">📲 تواصل عبر واتساب</a>`:''}
      ${c.mode!=='wa'?`<h4>✍️ رسالة جديدة</h4><select id="stsup-sj">${SUBJ.map(x=>`<option ${UV.subj===x?'selected':''}>${x}</option>`).join('')}</select><textarea id="stsup-n" rows="3" maxlength="1000" placeholder="اشرح مشكلتك أو سؤالك…">${esc(UV.body)}</textarea><button class="b" id="stsup-ns" style="width:100%">إرسال للدعم</button>
      <h4>🗂 رسائلي</h4>${open.length?open.map(x=>`<div class="st-ar stsup-row" data-id="${x.id}"><div class="st-ai"><b>${esc(x.s)}${x.uu?' <span class="tag warn">رد جديد</span>':''}</b><small>${fmtT(x.lu)} · ${x.st==='open'?'مفتوحة':'مغلقة'}</small></div><span>◀</span></div>`).join(''):'<p class="mut">لا توجد رسائل سابقة</p>'}`:''}</div>`;
    const sj=ov.querySelector('#stsup-sj'),n=ov.querySelector('#stsup-n');
    if(sj)sj.onchange=()=>{UV.subj=sj.value};if(n)n.oninput=()=>{UV.body=n.value};
    const ns=ov.querySelector('#stsup-ns');if(ns)ns.onclick=userNew;
    ov.querySelectorAll('.stsup-row').forEach(r=>r.onclick=()=>{UV.tid=r.dataset.id;drawSup()});
  }
  const x=ov.querySelector('#stsup-x');if(x)x.onclick=closeSup;
}
function rateOk(){if(Date.now()-LASTSEND<8000){toast('انتظر ثواني قبل إرسال رسالة أخرى');return false}LASTSEND=Date.now();return true}
function userNew(){
  const m=me();if(!m||m.role==='admin')return;
  const body=(UV.body||'').trim();
  if(body.length<3)return toast('اكتب رسالتك أولاً');
  if(myT().filter(t=>t.st==='open').length>=5)return toast('عندك 5 محادثات مفتوحة — انتظر الرد عليها أولاً');
  if(!rateOk())return;
  const now=Date.now(),t={id:uid(),u:m.id,un:m.name||'',rl:m.role,s:UV.subj||SUBJ[0],st:'open',d:now,lu:now,au:1,uu:1,lr:'u'};
  S.sup.push(t);S.sm.push({id:uid(),tk:t.id,u:m.id,f:'u',t:body.slice(0,1000),d:now});
  const w=sc().wel;if(w)S.sm.push({id:uid(),tk:t.id,u:m.id,f:'a',auto:1,t:w,d:now+1});
  admins().forEach(a=>notify(a.id,`🎧 رسالة دعم جديدة من ${m.name} — ${t.s}`,'supn'+t.id));
  UV.body='';UV.tid=t.id;t.uu=0;save();toast('✅ تم إرسال رسالتك للدعم');drawSup();
}
function userReply(id){
  const m=me(),t=S.sup.find(x=>x.id===id&&x.u===S.me),r=document.getElementById('stsup-r'),v=((r&&r.value)||'').trim();
  if(!t||!v)return;if(!rateOk())return;
  const now=Date.now();S.sm.push({id:uid(),tk:id,u:m.id,f:'u',t:v.slice(0,1000),d:now});
  t.lu=now;t.au=1;t.lr='u';UV.draft='';
  admins().forEach(a=>notify(a.id,`🎧 رد جديد من ${m.name} في الدعم`,'supr'+id));
  save();drawSup();
}
function openSup(id){UV.tid=id||null;userOv();drawSup()}

/* بطاقات الإعدادات (دعم + ذاكرة المساعد) */
function settingsCards(){
  const m=me(),c=sc();if(!m||m.role==='admin')return '';
  const un=unreadUser(),hasApp=c.mode!=='wa',hasWa=c.mode!=='app'&&c.wa;
  let h='';
  if(c.on&&(hasApp||hasWa)){
    h+=`<div class="card" id="stsup-card"><h3>🎧 الدعم</h3><p class="mut">عندك مشكلة أو اقتراح؟ تواصل معنا وهنرد عليك.</p><div class="row" style="flex-wrap:wrap">
      ${hasApp?`<button class="b" onclick="stSup.open()">💬 راسل الدعم${un?` <span class="tag warn">${un} رد</span>`:''}</button>`:''}
      ${hasWa?`<a class="b stsup-wa" href="${waLink()}" target="_blank" rel="noopener">📲 واتساب</a>`:''}</div></div>`;
  }
  const f=((S.aim||{})[m.id]||{}).f||[];
  h+=`<div class="card" id="stai-card"><h3>🧠 ذاكرة المساعد الذكي</h3><p class="mut">المساعد بيفتكر محادثاتك ومعلوماتك أنت بس (على جهازك ومنفصلة عن أي مستخدم تاني).${f.length?` · ${f.length} معلومة محفوظة`:''}</p>${f.length?`<button class="b s" onclick="stAI.clear()">🧹 مسح المعلومات اللي بيفتكرها</button>`:''}</div>`;
  return h;
}
window.stSup={open:openSup};

/* ===== إدارة الدعم ===== */
function tabSup(){
  const c=sc(),sub=NS.ssb||'in';
  return `<div class="stn-chips sm"><button class="${sub==='in'?'on':''}" onclick="stPP.ssb('in')">📥 الرسائل${supN()?' ('+supN()+')':''}</button><button class="${sub==='cf'?'on':''}" onclick="stPP.ssb('cf')">⚙️ الإعدادات</button></div>`+(sub==='cf'?supCfg(c):NS.stk?supThread(NS.stk):supInbox());
}
function supInbox(){
  const f=NS.sf||'open',l=S.sup.filter(t=>f==='all'||(f==='open'?t.st==='open':t.st==='closed')).sort((a,b)=>(b.au?1:0)-(a.au?1:0)||b.lu-a.lu).slice(0,60);
  return `<div class="stn-chips sm">${[['open','مفتوحة'],['closed','مغلقة'],['all','الكل']].map(x=>`<button class="${f===x[0]?'on':''}" onclick="stPP.sf('${x[0]}')">${x[1]}</button>`).join('')}</div>`+
    (l.length?l.map(t=>{const last=msgs(t.id).slice(-1)[0]||{};return `<div class="st-ar stsup-row" onclick="stPP.sopen('${t.id}')"><div class="st-ai"><b>${t.au?'🔴 ':''}${esc(t.un||'—')} <small class="mut">${ROLE[t.rl]||''}</small></b><small>${esc(t.s)} · ${esc(String(last.t||'').slice(0,60))} · ${fmtT(t.lu)}</small></div><span>${t.st==='open'?'🟢':'🔒'}</span></div>`}).join(''):'<p class="mut">لا توجد رسائل دعم.</p>');
}
function supThread(id){
  const t=S.sup.find(x=>x.id===id);if(!t){NS.stk=null;return supInbox()}
  if(t.au){t.au=0;save()}
  const c=sc();
  return `<div class="row"><button class="b s" onclick="stPP.sopen('')">→ رجوع</button><b>${esc(t.un)} · ${esc(t.s)}</b></div><small class="mut">${ROLE[t.rl]||''} · ${t.st==='open'?'مفتوحة':'مغلقة'}</small>
  <div class="stsup-th" id="stsup-ath">${msgs(id).map(bubble).join('')}</div>
  <div class="stn-chips sm">${c.qr.map((q,i)=>`<button onclick="stPP.qr(${i})">${esc(q.slice(0,28))}</button>`).join('')}</div>
  <textarea id="stsup-ar" rows="2" maxlength="1000" placeholder="اكتب الرد…"></textarea>
  <div class="row" style="flex-wrap:wrap"><button class="b" onclick="stPP.sreply('${id}')">📨 إرسال الرد</button><button class="b s" onclick="stPP.stog('${id}')">${t.st==='open'?'🔒 إغلاق':'🔓 إعادة فتح'}</button><button class="b r" onclick="stPP.sdel('${id}')">🗑 حذف</button></div>`;
}
function supCfg(c){
  return `${dz('إظهار زر الدعم للمستخدمين','في صفحة الإعدادات لكل الحسابات ما عدا الإدارة',sw(c.on,`stPP.sset('on',this.checked?1:0)`))}
  <h4>📡 طريقة الدعم</h4>${chips([['both','الاثنين'],['app','عبر المنصة فقط'],['wa','واتساب فقط']],c.mode,'stPP.smode')}
  <label class="fl"><span>رقم واتساب الدعم</span><input id="stsup-wa" dir="ltr" placeholder="01XXXXXXXXX" value="${esc(c.wa?'0'+c.wa.slice(2):'')}"></label>
  <label class="fl"><span>رسالة ترحيب تلقائية بعد إرسال الرسالة</span><textarea id="stsup-wel" rows="2" maxlength="200">${esc(c.wel)}</textarea></label>
  <label class="fl"><span>ردود سريعة (كل رد في سطر)</span><textarea id="stsup-qr" rows="4">${esc(c.qr.join('\n'))}</textarea></label>
  <button class="b" onclick="stPP.ssave()">💾 حفظ إعدادات الدعم</button>`;
}

/* ===================== المجتمع ===================== */
const CM0={title:'',sub:'',tabs:{all:1,fol:1,hot:1,find:1,rank:1},acc:'',bg:'none',rad:0,dens:'normal',maxlen:1000,img:1,cm:1,lk:1,sh:1,cool:5,roles:{teacher:1,student:1,assistant:1,parent:1},ban:[],pin:'',rules:''};
const cm=()=>{const o=cfg('socs')||{};return Object.assign({},CM0,o,{tabs:Object.assign({},CM0.tabs,o.tabs||{}),roles:Object.assign({},CM0.roles,o.roles||{}),ban:Array.isArray(o.ban)?o.ban:[]})};
const TABN={all:'🌐 الجميع',fol:'👥 المتابَعون',hot:'🔥 الأكثر تفاعلاً',find:'🔍 اكتشف',rank:'🏆 الشرف'};
let POSTQ=0;
function tabCm(){
  const c=cm(),posts=S.f.slice().sort((a,b)=>b.d-a.d).slice(0,25);
  return `<div class="row" style="flex-wrap:wrap"><button class="b" onclick="go('soc')">👁 فتح صفحة المجتمع</button><button class="b s" onclick="stPP.cmreset()">↩ الإعدادات الأصلية</button></div>
  <h4>✏️ العنوان والنصوص</h4><div class="row"><label class="fl"><span>عنوان الصفحة</span><input id="stcm-t" value="${esc(c.title)}" placeholder="🌐 المجتمع"></label><label class="fl"><span>جملة تحت العنوان</span><input id="stcm-s" value="${esc(c.sub)}" placeholder="اختياري"></label></div>
  <label class="fl"><span>📌 إعلان مثبّت أعلى الصفحة</span><textarea id="stcm-p" rows="2" maxlength="300">${esc(c.pin)}</textarea></label>
  <label class="fl"><span>📜 قواعد المجتمع (تظهر للجميع)</span><textarea id="stcm-r" rows="2" maxlength="300">${esc(c.rules)}</textarea></label>
  <h4>🎨 الشكل والتصميم</h4>
  <div class="row"><label class="fl"><span>لون مميز</span><input type="color" id="stcm-a" value="${hex(c.acc)||'#4f46e5'}"></label><label class="fl"><span>استدارة الكروت (0 = الافتراضي)</span><input id="stcm-rad" type="number" min="0" max="40" value="${c.rad}"></label></div>
  <p class="mut">الخلفية</p>${chips([['none','افتراضية'],['soft','هادئة'],['grad','متدرجة']],c.bg,'stPP.cmbg')}<p class="mut">الكثافة</p>${chips([['normal','عادية'],['compact','مضغوطة'],['roomy','مريحة']],c.dens,'stPP.cmdens')}
  <div class="row"><button class="b s" onclick="stPP.cmclr()">إلغاء اللون المميز</button></div>
  <h4>🧭 التبويبات</h4>${Object.keys(TABN).map(k=>dz(TABN[k],'',sw(c.tabs[k],`stPP.cmtab('${k}',this.checked)`))).join('')}
  <h4>⚙️ الصلاحيات والتفاعل</h4>${dz('الإعجاب 👍','',sw(c.lk,`stPP.cmtog('lk',this.checked)`))}${dz('التعليقات 💬','',sw(c.cm,`stPP.cmtog('cm',this.checked)`))}${dz('المشاركة 🔁','',sw(c.sh,`stPP.cmtog('sh',this.checked)`))}${dz('رفع الصور في المنشورات 🖼️','',sw(c.img,`stPP.cmtog('img',this.checked)`))}
  <p class="mut">من يقدر ينشر؟</p>${[['teacher','👨‍🏫 المعلمون'],['student','🎓 الطلاب'],['assistant','🧑‍🏫 المساعدون']].map(r=>dz(r[1],'',sw(c.roles[r[0]],`stPP.cmrole('${r[0]}',this.checked)`))).join('')}
  <div class="row"><label class="fl"><span>أقصى طول للمنشور</span><input id="stcm-ml" type="number" min="50" max="1000" value="${c.maxlen}"></label><label class="fl"><span>ثواني بين المنشورات (5 فأكثر)</span><input id="stcm-cd" type="number" min="5" max="600" value="${c.cool}"></label></div>
  <button class="b" onclick="stPP.cmsave()">💾 حفظ تصميم المجتمع</button>
  <h4>🛡️ إشراف على المنشورات (آخر ${posts.length})</h4>${c.ban.length?`<p class="mut">ممنوعون من النشر: ${c.ban.map(id=>esc((U(id)||{}).name||'؟')).join('، ')}</p>`:''}
  ${posts.length?posts.map(p=>{const u=U(p.u)||{},lk=S.fl.filter(x=>x.p===p.id).length,cn=S.fc.filter(x=>x.p===p.id).length,bn=c.ban.includes(p.u);
    return `<div class="card stcm-post"><div class="row"><b>${esc(u.name||'؟')} <small class="mut">${ROLE[u.role]||''}</small></b><small class="mut">${fmtT(p.d)}</small></div><div class="stad-msg">${p.rp?'🔁 مشاركة منشور':esc(String(p.t||'').slice(0,160))||(p.im?'🖼️ صورة':'')}</div><small class="mut">👍 ${lk} · 💬 ${cn}</small>
    <div class="row" style="flex-wrap:wrap;margin-top:6px"><button class="b r" onclick="stPP.pdel('${p.id}')">🗑 حذف</button>${cn?`<button class="b s" onclick="stPP.pcm('${p.id}')">💬 التعليقات</button>`:''}<button class="b s" onclick="stPP.pban('${p.u}')">${bn?'✅ رفع المنع':'🚫 منع من النشر'}</button></div></div>`}).join(''):'<p class="mut">لا توجد منشورات</p>'}`;
}
const cmCSS=()=>{
  const c=cm();let css='';
  const sel='[data-pg="soc"],[data-pg="prof"]';
  const a=hex(c.acc);
  if(a)css+=`${sel}{--pri:${a};--pri2:${a}}`;
  if(c.rad>0)css+=`[data-pg="soc"] .card,[data-pg="prof"] .card{border-radius:${Math.min(40,c.rad)}px}`;
  if(c.bg==='soft')css+=`[data-pg="soc"]{background:color-mix(in srgb,var(--pri) 7%,var(--bg));border-radius:16px;padding:8px}`;
  if(c.bg==='grad')css+=`[data-pg="soc"]{background:linear-gradient(160deg,color-mix(in srgb,var(--pri) 14%,var(--bg)),var(--bg));border-radius:16px;padding:8px}`;
  if(c.dens==='compact')css+=`[data-pg="soc"] .card,[data-pg="prof"] .card{padding:8px 10px;margin-top:8px}`;
  if(c.dens==='roomy')css+=`[data-pg="soc"] .card,[data-pg="prof"] .card{padding:20px;margin-top:18px}`;
  if(!c.lk)css+='[onclick*="socLike("]{display:none!important}';
  if(!c.cm)css+='[onclick*="socCm("],[onclick*="socCmt("],[id^="ci"]{display:none!important}';
  if(!c.sh)css+='[onclick*="socShare("]{display:none!important}';
  if(!c.img)css+='label:has([onchange*="socImg("]){display:none!important}';
  return css;
};
function applyCm(app){
  const c=cm(),pg=V.p;
  let st=document.getElementById('stcm-css');if(!st){st=document.createElement('style');st.id='stcm-css';document.head.append(st)}
  const css=cmCSS();if(st.textContent!==css)st.textContent=css;
  if(app&&(pg==='soc'||pg==='prof')){
    app.querySelectorAll('[onclick*="socFol(\'admroot\')"]').forEach(b=>{const c=b.closest('.card');if(c)c.remove()});
    if(pg==='prof'&&ST.uid==='admroot'){const pl=app.querySelector('.pfh .pill');if(pl&&pl.textContent!=='🛡️ الإدارة')pl.textContent='🛡️ الإدارة'}
  }
  if(pg!=='soc'||!app)return;
  const h=app.querySelector('h2');
  if(h&&c.title&&h.textContent!==c.title)h.textContent=c.title;
  const tabs=app.querySelector('.tabs');
  if(tabs){
    tabs.querySelectorAll('button').forEach(b=>{const m=(b.getAttribute('onclick')||'').match(/ST\.tab='(\w+)'/);if(m&&c.tabs[m[1]]===0)b.style.display='none'});
    if(c.tabs[ST.tab]===0){const f=Object.keys(TABN).find(k=>c.tabs[k]!==0);if(f&&f!==ST.tab&&!window.__cmFix){window.__cmFix=1;ST.tab=f;setTimeout(()=>{window.__cmFix=0;R()},0)}}
    if(!app.querySelector('.stcm-top')){
      let x='';
      if(c.sub)x+=`<p class="mut">${esc(c.sub)}</p>`;
      if(c.pin)x+=`<div class="card stcm-pin">📌 ${esc(c.pin)}</div>`;
      if(c.rules)x+=`<div class="card stcm-rules">📜 ${esc(c.rules)}</div>`;
      if(x){const d=document.createElement('div');d.className='stcm-top';d.innerHTML=x;tabs.after(d)}
    }
  }
}
/* تطبيق الصلاحيات على الإجراءات (الإدارة مستثناة) */
const wrapW=(n,fn)=>{const o=window[n];if(typeof o==='function')window[n]=fn(o)};
const gate=(key,msg)=>o=>function(){const m=me();if(m&&m.role!=='admin'&&!cm()[key]){toast(msg);return}return o.apply(this,arguments)};
wrapW('socLike',gate('lk','الإعجاب متوقف حالياً'));wrapW('socCmt',gate('cm','التعليقات متوقفة حالياً'));wrapW('socShare',gate('sh','المشاركة متوقفة حالياً'));
let LASTPOST=0;
wrapW('socPost',o=>function(){
  const c=cm(),m=me();
  if(m&&m.role!=='admin'){
    if(c.ban.includes(m.id)){toast('🚫 تم منعك من النشر من قبل الإدارة');return}
    if(m.role!=='parent'&&c.roles[m.role]===0){toast('النشر غير متاح لنوع حسابك حالياً');return}
    if(Date.now()-LASTPOST<c.cool*1000){toast('انتظر قليلاً قبل النشر مرة أخرى');return}
  }
  try{ST.draft=String(ST.draft||'').slice(0,c.maxlen);if(!c.img)ST.img=null}catch(e){}
  LASTPOST=Date.now();return o.apply(this,arguments);
});

/* ===================== ذاكرة الذكاء الاصطناعي لكل مستخدم ===================== */
const AIM=()=>{S.aim=S.aim||{};return S.aim[S.me]=S.aim[S.me]||{f:[]}};
const FACT=/(اسمي|اسمى|انا في|أنا في|انا بدرس|أنا بدرس|بدرس|في الصف|في سنة|بحب|أحب|احب|مش فاهم|صعب عليا|صعبة عليا|بذاكر|عندي امتحان|هدفي|عايز أبقى|عايز ابقى|اتذكر|تذكر|افتكر|مادتي|ضعيف في)/;
function learn(q){
  const m=me();if(!m)return;const o=AIM();
  String(q).split(/[.\n!؟?،]+/).map(x=>x.trim()).filter(x=>x.length>=6&&x.length<=160&&FACT.test(x)).forEach(x=>{
    if(!o.f.some(y=>y.t===x))o.f.push({t:x,d:Date.now()});
  });
  o.f=o.f.slice(-25);
}
function profileTxt(u){
  const L=[`الاسم: ${u.name||'—'}`,`نوع الحساب: ${ROLE[u.role]||u.role}`];
  if(u.sj)L.push('المادة/الصف: '+u.sj);
  try{
    if(u.role==='student'){
      const gs=S.g.filter(g=>g.st.some(x=>x.u===u.id&&x.s==='ok')).slice(0,6).map(g=>g.title);
      if(gs.length)L.push('مجموعاته: '+gs.join('، '));
      const ss=S.s.filter(s=>s.u===u.id).map(s=>{const e=E(s.e);return e?{n:e.name,p:score(e,s)}:null}).filter(Boolean);
      if(ss.length){const av=Math.round(ss.reduce((a,b)=>a+b.p,0)/ss.length);L.push(`امتحانات: ${ss.length} · المتوسط ${av}%`);const w=ss.slice().sort((a,b)=>a.p-b.p).slice(0,2);if(w[0]&&w[0].p<70)L.push('أضعف نتائجه: '+w.map(x=>`${x.n} (${x.p}%)`).join('، '))}
    }else if(u.role==='teacher'){
      const gs=S.g.filter(g=>g.t===u.id);L.push(`مجموعاته: ${gs.length} · طلابه: ${gs.reduce((a,g)=>a+g.st.length,0)} · امتحاناته: ${S.e.filter(e=>gs.some(g=>g.id===e.g)).length}`);
    }
  }catch(e){}
  return L.join('\n');
}
const words=s=>String(s||'').toLowerCase().replace(/[\u064B-\u0652ـ]/g,'').replace(/[^\p{L}\p{N}\s]/gu,' ').split(/\s+/).filter(w=>w.length>=3);
function memText(){
  const u=me();if(!u)return '';
  const o=AIS(),cur=o.c.find(x=>x.id===o.cur),qm=cur?cur.ms.slice().reverse().find(x=>x.r==='u'):null,q=qm?qm.t:'';
  let t='[ذاكرة خاصة بهذا المستخدم وحده — لا تخلطها ببيانات أي شخص آخر]\n'+profileTxt(u).slice(0,700);
  const f=(AIM().f||[]).map(x=>'- '+x.t).join('\n').slice(0,700);if(f)t+='\nمعلومات ذكرها بنفسه:\n'+f;
  const others=o.c.filter(x=>x.id!==o.cur).sort((a,b)=>b.d-a.d).slice(0,6).map(x=>{const fu=x.ms.find(m=>m.r==='u');return `- «${x.t}» (${x.ms.length} رسالة): ${String(fu?fu.t:'').slice(0,70)}`}).join('\n').slice(0,900);
  if(others)t+='\nمحادثاته السابقة:\n'+others;
  const qw=new Set(words(q));
  if(qw.size){
    const cand=[];
    o.c.forEach(c=>{const lim=c.id===o.cur?Math.max(0,c.ms.length-30):c.ms.length;for(let i=0;i<lim;i++){const m=c.ms[i];if(m.r!=='u')continue;const a=c.ms[i+1];const w=words(m.t);let s=0;w.forEach(x=>{if(qw.has(x))s++});if(s>=Math.min(2,qw.size))cand.push({s,txt:`س: ${String(m.t).slice(0,140)} | ج: ${String(a&&a.r==='a'?a.t:'').slice(0,200)}`})}});
    const top=cand.sort((a,b)=>b.s-a.s).slice(0,3).map(x=>'- '+x.txt).join('\n').slice(0,1000);
    if(top)t+='\nمقتطفات قديمة قد تفيد في سؤاله الحالي:\n'+top;
  }
  return t;
}
function memMsgs(){
  const t=memText();if(!t)return [];const out=[];
  for(let i=0;i<t.length;i+=1400){out.push({role:'user',content:t.slice(i,i+1400)},{role:'assistant',content:'تمام، سأستخدم هذه المعلومات الخاصة بهذا المستخدم فقط.'})}
  return out;
}
(()=>{const h=window.aiHist;if(typeof h==='function')window.aiHist=function(){const base=h.apply(this,arguments);try{return memMsgs().concat(base)}catch(e){return base}}})();
(()=>{const s=window.aiSend;if(typeof s==='function')window.aiSend=function(){try{const q=(document.getElementById('aiq')||{}).value||'';if(q.trim())learn(q)}catch(e){}return s.apply(this,arguments)}})();
window.stAI={clear(){const m=me();if(!m)return;if(S.aim&&S.aim[m.id])S.aim[m.id].f=[];cache();toast('تم مسح المعلومات المحفوظة');R()}};

/* ===================== ربط الأزرار الإدارية ===================== */
const save2=()=>{save();rb()};
window.stPP={
  ssb(v){NS.ssb=v;NS.stk=null;rb()},sf(v){NS.sf=v;rb()},
  sopen(id){NS.stk=id||null;rb()},
  qr(i){const t=document.getElementById('stsup-ar');if(t)t.value=(t.value?t.value+'\n':'')+sc().qr[i]},
  sreply(id){if(!canA())return;const t=S.sup.find(x=>x.id===id),r=document.getElementById('stsup-ar'),v=((r&&r.value)||'').trim();if(!t||!v)return toast('اكتب الرد أولاً');
    const now=Date.now();S.sm.push({id:uid(),tk:id,u:t.u,f:'a',t:v.slice(0,1000),d:now});t.lu=now;t.uu=1;t.lr='a';t.st='open';t.au=0;
    notify(t.u,`🎧 رد جديد من الدعم على «${t.s}»`,'supa'+id+now);aud('رد على دعم '+(t.un||''));toast('✅ تم إرسال الرد');save2()},
  stog(id){if(!canA())return;const t=S.sup.find(x=>x.id===id);if(!t)return;t.st=t.st==='open'?'closed':'open';t.lu=Date.now();t.uu=1;save2()},
  sdel(id){if(!canA())return;const bg=modal('<h3>🗑 حذف المحادثة؟</h3><p class="mut">سيتم حذفها نهائياً.</p><div class="row"><button class="b s" id="stsx">إلغاء</button><button class="b r" id="stso">حذف</button></div>');
    bg.querySelector('#stsx').onclick=()=>bg.remove();bg.querySelector('#stso').onclick=()=>{bg.remove();S.sup=S.sup.filter(x=>x.id!==id);S.sm=S.sm.filter(x=>x.tk!==id);NS.stk=null;save2();toast('تم الحذف')}},
  sset(k,v){if(!canA())return;cset('supc',{[k]:v},'إعدادات الدعم');rb();R()},
  smode(v){if(!canA())return;cset('supc',{mode:v},'طريقة الدعم: '+v);rb();R()},
  ssave(){if(!canA())return;let wa=ad(val('stsup-wa')).replace(/\D/g,'');if(wa&&!/^(0)?1[0125]\d{8}$/.test(wa)&&!/^201[0125]\d{8}$/.test(wa))return toast('رقم واتساب غير صحيح');
    if(wa.startsWith('0'))wa='20'+wa.slice(1);else if(wa&&!wa.startsWith('20'))wa='20'+wa;
    cset('supc',{wa,wel:val('stsup-wel').trim().slice(0,200),qr:val('stsup-qr').split('\n').map(x=>x.trim()).filter(Boolean).slice(0,12)},'حفظ إعدادات الدعم');toast('✅ تم الحفظ');rb();R()},
  /* المجتمع */
  cmtab(k,on){if(!canA())return;cset('socs',{tabs:Object.assign({},cm().tabs,{[k]:on?1:0})},'تبويبات المجتمع');rb();R()},
  cmtog(k,on){if(!canA())return;cset('socs',{[k]:on?1:0},'تفاعل المجتمع: '+k);rb();R()},
  cmrole(k,on){if(!canA())return;cset('socs',{roles:Object.assign({},cm().roles,{[k]:on?1:0})},'صلاحيات النشر');rb()},
  cmbg(v){if(!canA())return;cset('socs',{bg:v},'خلفية المجتمع');rb();R()},
  cmdens(v){if(!canA())return;cset('socs',{dens:v},'كثافة المجتمع');rb();R()},
  cmclr(){if(!canA())return;cset('socs',{acc:''},'إلغاء لون المجتمع');rb();R()},
  cmsave(){if(!canA())return;const a=document.getElementById('stcm-a');
    cset('socs',{title:val('stcm-t').trim().slice(0,40),sub:val('stcm-s').trim().slice(0,80),pin:val('stcm-p').trim(),rules:val('stcm-r').trim(),acc:a&&a.dataset.touched?a.value:cm().acc,rad:Math.min(40,Math.floor(num(val('stcm-rad')))),maxlen:Math.max(50,Math.min(1000,Math.floor(num(val('stcm-ml')))||1000)),cool:Math.max(5,Math.min(600,Math.floor(num(val('stcm-cd')))||5))},'تصميم المجتمع');
    toast('✅ تم حفظ تصميم المجتمع');rb();R()},
  cmreset(){if(!canA())return;cset('socs',{title:'',sub:'',tabs:CM0.tabs,acc:'',bg:'none',rad:0,dens:'normal',maxlen:1000,img:1,cm:1,lk:1,sh:1,cool:5,roles:CM0.roles,pin:'',rules:''},'استرجاع إعدادات المجتمع');toast('تم الاسترجاع');rb();R()},
  pdel(id){if(!canA())return;S.f=S.f.filter(x=>x.id!==id);S.fc=S.fc.filter(x=>x.p!==id);S.fl=S.fl.filter(x=>x.p!==id);aud('حذف منشور مجتمع');save2();toast('تم حذف المنشور')},
  pban(uid2){if(!canA())return;const c=cm(),on=c.ban.includes(uid2);cset('socs',{ban:on?c.ban.filter(x=>x!==uid2):[...c.ban,uid2]},on?'رفع منع النشر':'منع من النشر');rb()},
  pcm(id){const l=S.fc.filter(x=>x.p===id).sort((a,b)=>a.d-b.d);
    const bg=modal(`<h3>💬 التعليقات</h3><div class="stsup-th">${l.map(x=>`<div class="stsup-b ot"><div><b>${esc((U(x.u)||{}).name||'؟')}</b>: ${esc(x.t)}</div><small>${fmtT(x.d)} <a href="#" data-c="${x.id}">🗑 حذف</a></small></div>`).join('')||'<p class="mut">لا توجد تعليقات</p>'}</div><div class="row"><button class="b s" id="stsx">إغلاق</button></div>`);
    bg.querySelector('#stsx').onclick=()=>bg.remove();
    bg.querySelectorAll('a[data-c]').forEach(a=>a.onclick=e=>{e.preventDefault();S.fc=S.fc.filter(x=>x.id!==a.dataset.c);save();a.closest('.stsup-b').remove();rb()})}
};
document.addEventListener('input',e=>{if(e.target&&e.target.id==='stcm-a')e.target.dataset.touched='1'},true);

window.stTabs=Object.assign(window.stTabs||{},{sup:tabSup,cm:tabCm});
[['cm','🌐 المجتمع'],['sup','🎧 الدعم']].forEach(t=>{if(!ATABS.some(x=>x[0]===t[0])){const i=ATABS.findIndex(x=>x[0]==='ctl');ATABS.splice(i<0?1:i+1,0,t)}});

/* ===== تغليف R ===== */
const _R=window.R;
let RD=0,RT=[];
window.R=function(){
  const now=Date.now();RT=RT.filter(x=>now-x<1000);
  if(RD>=6||RT.length>=30){console.warn('render guard: skipped');return}
  RT.push(now);RD++;
  try{return rInner.apply(this,arguments)}finally{RD--}
};
function rInner(){
  const r=_R.apply(this,arguments);
  try{
    const app=document.querySelector('#app');
    if(isAdmin()){const t=ATABS.find(x=>x[0]==='sup');if(t)t[1]='🎧 الدعم'+(supN()?' ('+supN()+')':'')}
    applyCm(app);
    if(app&&V.p==='set'&&(!V.t||V.t==='preferences')&&me()&&!isAdmin()&&!app.querySelector('#stsup-card,#stai-card')){const h=settingsCards();if(h)app.insertAdjacentHTML('beforeend',h)}
    if(document.getElementById('stsup-ov')){if(!S.me||isAdmin())closeSup();else drawSup(true)}
  }catch(e){console.warn('platform-plus',e)}
  return r;
};

/* ===== تنسيق ===== */
const css=document.createElement('style');css.id='stpp-css';
css.textContent=`.stsup-ov{position:fixed;inset:0;z-index:9990;background:#0009;display:flex;align-items:flex-end;justify-content:center}
.stsup-bx{width:min(560px,100%);max-height:88vh;overflow:auto;background:var(--card,#fff);color:var(--tx,#111);border-radius:20px 20px 0 0;padding:16px;display:flex;flex-direction:column;gap:10px}
@media(min-width:700px){.stsup-ov{align-items:center}.stsup-bx{border-radius:20px}}
.stsup-bx textarea,.stsup-bx select{width:100%;box-sizing:border-box}.stsup-bx .row textarea{flex:1}
.stsup-th{display:flex;flex-direction:column;gap:8px;max-height:46vh;overflow:auto;padding:4px}
.stsup-b{max-width:84%;padding:8px 12px;border-radius:14px;word-break:break-word}.stsup-b small{display:block;opacity:.6;font-size:11px;margin-top:2px}
.stsup-b.me{align-self:flex-start;background:color-mix(in srgb,var(--pri) 16%,transparent)}.stsup-b.ot{align-self:flex-end;background:color-mix(in srgb,var(--mut,#888) 14%,transparent)}.stsup-b.auto{opacity:.8;font-style:italic}
.stsup-wa{background:#16a34a!important;color:#fff!important;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}.stsup-row{cursor:pointer}
.stcm-pin{border:1.5px solid var(--pri);background:color-mix(in srgb,var(--pri) 8%,var(--card));font-weight:600}.stcm-rules{font-size:14px;opacity:.9}.stcm-post{margin-top:10px}`;
document.head.append(css);

try{R()}catch(e){console.warn('platform-plus init',e)}
})();
