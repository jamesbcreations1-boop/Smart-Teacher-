/* Smart Teacher — platform-ctl.js
   الجزء اللي بينفّذ على المنصة الأساسية كل ما يتغيّر من «إدارة سمارت تيتشر» (الموقع المستقل):
   1) إيقاف/تشغيل الصفحات  2) قيود التسجيل حسب نوع الحساب  3) (الشريط الإعلاني بيتنفّذ من app.js)
   4) عنوان ووصف الموقع    5) إخفاء أقسام صفحة الزوار      6) شاشة الصيانة
   6.5) زرار «محتاج مساعدة؟» للزوار (واتساب/تيليجرام/بريد من بيانات التواصل في الإدارة)
   7) تسجيل أخطاء الأجهزة (بيظهر في لوحة الإدارة)           8) حارس: ممنوع أي جلسة إدارة على المنصة
   الملف ده بيقرأ نفس قاعدة البيانات اللي بتكتب فيها لوحة الإدارة، فالتغييرات بتوصل المنصة تلقائياً مع كل مزامنة. */
(()=>{
const B=window.__ST;
if(!B){console.warn('platform-ctl: bridge missing');return}
const {cfg,setCfg}=B;
const DAY=864e5;
const lab=e=>(e.textContent||'').replace(/\s+/g,' ').trim().slice(0,50);

/* ===== إعدادات «التحكم الكامل» ===== */
const CTL0={off:[],roff:[],bn:{on:0,t:'',c:'info'},sup:{wa:'',tg:'',em:''},ti:'',ds:'',vh:[]};
const ctl=()=>{
  const o=cfg('ctl')||{};
  return Object.assign({},CTL0,o,{
    off:Array.isArray(o.off)?o.off:[],roff:Array.isArray(o.roff)?o.roff:[],vh:Array.isArray(o.vh)?o.vh:[],
    bn:Object.assign({},CTL0.bn,o.bn||{}),sup:Object.assign({},CTL0.sup,o.sup||{})
  });
};

/* ===== حارس: لوحة الإدارة مش جزء من المنصة ===== */
/* (موقع واحد: الأدمن بيدخل من شاشة الدخول العادية، فمفيش حارس بيطلّعه) */
function guard(){return false}

/* ===== تسجيل أخطاء الأجهزة (بتتجمّع عند الإدارة) ===== */
(()=>{
  let n=0,last=0;
  const log=(m,src)=>{
    try{
      m=String(m||'').slice(0,160);
      if(!m||/ResizeObserver|Script error|Non-Error promise/i.test(m))return;
      const now=Date.now();if(n>=3||now-last<20000)return;n++;last=now;
      const u=me(),id='er_'+uid();
      setCfg(id,{t:now,m,s:String(src||'').slice(0,60),p:(typeof V!=='undefined'&&V.p)||'',r:u?u.role:'visitor',ua:String(navigator.userAgent||'').slice(0,60)});
    }catch(e){}
  };
  addEventListener('error',e=>log(e.message,(e.filename||'').split('/').pop()+':'+e.lineno));
  addEventListener('unhandledrejection',e=>log((e.reason&&e.reason.message)||e.reason,'promise'));
})();

/* ===== منع فتح الصفحات الموقوفة + قيود التسجيل ===== */
(()=>{
  const _go=window.go;
  if(typeof _go==='function')window.go=function(p){
    try{if(ctl().off.includes(p)){toast('هذا القسم متوقف مؤقتاً من الإدارة');return _go.call(this,'dash')}}catch(e){}
    return _go.apply(this,arguments);
  };
})();
(()=>{
  const _s=window.signup;
  if(typeof _s==='function')window.signup=function(){
    try{if(ctl().roff.includes(RR)){toast('التسجيل لهذا النوع من الحسابات متوقف حالياً');return}}catch(e){}
    return _s.apply(this,arguments);
  };
})();

/* ===== تغليف R: الصيانة، الإخفاء، العنوان، الشريط ===== */
const _R=window.R;
window.R=function(){
  guard();
  const r=_R.apply(this,arguments);
  try{apply()}catch(e){console.warn('platform-ctl',e)}
  return r;
};

function apply(){
  const m=me(),app=document.querySelector('#app'),bn=document.querySelector('#bn');
  const c=ctl(),mt=cfg('maint')||{},isA=!!m&&m.role==='admin';
  visitorHelp(m);

  /* صيانة — الامتحانات الجارية مش بتتقاطع */
  if(mt.on&&!isA&&V.p!=='exam'&&app){
    if(!document.getElementById('stpc-mt')){
      app.innerHTML=`<section class="card" id="stpc-mt" style="text-align:center;padding:44px 20px"><div style="font-size:56px">🛠️</div><h2>المنصة تحت الصيانة</h2><p class="mut">${esc(mt.msg||mt.t||'بنعمل تحديثات سريعة وهنرجع لك حالاً.')}</p></section>`;
    }
    if(bn)bn.style.display='none';
    return;
  }else if(bn&&bn.style.display==='none'){bn.style.display=''}

  /* إخفاء الصفحات الموقوفة من القوائم */
  let st=document.getElementById('stpc-css');
  if(!st){st=document.createElement('style');st.id='stpc-css';document.head.append(st)}
  const css=isA?'':c.off.map(k=>`[onclick*="go('${k}'"]{display:none!important}`).join('');
  if(st.textContent!==css)st.textContent=css;

  /* عنوان ووصف الموقع */
  if(c.ti&&!isA&&document.title!==c.ti)document.title=c.ti;
  if(c.ds){const md=document.querySelector('meta[name="description"]');if(md&&md.content!==c.ds)md.content=c.ds}

  /* إخفاء أقسام صفحة الزوار */
  if(!m&&app&&c.vh.length)app.querySelectorAll('.card,.x23r').forEach(e=>{if(c.vh.includes(lab(e)))e.style.display='none'});

}


/* ===== زرار الدعم للزوار (مشاكل تسجيل الدخول/إنشاء الحساب) ===== */
const ISSUES=['مش قادر أسجّل دخول','نسيت كلمة المرور','كود التحقق (OTP) مش بيوصل','مشكلة في إنشاء حساب جديد','حسابي موقوف','مشكلة تانية'];
function contacts(){
  const c=ctl().sup||{},s=cfg('supc')||{};
  let wa=String(c.wa||s.wa||'').replace(/\D/g,'');if(wa.startsWith('0'))wa='20'+wa.slice(1);
  return {wa,tg:String(c.tg||'').replace(/^@/,''),em:String(c.em||'')};
}
function visitorHelp(m){
  let b=document.getElementById('stpc-help');
  if(m){if(b)b.remove();const o=document.getElementById('stpc-hov');if(o)o.remove();return}
  if(b)return;
  b=document.createElement('button');b.id='stpc-help';b.type='button';
  b.setAttribute('aria-label','الدعم الفني');b.innerHTML='🎧<span>محتاج مساعدة؟</span>';
  b.onclick=openHelp;document.body.append(b);
}
function openHelp(){
  if(document.getElementById('stpc-hov'))return;
  const k=contacts(),has=k.wa||k.tg||k.em;
  const ov=document.createElement('div');ov.id='stpc-hov';ov.className='stpc-ov';
  ov.onclick=e=>{if(e.target===ov)ov.remove()};
  ov.innerHTML=`<div class="stpc-bx" role="dialog" aria-modal="true"><div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">🎧 الدعم الفني</h3><button class="b s" id="stpc-x" aria-label="إغلاق">✕</button></div>
  <p class="mut">عندك مشكلة في الدخول أو التسجيل؟ اختار المشكلة وابعتها لنا وهنساعدك.</p>
  <div class="stpc-tips"><b>جرّب الأول:</b> تأكد من البريد وكلمة المرور (الحروف الكبيرة والصغيرة) · استخدم «نسيت كلمة المرور» · افحص الإنترنت وحدّث الصفحة.</div>
  <label class="fl"><span>نوع المشكلة</span><select id="stpc-i">${ISSUES.map(x=>`<option>${x}</option>`).join('')}</select></label>
  <label class="fl"><span>اسمك (اختياري)</span><input id="stpc-n" maxlength="60" placeholder="الاسم"></label>
  <label class="fl"><span>بريدك أو رقمك للرد عليك</span><input id="stpc-c" maxlength="80" dir="ltr" placeholder="name@example.com أو 01xxxxxxxxx"></label>
  <label class="fl"><span>تفاصيل (اختياري)</span><textarea id="stpc-d" rows="2" maxlength="400"></textarea></label>
  <div class="stpc-act">${has?'':'<p class="mut">⚠️ وسائل التواصل لسه ماتحددتش من الإدارة.</p>'}
  ${k.wa?'<button class="b" data-w="wa">💬 واتساب</button>':''}${k.tg?'<button class="b s" data-w="tg">✈️ تيليجرام</button>':''}${k.em?'<button class="b s" data-w="em">✉️ بريد إلكتروني</button>':''}</div></div>`;
  document.body.append(ov);
  ov.querySelector('#stpc-x').onclick=()=>ov.remove();
  const val=id=>(ov.querySelector('#'+id).value||'').trim();
  const msg=()=>`مرحباً، عندي مشكلة في منصة المعلم الذكي:\n• المشكلة: ${val('stpc-i')}\n${val('stpc-n')?'• الاسم: '+val('stpc-n')+'\n':''}${val('stpc-c')?'• للتواصل: '+val('stpc-c')+'\n':''}${val('stpc-d')?'• تفاصيل: '+val('stpc-d'):''}`;
  ov.querySelectorAll('[data-w]').forEach(btn=>btn.onclick=()=>{
    const w=btn.dataset.w,m=encodeURIComponent(msg());
    const u=w==='wa'?'https://wa.me/'+k.wa+'?text='+m:w==='tg'?'https://t.me/'+k.tg+'?text='+m:'mailto:'+k.em+'?subject='+encodeURIComponent('مشكلة: '+val('stpc-i'))+'&body='+m;
    window.open(u,w==='em'?'_self':'_blank','noopener');
  });
}
const hcss=document.createElement('style');hcss.id='stpc-hcss';
hcss.textContent=`#stpc-help{position:fixed;inset-inline-start:14px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:950;display:flex;gap:6px;align-items:center;border:0;border-radius:999px;padding:11px 16px;background:var(--pri,#2563eb);color:#fff;font:700 14px inherit;font-family:inherit;box-shadow:0 8px 24px #0004;cursor:pointer}#stpc-help span{font-size:13px}
.stpc-ov{position:fixed;inset:0;z-index:9999;background:#0008;display:flex;align-items:flex-end;justify-content:center}
.stpc-bx{width:min(480px,100%);max-height:92vh;overflow:auto;background:var(--card,#fff);color:var(--tx,#111);border-radius:22px 22px 0 0;padding:18px;box-shadow:0 -10px 40px #0005}
@media(min-width:560px){.stpc-ov{align-items:center}.stpc-bx{border-radius:22px}}
.stpc-tips{background:color-mix(in srgb,var(--pri,#2563eb) 9%,transparent);border-radius:12px;padding:10px 12px;font-size:13px;margin:8px 0}
.stpc-act{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.stpc-act .b{flex:1;min-height:44px}`;
document.head.append(hcss);

try{guard();R()}catch(e){console.warn('platform-ctl init',e)}
})();
