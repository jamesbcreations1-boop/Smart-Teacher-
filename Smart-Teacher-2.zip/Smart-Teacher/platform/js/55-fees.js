/* ==========================================================================
   Smart Teacher — fees.js : نظام تحصيل المصاريف الشهرية
   يتحمّل بعد باقي الملفات (آخر سكريبت في index.html).

   1) الطالب: كود متحرك لكل مجموعة (مثال A49) يتغيّر كل ساعة + صورته الشخصية إجبارية.
   2) المساعد/المدرس: شريط بحث (اسم أو كود أو رقم موبايل) → بطاقة الطالب → زر «تم الدفع».
   3) المدرس: إعدادات المصاريف لكل مجموعة (المبلغ، شهر البداية، السماح للمساعدين).

   البيانات: مجموعة جديدة 'fp' (كل دفعة سجل مستقل id = مجموعة_طالب_شهر → ما فيش تكرار).
   حقول المجموعة الجديدة: fk (مفتاح الأكواد) • fm (المبلغ) • fst (شهر البداية) • fn (1 = المساعدون ممنوعون من التحصيل)

   ⚠️ حدود أمنية صريحة: المنصة بتشتغل من المتصفح بدون سيرفر، فالكود المتحرك + الصورة
   بيمنعوا التداول العادي (كود قديم/سكرين شوت/صديق)، لكن مش بيمنعوا مبرمج بيقرأ القاعدة.
   الحماية الحقيقية = قواعد Firebase + Cloud Function (راجع ملفات firebase/).
   ========================================================================== */
(()=>{
'use strict';
if(typeof S==='undefined'||typeof me!=='function'||typeof G!=='function'){console.warn('fees: core missing');return}
if(!Array.isArray(S.pay))S.pay=[];

/* ---------- أدوات ---------- */
const AR_MO=['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const mk=d=>{d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')};
const mlabel=k=>{const p=String(k||'').split('-');return AR_MO[(+p[1]||1)-1]+' '+p[0]};
const mshift=(k,n)=>{const p=k.split('-'),d=new Date(+p[0],+p[1]-1+n,1);return mk(d)};
const hm=t=>{const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')};
const money=n=>'<bdi>'+(+n||0).toLocaleString('en')+'</bdi> ج.م';
const AD='٠١٢٣٤٥٦٧٨٩';
const nz=s=>String(s||'').toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[٠-٩]/g,d=>AD.indexOf(d)).replace(/\s+/g,' ').trim();
const E=s=>esc(s);
const okImg=v=>/^data:image\/(jpeg|png|webp|gif);base64,/.test(v||'');
const photo=(u,z,cls)=>okImg(u&&u.av)?`<img class="${cls||'fee-ph'}" src="${u.av}" alt="" style="width:${z}px;height:${z}px">`:`<span class="${cls||'fee-ph'} fee-ph0" style="width:${z}px;height:${z}px;font-size:${z/2.2}px">${E((u?u.name:'؟').trim().charAt(0))}</span>`;
const rnd=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return [...a].map(b=>b.toString(36).padStart(2,'0')).join('').slice(0,n)};

/* ---------- SHA-256 متزامن (للكود المتحرك) ---------- */
const K256=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
function sha256(str){
  const b=new TextEncoder().encode(str),l=b.length,n=((l+9+63)>>6)<<6,m=new Uint8Array(n);
  m.set(b);m[l]=0x80;const dv=new DataView(m.buffer);dv.setUint32(n-8,Math.floor(l*8/4294967296));dv.setUint32(n-4,(l*8)>>>0);
  let h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a,h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
  const w=new Uint32Array(64),r=(x,k)=>(x>>>k)|(x<<(32-k));
  for(let o=0;o<n;o+=64){
    for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
    for(let i=16;i<64;i++){const a=w[i-15],c=w[i-2],s0=r(a,7)^r(a,18)^(a>>>3),s1=r(c,17)^r(c,19)^(c>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0}
    let a=h0,bb=h1,c=h2,d=h3,e=h4,f=h5,g=h6,h=h7;
    for(let i=0;i<64;i++){
      const S1=r(e,6)^r(e,11)^r(e,25),ch=(e&f)^(~e&g),t1=(h+S1+ch+K256[i]+w[i])>>>0,S0=r(a,2)^r(a,13)^r(a,22),mj=(a&bb)^(a&c)^(bb&c),t2=(S0+mj)>>>0;
      h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=bb;bb=a;a=(t1+t2)>>>0}
    h0=(h0+a)>>>0;h1=(h1+bb)>>>0;h2=(h2+c)>>>0;h3=(h3+d)>>>0;h4=(h4+e)>>>0;h5=(h5+f)>>>0;h6=(h6+g)>>>0;h7=(h7+h)>>>0}
  return [h0,h1,h2,h3,h4,h5,h6,h7].map(x=>x.toString(16).padStart(8,'0')).join('')}

/* ---------- الكود المتحرك ----------
   24 حرف (بدون I و O) × 100 رقم = 2400 كود. كل ساعة: كل طالب في المجموعة بياخد كود مختلف
   (التصادم بيتحل بشكل حتمي) فمفيش طالبين بنفس الكود في نفس المجموعة. */
const LET='ABCDEFGHJKLMNPQRSTUVWXYZ',SPACE=LET.length*100,HOUR=36e5;
const slotOf=t=>Math.floor(t/HOUR);
const roster=g=>(g.st||[]).filter(x=>x.s==='ok').map(x=>x.u).sort();
const _cm=new Map();
function codeMap(g,slot){
  if(!g||!g.fk)return null;
  const ids=roster(g),key=g.id+'|'+g.fk+'|'+slot+'|'+ids.join(',');
  let c=_cm.get(key);if(c)return c;
  const used=new Set(),byUser={},byCode={};
  ids.forEach(u=>{let a=0,i;do{i=parseInt(sha256(g.fk+'|'+g.id+'|'+u+'|'+slot+'|'+a++).slice(0,8),16)%SPACE}while(used.has(i)&&a<60);used.add(i);const code=LET[Math.floor(i/100)]+String(i%100).padStart(2,'0');byUser[u]=code;byCode[code]=u});
  c={byUser,byCode};if(_cm.size>80)_cm.clear();_cm.set(key,c);return c}
const codeOf=(g,u,t)=>{const m=codeMap(g,slotOf(t||Date.now()));return m?m.byUser[u]||'':''};
function parseCode(q){
  q=String(q||'').toUpperCase().replace(/[٠-٩]/g,d=>AD.indexOf(d)).replace(/[\s\-_.]/g,'');
  const a=/^([A-Z])(\d{2})$/.exec(q),b=/^(\d{2})([A-Z])$/.exec(q),m=a?[0,a[1],a[2]]:b?[0,b[2],b[1]]:null;
  return m&&LET.includes(m[1])?m[1]+m[2]:''}
const partialCode=q=>/^[A-Za-z][0-9٠-٩]?$/.test(String(q||'').trim());
/* التحقق: الساعة الحالية + (أول 10 دقايق من الساعة) الساعة اللي فاتت — تعويض فرق الساعة على الأجهزة */
function findByCode(code,gs){
  const now=Date.now(),cur=slotOf(now),slots=[cur];if(now%HOUR<6e5)slots.push(cur-1);
  const out=[];gs.forEach(g=>slots.forEach(s=>{const m=codeMap(g,s),u=m&&m.byCode[code];if(u&&!out.some(o=>o.g===g.id&&o.u===u))out.push({g:g.id,u,old:s!==cur})}));return out}

/* ---------- الدفعات ---------- */
const payId=(g,u,mo)=>g+'_'+u+'_'+mo;
const isPaid=(g,u,mo,idx)=>(idx||new Set(S.pay.map(x=>x.id))).has(payId(g,u,mo));
function dueMonths(g,u,idx){ // الأشهر غير المدفوعة من شهر البداية (آخر 12 شهر بحد أقصى) حتى الشهر الحالي
  const cur=mk();if(!g.bs)return [];let from=g.bs;const lim=mshift(cur,-11);if(from<lim)from=lim;const out=[];
  for(let m=from;m<=cur;m=mshift(m,1))if(!isPaid(g.id,u,m,idx))out.push(m);return out}
const isCollector=()=>{const m=me();return !!m&&(m.role==='teacher'||m.role==='assistant')};
const myGroups=()=>{const m=me();if(!m)return[];
  if(m.role==='teacher')return S.g.filter(g=>g.t===m.id);
  if(m.role==='assistant')return S.g.filter(g=>(g.as||[]).includes(m.id)&&!g.fn);return[]};
const canUndo=p=>{const m=me();if(!m||!p)return false;const g=G(p.g);if(!g)return false;
  return m.role==='teacher'?g.t===m.id:(p.by===m.id&&Date.now()-p.d<6e5&&(g.as||[]).includes(m.id))};

/* ---------- حالة الواجهة ---------- */
const FS={q:'',gid:'',sel:null,mo:'',cfg:0};

/* ---------- تنسيقات ---------- */
const css=document.createElement('style');css.textContent=`
.fee-ph{border-radius:50%;object-fit:cover;background:var(--bd);display:inline-flex;align-items:center;justify-content:center;font-weight:800;color:var(--mut);flex:none}
.fee-bar{position:sticky;top:calc(var(--hh,60px) + env(safe-area-inset-top,0px));z-index:4;background:var(--bg);padding:8px 0 6px;margin:-6px 0 6px}
.fee-q{display:flex;align-items:center;gap:8px;background:var(--card);border:2.5px solid var(--pri);border-radius:18px;padding:4px 12px;box-shadow:0 6px 22px color-mix(in srgb,var(--pri) 22%,transparent)}
.fee-q input{-webkit-appearance:none;appearance:none;border:0!important;border-radius:0!important;outline:0!important;background:transparent!important;font-size:22px!important;font-weight:700;padding:12px 4px!important;box-shadow:none!important;color:var(--tx)}
.fee-q #fee-q,.fee-q #fee-q:focus,:root[data-role] .fee-q #fee-q:focus{border:0!important;border-radius:0!important;outline:0!important;box-shadow:none!important;background:transparent!important;transform:none!important}
.fee-q button{border:0;background:var(--bd);color:var(--tx);border-radius:50%;width:38px;height:38px;font-size:18px;cursor:pointer;flex:none}
.fee-chips{display:flex;gap:8px;overflow-x:auto;padding:8px 2px 2px;scrollbar-width:none}.fee-chips::-webkit-scrollbar{display:none}
.fee-chips button{flex:none;border:1.5px solid var(--bd);background:var(--card);color:var(--tx);border-radius:999px;padding:8px 14px;font:inherit;font-weight:700;cursor:pointer}
.fee-chips button.on{background:var(--pri);border-color:var(--pri);color:#fff}
.fee-row{display:flex;align-items:center;gap:12px;padding:10px;border:1px solid var(--bd);border-radius:16px;background:var(--card);margin-bottom:8px;cursor:pointer;min-height:68px}
.fee-row:active{transform:scale(.99)}.fee-row b{display:block;font-size:17px}.fee-row small{color:var(--mut)}
.fee-tag{margin-inline-start:auto;border-radius:999px;padding:4px 12px;font-weight:800;font-size:13px;white-space:nowrap}
.fee-tag.ok{background:#16a34a22;color:#16a34a}.fee-tag.no{background:#dc262622;color:#dc2626}
.fee-big{text-align:center;border:2px solid var(--bd);border-radius:22px;background:var(--card);padding:18px 14px;margin-bottom:12px}
.fee-big .fee-ph{width:150px!important;height:150px!important;border-radius:26px;margin:0 auto 10px;display:flex;font-size:64px!important}
.fee-big h2{font-size:26px;margin:.1em 0}.fee-big .meta{color:var(--mut);font-size:15px}
.fee-due{margin:12px 0;padding:12px;border-radius:16px;background:color-mix(in srgb,var(--pri) 10%,transparent);font-size:19px;font-weight:800}
.fee-due small{display:block;font-size:14px;font-weight:600;color:var(--mut)}
.fee-mo{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:8px}
.fee-mo button{border:1.5px solid var(--bd);background:var(--card);color:var(--tx);border-radius:12px;padding:6px 12px;font:inherit;font-weight:700;cursor:pointer}
.fee-mo button.on{background:#dc2626;border-color:#dc2626;color:#fff}
.fee-pay{width:100%;min-height:80px;border:0;border-radius:20px;background:linear-gradient(135deg,#15803d,#22c55e);color:#fff;font:inherit;font-size:30px;font-weight:900;cursor:pointer;box-shadow:0 10px 26px #16a34a55;letter-spacing:.5px}
.fee-pay:active{transform:scale(.97)}
.fee-paid{padding:16px;border-radius:18px;background:#16a34a1f;color:#16a34a;font-size:20px;font-weight:800;text-align:center}
.fee-paid small{display:block;color:var(--mut);font-weight:600;font-size:14px}
.fee-warn{background:#f59e0b22;color:#b45309;border-radius:12px;padding:8px 12px;margin:8px 0;font-weight:700}
.fee-undo{margin-top:10px;border:1.5px solid var(--bd);background:transparent;color:var(--mut);border-radius:12px;padding:10px 16px;font:inherit;cursor:pointer}
.fee-prog{height:10px;border-radius:99px;background:var(--bd);overflow:hidden;margin:6px 0}.fee-prog i{display:block;height:100%;background:#16a34a}
.fee-code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:58px;font-weight:900;letter-spacing:6px;color:var(--pri);line-height:1.1;direction:ltr}
.fee-sp{margin-top:10px;padding:12px;border:1px dashed var(--bd);border-radius:16px;text-align:center}.fee-sp-h{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;font-weight:800;margin-bottom:6px}.fee-sp .fee-tag{white-space:normal;line-height:1.5}
.fee-c .fee-g{display:flex;align-items:center;gap:14px;padding:12px 0;border-top:1px solid var(--bd)}.fee-c .fee-g:first-of-type{border-top:0}
.fee-c .fee-g>div{flex:1;min-width:0;text-align:center}.fee-c .fee-tag{white-space:normal;overflow-wrap:anywhere;line-height:1.5}
.fee-tm{height:6px;border-radius:99px;background:var(--bd);overflow:hidden;margin:6px 0}.fee-tm i{display:block;height:100%;background:var(--pri);transition:width 1s linear}
.fee-btn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:64px;border:0;border-radius:18px;background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff;font:inherit;font-size:20px;font-weight:800;cursor:pointer;margin-bottom:14px}
#fee-toast{position:fixed;inset-inline:12px;bottom:calc(86px + env(safe-area-inset-bottom,0px));z-index:50;display:none;max-width:560px;margin:auto;background:#14532d;color:#fff;border-radius:16px;padding:14px 16px;font-weight:800;box-shadow:0 12px 30px #0006;align-items:center;gap:12px}
#fee-toast button{margin-inline-start:auto;border:0;background:#ffffff33;color:#fff;border-radius:10px;padding:8px 14px;font:inherit;font-weight:800;cursor:pointer}
.fee-cfg label{display:block;font-weight:700;margin:6px 0 2px}
@media(max-width:420px){.fee-code{font-size:48px}.fee-pay{font-size:26px}}`;
document.head.appendChild(css);

/* ---------- إشعار النجاح السريع ---------- */
let _tt;
function ftoast(msg,undoId){
  let t=document.getElementById('fee-toast');if(!t){t=document.createElement('div');t.id='fee-toast';t.setAttribute('role','status');document.body.appendChild(t)}
  t.style.display='flex';t.innerHTML=`<span>${msg}</span>${undoId?`<button onclick="FEE.undo('${undoId}')">تراجع</button>`:''}`;
  clearTimeout(_tt);_tt=setTimeout(()=>{t.style.display='none'},undoId?7000:3000)}

/* ---------- صورة الطالب (إجبارية) ---------- */
function shrink(file,z){return new Promise((res,rej)=>{const im=new Image(),u=URL.createObjectURL(file);
  im.onload=()=>{try{const s=Math.min(im.width,im.height),c=document.createElement('canvas');c.width=c.height=z;
    c.getContext('2d').drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,z,z);URL.revokeObjectURL(u);res(c.toDataURL('image/jpeg',.72))}catch(e){rej(e)}};
  im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('img'))};im.src=u})}
async function setPhoto(inp){
  const f=inp.files&&inp.files[0];if(!f)return;if(!/^image\//.test(f.type))return ftoast('اختار صورة فقط');
  try{const d=await shrink(f,260),m=me();m.av=d;save();ftoast('✅ تم حفظ صورتك');R()}catch(e){ftoast('تعذّر قراءة الصورة، جرّب صورة تانية')}}

/* ---------- جزء الدفع في بطاقة الطالب (يركّبه tabs.js) ---------- */
function studentPart(g,m){
  const idx=new Set(S.pay.map(x=>x.id)),cur=mk(),code=codeOf(g,m.id),due=dueMonths(g,m.id,idx),paid=!due.length;
  if(!g.fk||!code)return `<div class="fee-sp"><small class="mut">⏳ بانتظار تفعيل نظام المصاريف من المدرس</small></div>`;
  return `<div class="fee-sp" data-fg="${g.id}" data-fu="${m.id}"><div class="fee-sp-h"><span>💳 كود الدفع</span><span class="fee-tag ${paid?'ok':'no'}">${paid?'✅ مدفوع '+mlabel(cur):'⏳ '+due.map(mlabel).join('، ')+(+g.fee?' — '+money(g.fee*due.length):'')}</span></div><div class="fee-code" data-fc>${code}</div><div class="fee-tm"><i data-ft></i></div><small class="mut" data-fx></small></div>`}

/* تحديث الكود والعدّاد كل ثانية بدون إعادة رسم الصفحة */
setInterval(()=>{
  try{document.querySelectorAll('[data-fg]').forEach(el=>{
    const g=G(el.dataset.fg);if(!g)return;const now=Date.now(),code=codeOf(g,el.dataset.fu,now),c=el.querySelector('[data-fc]');
    if(c&&c.textContent!==code)c.textContent=code;
    const left=HOUR-(now%HOUR),b=el.querySelector('[data-ft]'),x=el.querySelector('[data-fx]');
    if(b)b.style.width=(left/HOUR*100)+'%';
    if(x){const mn=Math.ceil(left/6e4);x.textContent='يتغيّر بعد '+(mn>=60?'ساعة':mn+' دقيقة')+' (الساعة '+hm(now+left)+')'}})}catch(e){}},1000);

/* ---------- صفحة التحصيل ---------- */
const curMonth=()=>FS.mo||mk();
function allStudents(gs){const out=[];gs.forEach(g=>roster(g).forEach(u=>{const o=U(u);if(o)out.push({g,u:o})}));return out}
function search(q){
  const gs=myGroups().filter(g=>!FS.gid||g.id===FS.gid),raw=String(q||'').trim();if(!raw)return {list:[],byCode:false};
  const code=parseCode(raw);
  if(code){const hits=findByCode(code,gs);if(hits.length)return {list:hits.map(h=>({g:G(h.g),u:U(h.u),old:h.old})).filter(x=>x.g&&x.u),byCode:true}}
  const digits=raw.replace(/[٠-٩]/g,d=>AD.indexOf(d)).replace(/\D/g,''),toks=nz(raw).split(' ').filter(Boolean),all=allStudents(gs);
  if(digits.length>=4&&digits.length>=raw.replace(/\s/g,'').length-1)return {list:all.filter(x=>String(x.u.phone||'').replace(/\D/g,'').includes(digits)).slice(0,8),byCode:false};
  return {list:all.filter(x=>{const n=nz(x.u.name);return toks.every(t=>n.includes(t))}).sort((a,b)=>a.u.name.localeCompare(b.u.name,'ar')).slice(0,8),byCode:false}}

function personCard(g,u,old){
  const idx=new Set(S.pay.map(x=>x.id)),due=dueMonths(g,u.id,idx),cur=mk(),m=me();
  const target=(FS.mo&&due.includes(FS.mo))?FS.mo:due[0];
  const code=codeOf(g,u.id);
  if(!due.length){
    const p=S.pay.filter(x=>x.g===g.id&&x.u===u.id&&x.mo===cur)[0],by=p&&U(p.by);
    return `<div class="fee-big">${photo(u,150)}<h2>${E(u.name)}</h2><div class="meta">${E(g.title||'')}${u.phone?' • <span dir="ltr">'+E(u.phone)+'</span>':''}</div><div class="fee-paid" style="margin-top:12px">✅ مدفوع — ${mlabel(cur)}<small>${p?'بواسطة '+E(by?by.name:'—')+' • '+hm(p.d)+' '+new Date(p.d).toLocaleDateString('ar-EG'):''}</small></div>${p&&canUndo(p)?`<button class="fee-undo" onclick="FEE.undo('${p.id}')">↩ تراجع عن الدفع</button>`:''}</div>`}
  return `<div class="fee-big">${photo(u,150)}<h2>${E(u.name)}</h2><div class="meta">${E(g.title||'')}${u.phone?' • <span dir="ltr">'+E(u.phone)+'</span>':''}${code?' • الكود <b dir="ltr">'+code+'</b>':''}</div>
  ${old?'<div class="fee-warn">⚠️ الكود ده من الساعة اللي فاتت — اتأكد من الصورة والاسم</div>':''}
  ${okImg(u.av)?'':'<div class="fee-warn">📸 الطالب مرفعش صورة — اتأكد من هويته بطريقة تانية</div>'}
  <div class="fee-due"><small>الشهر المطلوب دفعه</small>${mlabel(target)}${+g.fee?' — '+money(g.fee):''}</div>
  ${due.length>1?`<div class="fee-warn">متأخر ${due.length} شهور — اختار الشهر:</div><div class="fee-mo">${due.map(d=>`<button class="${d===target?'on':''}" onclick="FEE.month('${d}')">${mlabel(d)}</button>`).join('')}</div>`:''}
  <button class="fee-pay" style="margin-top:12px" onclick="FEE.pay('${g.id}','${u.id}','${target}')">✅ تم الدفع</button></div>`}

function resultsHTML(){
  if(FS.sel){const g=G(FS.sel.g),u=U(FS.sel.u);if(g&&u)return `<button class="b s" style="margin-bottom:8px" onclick="FEE.back()">→ رجوع للنتائج</button>`+personCard(g,u,FS.sel.old)}
  const q=FS.q.trim();
  if(!q)return summaryHTML();
  if(partialCode(q))return `<div class="card" style="text-align:center"><div style="font-size:38px">⌨️</div><b>كمّل الكود… (حرف + رقمين)</b></div>`;
  const r=search(q);
  if(!r.list.length)return `<div class="card" style="text-align:center"><div style="font-size:42px">🔍</div><b>مفيش نتيجة</b><p class="mut">${parseCode(q)?'الكود غير صحيح أو انتهى — اطلب من الطالب يفتح صفحته ويقرأ الكود الحالي.':'جرّب جزء تاني من الاسم أو الكود.'}</p></div>`;
  if(r.list.length===1&&(r.byCode||q.length>=2)){const x=r.list[0];return personCard(x.g,x.u,x.old)}
  const idx=new Set(S.pay.map(x=>x.id));
  return r.list.map(x=>{const d=dueMonths(x.g,x.u.id,idx);return `<div class="fee-row" onclick="FEE.open('${x.g.id}','${x.u.id}',${x.old?1:0})">${photo(x.u,56)}<div><b>${E(x.u.name)}</b><small>${E(x.g.title||'')}</small></div><span class="fee-tag ${d.length?'no':'ok'}">${d.length?'مطلوب '+mlabel(d[0]).split(' ')[0]:'مدفوع ✔'}</span></div>`}).join('')}

function summaryHTML(){
  const gs=myGroups().filter(g=>!FS.gid||g.id===FS.gid),idx=new Set(S.pay.map(x=>x.id)),cur=mk(),m=me();
  const today=new Date().setHours(0,0,0,0),mine=S.pay.filter(p=>p.d>=today&&(m.role==='teacher'?gs.some(g=>g.id===p.g):p.by===m.id));
  const tot=mine.reduce((a,p)=>a+(+p.amt||0),0);
  const recent=S.pay.filter(p=>gs.some(g=>g.id===p.g)).sort((a,b)=>b.d-a.d).slice(0,5);
  let h=`<div class="card" style="display:flex;gap:10px;text-align:center"><div style="flex:1"><div class="mut">تحصيل اليوم</div><b style="font-size:26px">${mine.length}</b> <span class="mut">طالب</span></div><div style="flex:1"><div class="mut">المبلغ</div><b style="font-size:26px;color:#16a34a">${money(tot)}</b></div></div>`;
  gs.forEach(g=>{
    if(!g.bs||!(+g.fee>0)){h+=`<div class="card mut" style="text-align:center">${m.role==='teacher'?'⚙️ حدّد قيمة الاشتراك الشهري من قسم «المصروفات الشهرية» أسفل الصفحة عشان يبدأ التحصيل.':'المدرس لسه ما حدّدش قيمة الاشتراك.'}</div>`;return}
    const ids=roster(g),paid=ids.filter(u=>isPaid(g.id,u,cur,idx)).length,late=ids.filter(u=>!isPaid(g.id,u,cur,idx)),pc=ids.length?Math.round(paid/ids.length*100):0;
    h+=`<div class="card"><div class="row"><b>${E(g.title||'مجموعة')}</b><span class="mut">${mlabel(cur)}</span></div><div class="fee-prog"><i style="width:${pc}%"></i></div><div class="row"><span>✅ ${paid} دفعوا</span><span>⏳ ${late.length} لسه</span></div>`+
    (late.length?`<details><summary class="mut" style="cursor:pointer;padding:6px 0">عرض اللي لسه ما دفعوش</summary>${late.slice(0,60).map(u=>U(u)).filter(Boolean).sort((a,b)=>a.name.localeCompare(b.name,'ar')).map(u=>`<div class="fee-row" onclick="FEE.open('${g.id}','${u.id}',0)">${photo(u,44)}<b style="font-size:16px">${E(u.name)}</b></div>`).join('')}</details>`:'')+`</div>`});
  if(recent.length)h+=`<div class="card"><h3>🕘 آخر العمليات</h3>${recent.map(p=>{const u=U(p.u);return `<div class="row" style="padding:6px 0;border-top:1px solid var(--bd)"><span>${E(u?u.name:'—')} <small class="mut">${mlabel(p.mo)}</small></span><span class="mut">${hm(p.d)}${canUndo(p)?` <a href="#" onclick="FEE.undo('${p.id}');return false">تراجع</a>`:''}</span></div>`}).join('')}</div>`;
  if(!gs.length)h+=`<div class="card mut" style="text-align:center">${m.role==='assistant'?'مفيش مجموعات متاح لك التحصيل فيها — المدرس لازم يضيفك ويسمح بالتحصيل.':'أنشئ مجموعة أولاً.'}</div>`;
  return h}

function cfgHTML(){
  const m=me(),g=G(FS.gid);if(m.role!=='teacher'||!g||g.t!==m.id)return '';
  return `<div class="card" style="display:flex;align-items:center;gap:10px;justify-content:space-between"><span><b>👥 تحصيل المساعدين</b><br><small class="mut">السماح لمساعدي المجموعة بتسجيل الدفع</small></span><label class="st-switch"><input type="checkbox" ${g.fn?'':'checked'} onchange="FEE.toggleAs('${g.id}',this.checked)"><span></span></label></div>`}

function body(gid){
  if(FS.gid!==gid){FS.gid=gid;FS.sel=null;FS.q='';FS.mo=''}
  return `<div class="fee-bar"><div class="fee-q"><span style="font-size:20px">🔎</span><input id="fee-q" type="text" enterkeyhint="search" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="الاسم أو الكود (A49)" value="${E(FS.q)}" oninput="FEE.input(this.value)"><button aria-label="مسح" onclick="FEE.clear()">✕</button></div></div><div id="fee-res">${resultsHTML()}</div>${FS.sel||FS.q.trim()?'':cfgHTML()}`}

/* ---------- الإجراءات ---------- */
function ensureKeys(){ // أي عميل يلاقي مجموعة من غير مفتاح يولّده (عشان الطالب ما يستناش المدرس يفتح)
  const m=me();if(!m)return;let ch=0;
  const mine=m.role==='teacher'?S.g.filter(g=>g.t===m.id):m.role==='assistant'?S.g.filter(g=>(g.as||[]).includes(m.id)):m.role==='student'?S.g.filter(g=>(g.st||[]).some(x=>x.u===m.id&&x.s==='ok')):[];
  mine.filter(g=>!g.fk).forEach(g=>{g.fk=rnd(16);ch=1});if(ch)save()}
function pay(gid,uid,mo){
  const g=G(gid),u=U(uid);if(!g||!u||!/^\d{4}-\d{2}$/.test(mo))return;
  if(!myGroups().some(x=>x.id===gid))return ftoast('مش مسموح لك بالتحصيل في المجموعة دي');
  if(!g.bs||!(+g.fee>0))return ftoast('المدرس لسه ما حدّدش قيمة الاشتراك');
  const id=payId(gid,uid,mo);if(S.pay.some(x=>x.id===id))return ftoast('⚠️ الشهر ده مدفوع بالفعل');
  S.pay.push({id,g:gid,u:uid,mo,amt:+g.fee,d:Date.now(),by:S.me});
  notify(uid,`💰 تم تسجيل سداد ${g.fee} ج.م عن ${mlabel(mo)} — ${g.title||''}`,'pay'+id);
  save();try{push()}catch(e){}
  try{navigator.vibrate&&navigator.vibrate(60)}catch(e){}
  FS.sel=null;FS.q='';FS.mo='';rerender(true);
  ftoast('✅ تم تسجيل دفع '+E(u.name)+' — '+mlabel(mo),id)}
function undo(id){
  const i=S.pay.findIndex(x=>x.id===id),p=S.pay[i];if(!p)return;if(!canUndo(p))return ftoast('التراجع غير متاح لهذه العملية');
  S.pay.splice(i,1);notify(p.u,`↩️ تم إلغاء تسجيل سداد ${mlabel(p.mo)}`,'pay'+id);save();try{push()}catch(e){}
  ftoast('↩️ تم التراجع');rerender(false)}
function toggleAs(gid,on){const g=G(gid),m=me();if(!g||!m||g.t!==m.id)return;g.fn=on?0:1;save();ftoast(on?'✅ المساعدون يقدروا يحصّلوا':'🚫 التحصيل للمدرس فقط')}
function rerender(focus){R();if(focus)setTimeout(()=>{const i=document.getElementById('fee-q');i&&i.focus()},60)}
function paint(){const r=document.getElementById('fee-res');if(r)r.innerHTML=resultsHTML()}

window.FEE={
  photo:setPhoto,pay,undo,toggleAs,
  get cfg(){return FS.cfg},set cfg(v){FS.cfg=v},
  input(v){FS.q=v;FS.sel=null;FS.mo='';paint()},
  clear(){FS.q='';FS.sel=null;FS.mo='';rerender(true)},
  open(g,u,old){FS.sel={g,u,old:!!old};paint();scrollTo(0,0)},
  back(){FS.sel=null;FS.mo='';paint()},
  month(m){FS.mo=m;paint()},
  _t:{sha256,codeMap,codeOf,parseCode,findByCode,dueMonths,nz,mk,mshift,search,slotOf,partialCode}};

/* ---------- ربط بالمنصة (التبويبات والرئيسية بيتحكم فيها tabs.js) ---------- */
window.FEE.body=body;window.FEE.studentPart=studentPart;window.FEE.ensure=ensureKeys;window.FEE.collectGroups=myGroups;
/* ---------- عزل بيانات الدفع: الطالب يسحب دفعاته بس، المدرس/المساعد دفعات مجموعاتهم ---------- */
const _f=window.stFilt;
window.stFilt=(c,r)=>{
  if(c!=='pay')return _f?_f(c,r):r;
  const m=me();if(!m)return {};const o={};
  for(const id in r){const p=r[id];if(!p)continue;const g=G(p.g);
    const kids=(S.pl||[]).filter(x=>x.p===m.id&&!x.x).map(x=>x.s);if(m.role==='student'?p.u===m.id:m.role==='teacher'?g&&g.t===m.id:m.role==='assistant'?g&&(g.as||[]).includes(m.id):m.role==='parent'?kids.includes(p.u):true)o[id]=p}
  return o};
})();
