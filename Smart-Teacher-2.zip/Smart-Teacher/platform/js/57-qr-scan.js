/* qr-scan.js — قارئ QR بالجافاسكريبت (للمتصفحات اللي ماعندهاش BarcodeDetector زي Safari على آيفون).
   بيقرأ QR بوضع Byte (إصدارات 1–10، كل مستويات التصحيح) من ImageData. بيعتمد على جداول qr-lib.js. */
(function(){
'use strict';
const RS=QRLib._i.RSBlock,UT=QRLib._i.Util;
/* ---------- GF(256) + Reed-Solomon ---------- */
const EXP=new Uint8Array(512),LOG=new Uint8Array(256);
{let x=1;for(let i=0;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if(x&256)x^=0x11d}for(let i=255;i<512;i++)EXP[i]=EXP[i-255]}
const mul=(a,b)=>a&&b?EXP[LOG[a]+LOG[b]]:0,inv=a=>EXP[255-LOG[a]];
function rsCorrect(cw,nsym){ // cw: Uint8Array(data+ecc)، بيصلّح في مكانه. يرجع false لو فشل
  const n=cw.length,S=new Array(nsym).fill(0);let bad=false;
  for(let i=0;i<nsym;i++){let s=0;for(let j=0;j<n;j++)s=mul(s,EXP[i])^cw[j];S[i]=s;if(s)bad=true}
  if(!bad)return true;
  // Berlekamp–Massey
  let C=[1],B=[1],L=0,m=1,b=1;
  for(let i=0;i<nsym;i++){let d=S[i];for(let j=1;j<=L;j++)d^=mul(C[j]||0,S[i-j]);
    if(!d){m++;continue}
    const T=C.slice(),coef=mul(d,inv(b));while(C.length<B.length+m)C.push(0);
    for(let j=0;j<B.length;j++)C[j+m]^=mul(coef,B[j]);
    if(2*L<=i){L=i+1-L;B=T;b=d;m=1}else m++}
  if(L*2>nsym)return false;
  // Chien: مواضع الأخطاء
  const pos=[];for(let i=0;i<n;i++){const x=EXP[(255-(n-1-i))%255];
    let ev=0,xp=1;for(let j=0;j<=L;j++){ev^=mul(C[j]||0,xp);xp=mul(xp,x)}
    if(ev===0)pos.push(i)}
  if(pos.length!==L)return false;
  // Forney: Omega = S(x)*C(x) mod x^nsym
  const om=new Array(nsym).fill(0);for(let i=0;i<nsym;i++)for(let j=0;j<=i&&j<=L;j++)om[i]^=mul(C[j]||0,S[i-j]);
  for(const p of pos){const xi=EXP[n-1-p],xinv=inv(xi);
    let num=0,xp=1;for(let j=0;j<nsym;j++){num^=mul(om[j],xp);xp=mul(xp,xinv)}
    let den=0;xp=1;for(let j=1;j<=L;j+=2){den^=mul(C[j]||0,xp);xp=mul(xp,mul(xinv,xinv))}
    if(!den)return false;cw[p]^=mul(mul(num,xi),inv(den))}
  for(let i=0;i<nsym;i++){let s=0;for(let j=0;j<n;j++)s=mul(s,EXP[i])^cw[j];if(s)return false}
  return true}
/* ---------- تحويل لأبيض/أسود (عتبة محلية) ---------- */
function binarize(img){
  const w=img.width,h=img.height,d=img.data,g=new Uint8Array(w*h);
  for(let i=0,p=0;i<g.length;i++,p+=4)g[i]=(d[p]*77+d[p+1]*150+d[p+2]*29)>>8;
  const ii=new Float64Array((w+1)*(h+1));
  for(let y=0;y<h;y++){let r=0;for(let x=0;x<w;x++){r+=g[y*w+x];ii[(y+1)*(w+1)+x+1]=ii[y*(w+1)+x+1]+r}}
  const R=Math.max(8,Math.round(Math.min(w,h)/10)),bin=new Uint8Array(w*h);
  for(let y=0;y<h;y++){const y0=Math.max(0,y-R),y1=Math.min(h,y+R+1);for(let x=0;x<w;x++){const x0=Math.max(0,x-R),x1=Math.min(w,x+R+1),
    sum=ii[y1*(w+1)+x1]-ii[y0*(w+1)+x1]-ii[y1*(w+1)+x0]+ii[y0*(w+1)+x0],mean=sum/((x1-x0)*(y1-y0));
    bin[y*w+x]=g[y*w+x]<mean*0.92?1:0}} // 1 = غامق
  return {w,h,bin}}
/* ---------- إيجاد مربعات الزوايا (1:1:3:1:1) ---------- */
const near=(a,b,u)=>Math.abs(a-b)<u*0.6;
function ratioOk(r){const t=(r[0]+r[1]+r[2]+r[3]+r[4]);if(t<7)return 0;const u=t/7;return near(r[0],u,u)&&near(r[1],u,u)&&near(r[2],3*u,u*1.4)&&near(r[3],u,u)&&near(r[4],u,u)?u:0}
function crossCheck(B,cx,cy,vertical,maxLen){
  const {w,h,bin}=B,L=vertical?h:w,at=i=>vertical?bin[i*w+cx]:bin[cy*w+i],c=vertical?cy:cx,cnt=[0,0,0,0,0];
  let i=c;while(i>=0&&at(i)){cnt[2]++;i--}if(i<0)return null;while(i>=0&&!at(i)){cnt[1]++;i--}if(i<0)return null;while(i>=0&&at(i)){cnt[0]++;i--}
  i=c+1;while(i<L&&at(i)){cnt[2]++;i++}if(i>=L)return null;while(i<L&&!at(i)){cnt[3]++;i++}if(i>=L)return null;while(i<L&&at(i)){cnt[4]++;i++}
  const u=ratioOk(cnt);if(!u)return null;const end=i-cnt[4]-cnt[3];return {u,center:end-cnt[2]/2}}
function findFinders(B){
  const {w,h,bin}=B,found=[];
  for(let y=0;y<h;y+=2){
    const runs=[];let cur=bin[y*w],len=0,x0=0;
    for(let x=0;x<w;x++){if(bin[y*w+x]===cur)len++;else{runs.push([cur,len,x0]);cur=bin[y*w+x];len=1;x0=x}}runs.push([cur,len,x0]);
    for(let k=0;k+4<runs.length;k++){if(!runs[k][0])continue;
      const r=[runs[k][1],runs[k+1][1],runs[k+2][1],runs[k+3][1],runs[k+4][1]],u=ratioOk(r);if(!u)continue;
      const cx=Math.round(runs[k+2][2]+runs[k+2][1]/2),v=crossCheck(B,cx,y,true);if(!v)continue;
      const cy=Math.round(v.center),hx=crossCheck(B,cx,cy,false);if(!hx)continue;
      const fx=hx.center,fy=v.center,ms=(u+v.u+hx.u)/3;
      let m=found.find(f=>Math.abs(f.x-fx)<ms*2&&Math.abs(f.y-fy)<ms*2&&Math.abs(f.s-ms)<ms*0.6);
      if(m){m.x=(m.x*m.n+fx)/(m.n+1);m.y=(m.y*m.n+fy)/(m.n+1);m.s=(m.s*m.n+ms)/(m.n+1);m.n++}else found.push({x:fx,y:fy,s:ms,n:1})}}
  return found.filter(f=>f.n>=2)}
/* ---------- مواصفات النسخة ---------- */
function funcMap(ver){
  const n=17+4*ver,f=new Uint8Array(n*n),set=(x,y,w,h)=>{for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)if(i>=0&&j>=0&&i<n&&j<n)f[j*n+i]=1};
  set(0,0,9,9);set(n-8,0,8,9);set(0,n-8,9,8);set(6,0,1,n);set(0,6,n,1);
  const p=UT.getPatternPosition(ver);
  for(const a of p)for(const b of p){if((a===p[0]&&b===p[0])||(a===p[0]&&b===p[p.length-1])||(a===p[p.length-1]&&b===p[0]))continue;set(b-2,a-2,5,5)}
  if(ver>=7){set(n-11,0,3,6);set(0,n-11,6,3)}
  return {n,f}}
const FMT=[];{for(let d=0;d<32;d++){let v=d<<10;for(let i=14;i>=10;i--)if(v>>i&1)v^=0x537<<(i-10);FMT.push(((d<<10)|v)^0x5412)}}
const pop=x=>{let c=0;while(x){c+=x&1;x>>=1}return c};
function readFormat(get){
  const bits=[];const a=[[8,0],[8,1],[8,2],[8,3],[8,4],[8,5],[8,7],[8,8],[7,8],[5,8],[4,8],[3,8],[2,8],[1,8],[0,8]];
  let v1=0;for(let i=0;i<15;i++)v1|=get(a[i][0],a[i][1])<<i;
  const n=get.n;let v2=0;for(let i=0;i<7;i++)v2|=get(n-1-i,8)<<i;for(let i=7;i<15;i++)v2|=get(8,n-15+i)<<i;
  let best=null;for(const v of [v1,v2])for(let d=0;d<32;d++){const dist=pop(v^FMT[d]);if(dist<=3&&(!best||dist<best.dist))best={dist,d}}
  return best?{ec:best.d>>3,mask:best.d&7}:null}
const MASK=[(i,j)=>(i+j)%2===0,(i,j)=>i%2===0,(i,j)=>j%3===0,(i,j)=>(i+j)%3===0,(i,j)=>(Math.floor(i/2)+Math.floor(j/3))%2===0,(i,j)=>(i*j)%2+(i*j)%3===0,(i,j)=>((i*j)%2+(i*j)%3)%2===0,(i,j)=>((i+j)%2+(i*j)%3)%2===0];
function parseData(bytes,ver){
  let pos=0;const bit=()=>{const v=bytes[pos>>3]>>(7-(pos&7))&1;pos++;return v},rd=n=>{let v=0;while(n--)v=v<<1|bit();return v};
  let out='';while(pos+4<=bytes.length*8){const mode=rd(4);if(mode===0)break;if(mode!==4)return null;
    const cl=ver<=9?8:16,len=rd(cl);if(pos+len*8>bytes.length*8)return null;for(let i=0;i<len;i++)out+=String.fromCharCode(rd(8))}
  return out}
function homog(s,d){ // يحل 8 معادلات: module(s) -> image(d)
  const A=[],r=[];for(let i=0;i<4;i++){const [x,y]=s[i],[u,v]=d[i];A.push([x,y,1,0,0,0,-u*x,-u*y]);r.push(u);A.push([0,0,0,x,y,1,-v*x,-v*y]);r.push(v)}
  for(let i=0;i<8;i++){let p=i;for(let k=i+1;k<8;k++)if(Math.abs(A[k][i])>Math.abs(A[p][i]))p=k;[A[i],A[p]]=[A[p],A[i]];[r[i],r[p]]=[r[p],r[i]];
    for(let k=i+1;k<8;k++){const f=A[k][i]/A[i][i];for(let j=i;j<8;j++)A[k][j]-=f*A[i][j];r[k]-=f*r[i]}}
  const h=new Array(8);for(let i=7;i>=0;i--){let t=r[i];for(let j=i+1;j<8;j++)t-=A[i][j]*h[j];h[i]=t/A[i][i]}return h}
function sampleDecode(B,tl,tr,bl,ms){
  const dimF=((Math.hypot(tr.x-tl.x,tr.y-tl.y)+Math.hypot(bl.x-tl.x,bl.y-tl.y))/2)/ms+7;
  const ver0=Math.round((dimF-17)/4);
  for(const ver of [ver0,ver0-1,ver0+1]){
    if(ver<1||ver>10)continue;const {n,f}=funcMap(ver);
    const ax=(tr.x-tl.x)/(n-7),ay=(tr.y-tl.y)/(n-7),bx=(bl.x-tl.x)/(n-7),by=(bl.y-tl.y)/(n-7);
    const aff=(mx,my)=>({x:tl.x+(mx-3.5)*ax+(my-3.5)*bx,y:tl.y+(mx-3.5)*ay+(my-3.5)*by});
    let ap=aff(n-3.5,n-3.5),apm=[n-3.5,n-3.5];
    if(ver>=2){const p=UT.getPatternPosition(ver),c=p[p.length-1]+.5,e=aff(c,c),r=Math.ceil(ms*3.5),W=B.w,H=B.h;let best=-1,sx=0,sy=0,sn=0;
      const ring=(X,Y)=>{let sc=0;for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++){if(!i&&!j)continue;const q=at2(X+i*ax+j*bx,Y+i*ay+j*by);if(!q)sc++}
        for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++){if(Math.max(Math.abs(i),Math.abs(j))!==2)continue;if(at2(X+i*ax+j*bx,Y+i*ay+j*by))sc++}return sc};
      const at2=(x,y)=>{const X=Math.round(x),Y=Math.round(y);return X<0||Y<0||X>=W||Y>=H?0:B.bin[Y*W+X]};
      const cand=[];for(let dy=-r;dy<=r;dy+=1)for(let dx=-r;dx<=r;dx+=1){const X=Math.round(e.x+dx),Y=Math.round(e.y+dy);if(at2(X,Y)){const sc=ring(X,Y);cand.push([sc,X,Y]);if(sc>best)best=sc}}
      if(best>=18){for(const [sc,X,Y] of cand)if(sc>=best-1){sx+=X;sy+=Y;sn++}ap={x:sx/sn,y:sy/sn};apm=[c,c]}}
    const H=homog([[3.5,3.5],[n-3.5,3.5],[3.5,n-3.5],apm],[[tl.x,tl.y],[tr.x,tr.y],[bl.x,bl.y],[ap.x,ap.y]]);
    const W2=B.w,H2=B.h,px=(mx,my)=>{const w=H[6]*mx+H[7]*my+1,X=Math.round((H[0]*mx+H[1]*my+H[2])/w),Y=Math.round((H[3]*mx+H[4]*my+H[5])/w);return X<0||Y<0||X>=W2||Y>=H2?0:B.bin[Y*W2+X]};
    const get=(mx,my)=>{const x=mx+.5,y=my+.5,t=px(x,y)*2+px(x-.22,y)+px(x+.22,y)+px(x,y-.22)+px(x,y+.22);return t>=4?1:0};get.n=n;
    const fm=readFormat(get);if(!fm)continue;
    const bitsArr=[];let up=true;
    for(let col=n-1;col>0;col-=2){if(col===6)col--;
      for(let k=0;k<n;k++){const y=up?n-1-k:k;for(let dx=0;dx<2;dx++){const x=col-dx;if(f[y*n+x])continue;let v=get(x,y);if(MASK[fm.mask](y,x))v^=1;bitsArr.push(v)}}up=!up}
    const bytes=new Uint8Array(bitsArr.length>>3);for(let i=0;i<bytes.length*8;i++)bytes[i>>3]|=bitsArr[i]<<(7-(i&7));
    const blocks=RS.getRSBlocks(ver,fm.ec===1?1:fm.ec===0?0:fm.ec===3?3:2);
    const total=blocks.reduce((a,b)=>a+b.totalCount,0);if(bytes.length<total)continue;
    const maxD=Math.max(...blocks.map(b=>b.dataCount)),maxE=Math.max(...blocks.map(b=>b.totalCount-b.dataCount)),dat=blocks.map(b=>new Uint8Array(b.totalCount)),ec=[];
    let idx=0;const cws=bytes.slice(0,total),bl2=blocks.map(()=>[]);
    for(let i=0;i<maxD;i++)blocks.forEach((b,bi)=>{if(i<b.dataCount)bl2[bi].push(cws[idx++])});
    for(let i=0;i<maxE;i++)blocks.forEach((b,bi)=>{if(i<b.totalCount-b.dataCount)bl2[bi].push(cws[idx++])});
    let ok=true,data=[];
    for(let bi=0;bi<blocks.length&&ok;bi++){const arr=Uint8Array.from(bl2[bi]);if(!rsCorrect(arr,blocks[bi].totalCount-blocks[bi].dataCount)){ok=false;break}data.push(...arr.slice(0,blocks[bi].dataCount))}
    if(!ok)continue;const s=parseData(Uint8Array.from(data),ver);if(s!=null)return s}
  return null}
function order(a,b,c){ // TL = الركن اللي عند الزاوية القائمة
  const d=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y),ab=d(a,b),bc=d(b,c),ac=d(a,c);let tl,p,q;
  if(bc>=ab&&bc>=ac){tl=a;p=b;q=c}else if(ac>=ab&&ac>=bc){tl=b;p=a;q=c}else{tl=c;p=a;q=b}
  const cr=(p.x-tl.x)*(q.y-tl.y)-(p.y-tl.y)*(q.x-tl.x);return cr>0?{tl,tr:p,bl:q}:{tl,tr:q,bl:p}}
function decode(img,dbg){
  const B=binarize(img),fs=findFinders(B);if(dbg)dbg.f=fs.length;if(fs.length<3)return null;
  fs.sort((a,b)=>b.n-a.n);const top=fs.slice(0,6);
  for(let i=0;i<top.length;i++)for(let j=i+1;j<top.length;j++)for(let k=j+1;k<top.length;k++){
    const a=top[i],b=top[j],c=top[k],ms=(a.s+b.s+c.s)/3;if(Math.max(a.s,b.s,c.s)/Math.min(a.s,b.s,c.s)>1.6)continue;
    const o=order(a,b,c),d1=Math.hypot(o.tr.x-o.tl.x,o.tr.y-o.tl.y),d2=Math.hypot(o.bl.x-o.tl.x,o.bl.y-o.tl.y);if(Math.abs(d1-d2)/Math.max(d1,d2)>0.35)continue;
    if(dbg)dbg.tri=(dbg.tri||0)+1;const r=sampleDecode(B,o.tl,o.tr,o.bl,ms);if(r)return r}
  return null}
window.QRScan={decode,_rs:rsCorrect};
})();
