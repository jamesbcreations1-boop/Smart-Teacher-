/* ==========================================================================
   Smart Teacher — attend.js : الحضور والغياب
   يتحمّل بعد fees.js و qr-lib.js.

   • الطالب: QR يومي (صالح لحد آخر اليوم) + كود نصي ثابت (مثل B28) — يشتغل بسكرين شوت بدون إنترنت.
   • المساعد/المدرس: صفحة «✅ الحضور» (تاب في صفحة المجموعة): كاميرا مسح مستمر + بحث سريع.
   • الصورة الشخصية إجبارية للطالب والمدرس (عند التسجيل، وللحسابات القديمة عند أول دخول).
   • Offline-first: التسجيل بيتحفظ محلياً فوراً ويتزامن لما النت يرجع.

   ⚠️ نفس الحد الأمني الموثّق في fees.js: التوقيع بيتحسب من مفتاح المجموعة (fk) الموجود
   في القاعدة؛ السد الحقيقي = توليد/فحص التوقيع على سيرفر (راجع firebase/اقرأني-الأمان.md).
   ========================================================================== */
(()=>{
'use strict';
if(typeof S==='undefined'||!window.FEE||!window.QRLib||!window.QRScan){console.warn('attend: deps missing');return}
if(!Array.isArray(S.at))S.at=[];
const sha=FEE._t.sha256,AD='٠١٢٣٤٥٦٧٨٩',nz=FEE._t.nz,E=s=>esc(s);
const okImg=v=>/^data:image\/(jpeg|png|webp|gif);base64,/.test(v||'');
const pad=n=>String(n).padStart(2,'0');
const dayOf=t=>{const d=new Date(t||Date.now());return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
const hm=t=>{const d=new Date(t);return pad(d.getHours())+':'+pad(d.getMinutes())};
const rnd=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return [...a].map(b=>b.toString(36).padStart(2,'0')).join('').slice(0,n)};
const roster=g=>(g.st||[]).filter(x=>x.s==='ok').map(x=>x.u).sort();
const isCol=()=>{const m=me();return !!m&&(m.role==='teacher'||m.role==='assistant')};
const myGs=()=>{const m=me();if(!m)return[];return m.role==='teacher'?S.g.filter(g=>g.t===m.id):m.role==='assistant'?S.g.filter(g=>(g.as||[]).includes(m.id)):[]};
const ensureKeys=()=>{const m=me();if(!m||m.role!=='teacher')return;let c=0;S.g.filter(g=>g.t===m.id&&!g.fk).forEach(g=>{g.fk=rnd(16);if(!g.fst)g.fst=FEE._t.mk();c=1});if(c)save()};

/* ---------- الرموز ---------- */
const sig=(g,u,day)=>sha(g.fk+'|att|'+g.id+'|'+u+'|'+day).slice(0,12);
const token=(g,u,day)=>g&&g.fk?['ST1',g.id,u,day||dayOf(),sig(g,u,day||dayOf())].join('.'):'';
function verify(raw,gs){
  const p=String(raw||'').trim().split('.');if(p.length!==5||p[0]!=='ST1')return {err:'ده مش QR بتاع المنصة'};
  const g=gs.find(x=>x.id===p[1]);if(!g)return {err:'الـ QR ده من مجموعة مش بتاعتك'};
  if(!g.fk)return {err:'المجموعة غير مفعّلة'};
  if(sig(g,p[2],p[3])!==p[4])return {err:'QR غير صالح (مزوّر أو تالف)'};
  if(p[3]!==dayOf())return {err:'QR قديم — تاريخه '+p[3]+' (صالح ليوم واحد بس)'};
  if(!roster(g).includes(p[2]))return {err:'الطالب مش مسجّل في المجموعة'};
  return {g,u:p[2]}}
const LET='ABCDEFGHJKLMNPQRSTUVWXYZ',SP=2400,_sc=new Map();
function scMap(g){ // كود نصي ثابت لكل طالب في المجموعة (حرف + رقمين)، فريد داخل المجموعة
  const ids=roster(g),key=g.id+'|'+g.fk+'|'+ids.join(',');let c=_sc.get(key);if(c)return c;
  const used=new Set(),by={},bc={};
  ids.forEach(u=>{let a=0,i;do{i=parseInt(sha(g.fk+'|static|'+g.id+'|'+u+'|'+a++).slice(0,8),16)%SP}while(used.has(i)&&a<60);used.add(i);const k=LET[Math.floor(i/100)]+pad(i%100);by[u]=k;bc[k]=u});
  c={by,bc};if(_sc.size>60)_sc.clear();_sc.set(key,c);return c}
const staticCode=(g,u)=>g&&g.fk?(scMap(g).by[u]||''):'';
const normCode=q=>{q=String(q||'').toUpperCase().replace(/[٠-٩]/g,d=>AD.indexOf(d)).replace(/[\s\-_.]/g,'');const a=/^([A-Z])(\d{2})$/.exec(q),b=/^(\d{2})([A-Z])$/.exec(q);return a?a[1]+a[2]:b?b[2]+b[1]:''};

/* ---------- QR → SVG ---------- */
function qrSvg(text,px){
  const m=QRLib.make(text),n=m.length,q=4;let d='';
  for(let y=0;y<n;y++){let x=0;while(x<n){if(m[y][x]){let w=1;while(x+w<n&&m[y][x+w])w++;d+=`M${x+q} ${y+q}h${w}v1h-${w}z`;x+=w}else x++}}
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n+2*q} ${n+2*q}" width="${px}" height="${px}" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`}

/* ---------- السجلات: نفس نموذج بيانات الحضور الموجود في المنصة (سجل لكل مجموعة/يوم: r = حالة كل طالب) ---------- */
const recOf=(gid,day)=>S.at.find(a=>a.id===gid+'_'+day);
const PRES=c=>c==='p'||c==='l';
const hasRec=(g,u,day)=>{const r=recOf(g,day);return !!(r&&r.r&&PRES(r.r[u]))};
function ensureRec(gid,day){let r=recOf(gid,day);if(!r){r={id:gid+'_'+day,g:gid,d:day,r:{}};S.at.push(r)}r.r=r.r||{};r.t=r.t||{};return r}
function mark(g,u,how){
  const day=dayOf(),r=ensureRec(g.id,day);
  if(PRES(r.r[u]))return {dup:true,t:(r.t||{})[u]||0};
  r.r[u]='p';r.t[u]=Date.now();g.act=Date.now();save();return {dup:false,t:r.t[u]}}
function unmark(gid,u){const r=recOf(gid,dayOf());if(!r||!r.r)return;delete r.r[u];if(r.t)delete r.t[u];save()}
const pending=()=>{try{const B=(typeof BASE!=='undefined'&&BASE.at)||{};let n=0;S.at.forEach(a=>{Object.keys(a.r||{}).forEach(u=>{if(!((a.id+'/r/'+u) in B))n++})});return n}catch(e){return 0}};

/* ---------- تنسيقات ---------- */
const css=document.createElement('style');css.textContent=`
.at-grid{display:grid;gap:12px}@media(min-width:860px){.at-grid{grid-template-columns:1.1fr .9fr;align-items:start}}
.at-cam{position:relative;background:#000;border-radius:20px;overflow:hidden;aspect-ratio:4/3;max-height:46vh;width:100%}
.at-cam video{width:100%;height:100%;object-fit:cover;display:block}
.at-cam .frame{position:absolute;inset:18% 18%;border:3px solid #fff9;border-radius:22px;pointer-events:none}
.at-cam .off{position:absolute;inset:0;display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;color:#fff;text-align:center;padding:16px}
.at-chips{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}
.at-chip{border-radius:999px;padding:6px 14px;font-weight:800;background:var(--card);border:1.5px solid var(--bd)}
.at-chip.ok{color:#16a34a;border-color:#16a34a66}.at-chip.wait{color:#b45309;border-color:#f59e0b88}
.at-res{border-radius:22px;padding:14px;text-align:center;border:3px solid #16a34a;background:color-mix(in srgb,#16a34a 12%,var(--card));margin-top:10px;position:relative;overflow:hidden}
.at-res.dup{border-color:#f59e0b;background:color-mix(in srgb,#f59e0b 14%,var(--card))}.at-res.err{border-color:#dc2626;background:color-mix(in srgb,#dc2626 12%,var(--card))}
.at-res{display:grid;grid-template-columns:104px 1fr;gap:8px 14px;align-items:center;text-align:start;margin:0 0 10px}.at-res .act{grid-column:1/-1}.at-res.err{grid-template-columns:1fr;text-align:center}
.at-res .ph{width:104px;height:104px;border-radius:22px;object-fit:cover;display:flex;align-items:center;justify-content:center;background:var(--bd);font-size:44px;font-weight:800}
.at-res h2{font-size:22px;margin:0 0 2px}.at-res .st{font-weight:900;font-size:17px}
.at-skip{width:100%;min-height:70px;border:0;border-radius:18px;margin-top:10px;background:var(--pri);color:#fff;font:inherit;font-size:24px;font-weight:900;cursor:pointer}
.at-skip:active{transform:scale(.97)}
.at-bar{position:absolute;bottom:0;inset-inline:0;height:6px;background:#0002}.at-bar i{display:block;height:100%;background:var(--pri);transition:width .25s linear}
.at-q{display:flex;gap:8px;align-items:center;background:var(--card);border:2.5px solid var(--pri);border-radius:18px;padding:4px 12px}
#at-q,#at-q:focus,:root[data-role] #at-q:focus{border:0!important;box-shadow:none!important;outline:0!important;background:transparent!important;font-size:21px!important;font-weight:700;padding:12px 4px!important;transform:none!important}
.at-row{display:flex;align-items:center;gap:12px;padding:8px;border:1px solid var(--bd);border-radius:16px;background:var(--card);margin-top:8px;cursor:pointer;min-height:64px}
.at-row img,.at-row .p0{width:52px;height:52px;border-radius:50%;object-fit:cover;background:var(--bd);display:flex;align-items:center;justify-content:center;font-weight:800;flex:none}
.at-row b{display:block}.at-row small{color:var(--mut)}.at-row .tg{margin-inline-start:auto;font-weight:800;font-size:13px}
.at-qrc{text-align:center}.at-qrc .qr{display:inline-block;padding:6px;background:#fff;border-radius:16px;border:1px solid var(--bd)}
.at-qrc .sc{font-family:ui-monospace,Menlo,monospace;font-size:34px;font-weight:900;letter-spacing:5px;direction:ltr;color:var(--pri)}
.at-gate{max-width:440px;margin:30px auto;text-align:center}
#at-fs{position:fixed;inset:0;z-index:99999;background:#05080f;display:none;flex-direction:column;height:100dvh;color:#fff;font-family:inherit}
#at-fs.on{display:flex}
#at-fs .fv{position:absolute;inset:0}#at-fs .fv video{width:100%;height:100%;object-fit:cover;display:block}
#at-fs .shade{position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,#000a 0,#0000 22%,#0000 55%,#000b 100%)}
#at-fs .top{position:relative;z-index:3;display:flex;align-items:center;gap:10px;padding:calc(env(safe-area-inset-top,0px) + 12px) 14px 8px}
#at-fs .top .tt{flex:1;min-width:0}#at-fs .top b{display:block;font-size:17px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#at-fs .top .chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
#at-fs .chp{background:#ffffff22;backdrop-filter:blur(8px);border-radius:999px;padding:4px 12px;font-size:13px;font-weight:700}
#at-fs .chp.ok{background:#16a34acc}
#at-fs .ib{width:44px;height:44px;border-radius:50%;border:0;background:#ffffff2b;color:#fff;font-size:20px;backdrop-filter:blur(8px);cursor:pointer;flex:none}
#at-fs .scan{position:absolute;z-index:2;left:50%;top:42%;width:min(68vw,320px);aspect-ratio:1;transform:translate(-50%,-50%);pointer-events:none}
#at-fs .scan i{position:absolute;width:34px;height:34px;border:4px solid #fff;opacity:.95}
#at-fs .scan i:nth-child(1){top:0;left:0;border-right:0;border-bottom:0;border-radius:16px 0 0 0}
#at-fs .scan i:nth-child(2){top:0;right:0;border-left:0;border-bottom:0;border-radius:0 16px 0 0}
#at-fs .scan i:nth-child(3){bottom:0;left:0;border-right:0;border-top:0;border-radius:0 0 0 16px}
#at-fs .scan i:nth-child(4){bottom:0;right:0;border-left:0;border-top:0;border-radius:0 0 16px 0}
#at-fs .hint{position:absolute;z-index:2;left:0;right:0;top:calc(42% + min(34vw,160px) + 18px);text-align:center;font-size:14px;color:#fffc}
#at-fs .sheet{position:absolute;z-index:4;left:0;right:0;bottom:0;padding:12px 12px calc(env(safe-area-inset-bottom,0px) + 12px)}
#at-fs .at-res{margin:0;background:#101826ee;color:#fff;backdrop-filter:blur(14px);border-width:2px;border-radius:24px;box-shadow:0 12px 40px #0009;grid-template-columns:96px 1fr}
#at-fs .at-res .ph{width:96px;height:96px}
#at-fs .at-res .mut{color:#cbd5e1}
#at-fs .at-res .meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
#at-fs .at-res .meta span{background:#ffffff1c;border-radius:10px;padding:3px 9px;font-size:13px}
#at-fs .at-skip{min-height:48px;font-size:17px;background:#ffffff26;margin-top:8px}
.at-res .meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}.at-res .meta span{background:var(--bd);border-radius:10px;padding:3px 9px;font-size:13px}
.at-cam{aspect-ratio:16/10;max-height:34vh}
`;document.head.appendChild(css);

/* ---------- جزء الحضور في بطاقة الطالب (يركّبه tabs.js) ---------- */
function studentPart(g,m){
  if(!g.fk)return '';const day=dayOf();
  return `<div class="at-qrc"><div class="qr">${qrSvg(token(g,m.id,day),210)}</div><div class="sc">${staticCode(g,m.id)}</div><small class="mut">📸 خد لقطة شاشة للـ QR — بيشتغل بدون إنترنت وبينتهي آخر النهارده (${day})</small></div>`}

/* ---------- صفحة الحضور ---------- */
const AT={gid:'',q:'',cur:null,video:null,stream:null,det:null,timer:0,busy:0,seen:new Map(),cam:0,nocam:0,exp:0};
const gOf=()=>G(AT.gid);
function stats(){
  const g=gOf();if(!g)return '';const ids=roster(g),day=dayOf(),pr=ids.filter(u=>hasRec(g.id,u,day)).length,pn=pending();
  return `<span class="at-chip ok">حاضر ${pr}</span><span class="at-chip">غايب ${ids.length-pr}</span><span class="at-chip">إجمالي ${ids.length}</span><span class="at-chip ${navigator.onLine&&!pn?'ok':'wait'}">${navigator.onLine?(pn?'⏳ '+pn+' بانتظار المزامنة':'📶 متزامن'):'✈️ أوفلاين'+(pn?' — '+pn+' محفوظ':'')}</span>`}
function ph(u,cls){return okImg(u&&u.av)?`<img class="${cls}" src="${u.av}" alt="">`:`<span class="${cls} p0">${E((u?u.name:'؟').trim().charAt(0))}</span>`}
function resHTML(){
  const c=AT.cur;if(!c)return '';
  if(c.kind==='err')return `<div class="at-res err"><div style="font-size:34px">⛔</div><div class="st" style="color:#dc2626">${E(c.msg)}</div><button class="at-skip" onclick="ATT.skip()">التالي ⏭</button></div>`;
  const u=U(c.u);
  return `<div class="at-res ${c.kind==='dup'?'dup':''}">${ph(u,'ph')}<div><h2>${E(u?u.name:'—')}</h2><div class="st" style="color:${c.kind==='dup'?'#b45309':'#16a34a'}">${c.kind==='dup'?'⚠️ مسجّل قبل كده'+(c.t?' '+hm(c.t):''):'✅ تم تسجيل الحضور'}</div><div class="mut">${E(G(c.g)?.title||'')}</div><div class="meta"><span>🔢 ${E(staticCode(G(c.g),c.u))}</span>${u&&u.phone?`<span dir="ltr">📞 ${E(u.phone)}</span>`:''}${c.t?`<span>🕒 ${hm(c.t)}</span>`:''}<span>✅ ${cntToday(c.g)}</span></div></div><div class="act">${c.kind==='ok'?`<button class="b s" style="width:100%;margin-bottom:6px" onclick="ATT.undo('${c.g}','${c.u}')">↩ تراجع</button>`:''}<button class="at-skip" style="margin-top:0" onclick="ATT.skip()">تخطي / التالي ⏭</button></div><div class="at-bar"><i id="at-bar" style="width:100%"></i></div></div>`}
function cntToday(gid){const g=G(gid);if(!g)return '';const ids=roster(g),day=dayOf();return ids.filter(u=>hasRec(gid,u,day)).length+'/'+ids.length}
function show(c){AT.cur=c;AT.dur=AT.fs?5000:15000;AT.exp=Date.now()+AT.dur;const h=resHTML();['at-res','at-fs-res'].forEach(i=>{const r=document.getElementById(i);if(r)r.innerHTML=h});refresh();
  try{navigator.vibrate&&navigator.vibrate(c.kind==='ok'?50:[40,40,40])}catch(e){}beep(c.kind)}
let _ac;function beep(k){try{_ac=_ac||new(window.AudioContext||window.webkitAudioContext)();const o=_ac.createOscillator(),g=_ac.createGain();o.frequency.value=k==='ok'?880:k==='dup'?520:220;g.gain.value=.08;o.connect(g);g.connect(_ac.destination);o.start();o.stop(_ac.currentTime+.12)}catch(e){}}
function refresh(){const s=document.getElementById('at-stats');if(s)s.innerHTML=stats();const f=document.getElementById('at-fs-stats');if(f)f.innerHTML=fsStats();const a=document.getElementById('at-abs');if(a&&a.open)a.innerHTML=absHTML(true)}
function absHTML(open){const g=gOf(),day=dayOf();const ab=roster(g).filter(u=>!hasRec(g.id,u,day)).map(U).filter(Boolean).sort((a,b)=>a.name.localeCompare(b.name,'ar'));
  return `<summary class="mut" style="cursor:pointer;padding:6px 0">عرض الغائبين (${ab.length})</summary>`+(open?ab.slice(0,80).map(u=>`<div class="at-row" onclick="ATT.manual('${u.id}')">${ph(u,'')}<div><b>${E(u.name)}</b></div><span class="tg">تسجيل ✔</span></div>`).join(''):'')}
function searchHTML(){
  const g=gOf(),q=AT.q.trim();if(!g||!q)return '';const day=dayOf(),ids=roster(g);
  const code=normCode(q);let list=[];
  if(code&&g.fk){const u=scMap(g).bc[code];if(u)list=[U(u)].filter(Boolean)}
  if(!list.length){const digits=q.replace(/[٠-٩]/g,d=>AD.indexOf(d)).replace(/\D/g,''),toks=nz(q).split(' ').filter(Boolean);
    list=ids.map(U).filter(u=>u&&(digits.length>=4&&digits.length>=q.replace(/\s/g,'').length-1?String(u.phone||'').replace(/\D/g,'').includes(digits):toks.every(t=>nz(u.name).includes(t)))).slice(0,8)}
  if(!list.length)return `<div class="at-row" style="cursor:default"><b>مفيش نتيجة</b></div>`;
  return list.map(u=>`<div class="at-row" onclick="ATT.manual('${u.id}')">${ph(u,'')}<div><b>${E(u.name)}</b><small>${E(staticCode(g,u.id))} • ${E(u.phone||'')}</small></div><span class="tg" style="color:${hasRec(g.id,u.id,day)?'#16a34a':'var(--pri)'}">${hasRec(g.id,u.id,day)?'حاضر ✔':'سجّل حضور'}</span></div>`).join('')}
function body(gid){
  AT.gid=gid;const g=gOf();if(!g)return `<div class="card mut">المجموعة غير متاحة</div>`;
  return `<div id="att-root"><div class="at-chips" id="at-stats">${stats()}</div>
  <div class="at-grid"><div><div id="at-res">${resHTML()}</div><div class="at-cam"><div id="at-vslot" style="width:100%;height:100%"></div><div class="frame"></div><div class="off" id="at-off" style="display:${AT.cam?'none':'flex'}"><button class="b" style="font-size:20px;padding:14px 26px" onclick="ATT.start()">📷 تشغيل الكاميرا</button><small>المسح تلقائي — وجّه الكاميرا على QR الطالب</small></div></div></div>
  <div><div class="at-q"><span style="font-size:20px">🔎</span><input id="at-q" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" enterkeyhint="done" placeholder="الكود (B28) أو الاسم أو الموبايل" value="${E(AT.q)}" oninput="ATT.input(this.value)" onkeydown="if(event.key==='Enter')ATT.enter()"></div><div id="at-sres">${searchHTML()}</div><details class="card" style="margin-top:10px" id="at-abs" ontoggle="if(this.open)this.innerHTML=ATT.abs()">${absHTML(false)}</details><div class="tb-ops"><button class="b s" onclick="ATT.csv()">⬇️ تصدير CSV</button><button class="b s" onclick="ATT.finish()">🔚 إنهاء الحصة (تسجيل الغياب)</button></div></div></div></div>`}
const isAtt=()=>V.t==='at'&&(V.p==='group'||V.p==='gx');

async function start(){
  if(AT.stream)return;
  try{
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw new Error('nocam');
    AT.det=('BarcodeDetector' in window)?(AT.det||new BarcodeDetector({formats:['qr_code']})):null;
    AT.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}},audio:false});
    const v=AT.video=AT.video||document.createElement('video');v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.muted=true;v.srcObject=AT.stream;await v.play();
    AT.cam=1;openFS();const o=document.getElementById('at-off');if(o)o.style.display='none';loop()}
  catch(e){AT.stream=null;toast(e&&e.message==='nocam'?'الكاميرا تحتاج اتصال آمن (https) أو localhost':'تعذّر تشغيل الكاميرا — اسمح بالإذن من إعدادات المتصفح')}}
function stop(){clearTimeout(AT.timer);if(AT.stream){AT.stream.getTracks().forEach(t=>t.stop());AT.stream=null}AT.cam=0;AT.torch=0;hideFS();const o=document.getElementById('at-off');if(o)o.style.display='flex'}
const fsStats=()=>{const g=gOf();if(!g)return '';const ids=roster(g),day=dayOf(),pr=ids.filter(u=>hasRec(g.id,u,day)).length;return `<span class="chp ok">حاضر ${pr}</span><span class="chp">غايب ${ids.length-pr}</span><span class="chp">${ids.length} طالب</span>`};
function fsEl(){let e=document.getElementById('at-fs');if(e)return e;e=document.createElement('div');e.id='at-fs';
  e.innerHTML='<div class="fv" id="at-fs-v"></div><div class="shade"></div><div class="top"><button class="ib" onclick="ATT.close()" aria-label="إغلاق">✕</button><div class="tt"><b id="at-fs-t"></b><div class="chips" id="at-fs-stats"></div></div><button class="ib" id="at-fs-torch" onclick="ATT.torch()" style="display:none" aria-label="فلاش">🔦</button></div><div class="scan"><i></i><i></i><i></i><i></i></div><div class="hint">وجّه الكاميرا على QR الطالب — التسجيل تلقائي</div><div class="sheet" id="at-fs-res"></div>';
  document.body.appendChild(e);return e}
function openFS(){const e=fsEl(),g=gOf();AT.fs=1;e.classList.add('on');document.documentElement.style.overflow='hidden';
  const t=document.getElementById('at-fs-t');if(t)t.textContent='✅ حضور — '+(g?g.title:'');refresh();
  const v=document.getElementById('at-fs-v');if(v&&AT.video&&!v.contains(AT.video)){v.innerHTML='';v.appendChild(AT.video)}
  const r=document.getElementById('at-fs-res');if(r)r.innerHTML=resHTML();
  try{const tr=AT.stream&&AT.stream.getVideoTracks()[0],cp=tr&&tr.getCapabilities&&tr.getCapabilities();const b=document.getElementById('at-fs-torch');if(b)b.style.display=cp&&cp.torch?'block':'none'}catch(x){}
  try{const el=document.documentElement;if(el.requestFullscreen&&!document.fullscreenElement)el.requestFullscreen({navigationUI:'hide'}).catch(()=>{})}catch(x){}}
function hideFS(){if(!AT.fs)return;AT.fs=0;const e=document.getElementById('at-fs');if(e)e.classList.remove('on');document.documentElement.style.overflow='';
  try{if(document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen().catch(()=>{})}catch(x){}
  const s=document.getElementById('at-vslot');if(s&&AT.video&&s.contains(AT.video))s.innerHTML=''}
function closeFS(){stop();refresh()}
async function torch(){try{const tr=AT.stream&&AT.stream.getVideoTracks()[0];AT.torch=!AT.torch;await tr.applyConstraints({advanced:[{torch:!!AT.torch}]})}catch(e){AT.torch=0}}
document.addEventListener('fullscreenchange',()=>{if(AT.fs&&!document.fullscreenElement)closeFS()});
addEventListener('keydown',e=>{if(e.key==='Escape'&&AT.fs)closeFS()});
function mountVideo(){if(AT.fs)return;const s=document.getElementById('at-vslot');if(s&&AT.video&&AT.stream&&!s.contains(AT.video)){s.innerHTML='';s.appendChild(AT.video)}}
let _cv,_cx;
function grab(v){const k=Math.min(1,520/Math.max(v.videoWidth,1)),w=Math.max(2,Math.round(v.videoWidth*k)),h=Math.max(2,Math.round(v.videoHeight*k));
  _cv=_cv||document.createElement('canvas');if(_cv.width!==w||_cv.height!==h){_cv.width=w;_cv.height=h;_cx=_cv.getContext('2d',{willReadFrequently:true})}
  _cx.drawImage(v,0,0,w,h);return _cx.getImageData(0,0,w,h)}
function loop(){
  clearTimeout(AT.timer);if(!AT.stream)return;
  if(!isAtt()){stop();return}
  const v=AT.video;
  if(v.readyState>=2&&v.videoWidth&&!AT.busy){AT.busy=1;
    const p=AT.det?AT.det.detect(v).then(r=>r.forEach(c=>onRaw(c.rawValue))):Promise.resolve().then(()=>{const r=QRScan.decode(grab(v));if(r)onRaw(r)});
    p.catch(()=>{}).finally(()=>{AT.busy=0;AT.timer=setTimeout(loop,AT.det?100:160)})}
  else AT.timer=setTimeout(loop,90)}
function onRaw(raw){
  const now=Date.now(),last=AT.seen.get(raw);if(last&&now-last<4000)return;AT.seen.set(raw,now);
  if(AT.seen.size>300)AT.seen.clear();
  const r=verify(raw,myGs().filter(g=>g.id===AT.gid));
  if(r.err)return show({kind:'err',msg:r.err});
  register(r.g,r.u,'qr')}
function register(g,u,how){
  const r=mark(g,u,how);
  show({kind:r.dup?'dup':'ok',u,g:g.id,t:r.t})}
setInterval(()=>{ // مؤقت الـ 15 ثانية
  if(!AT.cur||!isAtt())return;const left=AT.exp-Date.now(),b=document.getElementById('at-bar');
  if(left<=0){skip();return}if(b)b.style.width=Math.max(0,left/(AT.dur||15000)*100)+'%'},250);
function skip(){AT.cur=null;['at-res','at-fs-res'].forEach(i=>{const r=document.getElementById(i);if(r)r.innerHTML=''})}
setInterval(()=>{if(isAtt())refresh();try{if(navigator.onLine&&pending())push()}catch(e){}},15000);
addEventListener('online',()=>{try{push()}catch(e){}refresh()});addEventListener('offline',refresh);

window.ATT={
  start,skip,close:closeFS,torch,
  undo(gid,u){unmark(gid,u);skip();refresh();const s=document.getElementById('at-sres');if(s)s.innerHTML=searchHTML()},
  input(v){AT.q=v;const s=document.getElementById('at-sres');if(s)s.innerHTML=searchHTML()},
  enter(){const g=gOf(),c=normCode(AT.q);if(g&&c&&g.fk){const u=scMap(g).bc[c];if(u)return this.manual(u)}},
  manual(u){const g=gOf();if(!g||!roster(g).includes(u))return;register(g,u,'manual');AT.q='';const i=document.getElementById('at-q');if(i){i.value='';i.focus()}const s=document.getElementById('at-sres');if(s)s.innerHTML=''},
  abs(){return absHTML(true)},
  finish(){const g=gOf();if(!g)return;const day=dayOf(),r=ensureRec(g.id,day),left=roster(g).filter(u=>!r.r[u]);
    if(!left.length)return toast('كل الطلاب متسجّل لهم حالة');
    if(!confirm('تسجيل '+left.length+' طالب غياب وإخطار أولياء الأمور؟'))return;
    left.forEach(u=>{r.r[u]='a';const o=U(u),t=`⚠️ تم تسجيل غياب ${o?o.name:''} عن ${g.title} بتاريخ ${day}`;[u,...(S.pl||[]).filter(x=>x.s===u&&!x.x).map(x=>x.p)].forEach(x=>notify(x,t,'at'+r.id+u))});
    save();try{push()}catch(e){}toast('✅ تم تسجيل '+left.length+' غياب');R()},
  csv(){const g=gOf(),day=dayOf();if(!g)return;const L={p:'حاضر',l:'متأخر',a:'غائب',x:'بعذر'},rec=recOf(g.id,day)||{r:{},t:{}},rows=[['الاسم','الموبايل','الكود','الحالة','الوقت']];roster(g).forEach(id=>{const u=U(id),c=(rec.r||{})[id],t=(rec.t||{})[id];rows.push([u?u.name:'',u?u.phone||'':'',staticCode(g,id),c?L[c]||c:'غير مسجّل',t?hm(t):''])});
    const b=new Blob(['\ufeff'+rows.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n')],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='attendance-'+day+'.csv';a.click()},
  _t:{token,verify,staticCode,scMap,normCode,dayOf,mark,qrSvg,AT,body}};

/* ---------- ربط بالمنصة ---------- */
if(typeof OKP!=='undefined'&&Array.isArray(OKP)&&!OKP.includes('att'))OKP.push('att');
const gate=()=>`<div class="card at-gate"><h2>📸 صورتك الشخصية مطلوبة</h2><p class="mut">لازم ترفع صورة واضحة لوجهك علشان تكمل. بتظهر في المجتمع وعلى شاشة المساعد وقت الحضور.</p><label class="b" style="display:block;margin:8px 0;cursor:pointer;padding:14px">📷 التقط صورة<input type="file" accept="image/*" capture="user" hidden onchange="FEE.photo(this)"></label><label class="b s" style="display:block;cursor:pointer;padding:14px">🖼️ اختيار من المعرض<input type="file" accept="image/*" hidden onchange="FEE.photo(this)"></label><button class="b s" style="margin-top:10px" onclick="S.me=null;save();go('dash')">خروج</button></div>`;
const _R=window.R;
window.R=function(){
  const m=me();
  if(m&&(m.role==='student'||m.role==='teacher')&&!okImg(m.av)){const r=_R.apply(this,arguments);try{$('#app').innerHTML=gate()}catch(e){}return r}
  if(AT.stream&&!isAtt())stop();
  return _R.apply(this,arguments)};
window.ATT.body=body;window.ATT.studentPart=studentPart;window.ATT.mount=mountVideo;window.ATT.isAtt=isAtt;window.ATT.myGroups=myGs;

/* ---------- تسجيل: صورة إجبارية للطالب والمدرس ---------- */
const _rf=window.regForm;
if(typeof _rf==='function')window.regForm=function(){
  let h=_rf.apply(this,arguments);
  if(RR!=='student'&&RR!=='teacher')return h;
  const blk=`<div class="fl" style="text-align:center"><span>📸 صورتك الشخصية (إجبارية)</span>${RF.av?`<img src="${RF.av}" alt="" style="width:110px;height:110px;border-radius:50%;object-fit:cover;display:block;margin:8px auto">`:''}<label class="b s" style="display:inline-block;cursor:pointer;margin-top:6px">${RF.av?'تغيير الصورة':'التقط / اختر صورة'}<input type="file" accept="image/*" capture="user" hidden onchange="ATT.regPhoto(this)"></label></div>`;
  const k=h.search(/<button[^>]*signup\(\)/);return k<0?h+blk:h.slice(0,k)+blk+h.slice(k)};
ATT.regPhoto=async inp=>{const f=inp.files&&inp.files[0];if(!f||!/^image\//.test(f.type))return;
  try{const im=new Image(),u=URL.createObjectURL(f);await new Promise((a,b)=>{im.onload=a;im.onerror=b;im.src=u});const s=Math.min(im.width,im.height),c=document.createElement('canvas');c.width=c.height=260;c.getContext('2d').drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,260,260);URL.revokeObjectURL(u);RF.av=c.toDataURL('image/jpeg',.72);R()}catch(e){toast('تعذّر قراءة الصورة')}};
const _su=window.signup;
if(typeof _su==='function')window.signup=async function(){
  if((RR==='student'||RR==='teacher')&&!okImg(RF.av))return toast('📸 ارفع صورتك الشخصية الأول — إجبارية');
  const av=RF.av,r=await _su.apply(this,arguments);
  try{if(av&&OTP&&OTP.u&&!OTP.u.av)OTP.u.av=av}catch(e){}return r};

/* ---------- عزل بيانات الحضور: كل مستخدم يشوف اللي يخصه بس ---------- */
const _f=window.stFilt;
window.stFilt=(c,r)=>{
  if(c!=='at')return _f?_f(c,r):r;
  const m=me();if(!m)return {};const o={};
  const kids=(S.pl||[]).filter(x=>x.p===m.id&&!x.x).map(x=>x.s);
  for(const id in r){const p=r[id];if(!p)continue;const g=G(p.g);
    const own=ids=>{const q=Object.assign({},p,{r:{},t:{}});ids.forEach(u=>{if(p.r&&p.r[u]!=null)q.r[u]=p.r[u];if(p.t&&p.t[u]!=null)q.t[u]=p.t[u]});return q};
    if(m.role==='student'){if(p.r&&p.r[m.id]!=null)o[id]=own([m.id])}
    else if(m.role==='parent'){const k=kids.filter(u=>p.r&&p.r[u]!=null);if(k.length)o[id]=own(k)}
    else if(m.role==='teacher'){if(g&&g.t===m.id)o[id]=p}
    else if(m.role==='assistant'){if(g&&(g.as||[]).includes(m.id))o[id]=p}
    else o[id]=p}
  return o};

/* ---------- أوفلاين: Service Worker ---------- */
try{if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{})}catch(e){}
try{if(me())window.R()}catch(e){console.warn('attend first paint',e)}
})();
