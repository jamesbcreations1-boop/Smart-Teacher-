/* ==========================================================================
   Smart Teacher — tabs.js : تجميع الحضور والتحصيل داخل كل مجموعة (بدون تكرار)
   • المدرس: تبويبَا «✅ الحضور» و«💰 التحصيل» داخل صفحة كل مجموعة.
   • المساعد: صفحة المجموعة (gx) بنفس التبويبين، ويدخلها من رئيسيته.
   • الطالب: بطاقة واحدة «🎫 بطاقتي» (QR الحضور + كود الدفع) لكل مجموعة.
   لا زر تحصيل/حضور في شريط التنقل ولا في الرئيسية للمدرس — مكان واحد بس.
   ========================================================================== */
(()=>{
'use strict';
if(typeof S==='undefined'||!window.FEE||!window.ATT){console.warn('tabs: deps missing');return}
const E=s=>esc(s),okImg=v=>/^data:image\/(jpeg|png|webp|gif);base64,/.test(v||'');
const TABS=[['at','✅','الحضور'],['pay','💰','التحصيل']];
if(typeof OKP!=='undefined'&&Array.isArray(OKP)&&!OKP.includes('gx'))OKP.push('gx');
const css=document.createElement('style');css.textContent=`
.tabs{display:flex!important;gap:8px;overflow-x:auto;flex-wrap:nowrap!important;scrollbar-width:none;padding:2px 0 8px;-webkit-overflow-scrolling:touch}.tabs::-webkit-scrollbar{display:none}.tabs button{flex:none;white-space:nowrap}
.tb-c .tb-g{padding:14px 0;border-top:1px solid var(--bd)}.tb-c .tb-g:first-of-type{border-top:0;padding-top:4px}
.tb-h{display:flex;gap:12px;align-items:center;margin-bottom:6px}.tb-h img{width:62px;height:62px;border-radius:50%;object-fit:cover;flex:none;border:2px solid var(--pri)}
.tb-h b{display:block;font-size:17px}.tb-h small{color:var(--mut)}
.tb-ops{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.tb-ops button{min-height:54px;font-size:15px}
.tb-gx-t{display:flex;gap:8px;margin:10px 0}.tb-gx-t button{flex:1;min-height:50px;font-size:17px}
.tb-sec{margin:18px 0 6px;color:var(--mut);font-size:14px;font-weight:800;display:flex;align-items:center;gap:8px}.tb-sec:after{content:"";flex:1;height:1px;background:var(--bd)}
`;document.head.appendChild(css);

/* ترتيب موحّد للتبويبات (المدرس) — أي تبويب مش في القائمة بيتحط قبل «الإعدادات» */
const ORDER=['الطلاب','الحضور','التحصيل','الامتحانات','المواد','التقييم','فيديوهات','التحديات','التحليلات','الإعدادات'];
const rank=t=>{const i=ORDER.findIndex(k=>t.includes(k));return i<0?ORDER.length-1.5:i};
/* ---------- المدرس: الحضور والتحصيل جوه صفحة المجموعة (يستبدلوا تبويبَي «الحضور/المصروفات» القديمين) ---------- */
const _g=window.group;
window.group=function(){
  const h=_g.apply(this,arguments),g=G(V.a);
  if(typeof h!=='string'||!g||!isT())return h;
  const i=h.indexOf('<div class="tabs">');if(i<0)return h;const j=h.indexOf('</div>',i);if(j<0)return h;
  const open='<div class="tabs">',inner=h.slice(i+open.length,j),btns=inner.match(/<button[\s\S]*?<\/button>/g)||[];
  const seen=new Set(),list=[];
  btns.forEach(b=>{let t=b.replace(/<[^>]*>/g,'').trim();
    if(t.includes('الحضور'))b=b.replace(/📋 الحضور|الحضور/,'✅ الحضور');
    if(t.includes('المصروفات')||t.includes('التحصيل'))b=b.replace(/💰 المصروفات|المصروفات/,'💰 التحصيل');
    t=b.replace(/<[^>]*>/g,'').trim();const k=t.replace(/[^\u0600-\u06FF]/g,'');if(seen.has(k))return;seen.add(k);list.push([rank(t),b])});
  list.sort((x,y)=>x[0]-y[0]);
  const tabs=open+list.map(x=>x[1]).join('')+'</div>';
  let extra='';
  if(V.t==='at')extra=ATT.body(g.id)+'<div class="tb-sec">كشف الحضور والتعديل اليدوي</div>';
  else if(V.t==='pay')extra=FEE.body(g.id)+'<div class="tb-sec">كشف المصروفات والمتأخرات</div>';
  return h.slice(0,i)+tabs+extra+h.slice(j+6)};

/* ---------- المساعد: صفحة المجموعة ---------- */
function gx(){
  const g=G(V.a);if(!g||!ATT.myGroups().some(x=>x.id===g.id))return `<div class="card mut">المجموعة غير متاحة</div>`;
  const t=V.t==='pay'?'pay':'at',can=FEE.collectGroups().some(x=>x.id===g.id);
  return `<div class="row"><h2>${E(g.title||'')}</h2><button class="b s" onclick="go('dash')">رجوع</button></div><div class="tb-gx-t">${TABS.map(x=>`<button class="b ${t===x[0]?'':'s'}" onclick="go('gx','${g.id}','${x[0]}')">${x[1]} ${x[2]}</button>`).join('')}</div>`+
    (t==='at'?ATT.body(g.id):can?FEE.body(g.id):`<div class="card mut" style="text-align:center">المدرس لم يسمح للمساعدين بالتحصيل في هذه المجموعة.</div>`)}

/* ---------- الطالب: بطاقة واحدة ---------- */
function studentCard(m){
  const gs=S.g.filter(g=>(g.st||[]).some(x=>x.u===m.id&&x.s==='ok'));if(!gs.length||!okImg(m.av))return '';
  return `<div class="card tb-c"><h3>🎫 بطاقتي</h3>`+gs.map(g=>`<div class="tb-g"><div class="tb-h"><img src="${m.av}" alt=""><div><b>${E(m.name)}</b><small>${E(g.title||'مجموعة')}</small></div></div>${ATT.studentPart(g,m)}${FEE.studentPart(g,m)}</div>`).join('')+`<p class="mut" style="font-size:13px;margin:6px 0 0">🔒 كود الدفع بيتغيّر كل ساعة، والـ QR بينتهي آخر اليوم — ما تشاركهمش مع حد.</p><label class="b s" style="display:inline-block;cursor:pointer;margin-top:6px;font-size:13px">📸 تغيير الصورة<input type="file" accept="image/*" capture="user" hidden onchange="FEE.photo(this)"></label></div>`}
const _d=window.dash;
window.dash=function(){
  const h=_d.apply(this,arguments);if(typeof h!=='string')return h;const m=me();if(!m)return h;
  try{
    if(m.role==='assistant'){const gs=ATT.myGroups();if(gs.length)return `<div class="card"><h3>📋 عمليات اليوم</h3>${gs.map(g=>`<div style="padding:8px 0;border-top:1px solid var(--bd)"><b>${E(g.title||'مجموعة')}</b><div class="tb-ops"><button class="b" onclick="go('gx','${g.id}','at')">✅ الحضور</button><button class="b s" onclick="go('gx','${g.id}','pay')">💰 التحصيل</button></div></div>`).join('')}</div>`+h}
  }catch(e){console.warn('tabs dash',e)}
  return h};

/* ---------- الإعدادات ← الحساب: صورة الحساب + «بطاقتي» للطالب ---------- */
const _s=window.set;
window.set=function(){
  let h=_s.apply(this,arguments);if(typeof h!=='string')return h;const m=me();if(!m||V.t!=='account')return h;
  try{
    if(okImg(m.av))h=h.replace(/<div class="st-avatar st-profile-avatar">[^<]*<\/div>/,`<div class="st-avatar st-profile-avatar" style="padding:0;overflow:hidden"><img src="${m.av}" alt="" style="width:100%;height:100%;object-fit:cover"></div>`);
    if(m.role==='student'){const c=studentCard(m),p=h.indexOf('st-gmail-pill'),k=p>=0?h.indexOf('<div class="card',p):-1;if(c&&k>=0)h=h.slice(0,k)+c+h.slice(k)}
  }catch(e){console.warn('tabs set',e)}
  return h};

/* ---------- تنظيف الواجهة بعد كل رسم: بدون تكرار، وصفوف الطلاب مرتّبة ---------- */
css.textContent+=`
.tb-stu{display:flex;gap:12px;align-items:flex-start;padding:12px 0;border-top:1px solid var(--bd)}
.tb-stu>img,.tb-stu>.p0{width:48px;height:48px;border-radius:50%;object-fit:cover;background:var(--bd);flex:none;display:flex;align-items:center;justify-content:center;font-weight:800}
.tb-stu .tb-in{flex:1;min-width:0}.tb-stu .tb-in b{display:block;font-size:16px}.tb-stu .tb-in .mut{font-size:13px}
.tb-menu{margin-top:6px}.tb-menu>summary{list-style:none;display:inline-flex;align-items:center;gap:6px;cursor:pointer;padding:8px 14px;border-radius:12px;border:1.5px solid var(--bd);font-weight:700;font-size:14px;background:var(--card)}
.tb-menu>summary::-webkit-details-marker{display:none}.tb-menu[open]>summary{border-color:var(--pri);color:var(--pri)}
.tb-menu .tb-mb{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}.tb-menu .tb-mb .b,.tb-menu .tb-mb a{flex:1 1 44%;text-align:center;min-height:44px;display:inline-flex;align-items:center;justify-content:center;margin:0!important}
.tb-menu .tb-mb .r{flex-basis:100%}
`;
function polish(){
  const m=me();if(!m)return;
  // الاستمارة: بطاقة الطالب تحت بيانات الحساب مباشرة
  const c=document.querySelector('.tb-c'),hero=document.querySelector('.st-profile-hero');if(c&&hero&&hero.nextElementSibling!==c)hero.after(c);
  // الرئيسية (مدرس/مساعد): اختصارات المجتمع/الذكاء/الشاتات موجودة في الشريط السفلي → نشيلها
  if(V.p==='dash'&&(m.role==='teacher'||m.role==='assistant')){
    const qa=document.querySelector('#app .qa');
    if(qa){qa.querySelectorAll('button').forEach(b=>{if(/go\('(ai|chats|soc)'\)|go\('soc'\)/.test(b.getAttribute('onclick')||''))b.remove()});if(qa.children.length<=1)qa.style.gridTemplateColumns='1fr';if(!qa.children.length)qa.remove()}
    document.querySelectorAll('#v7sum h3').forEach(h=>{h.textContent='💰 التحصيل'})}
  // تبويب الطلاب: صف مرتّب (صورة + اسم + قائمة إجراءات)
  if(V.p==='group'&&V.t==='st'&&m.role==='teacher'){
    document.querySelectorAll('#app .row').forEach(row=>{
      if(row.dataset.tb||!row.querySelector('button[onclick^="stu("]'))return;row.dataset.tb='1';
      const spans=row.children;if(spans.length<2)return;const info=spans[0],acts=spans[1];
      const pm=(info.innerHTML.match(/go\('pm','([^']+)'\)/)||[])[1],u=pm&&U(pm),cts=info.querySelector('.cts');
      const keep=[],menu=[];acts.querySelectorAll('button').forEach(b=>{const t=b.textContent.trim();(t==='قبول'||t==='رفض'||t==='تفعيل'||t==='✔ قبول'?keep:menu).push(b)});
      const mb=document.createElement('div');mb.className='tb-mb';
      if(cts)[...cts.children].forEach(x=>mb.appendChild(x));menu.forEach(b=>mb.appendChild(b));
      if(mb.children.length){const d=document.createElement('details');d.className='tb-menu';d.innerHTML='<summary>⋯ إجراءات</summary>';d.appendChild(mb);info.appendChild(d)}
      if(cts)cts.remove();
      const av=u&&okImg(u.av)?`<img src="${u.av}" alt="">`:`<span class="p0">${E(((u&&u.name)||'؟').trim().charAt(0))}</span>`;
      const wrap=document.createElement('div');wrap.className='tb-stu';wrap.innerHTML=av;info.classList.add('tb-in');wrap.appendChild(info);
      keep.forEach(b=>wrap.appendChild(b));acts.remove();row.replaceWith(wrap)})}
}
/* ---------- راوتر ---------- */
const _R=window.R;
window.R=function(){
  try{FEE.ensure()}catch(e){}
  if(typeof V!=='undefined'&&V.p==='gx'){
    const m=me();if(!m||m.role!=='assistant'){V={p:'dash'};return _R.apply(this,arguments)}
    const keep=V;V={p:'dash'};try{_R.apply(this,arguments)}finally{V=keep}
    try{$('#app').innerHTML=gx();document.querySelectorAll('#bn button.on').forEach(b=>b.classList.remove('on'))}catch(e){console.warn('gx',e)}
    try{ATT.mount()}catch(e){}return}
  const r=_R.apply(this,arguments);try{ATT.mount();polish()}catch(e){console.warn('polish',e)}return r};
try{if(me())window.R()}catch(e){console.warn('tabs first paint',e)}
})();
