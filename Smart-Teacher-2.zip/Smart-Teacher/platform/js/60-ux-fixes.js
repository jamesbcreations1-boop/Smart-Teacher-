/* ==========================================================================
   Smart Teacher — ux-fixes.js  (يُحمَّل آخر ملف بعد كل الملفات)
   1) الشريط الأفقي للتبويبات: حفظ موضع التمرير بين كل عمليات إعادة الرسم
   2) منع القفز لأعلى الصفحة: حفظ scrollY ومكان المؤشر عند أي R()
   3) صور المجتمع: تحميل النسخة عالية الدقة (من /files) بكسل عند الظهور
      + عرض الصورة بالحجم الكامل عند الضغط عليها
   4) (v12) حجز مساحة الصور قبل تحميلها + استعادة التمرير فورياً (instant)
      لأن html{scroll-behavior:smooth} كان بيخلّي الاستعادة تنزلق قدام المستخدم
   ========================================================================== */
(()=>{
'use strict';
if(window.__stUx)return;window.__stUx=1;

const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const pageKey=()=>{try{return typeof V!=='undefined'&&V?V.p+'|'+(V.a||''):'x'}catch(e){return 'x'}};

/* ---------------- 1) تمرير شريط التبويبات ---------------- */
const TS=new Map(),SSK='st.tabsScroll';
try{const o=JSON.parse(sessionStorage.getItem(SSK)||'{}');Object.keys(o).forEach(k=>{if(typeof o[k]==='number')TS.set(k,o[k])})}catch(e){}
let pt=0;
const persist=()=>{clearTimeout(pt);pt=setTimeout(()=>{try{sessionStorage.setItem(SSK,JSON.stringify(Object.fromEntries(TS)))}catch(e){}},300)};

/* scroll لا يعمل bubbling، فنلتقطه في مرحلة الـ capture */
document.addEventListener('scroll',e=>{
  const t=e.target;
  if(!t||t.nodeType!==1||!t.classList.contains('tabs'))return;
  const i=$$('#app .tabs').indexOf(t);
  if(i<0)return;                       // عنصر قديم اتشال من الصفحة
  TS.set(pageKey()+'#'+i,t.scrollLeft);persist();
},true);

const activeBtn=t=>t.querySelector('button.on')||t.querySelector('button.b:not(.s)');
/* تمركز الزر النشط داخل الشريط فقط (بدون تحريك الصفحة نفسها) — يشتغل RTL و LTR */
const reveal=(t,force)=>{
  const b=activeBtn(t);if(!b)return;
  const a=t.getBoundingClientRect(),r=b.getBoundingClientRect();
  if(force||r.left<a.left||r.right>a.right)t.scrollLeft+=(r.left+r.width/2)-(a.left+a.width/2);
};
const applyTabs=()=>{
  const k=pageKey();
  $$('#app .tabs').forEach((t,i)=>{
    const s=TS.get(k+'#'+i);
    if(typeof s==='number'){if(Math.abs(t.scrollLeft-s)>1)t.scrollLeft=s;reveal(t,false)}
    else reveal(t,true);               // أول زيارة: وسّط التبويب النشط
  });
};

/* ---------------- 3) صور المجتمع بدقة عالية ---------------- */
const HQ=new Map();
const setHQ=(id,d)=>{
  HQ.delete(id);HQ.set(id,d);if(HQ.size>30)HQ.delete(HQ.keys().next().value);
  $$('img.pimg[data-fid]').forEach(i=>{if(i.dataset.fid===id){i.src=d;i.dataset.hq='1'}});
};
const loadHQ=async img=>{
  const id=img.dataset.fid;
  if(!id||img.dataset.hq||typeof fGet!=='function')return;
  if(HQ.has(id)){img.src=HQ.get(id);img.dataset.hq='1';return}
  try{const o=await fGet(id);if(o&&o.d)setHQ(id,o.d)}catch(e){/* نكمّل بالمعاينة المصغّرة */}
};
const io='IntersectionObserver' in window
  ?new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){io.unobserve(en.target);loadHQ(en.target)}}),{rootMargin:'900px 0px'})
  :null;
const hqScan=()=>$$('img.pimg[data-fid]').forEach(i=>{
  if(i.dataset.hq)return;
  const id=i.dataset.fid;
  if(HQ.has(id)){i.src=HQ.get(id);i.dataset.hq='1'}else if(io)io.observe(i);else loadHQ(i);
});

/* ---------------- 4) حجز مساحة الصور (يمنع انهيار ارتفاع الصفحة أثناء إعادة الرسم) ---------------- */
const RAT=new Map();
const fk=i=>{const s=i.getAttribute('src')||'';return s.length+':'+s.slice(-48)};
document.addEventListener('load',e=>{
  const i=e.target;
  if(!(i instanceof HTMLImageElement)||!i.classList.contains('pimg')||!i.naturalWidth)return;
  RAT.set(fk(i),i.naturalWidth+'/'+i.naturalHeight);
  if(RAT.size>200)RAT.delete(RAT.keys().next().value);
  settle();
},true);
const reserve=()=>$$('#app img.pimg').forEach(i=>{
  if(i.hasAttribute('width')||i.style.aspectRatio)return;
  const r=RAT.get(fk(i));if(r)i.style.aspectRatio=r;
});
/* بعد أي إعادة رسم لنفس الصفحة: لو الصور لسه بتتحمّل وارتفاع الصفحة اتغيّر، رجّع نفس المكان
   (بس لو المستخدم ما لمسش الشاشة في الأثناء) */
const KEEP={y:0,until:0,moved:false};
['wheel','touchstart','touchmove','keydown','pointerdown'].forEach(ev=>addEventListener(ev,()=>{KEEP.moved=true},{passive:true,capture:true}));
const jump=y=>window.scrollTo({top:y,left:0,behavior:'instant'});
function settle(){if(Date.now()<KEEP.until&&!KEEP.moved&&Math.abs(window.scrollY-KEEP.y)>2)jump(KEEP.y)}

/* عرض الصورة بالحجم الكامل */
document.addEventListener('click',e=>{
  const i=e.target;
  if(!(i instanceof HTMLImageElement)||!i.classList.contains('pimg'))return;
  const o=document.createElement('div');o.className='st-lb';o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');
  o.innerHTML='<img alt=""><button type="button" aria-label="إغلاق">✕</button>';
  const big=o.firstChild,id=i.dataset.fid;
  big.src=(id&&HQ.get(id))||i.currentSrc||i.src;
  const close=()=>{o.remove();document.removeEventListener("keydown",onKey)};
  const onKey=ev=>{if(ev.key==="Escape")close()};
  o.addEventListener('click',close);document.addEventListener("keydown",onKey);
  document.body.appendChild(o);
  if(id&&!HQ.has(id)&&typeof fGet==='function')fGet(id).then(x=>{if(x&&x.d){setHQ(id,x.d);big.src=x.d}}).catch(()=>{});
});

/* ---------------- 2) تغليف R(): حفظ مكان التمرير والمؤشر ---------------- */
const wrapR=()=>{
  const _R=window.R;
  if(typeof _R!=='function'||_R.__ux)return;
  const w=function(){
    const k0=pageKey(),y=window.scrollY,ae=document.activeElement;
    const fx=ae&&ae.id&&/^(INPUT|TEXTAREA)$/.test(ae.tagName)?{id:ae.id,s:ae.selectionStart,e:ae.selectionEnd,v:ae.value}:null;
    const r=_R.apply(this,arguments);
    try{
      reserve();applyTabs();hqScan();
      /* رجّع المؤشر فقط لو المحتوى لسه زي ما هو (عشان ما نرجّع نص اتبعت فعلاً) */
      if(fx){
        const n=document.getElementById(fx.id);
        if(n&&n!==document.activeElement&&n.value===fx.v){
          n.focus({preventScroll:true});
          try{n.setSelectionRange(fx.s,fx.e)}catch(e){}
          if(n.tagName==='TEXTAREA'){n.style.height='auto';n.style.height=n.scrollHeight+'px'}
        }
      }
      /* نفس الصفحة → خلّيك في مكانك. (go() بيعمل scrollTo(0,0) بعدنا لما يكون تنقّل حقيقي) */
      if(pageKey()===k0){
        if(Math.abs(window.scrollY-y)>2)jump(y);
        Object.assign(KEEP,{y,until:Date.now()+2000,moved:false});
      }
    }catch(e){console.warn('ux-fixes',e)}
    return r;
  };
  w.__ux=1;window.R=w;
};

const boot=()=>{
  const a=document.getElementById('app');if(!a)return;
  wrapR();
  /* أي كود بيبدّل محتوى #app مباشرة (fees/attend/tabs...) هيعدّي من هنا برضه */
  new MutationObserver(()=>{try{reserve();applyTabs();hqScan()}catch(e){}}).observe(a,{childList:true});
  applyTabs();hqScan();
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();


/* ===== CREDIT-LAST: سطر "تطوير Omar Essam Elshanab" يفضل آخر الصفحة دايماً (البطاقات اللي بتتضاف بعد الرسم كانت بتنزل تحته) ===== */
(()=>{
  let busy=0;
  const fix=()=>{
    if(busy)return;const c=document.getElementById('stn-credit');
    if(c&&c.parentNode&&c.parentNode.lastElementChild!==c){busy=1;c.parentNode.appendChild(c);busy=0}
  };
  const start=()=>{const app=document.getElementById('app');if(!app)return;
    new MutationObserver(()=>{requestAnimationFrame(fix)}).observe(app,{childList:true});
    (app.parentNode&&app.parentNode!==document.body)&&new MutationObserver(()=>{requestAnimationFrame(fix)}).observe(app.parentNode,{childList:true});
    fix()};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();

/* ===== CHAT-SCROLL: شات بملء الشاشة. الفتح على آخر رسالة، مبيقفزش وانت بتقرا القديم، الكيبورد مبيغطيش مربع الكتابة، وزرار رجوع ===== */
(()=>{
  if(window.__stChat)return;window.__stChat=1;
  let lastKey='',keep={top:0,near:true},moved=false,stick=0,prev=null;
  const wbEl=()=>document.getElementById('wb');
  const near=e=>e.scrollHeight-e.scrollTop-e.clientHeight<90;
  const toBottom=()=>{const w=wbEl();if(w)w.scrollTop=w.scrollHeight};
  /* نفتكر الصفحة اللي جينا منها عشان زرار الرجوع يرجّعنا لها */
  if(typeof go==='function'){const _go=go;go=window.go=function(p,a,t){try{prev={p:V.p,a:V.a,t:V.t}}catch(e){}return _go.apply(this,arguments)}}
  window.stChatBack=()=>{const cur=V;if(prev&&prev.p&&!(prev.p===cur.p&&prev.a===cur.a&&prev.t===cur.t)&&!(prev.p==='pm'||prev.t==='chat'))return go(prev.p,prev.a,prev.t);
    return cur.p==='pm'?go('chats'):go('chats')};
  const _R=window.R;
  if(typeof _R==='function'){window.R=R=function(){
    const w=wbEl();if(w)keep={top:w.scrollTop,near:near(w)};
    const r=_R.apply(this,arguments);
    try{const nw=wbEl();document.body.classList.toggle('chat-fs',!!document.querySelector('.wa'));
      if(nw){const key=(V&&V.p)+':'+((V&&V.a)||'');
      if(key!==lastKey||keep.near){toBottom();requestAnimationFrame(toBottom);
        /* المحتوى بيكبر بعد الرسم (خطوط/صور): نفضل ملصوقين بآخر رسالة لحد ما المستخدم يحرّك الشاشة بنفسه */
        if(key!==lastKey)moved=false;const t0=Date.now();clearInterval(stick);stick=setInterval(()=>{const w=wbEl();if(!w||moved||Date.now()-t0>3500){clearInterval(stick);return}toBottom()},150)}
      else nw.scrollTop=keep.top;
      lastKey=key}else lastKey=''}catch(e){}
    return r}}
  ['wheel','touchmove','keydown','mousedown'].forEach(ev=>document.addEventListener(ev,e=>{if(e.target&&e.target.closest&&e.target.closest('#wb'))moved=true},{passive:true}));
  /* الكيبورد: visualViewport بيدّينا الارتفاع والموضع الحقيقيين المرئيين */
  const vv=window.visualViewport,setVV=()=>{try{const s=document.documentElement.style;s.setProperty('--vvh',(vv?vv.height:innerHeight)+'px');s.setProperty('--vvt',(vv?vv.offsetTop:0)+'px')}catch(e){}};
  if(vv){vv.addEventListener('resize',()=>{setVV();toBottom()});vv.addEventListener('scroll',setVV)}addEventListener('resize',setVV);setVV();
  document.addEventListener('focusin',e=>{if(e.target&&e.target.closest&&e.target.closest('.wf'))setTimeout(()=>{setVV();toBottom()},250)});
})();
/* ===== TICKS: علامة الرسالة (🕓 → ✓ → ✓✓) تتحدّث لوحدها أول ما الرسالة تتحفظ/تتقرا من غير إعادة رسم الصفحة ===== */
(()=>{
  const refresh=()=>{try{if(!document.getElementById('wb')||typeof S==='undefined'||!S.p)return;
    document.querySelectorAll('#wb .bb.me[data-m]').forEach(b=>{const x=S.p.find(y=>y.id===b.dataset.m);if(!x)return;let t=b.querySelector('.stk');if(!t)return;
      const sent=typeof BASE!=='undefined'&&BASE.p&&((x.id+'/id') in BASE.p),st=x.r?'✓✓':sent?'✓':'🕓';
      if(t.textContent!==st){t.textContent=st;t.classList.toggle('rd',!!x.r);t.title=x.r?'تمت القراءة':sent?'تم الإرسال':'قيد الإرسال'}})}catch(e){}};
  if(typeof push==='function'){const _p=push;push=window.push=async function(){const r=await _p.apply(this,arguments);refresh();return r}}
  if(typeof pull==='function'){const _l=pull;pull=window.pull=async function(){const r=await _l.apply(this,arguments);refresh();return r}}
})();
