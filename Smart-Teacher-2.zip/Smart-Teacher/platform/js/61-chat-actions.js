/* ==========================================================================
   Smart Teacher — 61-chat-actions.js : خيارات الرسائل في الشات (خاص ومجموعات)
   نسخ • رد (مع عرض الرسالة الأصلية والانتقال لها) • تعديل • حذف عندي • حذف للجميع
   حقول الرسالة الجديدة (اختيارية، ومش بتكسر الرسائل القديمة):
     rq = {i:id الرسالة الأصلية, n:اسم صاحبها, t:مقتطف}   ed = وقت التعديل   h = {uid:1} مخفية عند المستخدم ده بس
   ========================================================================== */
(()=>{
  if(window.__stActs)return;window.__stActs=1;
  const arr=k=>k==='p'?S.p:S.m,own=x=>(x.u||x.a)===S.me,esc2=t=>String(t==null?'':t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const closeSheet=()=>{const e=document.getElementById('stsheet');if(e)e.remove()};
  const sheet=html=>{closeSheet();const d=document.createElement('div');d.id='stsheet';d.className='stsheet';d.innerHTML='<div class="stsh-bg"></div><div class="stsh-box" role="dialog">'+html+'</div>';
    d.querySelector('.stsh-bg').onclick=closeSheet;document.body.appendChild(d);return d};
  const find=(k,id)=>arr(k).find(y=>y.id===id);
  window.stMsgMenu=(k,id)=>{const x=find(k,id);if(!x)return;const mine=own(x),recent=Date.now()-(x.d||0)<48*36e5;
    const act=[['copy','📋','نسخ'],['reply','↩️','رد']];if(mine&&recent)act.push(['edit','✏️','تعديل']);act.push(['delme','🙈','حذف عندي']);if(mine)act.push(['delall','🗑️','حذف للجميع']);
    const d=sheet('<p class="stsh-t">'+esc2((x.t||'').slice(0,80))+'</p>'+act.map(a=>'<button class="stsh-b" data-a="'+a[0]+'"><span>'+a[1]+'</span>'+a[2]+'</button>').join('')+'<button class="stsh-b stsh-x" data-a="x">إلغاء</button>');
    d.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>run(b.dataset.a,k,id))};
  const run=(a,k,id)=>{const x=find(k,id);if(!x){closeSheet();return}
    if(a==='x')return closeSheet();
    if(a==='copy'){closeSheet();const t=x.t||'';(navigator.clipboard&&navigator.clipboard.writeText?navigator.clipboard.writeText(t):Promise.reject()).then(()=>toast('تم النسخ ✅')).catch(()=>{const ta=document.createElement('textarea');ta.value=t;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('تم النسخ ✅')}catch(e){toast('تعذر النسخ')}ta.remove()});return}
    if(a==='reply'){closeSheet();window.__stReply={k,i:x.id,n:(U(x.u||x.a)||{}).name||'',t:(x.t||'').slice(0,90)};bar();const i=document.getElementById(k==='p'?'pt':'ct');i&&i.focus();return}
    if(a==='delme'){closeSheet();if(k==='p')x.h=Object.assign({},x.h,{[S.me]:1});else{S.hid=S.hid||{};S.hid[x.id]=1}save();R();toast('اتشالت من عندك بس');return}
    if(a==='delall'){if(!own(x))return;closeSheet();if(k==='p')S.p=S.p.filter(y=>y.id!==id);else S.m=S.m.filter(y=>y.id!==id);save();R();toast('اتحذفت عند الجميع');return}
    if(a==='edit'){if(!own(x))return;const d=sheet('<p class="stsh-t">✏️ تعديل الرسالة</p><textarea id="sted" rows="4" maxlength="2000">'+esc2(x.t)+'</textarea><div class="stsh-row"><button class="stsh-b" id="stedok">💾 حفظ</button><button class="stsh-b stsh-x" data-a="x">إلغاء</button></div>');
      d.querySelector('[data-a=x]').onclick=closeSheet;d.querySelector('#stedok').onclick=()=>{const v=d.querySelector('#sted').value.trim();if(!v)return toast('الرسالة فاضية');if(v!==x.t){x.t=v;x.ed=Date.now();save();R()}closeSheet()};setTimeout(()=>{const t=d.querySelector('#sted');t&&t.focus()},50)}};
  /* شريط الرد فوق مربع الكتابة */
  const bar=()=>{const e=document.getElementById('strb');if(!e)return;const r=window.__stReply;
    e.innerHTML=r?'<div class="strp"><span>↩️ رد على <b>'+esc2(r.n)+'</b>: '+esc2(r.t)+'</span><button aria-label="إلغاء الرد" onclick="window.__stReply=null;document.getElementById(\'strb\').innerHTML=\'\'">✕</button></div>':''};
  /* نلصق بيانات الرد في الرسالة الجديدة وقت الإرسال (من غير ما نغيّر كود الإرسال الأصلي) */
  const wrap=(name,k)=>{const f=window[name];if(typeof f!=='function')return;window[name]=function(){const r=window.__stReply,a=arr(k),before=a.length;let rs;try{rs=f.apply(this,arguments)}finally{
      if(r&&r.k===k){const cur=arr(k);if(cur.length>before){const m=cur[cur.length-1];if(m&&own(m)&&!m.rq){m.rq={i:r.i,n:r.n,t:r.t};window.__stReply=null;save();R()}}}}return rs}};
  wrap('sendP','p');wrap('chat','m');
  window.stJump=id=>{const e=document.querySelector('#wb [data-m="'+(window.CSS&&CSS.escape?CSS.escape(id):id)+'"]');if(!e){toast('الرسالة الأصلية مش موجودة');return}e.scrollIntoView({block:'center',behavior:'smooth'});e.classList.add('stflash');setTimeout(()=>e.classList.remove('stflash'),1400)};
  /* الرد لا يفضل مفتوح لو خرجنا من المحادثة */
  const _R=window.R;if(typeof _R==='function'){window.R=R=function(){const r=_R.apply(this,arguments);try{if(!document.getElementById('wb'))window.__stReply=null;else bar()}catch(e){}return r}}
})();
