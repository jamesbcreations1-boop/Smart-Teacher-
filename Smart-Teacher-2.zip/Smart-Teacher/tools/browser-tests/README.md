# اختبارات المتصفح (Python + Playwright)

محتاج: `pip install playwright` ثم `playwright install chromium`، وسيرفر محلي للمجلد:

```
cd platform && python3 -m http.server 8300
PORT=8300 python3 ../tools/browser-tests/admin_e2e.py     # دخول الإدارة ← تغيير إعدادات ← الطالب يشوفها
PORT=8300 python3 ../tools/browser-tests/admin_ctl.py     # شريط الإعلان / الصيانة / إيقاف صفحة / عنوان الموقع
PORT=8300 python3 ../tools/browser-tests/admin_tabs.py    # كل تبويبات لوحة الإدارة (أخطاء/تباين/تجاوز العرض)
PORT=8300 ONLY=default,ocean MODES=light,dark python3 ../tools/browser-tests/audit.py   # فحص تباين الألوان للثيمات
```
القاعدة وFirebase والـ Worker بتتقلّد (`lib.py`) — مفيش اتصال حقيقي بحسابك.
(الاختبارات بتفترض مسار `/tmp/br/` في بعض الملفات؛ عدّله لو شغّلتها من مكان تاني.)

اختبارات إضافية (`chat_actions.py` = خيارات الرسائل): `chat_layout.py` و`chat_ticks.py` و`data_loading.py` و`data_integrity.py` و`admin_accounts.py` و`responsive_audit.py` (WIDTHS=320,390,768 لتحديد المقاسات).
