"""لوحة الإدارة: إنشاء حساب بنوع محدد (طالب/مدرس/مدرس مساعد/ولي أمر) وتغيير كلمة مرور مستخدم — من غير أي تعديل على الـ Worker."""
import os,sys,json,hashlib; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
hp=lambda p:'h:'+hashlib.sha256(('stp|'+p).encode()).hexdigest()
def login(pg,em,pw):
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("([e,p])=>{RF={em:e,pw:p}}",[em,pw]); pg.evaluate("login()"); pg.wait_for_timeout(2600)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
def create(pg,role,name,email,phone='',sj='',pw=''):
    pg.evaluate("stA.newAcc()"); pg.wait_for_timeout(300)
    pg.select_option('#na-r',role); pg.fill('#na-n',name); pg.fill('#na-e',email); pg.fill('#na-p',phone)
    if sj and pg.is_visible('#na-s'): pg.fill('#na-s',sj)
    if pw: pg.fill('#na-w',pw)
    pg.click('#na-ok'); pg.wait_for_timeout(1500)
with sync_playwright() as p:
    br=p.chromium.launch(); ctx=br.new_context(viewport={'width':390,'height':820}); A=ctx.new_page(); ctx.route('**/*',env.route(tok_role)); errs=[]; A.on('pageerror',lambda e:errs.append(str(e)[:150]))
    login(A,'admin@admin.com','admin1020@'); A.evaluate("go('stadm');stA.tab('u')"); A.wait_for_timeout(800)
    ok('accounts tab has the "create account" button',A.evaluate("!!document.querySelector('#app button[onclick*=\"stA.newAcc\"]')"))
    A.evaluate("stA.newAcc()"); A.wait_for_timeout(300)
    opts=A.evaluate("[...document.querySelectorAll('#na-r option')].map(o=>o.value)"); ok('role choices: student / teacher / assistant / parent',opts==['student','teacher','assistant','parent'],opts)
    A.evaluate("document.querySelectorAll('.mod,.ov,.askbg').forEach(e=>e.remove())")
    made={}
    for role,name,email,ph,sj,pw in [('teacher','أ. أحمد','teacher1@x.com','01011111111','رياضيات',''),('assistant','مساعد سامي','asst1@x.com','','',' Asst12345 '.strip()),('student','طالب جديد','stud1@x.com','01022222222','',''),('parent','ولي أمر','par1@x.com','','','')]:
        create(A,role,name,email,ph,sj,pw)
        rec=next((v for v in (env.get('db/u') or {}).values() if v.get('email')==email),None)
        ok(f'create {role}: saved in the database with the right role',bool(rec) and rec['role']==role and rec['ev']==1 and rec['ok']==1,rec)
        shown=A.evaluate("(document.querySelector('.pcode')||{}).innerText||''")
        pwd=pw or (shown.split('\n')[-1].strip() if shown else '')
        ok(f'  {role}: credentials shown once and match the stored hash',bool(pwd) and rec and rec.get('pw')==hp(pwd),(shown,rec and rec.get('pw')))
        if rec and role=='teacher': ok('  teacher subject kept',rec.get('sj')=='رياضيات',rec)
        made[role]=(rec,pwd); A.evaluate("document.querySelectorAll('.mod,.ov,.askbg').forEach(e=>e.remove())")
    create(A,'student','مكرر','teacher1@x.com'); toast=A.evaluate("(document.getElementById('toast')||{}).textContent||''")
    ok('duplicate email is refused with a clear message','مستخدم' in toast and len([v for v in env.get('db/u').values() if v.get('email')=='teacher1@x.com'])==1,toast)
    A.evaluate("document.querySelectorAll('.mod,.ov,.askbg').forEach(e=>e.remove())")
    create(A,'student','بدون اسم','not-an-email'); toast=A.evaluate("(document.getElementById('toast')||{}).textContent||''"); ok('invalid email refused',('بريد' in toast),toast)
    A.evaluate("document.querySelectorAll('.mod,.ov,.askbg').forEach(e=>e.remove())")
    ok('new accounts appear in the accounts list',A.evaluate("S.u.some(u=>u.email==='teacher1@x.com'&&u.role==='teacher')"))
    ok('no password ever stored in local storage',A.evaluate("!/\\\"pw\\\"/.test(localStorage.getItem('stp')||'')"))
    # تغيير كلمة مرور مستخدم
    rec=made['student'][0]; oldhash=rec['pw']; A.evaluate("window.ask=async()=>true"); A.evaluate("id=>stA.pw(id)",rec['id']); A.wait_for_timeout(1200)
    newpw=(A.evaluate("(document.querySelector('.askbg .pcode')||{}).innerText||''")).strip(); cur=env.get('db/u/'+rec['id'])
    ok('admin resets a user password: temporary password shown',len(newpw)>=8,newpw)
    ok('  and stored as a hash the Worker accepts',cur['pw']==hp(newpw) and cur['pw']!=oldhash,(newpw,cur['pw'],hp(newpw)))
    # أمان: غير الأدمن مايقدرش يكتب
    S=ctx.new_page(); S.goto(f'http://localhost:{PORT}/index.html'); S.wait_for_timeout(1000)
    r=S.evaluate("""async()=>{const u=await fetch('https://smart-teacher-om-default-rtdb.firebaseio.com/db/u/hack1.json?auth=T:s1:student',{method:'PUT',body:'{"id":"hack1"}'});return u.status}"""); ok('a student token cannot create accounts (database rules)',r==401,r)
    ok('no page errors',not errs,errs)
    br.close()
print(sum(res),'/',len(res),'passed')
