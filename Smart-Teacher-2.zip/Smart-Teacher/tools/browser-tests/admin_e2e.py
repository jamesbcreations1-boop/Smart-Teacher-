import os,sys
import sys,os,time; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT)
res=[]; 
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
with sync_playwright() as p:
    br=p.chromium.launch()
    # ---------- admin context ----------
    ctx=br.new_context(viewport={'width':390,'height':820},device_scale_factor=2,locale='ar-EG'); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:150])); ctx.route('**/*',env.route(tok_role))
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1800)
    pg.evaluate("go('dash','login')"); pg.wait_for_timeout(500)
    inputs=pg.evaluate("[...document.querySelectorAll('#app input')].map(i=>i.type+'|'+(i.getAttribute('oninput')||'').slice(0,30))"); print('login inputs',inputs)
    pg.evaluate("RF={em:'admin@admin.com',pw:'admin1020@'}"); pg.evaluate("login()"); pg.wait_for_timeout(2500)
    st=pg.evaluate("({me:S.me,role:(me()||{}).role,page:V.p,adm:document.body.dataset.adm})")
    ok('admin logs in from normal login -> admin panel',st['me']=='admroot' and st['role']=='admin' and st['page']=='stadm' and st['adm']=='1',st)
    pg.evaluate("document.querySelectorAll('.tour').forEach(e=>e.remove())"); pg.screenshot(path=os.path.join(__import__('tempfile').gettempdir(),'adm_home.png'))
    hdr=pg.evaluate("[...document.querySelectorAll('header button')].map(b=>b.textContent.trim().slice(0,12))"); print('header buttons',hdr)
    ok('no logout / admin-gate button in header',not any('خروج' in x or 'الإدارة' in x for x in hdr),hdr)
    # feature toggle
    pg.evaluate("stA.fset('board',0)"); pg.wait_for_timeout(1500)
    ok('admin write accepted (cf)',any('cf/feat' in k for pt in env.patches for k in pt),(env.patches[-3:],env.denied))
    # appearance: site name + preset + font
    pg.evaluate("stA.tab('d')"); pg.wait_for_timeout(600)
    pg.evaluate("""(()=>{const g=i=>document.getElementById(i);g('sd-nm').value='منصة اختبار';g('sd-fs').value='1.1';stA.dpre('teal');stA.dsave()})()"""); pg.wait_for_timeout(1500)
    site=env.get('db/cf/site'); print('site cf',str(site)[:200])
    ok('appearance saved in DB',bool(site),site)
    # broadcast banner
    try:
        pg.evaluate("stA.tab('b')"); pg.wait_for_timeout(400); print('bc fn',pg.evaluate("typeof stA.bnr+typeof stA.bc"))
    except Exception as e: print('bc err',str(e)[:80])
    ok('no page errors (admin)',not errs,errs[:3])
    # ---------- student context (fresh browser profile) ----------
    ctx2=br.new_context(viewport={'width':390,'height':820},device_scale_factor=2,locale='ar-EG'); pg2=ctx2.new_page(); e2=[]
    pg2.on('pageerror',lambda e:e2.append(str(e)[:150])); ctx2.route('**/*',env.route(tok_role))
    pg2.goto(f'http://localhost:{PORT}/index.html'); pg2.wait_for_timeout(1500)
    pg2.evaluate("go('dash','login')"); pg2.evaluate("RF={em:'s1@x.com',pw:'pass1234'}"); pg2.evaluate("login()"); pg2.wait_for_timeout(2800)
    pg2.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
    info=pg2.evaluate("""({me:S.me,title:document.title,fs:getComputedStyle(document.documentElement).fontSize,nav:[...document.querySelectorAll('#bn button')].map(b=>b.textContent.trim()),acc:getComputedStyle(document.documentElement).getPropertyValue('--ac')||getComputedStyle(document.documentElement).getPropertyValue('--a')})""")
    print('student sees',info)
    ok('student logged in',info['me']=='s1',info)
    ok('site name applied in platform',info['title']=='منصة اختبار',info['title'])
    ok('disabled section (board) hidden from student nav',not any('الشرف' in x for x in info['nav']),info['nav'])
    pg2.screenshot(path=os.path.join(__import__('tempfile').gettempdir(),'stu_after_admin.png'))
    ok('no page errors (student)',not e2,e2[:3])
    br.close()
print(sum(res),'/',len(res),'passed')
