import os,sys
import sys,os,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'audit.py')).read().split("def setup")[0].split("PORT=int")[0])  # imports only
PORT=int(os.environ['PORT']); env=Env(PORT)
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'audit.py')).read(); CHECK_JS=src.split('CHECK_JS="""')[1].split('"""')[0]
OVER="""()=>{const w=document.documentElement.clientWidth;const bad=[];document.querySelectorAll('#app *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width>0&&(r.right>w+2||r.left<-2)){const cs=getComputedStyle(e);if(cs.position!=='fixed'&&!e.closest('.stn-chips,.st-settings-tabs,[style*=overflow],pre,table,.tbl,.scroll'))bad.push(e.tagName.toLowerCase()+'.'+(typeof e.className==='string'?e.className.split(' ')[0]:'')+' '+Math.round(r.left)+'..'+Math.round(r.right))}});return [...new Set(bad)].slice(0,5)}"""
with sync_playwright() as p:
    br=p.chromium.launch(); ctx=br.new_context(viewport={'width':390,'height':820},device_scale_factor=1,locale='ar-EG'); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:140])); ctx.route('**/*',env.route(tok_role))
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("RF={em:'admin@admin.com',pw:'admin1020@'}"); pg.evaluate("login()"); pg.wait_for_timeout(2500)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
    chips=pg.evaluate("[...document.querySelectorAll('.stn-chips button')].map(b=>[b.getAttribute('onclick'),b.textContent.trim()])")
    print(len(chips),'admin tabs')
    for mode in ['light','dark']:
        pg.evaluate("m=>{S.dark=m==='dark';th();R()}",mode)
        for k,(oc,label) in enumerate(chips):
            try:
                pg.evaluate("j=>{document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove());new Function(j)()}",oc); pg.wait_for_timeout(600)
                n0=len(errs)
                res=[x for x in pg.evaluate(CHECK_JS) if x['r']<3 and not x['grad']]
                ov=pg.evaluate(OVER); h=pg.evaluate("document.documentElement.scrollHeight")
                flag=('  ERR' if len(errs)>n0 else '')
                print(f"{mode:5s} {label[:22]:22s} h={h:5d} lowcontrast={len(res)} overflow={ov}{flag}")
                for x in res[:2]: print('       ',x['sel'][:40],x['r'],x['t'])
                if mode=='light': pg.screenshot(path=fos.path.join(__import__('tempfile').gettempdir(),'adm_tab_{k}.png'),full_page=True)
            except Exception as e: print('FAIL',label,str(e)[:100])
    print('page errors:',errs[:5]); br.close()
