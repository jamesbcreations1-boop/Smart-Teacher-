import os,sys
import sys,os,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT)
PRES=json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'presets.json')))
ONLY=os.environ.get('ONLY'); 
MODES=os.environ.get('MODES','light,dark').split(',')
CHECK_JS="""()=>{
 const cv=document.createElement('canvas');cv.width=cv.height=1;const cx=cv.getContext('2d',{willReadFrequently:true});
 const parse=s=>{try{cx.clearRect(0,0,1,1);cx.fillStyle='#000';cx.fillStyle=s;cx.fillRect(0,0,1,1);const d=cx.getImageData(0,0,1,1).data;return [d[0],d[1],d[2],d[3]/255]}catch(e){return [0,0,0,0]}};
 const over=(f,b)=>{const a=f[3];return [f[0]*a+b[0]*(1-a),f[1]*a+b[1]*(1-a),f[2]*a+b[2]*(1-a),1]};
 const lum=c=>{const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2])};
 const bgOf=el=>{const layers=[];let e=el;while(e&&e.nodeType===1){const cs=getComputedStyle(e);
   let bg=parse(cs.backgroundColor);
   if(cs.backgroundImage&&cs.backgroundImage!=='none'){const toks=cs.backgroundImage.match(/(rgba?\\([^)]*\\)|color\\([^)]*\\)|#[0-9a-f]{3,8})/gi);if(toks&&toks.length){const cs2=toks.map(parse);const avg=[0,1,2].map(i=>cs2.reduce((a,c)=>a+c[i],0)/cs2.length);const al=Math.max(...cs2.map(c=>c[3]));bg=[avg[0],avg[1],avg[2],Math.max(bg[3],al)];layers.push({g:1,c:bg});if(bg[3]>=.99)break;continue}}
   if(bg[3]>0)layers.push({g:0,c:bg});if(bg[3]>=.99)break;e=e.parentElement}
   let base=[255,255,255,1];const bb=parse(getComputedStyle(document.body).backgroundColor);if(bb[3]>0)base=[bb[0],bb[1],bb[2],1];else{const hb=parse(getComputedStyle(document.documentElement).backgroundColor);if(hb[3]>0)base=[hb[0],hb[1],hb[2],1]}
   for(let i=layers.length-1;i>=0;i--)base=over(layers[i].c,base);return {c:base,grad:layers.some(l=>l.g)}};
 const out=[];const seen=new Set();const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(tw.nextNode()){const n=tw.currentNode;const t=(n.nodeValue||'').trim();if(t.length<1||!/[\\p{L}\\p{N}]/u.test(t))continue;const el=n.parentElement;if(!el||seen.has(el))continue;
   if(/^(SCRIPT|STYLE|NOSCRIPT)$/.test(el.tagName))continue;
   const cs=getComputedStyle(el);if(cs.display==='none'||cs.visibility==='hidden'||+cs.opacity<.3)continue;
   const r=el.getBoundingClientRect();if(r.width<3||r.height<3)continue;
   let hid=0;for(let e=el;e&&e!==document.body;e=e.parentElement){const c2=getComputedStyle(e);if(c2.display==='none'||c2.visibility==='hidden'||+c2.opacity<.3||(c2.overflow==='hidden'&&e.getBoundingClientRect().height<3)){hid=1;break}}if(hid)continue;
   seen.add(el);
   let fg=parse(cs.webkitTextFillColor&&cs.webkitTextFillColor!==''?cs.webkitTextFillColor:cs.color);if(!(fg[3]>0))fg=parse(cs.color);
   const b=bgOf(el);const f=over(fg,b.c);
   const L1=lum(f),L2=lum(b.c),ratio=(Math.max(L1,L2)+.05)/(Math.min(L1,L2)+.05);
   const px=parseFloat(cs.fontSize),bold=+cs.fontWeight>=700,large=px>=24||(px>=18.66&&bold);
   const need=large?3:4.5;
   if(ratio<need){const sel=el.tagName.toLowerCase()+(el.className&&typeof el.className==='string'?'.'+el.className.trim().split(/\\s+/).slice(0,2).join('.'):'')+' < '+(el.parentElement?el.parentElement.tagName.toLowerCase()+(typeof el.parentElement.className==='string'&&el.parentElement.className?'.'+el.parentElement.className.trim().split(/\\s+/).slice(0,2).join('.'):''):'');
     out.push({sel,t:t.slice(0,24),r:Math.round(ratio*100)/100,need,fg:f.map(Math.round).join(','),bg:b.c.map(Math.round).join(','),grad:b.grad?1:0})}}
 return out}"""
def setup(pg,role,email=None):
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    if email:
        pg.evaluate("go('dash','login')"); pg.evaluate("e=>{RF={em:e,pw:e==='admin@admin.com'?'admin1020@':'pass1234'}}",email); pg.evaluate("login()"); pg.wait_for_timeout(2600)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
CUR={'t':None}
def apply_theme(pg,theme,mode,role=None):
    # الثيم بيتطبّق فعلياً من لوحة الإدارة (stT.apply) وبعدها كل صفحة بتعمل pull
    pg.evaluate("""([m])=>{S.dark=(m==='dark');try{localStorage.setItem('stx_theme',m)}catch(e){}try{th()}catch(e){}}""",[mode])
    if CUR['t']!=(theme['id'] if theme else None):
        pass
    pg.evaluate("async()=>{try{await pull()}catch(e){}try{R()}catch(e){}}"); pg.wait_for_timeout(300)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
def set_global_theme(pages,theme):
    adm=pages['admin']
    if theme is not None and theme.get('pal'):
        adm.evaluate("()=>{try{stT.reset()}catch(e){}}"); adm.wait_for_timeout(300); adm.evaluate("()=>{go('stadm');stA.tab('d')}"); adm.wait_for_timeout(400)
        adm.evaluate("k=>{stA.dpre(k);stA.dsave()}",theme['pal'])
    elif theme is None:
        adm.evaluate("()=>{try{stT.reset()}catch(e){}}")
    else:
        adm.evaluate("id=>{stT.pv(id)}",theme['id']); adm.wait_for_timeout(200); adm.evaluate("id=>{stT.apply(id)}",theme['id'])
    adm.wait_for_timeout(900)
VIEWS={
 'guest':[('landing',"go('dash')"),('login',"go('dash','login')"),('register',"go('dash','reg')")],
 'student':[('dash',"go('dash')"),('chats',"go('chats')"),('ai',"go('ai')"),('settings',"go('set')"),('account',"go('set',undefined,'account')")],
 'teacher':[('dash',"go('dash')"),('settings',"go('set')")],
 'admin':[('home',"go('stadm')"),('tab-d',"go('stadm');stA.tab('d')"),('tab-th',"go('stadm');stA.tab('th')"),('tab-f',"go('stadm');stA.tab('f')"),('tab-u',"go('stadm');stA.tab('u')")],
}
issues={}; shots={}
with sync_playwright() as p:
    br=p.chromium.launch(); pages={}
    for role,email in [('guest',None),('student','s1@x.com'),('teacher','t1@x.com'),('admin','admin@admin.com')]:
        ctx=br.new_context(viewport={'width':390,'height':820},device_scale_factor=1,locale='ar-EG'); pg=ctx.new_page(); ctx.route('**/*',env.route(tok_role)); pg.on('pageerror',lambda e:print('PAGEERR',role,str(e)[:100]))
        setup(pg,role,email); pages[role]=pg
        print(role,'ready', pg.evaluate("({me:S.me,p:V.p})"))
    configs=[('default',None)]+[(t['id'],t) for t in PRES]+[('pal-'+k,{'id':'pal-'+k,'pal':k}) for k in ['blue','teal','purple','rose','amber','green']]
    if ONLY: configs=[c for c in configs if c[0] in ONLY.split(',')]
    for name,theme in configs:
        set_global_theme(pages,theme); print('applied',name,str(env.get('db/cf/site'))[:90])
        for mode in MODES:
            key=f'{name}/{mode}'; issues[key]=[]
            for role,views in VIEWS.items():
                pg=pages[role]; apply_theme(pg,theme,mode)
                for vn,js in views:
                    try: pg.evaluate("j=>{document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove());new Function(j)()}",js)
                    except Exception as e: print('view fail',role,vn,str(e)[:80]); continue
                    pg.wait_for_timeout(450)
                    res=pg.evaluate(CHECK_JS)
                    for x in res: x['view']=f'{role}/{vn}'
                    issues[key]+=res
                    if os.environ.get('SHOTS') and vn in ('dash','home','landing'): pg.screenshot(path=fos.path.join(__import__('tempfile').gettempdir(),'th_{name}_{mode}_{role}_{vn}.png'))
            n=len(issues[key]); crit=sum(1 for x in issues[key] if x['r']<3)
            print(f'{key:18s} issues={n:3d} critical(<3)={crit:3d}',flush=True)
    br.close()
json.dump(issues,open(os.path.join(__import__('tempfile').gettempdir(),'audit_out.json'),'w',encoding='utf-8'),ensure_ascii=False)
