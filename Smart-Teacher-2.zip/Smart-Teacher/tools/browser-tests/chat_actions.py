"""خيارات الرسائل بين حسابين: نسخ، رد (مع الرسالة الأصلية)، تعديل، حذف عندي، حذف للجميع، وصلاحيات كل واحد."""
import os,sys,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
env.setp('db/g/g1',{'id':'g1','title':'رياضيات','t':'t1','code':'ABC123','mat':[]}); env.setp('db/g/g1/st',{'s1':{'u':'s1','s':'ok'}})
def login(pg,em):
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("e=>{RF={em:e,pw:'pass1234'}}",em); pg.evaluate("login()"); pg.wait_for_timeout(2600); pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
def texts(pg): return pg.evaluate("[...document.querySelectorAll('#wb .bb')].map(b=>b.textContent.replace(/⋯|[🕓✓]+|\\d{1,2}:\\d{2}.{0,3}/g,'').trim())")
def menu(pg,i):  # يفتح قائمة الرسالة رقم i (من الأحدث) ويرجّع أسماء الخيارات
    pg.evaluate("i=>{const b=[...document.querySelectorAll('#wb .bb')];b[b.length-1-i].querySelector('.stmb').click()}",i); pg.wait_for_timeout(250)
    return pg.evaluate("[...document.querySelectorAll('#stsheet [data-a]')].map(b=>b.dataset.a)")
def act(pg,a): pg.evaluate("a=>document.querySelector('#stsheet [data-a=\"'+a+'\"]').click()",a); pg.wait_for_timeout(300)
with sync_playwright() as p:
    br=p.chromium.launch(); errs=[]
    def mk():
        c=br.new_context(viewport={'width':390,'height':780},permissions=['clipboard-read','clipboard-write']); pg=c.new_page(); c.route('**/*',env.route(tok_role)); pg.on('pageerror',lambda e:errs.append(str(e)[:100])); return pg
    S1=mk(); T1=mk(); login(S1,'s1@x.com'); login(T1,'t1@x.com')
    S1.evaluate("go('pm','t1')"); S1.wait_for_timeout(700); S1.fill('#pt','الرسالة الأولى'); S1.click('.wf .b'); S1.wait_for_timeout(2200)
    T1.evaluate("pull()"); T1.wait_for_timeout(1200); T1.evaluate("go('pm','s1')"); T1.wait_for_timeout(1500)
    ok('both sides see the message',texts(S1)[-1].startswith('الرسالة الأولى') and texts(T1)[-1].startswith('الرسالة الأولى'),(texts(S1),texts(T1)))
    o=menu(S1,0); ok('sender menu: copy, reply, edit, delete-for-me, delete-for-everyone',set(o)=={'copy','reply','edit','delme','delall','x'},o); act(S1,'x')
    o=menu(T1,0); ok('recipient menu: NO edit / NO delete-for-everyone on someone else\'s message',set(o)=={'copy','reply','delme','x'},o)
    act(T1,'copy'); clip=T1.evaluate("navigator.clipboard.readText()"); ok('copy puts the message text in the clipboard',clip=='الرسالة الأولى',clip)
    # رد
    menu(T1,0); act(T1,'reply'); ok('reply bar shows the quoted message',T1.evaluate("(document.querySelector('.strp')||{}).textContent||''").find('الرسالة الأولى')>=0)
    T1.fill('#pt','ده ردي'); T1.click('.wf .b'); T1.wait_for_timeout(2000)
    r=next((v for v in (env.get('db/p') or {}).values() if v.get('t')=='ده ردي'),None); ok('reply stored with a pointer to the original',bool(r and r.get('rq') and r['rq'].get('t')=='الرسالة الأولى'),r)
    ok('reply bar cleared after sending',T1.evaluate("!document.querySelector('.strp')"))
    S1.evaluate("pull()"); S1.wait_for_timeout(1500); S1.evaluate("R()"); S1.wait_for_timeout(500)
    ok('the other user sees the quoted original inside the reply',S1.evaluate("!!document.querySelector('#wb .bb .stq')&&document.querySelector('#wb .bb .stq').textContent.includes('الرسالة الأولى')"))
    S1.evaluate("document.querySelector('#wb .stq').click()"); S1.wait_for_timeout(300); ok('tapping the quote jumps to (highlights) the original',S1.evaluate("!!document.querySelector('#wb .bb.stflash')"))
    # تعديل
    S1.wait_for_timeout(1500); idx=S1.evaluate("[...document.querySelectorAll('#wb .bb')].findIndex(b=>b.textContent.includes('الرسالة الأولى')&&!b.querySelector('.stq'))")
    n=S1.evaluate("document.querySelectorAll('#wb .bb').length"); menu(S1,n-1-idx); act(S1,'edit'); S1.fill('#sted','الرسالة بعد التعديل'); S1.click('#stedok'); S1.wait_for_timeout(2200)
    d=next((v for v in (env.get('db/p') or {}).values() if v.get('ed')),None); ok('edit saved (with edit time) in the database',bool(d and d['t']=='الرسالة بعد التعديل'),d)
    T1.evaluate("pull()"); T1.wait_for_timeout(1500); T1.evaluate("R()"); T1.wait_for_timeout(500)
    ok('the other user sees the edited text and the (edited) label',T1.evaluate("[...document.querySelectorAll('#wb .bb')].some(b=>b.textContent.includes('الرسالة بعد التعديل')&&b.textContent.includes('معدّلة'))"))
    # حذف عندي
    i2=T1.evaluate("[...document.querySelectorAll('#wb .bb')].findIndex(b=>b.textContent.includes('الرسالة بعد التعديل'))"); n2=T1.evaluate("document.querySelectorAll('#wb .bb').length"); menu(T1,n2-1-i2); act(T1,'delme'); T1.wait_for_timeout(1800)
    ok('delete-for-me hides it only for that user',not any('الرسالة بعد التعديل' in t for t in texts(T1)),texts(T1))
    S1.evaluate("pull()"); S1.wait_for_timeout(1200); ok('...and it is still there for the sender',any('الرسالة بعد التعديل' in t for t in texts(S1)),texts(S1))
    # حذف للجميع
    i3=S1.evaluate("[...document.querySelectorAll('#wb .bb')].findIndex(b=>b.textContent.includes('الرسالة بعد التعديل'))"); n3=S1.evaluate("document.querySelectorAll('#wb .bb').length"); menu(S1,n3-1-i3); act(S1,'delall'); S1.wait_for_timeout(2200)
    ok('delete-for-everyone removes it from the database',not any(v.get('t')=='الرسالة بعد التعديل' for v in (env.get('db/p') or {}).values()))
    T1.evaluate("pull()"); T1.wait_for_timeout(1200); ok('...and from the other user\'s screen',not any('الرسالة بعد التعديل' in t for t in texts(T1)))
    # مجموعة
    S1.evaluate("go('group','g1','chat')"); S1.wait_for_timeout(1500); S1.fill('#ct','رسالة في الجروب'); S1.click('.wa .wf .b'); S1.wait_for_timeout(2200)
    T1.evaluate("pull()"); T1.wait_for_timeout(1000); T1.evaluate("go('group','g1','chat')"); T1.wait_for_timeout(1500)
    o=menu(T1,0); ok('group chat: menu works for the teacher on a student message',{'copy','reply','delme'}<=set(o) and 'edit' not in o,o); act(T1,'reply'); T1.fill('#ct','رد في الجروب'); T1.click('.wa .wf .b'); T1.wait_for_timeout(2000)
    g=next((v for v in (env.get('db/m') or {}).values() if v.get('t')=='رد في الجروب'),None); ok('group reply keeps the quote',bool(g and g.get('rq') and 'رسالة في الجروب' in g['rq']['t']),g)
    # حذف عندي في المجموعة = على الجهاز بس (القواعد مبتسمحش بتعديل رسالة غيرك)
    n=T1.evaluate("document.querySelectorAll('#wb .bb').length"); i=T1.evaluate("[...document.querySelectorAll('#wb .bb')].findIndex(b=>b.textContent.includes('رسالة في الجروب')&&!b.querySelector('.stq'))")
    menu(T1,n-1-i); act(T1,'delme'); T1.wait_for_timeout(1500)
    ok('group delete-for-me hides it locally',not any(t.startswith('رسالة في الجروب') for t in texts(T1)),texts(T1))
    ok('...without touching the message in the database',any(v.get('t')=='رسالة في الجروب' and not v.get('h') for v in (env.get('db/m') or {}).values()))
    # الطالب يحذف رسالته للجميع في المجموعة (كان مرفوض بالقواعد القديمة)
    S1.evaluate("pull()"); S1.wait_for_timeout(1000); S1.evaluate("go('group','g1','chat')"); S1.wait_for_timeout(1200)
    n=S1.evaluate("document.querySelectorAll('#wb .bb').length"); i=S1.evaluate("[...document.querySelectorAll('#wb .bb')].findIndex(b=>b.textContent.includes('رسالة في الجروب')&&!b.querySelector('.stq'))")
    menu(S1,n-1-i); act(S1,'delall'); S1.wait_for_timeout(2200)
    ok('student deletes his own group message for everyone (allowed by the rules)',not any(v.get('t')=='رسالة في الجروب' for v in (env.get('db/m') or {}).values()),[v.get('t') for v in (env.get('db/m') or {}).values()])
    ok('no write was rejected by the database rules (a rejected path would block all sync)',not env.denied,env.denied)
    ok('no page errors',not errs,errs); br.close()
print(sum(res),'/',len(res),'passed')
