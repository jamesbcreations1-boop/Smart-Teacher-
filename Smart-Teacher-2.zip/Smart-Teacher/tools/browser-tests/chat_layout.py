"""الشات بملء الشاشة (خاص + مجموعة): مربع الكتابة ثابت تحت الشاشة، الهيدر فوق، القائمة بتتمرّر، بيفتح على آخر رسالة، زرار الرجوع بيشتغل، والكيبورد مبيغطيش الكتابة."""
import os,sys,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
M="""()=>{const wa=document.querySelector('.wa'),wb=document.getElementById('wb'),wf=document.querySelector('.wa .wf'),wh=document.querySelector('.wa .wh'),bn=document.getElementById('bn');if(!wa||!wb||!wf)return null;
 const r=e=>e.getBoundingClientRect();return {vh:innerHeight,wa:[Math.round(r(wa).top),Math.round(r(wa).bottom)],wf:[Math.round(r(wf).top),Math.round(r(wf).bottom)],wh:Math.round(r(wh).top),bn:bn?getComputedStyle(bn).display:'none',
  scrolls:wb.scrollHeight>wb.clientHeight+5,atBottom:Math.abs(wb.scrollTop+wb.clientHeight-wb.scrollHeight)<30,hscroll:document.documentElement.scrollWidth>innerWidth+1,back:!!wh.querySelector('.stbk')}}"""
for W,H in [(390,780),(768,1024),(1280,800)]:
    env=Env(PORT)
    env.setp('db/g/g1',{'id':'g1','title':'الصف الثاني ثانوي','t':'t1','code':'ABC123','mat':[]}); env.setp('db/g/g1/st',{'s1':{'u':'s1','s':'ok'}})
    for i in range(60):
        env.setp(f'db/p/m{i}',{'id':f'm{i}','a':'t1' if i%2 else 's1','b':'s1' if i%2 else 't1','t':f'رسالة رقم {i} '+('نص طويل '*(i%5)),'d':1700000000000+i*60000})
        env.setp(f'db/m/gm{i}',{'id':f'gm{i}','g':'g1','u':'t1' if i%2 else 's1','t':f'رسالة مجموعة {i} '+('كلام '*(i%6)),'d':1700000000000+i*60000})
    with sync_playwright() as p:
        br=p.chromium.launch(); ctx=br.new_context(viewport={'width':W,'height':H},locale='ar-EG'); pg=ctx.new_page(); ctx.route('**/*',env.route(tok_role)); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:100]))
        pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
        pg.evaluate("go('dash','login')"); pg.evaluate("RF={em:'s1@x.com',pw:'pass1234'}"); pg.evaluate("login()"); pg.wait_for_timeout(2600)
        pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
        for name,js,backTo in [('private chat',"go('chats');",'chats'),('group chat',"go('group','g1','chat')",None)]:
            if name=='private chat':
                pg.evaluate("go('chats')"); pg.wait_for_timeout(500); pg.evaluate("go('pm','t1')")
            else:
                pg.evaluate("go('group','g1','ex')"); pg.wait_for_timeout(500); pg.evaluate("go('group','g1','chat')")
            pg.wait_for_timeout(1800); r=pg.evaluate(M); tag=f'{W}px {name}'
            if not r: ok(tag+': chat opened',False,pg.evaluate("V.p+':'+V.a+':'+V.t")); continue
            ok(tag+': takes the whole screen (header at top, composer at the very bottom)',r['wa'][0]==0 and r['wf'][1]>=r['vh']-1 and r['wh']==0,r)
            ok(tag+': bottom nav hidden behind the full-screen chat',r['bn']=='none',r['bn'])
            ok(tag+': messages area scrolls, opens at the latest message',r['scrolls'] and r['atBottom'],r)
            ok(tag+': no horizontal scroll, back button present',not r['hscroll'] and r['back'],r)
            # الكيبورد: لو الارتفاع المرئي صغر، المربع لازم يطلع معاه
            pg.evaluate("document.documentElement.style.setProperty('--vvh','"+str(int(H*0.55))+"px')"); pg.wait_for_timeout(200)
            r2=pg.evaluate(M); ok(tag+': composer stays visible when the keyboard shrinks the viewport',r2['wf'][1]<=int(H*0.55)+1,r2); pg.evaluate("document.documentElement.style.removeProperty('--vvh')")
            pg.evaluate("document.querySelector('.wa .stbk').click()"); pg.wait_for_timeout(900)
            gone=pg.evaluate("!document.querySelector('.wa')&&document.getElementById('bn')&&getComputedStyle(document.getElementById('bn')).display!=='none'"); where=pg.evaluate("V.p+':'+(V.t||'')")
            ok(tag+': back button leaves the chat and restores the app',gone,where); print('     went back to ->',where)
        ok(f'{W}px: no page errors',not errs,errs); br.close()

# المدرس: زرار «منع الطلاب» جوه الشات الكامل
env=Env(PORT); env.setp('db/g/g1',{'id':'g1','title':'ص','t':'t1','code':'A','mat':[]}); env.setp('db/g/g1/st',{'s1':{'u':'s1','s':'ok'}})
with sync_playwright() as p:
    br=p.chromium.launch(); ctx=br.new_context(viewport={'width':390,'height':780}); pg=ctx.new_page(); ctx.route('**/*',env.route(tok_role))
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("RF={em:'t1@x.com',pw:'pass1234'}"); pg.evaluate("login()"); pg.wait_for_timeout(2600); pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
    pg.evaluate("go('group','g1','chat')"); pg.wait_for_timeout(1500)
    ok('teacher: mute-students button is inside the full-screen chat (reachable)',pg.evaluate("!!document.querySelector('.wa .wh .stmute')&&document.querySelector('.wa .wh .stmute').getBoundingClientRect().bottom<200"))
    pg.evaluate("document.querySelector('.wa .stmute').click()"); pg.wait_for_timeout(1800)
    ok('  pressing it closes writing for students and it reaches the database',env.get('db/g/g1/chatOff')==1,env.get('db/g/g1'))
    ok('  the teacher can still type while students are muted',pg.evaluate("!!document.querySelector('.wa .wf input')"))
    br.close()
print(sum(res),'/',len(res),'passed')
