"""شات تيليجرام: علامات 🕓 ✓ ✓✓ بين حسابين + أمان الرسائل الخاصة"""
import sys,os,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
env.setp('db/g/g1',{'id':'g1','title':'رياضيات','t':'t1','code':'ABC123','mat':[]}); env.setp('db/g/g1/st',{'s1':{'u':'s1','s':'ok'}})
def login(pg,em):
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("e=>{RF={em:e,pw:'pass1234'}}",em); pg.evaluate("login()"); pg.wait_for_timeout(2600); pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
with sync_playwright() as p:
    br=p.chromium.launch(); errs=[]
    def mk():
        c=br.new_context(viewport={'width':390,'height':780}); pg=c.new_page(); c.route('**/*',env.route(tok_role)); pg.on('pageerror',lambda e:errs.append(str(e)[:100])); return pg
    S1=mk(); T1=mk(); login(S1,'s1@x.com'); login(T1,'t1@x.com')
    S1.evaluate("go('pm','t1')"); S1.wait_for_timeout(800)
    S1.fill('#pt','مرحبا يا أستاذ'); S1.click('.wf .b'); 
    tk=lambda:S1.evaluate("(()=>{const m=[...document.querySelectorAll('#wb .bb.me')].pop();const t=m&&m.querySelector('.stk');return t?t.textContent:null})()")
    S1.wait_for_timeout(150); first=tk(); print('   right after send:',first)
    S1.wait_for_timeout(2200); ok('sender sees ✓ (saved on the server) after sending',tk()=='✓',tk())
    msg=next((v for v in (env.get('db/p') or {}).values() if v.get('t')=='مرحبا يا أستاذ'),None); ok('message stored in the database',bool(msg) and 'r' not in msg,msg)
    ok('✓ is NOT shown as read before the other side opens the chat','rd' not in (S1.evaluate("(()=>{const m=[...document.querySelectorAll('#wb .bb.me')].pop();return m.querySelector('.stk').className})()")))
    T1.evaluate("pull()"); T1.wait_for_timeout(1200); T1.evaluate("go('pm','s1')"); T1.wait_for_timeout(2500)
    msg=next((v for v in (env.get('db/p') or {}).values() if v.get('t')=='مرحبا يا أستاذ'),None); ok('recipient opening the chat marks it read in the database',bool(msg and msg.get('r')),msg)
    S1.evaluate("pull()"); S1.wait_for_timeout(1500); S1.evaluate("R()"); S1.wait_for_timeout(500)
    ok('sender now sees ✓✓ (read)',tk()=='✓✓' and 'rd' in S1.evaluate("(()=>{const m=[...document.querySelectorAll('#wb .bb.me')].pop();return m.querySelector('.stk').className})()"),tk())
    # offline: clock while not delivered
    env.offline=True; S1.fill('#pt','رسالة بدون نت'); S1.click('.wf .b'); S1.wait_for_timeout(1500)
    ok('while offline the message shows 🕓 (sending)',tk()=='🕓',tk())
    env.offline=False; S1.evaluate("(async()=>{await push()})()"); S1.wait_for_timeout(2500)
    ok('after reconnect it becomes ✓ and is saved once (no duplicate)',tk()=='✓' and sum(1 for v in (env.get('db/p') or {}).values() if v.get('t')=='رسالة بدون نت')==1,(tk()))

    # أمان: مستخدم ثالث مش طرف في المحادثة
    env.setp('db/p/secret1',{'id':'secret1','a':'t1','b':'t2other','t':'رسالة سرية بين مدرسين','d':1})
    S1.evaluate("pull()"); S1.wait_for_timeout(1500)
    ok('security: student does NOT receive other people\'s private messages',not S1.evaluate("S.p.some(x=>x.id==='secret1')"),S1.evaluate("S.p.map(x=>x.id)"))
    code=S1.evaluate("async()=>{const t=await idToken();const r=await fetch(DB+'/db/p.json?auth='+t);return r.status}")
    ok('security: reading the whole private-messages table is rejected (401)',code==401,code)
    code=S1.evaluate("async()=>{const t=await idToken();const r=await fetch(DB+'/db/p.json?auth='+t+'&orderBy=%22a%22&equalTo=%22t1%22');return r.status}")
    ok('security: querying someone else\'s messages is rejected (401)',code==401,code)
    ok('security: own conversation still loads fine',S1.evaluate("S.p.some(x=>x.t==='مرحبا يا أستاذ')"))
    ok('no page errors',not errs,errs); br.close()
print(sum(res),'/',len(res))
