"""يتأكد إن البيانات بتتحفظ وبتتزامن صح: حفظ، قراءة من جهاز تاني، تعديلين في نفس الوقت، قطع النت وإرجاعه، الحذف."""
import os,sys,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
def login(pg,em,pw):
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(1500)
    pg.evaluate("go('dash','login')"); pg.evaluate("([e,p])=>{RF={em:e,pw:p}}",[em,pw]); pg.evaluate("login()"); pg.wait_for_timeout(2600)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
def mk(br):
    c=br.new_context(viewport={'width':390,'height':820}); p=c.new_page(); c.route('**/*',env.route(tok_role)); errs=[]; p.on('pageerror',lambda e:errs.append(str(e)[:120])); return p,errs
G=lambda pg,gid='g1':pg.evaluate("id=>{const g=S.g.find(x=>x.id===id);return g?{title:g.title,lock:g.lock||0,dsc:g.dsc||''}:null}",gid)
with sync_playwright() as p:
    br=p.chromium.launch(); A1,e1=mk(br); A2,e2=mk(br); B,e3=mk(br)
    login(A1,'t1@x.com','pass1234'); login(A2,'t1@x.com','pass1234'); login(B,'s1@x.com','pass1234')
    # 1) حفظ ومشاركة
    A1.evaluate("S.g.push({id:'g1',title:'رياضيات',t:'t1',code:'ABC123',st:[],mat:[]});save()"); A1.wait_for_timeout(1600)
    d=env.get('db/g/g1') or {}; ok('1. new group saved to the database',d.get('title')=='رياضيات' and d.get('t')=='t1',d)
    B.evaluate("pull()"); B.wait_for_timeout(1200); ok('2. another user (student) sees the group',(G(B) or {}).get('title')=='رياضيات',G(B))
    # 3) تعديل نفس السجل من جهازين في نفس الوقت (حقول مختلفة)
    A1.evaluate("pull()"); A2.evaluate("pull()"); A1.wait_for_timeout(900); A2.wait_for_timeout(900)
    A1.evaluate("S.g.find(x=>x.id==='g1').title='رياضيات 2';save()"); A2.evaluate("S.g.find(x=>x.id==='g1').lock=1;save()"); A1.wait_for_timeout(1800); A2.wait_for_timeout(1800)
    d=env.get('db/g/g1'); ok('3. two devices edit different fields at once -> both edits kept',d.get('title')=='رياضيات 2' and d.get('lock')==1,d)
    A1.evaluate("pull()"); A2.evaluate("pull()"); A1.wait_for_timeout(1200); A2.wait_for_timeout(1200)
    ok('   both devices converge to the same state',G(A1)==G(A2) and G(A1)['lock']==1 and G(A1)['title']=='رياضيات 2',(G(A1),G(A2)))
    # 4) قطع النت: تعديل محلي + تعديل بعيد، وبعدين النت يرجع
    env.offline=True; A1.evaluate("S.g.find(x=>x.id==='g1').title='تعديل أوفلاين';save()"); A1.wait_for_timeout(1500)
    ok('4. offline edit is kept locally, database not changed yet',G(A1)['title']=='تعديل أوفلاين' and env.get('db/g/g1').get('title')=='رياضيات 2',(G(A1),env.get('db/g/g1')))
    env.offline=False; env.setp('db/g/g1/dsc','وصف من جهاز تاني')   # تعديل حصل على السيرفر أثناء قطع النت
    A1.evaluate("(async()=>{await push();await pull()})()"); A1.wait_for_timeout(2500)
    d=env.get('db/g/g1'); ok('5. after reconnect: offline edit reached the database',d.get('title')=='تعديل أوفلاين',d)
    ok('   and the remote edit made meanwhile was not lost',d.get('dsc')=='وصف من جهاز تاني' and G(A1)['dsc']=='وصف من جهاز تاني',(d,G(A1)))
    # 6) الحذف
    A2.evaluate("pull()"); A2.wait_for_timeout(1000)
    A2.evaluate("S.g=S.g.filter(x=>x.id!=='g1');save()"); A2.wait_for_timeout(1800)
    ok('6. delete reaches the database',env.get('db/g/g1') is None,env.get('db/g/g1'))
    A1.evaluate("pull()"); B.evaluate("pull()"); A1.wait_for_timeout(1200); B.wait_for_timeout(1200)
    ok('   and disappears on the other devices',G(A1) is None and G(B) is None,(G(A1),G(B)))
    # 7) refresh الصفحة: البيانات والجلسة
    A1.evaluate("S.n.push({id:'nx1',to:'t1',t:'اختبار',d:Date.now(),r:0});save()"); A1.wait_for_timeout(1600)
    A1.reload(); A1.wait_for_timeout(2500)
    ok('7. after a page refresh: still logged in and data intact',A1.evaluate("S.me")=='t1' and A1.evaluate("S.n.some(n=>n.id==='nx1')"),(A1.evaluate("S.me")))
    ok('   notification stored in the database',bool(env.get('db/n/nx1')),env.get('db/n/nx1'))
    # 8) لا بيانات حساسة على الجهاز / في المزامنة
    ok('8. password hashes never in local storage',A1.evaluate("!/\"pw\"/.test(localStorage.getItem('stp')||'')"))
    ok('   and never pushed from the browser',not any(('/pw' in k) for pt in env.patches for k in pt),[k for pt in env.patches for k in pt if '/pw' in k])
    ok('no page errors',not (e1 or e2 or e3),(e1,e2,e3))
    br.close()
print(sum(res),'/',len(res),'passed')
