"""يتأكد إن كل صفحة بتحمّل جداولها بس (مش كل بيانات الموقع)، وإن الزائر بياخد الإعدادات العامة من غير ما ياخد 401."""
import os,sys,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); env=Env(PORT); res=[]
def ok(n,c,x=''): res.append(c); print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(x)))
def cols(): return sorted(set(p.split('/')[-1] for p,_ in env.reads))
def login(pg,em,pw):
    pg.evaluate("go('dash','login')"); pg.evaluate("([e,p])=>{RF={em:e,pw:p}}",[em,pw]); pg.evaluate("login()"); pg.wait_for_timeout(2600)
    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())")
def nav(pg,js,wait=1700):
    env.reads.clear(); pg.evaluate(js); pg.wait_for_timeout(wait)
with sync_playwright() as p:
    br=p.chromium.launch()
    # ---- زائر ----
    ctx=br.new_context(viewport={'width':390,'height':820}); pg=ctx.new_page(); ctx.route('**/*',env.route(tok_role)); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
    env.setp('db/cf/site',{'id':'site','nm':'اسم عام'}); env.setp('db/cf/admpw',{'id':'admpw','h':'x'})
    pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(2500)
    ok('guest: only public site settings + news are read (no 401, no users/groups)',not env.unauth and not env.reads and env.pubreads and all(x=='db/nw' or x.startswith('db/cf/') for x in env.pubreads),(env.pubreads,env.unauth,env.reads))
    ok('guest: site config arrived',pg.evaluate("document.title")=='اسم عام' or pg.evaluate("(S.cf||[]).some(x=>x.id==='site')"),pg.evaluate("document.title"))
    ok('guest: admin-only config never requested',not any(x.endswith('admpw') or x.endswith('audit') for x in env.pubreads),env.pubreads)
    # ---- طالب ----
    login(pg,'s1@x.com','pass1234'); ok('student logged in',pg.evaluate("S.me")=='s1')
    nav(pg,"go('dash')"); c=cols(); print('  dash ->',c)
    ok('dash: core + dash tables loaded',all(x in c for x in ['u','g','n','cf','nw','e','s','m','p']),c)
    ok('dash: does NOT load community / disputes / support / battles / admin tables',not any(x in c for x in ['f','fc','fl','ff','d','bt','sup','sm','sp','k']),c)
    nav(pg,"go('ai')"); c=cols(); print('  ai ->',c)
    ok('ai page: only the basics',sorted(c)==sorted(['u','g','n','cf','nw']),c)
    nav(pg,"ST.tab='all';go('soc')"); c=cols(); print('  soc ->',c)
    ok('community page: loads posts/comments/likes/follows',all(x in c for x in ['f','fc','fl','ff']),c)
    ok('community page: no exams/attendance/fees',not any(x in c for x in ['e','s','at','pay','ev']),c)
    nav(pg,"go('set')"); c=cols(); print('  settings ->',c)
    ok('settings: support tables only here',all(x in c for x in ['sup','sm']) and not any(x in c for x in ['f','e','s','at']),c)
    nav(pg,"go('chats')"); c=cols(); print('  chats ->',c)
    ok('chats: messages loaded, not exams',all(x in c for x in ['m','p']) and not any(x in c for x in ['e','s','at','f']),c)
    ok('no 401 for a logged-in student',not env.unauth,env.unauth)
    # ---- أدمن ----
    ctxA=br.new_context(viewport={'width':390,'height':820}); A=ctxA.new_page(); ctxA.route('**/*',env.route(tok_role)); ea=[]; A.on('pageerror',lambda e:ea.append(str(e)[:120]))
    A.goto(f'http://localhost:{PORT}/index.html'); A.wait_for_timeout(1500); login(A,'admin@admin.com','admin1020@')
    nav(A,"go('stadm')",2200); c=cols(); print('  admin panel ->',c)
    ok('admin panel: loads everything it needs to show stats',all(x in c for x in ['u','g','e','s','m','sup','sm','sp']),c)
    nav(A,"go('set')"); c=cols(); print('  admin settings ->',c)
    ok('admin on a normal page: only that page tables (not everything)',len(c)<=8 and 'sp' not in c,c)
    ok('no page errors',not errs and not ea,(errs,ea))
    br.close()
print(sum(res),'/',len(res),'passed')
