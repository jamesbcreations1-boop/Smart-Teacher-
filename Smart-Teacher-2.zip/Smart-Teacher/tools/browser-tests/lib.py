import os,json,base64,io,sys,copy
import urllib.parse as up
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
DBU='firebaseio.com'
FB_STUB="""(()=>{let cur=null;const L=[];const mk=(t)=>{const p=t.split(':');const jwt='eyJhbGciOiJub25lIn0.'+btoa(JSON.stringify({user_id:p[1],sub:p[1],role:p[2]})).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'')+'.sig';return{uid:p[1],isAnonymous:false,role:p[2],getIdToken:async()=>jwt}};
window.firebase={initializeApp(){},apps:[],messaging(){return{}},auth(){return{onAuthStateChanged(cb){L.push(cb);setTimeout(()=>cb(cur),0)},get currentUser(){return cur},signInWithCustomToken:async(t)=>{cur=mk(t);L.forEach(f=>f(cur))},signOut:async()=>{cur=null},signInAnonymously:async()=>{}}}}})();"""
def new_db():
    return {'db':{'u':{
      'admroot':{'id':'admroot','name':'الإدارة','email':'admin@admin.com','role':'admin','ok':1,'ev':1,'pv':1},
      's1':{'id':'s1','name':'Student One','email':'s1@x.com','role':'student','ok':1,'ev':1,'pv':1,'av':AV()},
      't1':{'id':'t1','name':'Teacher One','email':'t1@x.com','role':'teacher','ok':1,'ev':1,'pv':1,'av':AV()}},
      'g':{},'e':{},'s':{},'m':{},'n':{},'p':{},'k':{},'nw':{},'cf':{},'sp':{}}}
def AV():
    from PIL import Image
    im=Image.new('RGB',(120,120),(90,140,200)); b=io.BytesIO(); im.save(b,'JPEG',quality=60); return 'data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
USERS={'admin@admin.com':('admin1020@','admroot','admin'),'s1@x.com':('pass1234','s1','student'),'t1@x.com':('pass1234','t1','teacher')}
def check_rules(env,path,body,uid,role):
    """يقلّد قواعد الكتابة على الرسائل (db/m و db/p). بيرجّع نص السبب لو في كتابة مرفوضة."""
    if role=='admin': return None
    base=path.strip('/'); changes={}
    for k,v in body.items():
        full=(base+'/'+k).strip('/').split('/')
        if len(full)>=3 and full[0]=='db' and full[1] in('m','p'): changes.setdefault((full[1],full[2]),[]).append((full[3:],v))
    for (col,mid),ch in changes.items():
        old=env.get(f'db/{col}/{mid}'); new=json.loads(json.dumps(old)) if old else None
        for sub,v in ch:
            if not sub: new=v
            else:
                if new is None: new={}
                d=new
                for q in sub[:-1]: d=d.setdefault(q,{})
                if v is None: d.pop(sub[-1],None)
                else: d[sub[-1]]=v
        def tea(g): 
            gg=env.get(f'db/g/{g}') or {}; return gg.get('t')==uid or uid in (gg.get('as') or {})
        if new:   # كتابة/تعديل
            if col=='m': okw=new.get('u')==uid or tea(new.get('g'))
            else: okw=new.get('a')==uid or new.get('b')==uid or tea(new.get('g'))
        else:     # حذف: بنبص على الرسالة الموجودة
            if col=='m': okw=bool(old) and (old.get('u')==uid or tea(old.get('g')))
            else: okw=bool(old) and old.get('a')==uid
        if not okw: return f'WRITE denied on {col}/{mid}'
    return None
class Env:
    def __init__(self,port): self.port=port; self.db=new_db(); self.patches=[]; self.denied=[]; self.reads=[]; self.offline=False; self.unauth=[]; self.pubreads=[]; self.puts=[]
    def get(self,path):
        d=self.db
        for k in [x for x in path.split('/') if x]:
            d=(d or {}).get(k) if isinstance(d,dict) else None
        return d
    def setp(self,path,v):
        ks=[x for x in path.split('/') if x]; d=self.db
        for k in ks[:-1]: d=d.setdefault(k,{})
        if v is None:
            d.pop(ks[-1],None)
            for i in range(len(ks)-1,0,-1):
                par=self.get('/'.join(ks[:i]))
                if isinstance(par,dict) and not par: self.get('/'.join(ks[:i-1])).pop(ks[i-1],None) if ks[:i-1] else self.db.pop(ks[0],None)
                else: break
        else: d[ks[-1]]=v
    def route(self,role_of):
        def h(r):
            u=r.request.url
            if u.endswith('/firebase-config.js'): return r.fulfill(body="self.ST_FB={apiKey:'AIzaTEST',authDomain:'t.firebaseapp.com',databaseURL:'https://smart-teacher-om-default-rtdb.firebaseio.com',projectId:'t',appId:'1:1:web:1',messagingSenderId:'1'};self.ST_WORKER_URL='https://smart-teacher-api.test.workers.dev';",content_type='application/javascript')
            if u.startswith(f'http://localhost:{self.port}'): return r.continue_()
            if 'gstatic.com/firebasejs' in u: return r.fulfill(body=FB_STUB,content_type='application/javascript')
            if self.offline and ('workers.dev' in u or DBU in u): return r.abort()
            if 'workers.dev' in u:
                if u.endswith('/login'):
                    b=json.loads(r.request.post_data or '{}'); e=USERS.get((b.get('id') or '').lower())
                    if e and e[0]==b.get('password'): return r.fulfill(body=json.dumps({'ok':True,'token':f'T:{e[1]}:{e[2]}','uid':e[1],'role':e[2]}),content_type='application/json',headers={'access-control-allow-origin':'*'})
                    return r.fulfill(status=401,body=json.dumps({'ok':False,'reason':'bad_pw'}),content_type='application/json',headers={'access-control-allow-origin':'*'})
                return r.fulfill(body='{}',content_type='application/json',headers={'access-control-allow-origin':'*'})
            if DBU in u:
                tok=''
                import urllib.parse as up
                q=up.parse_qs(up.urlparse(u).query); tok=(q.get('auth') or [''])[0]
                role=role_of(tok)
                path=u.split(DBU+'/')[1].split('.json')[0]
                if not tok and r.request.method=='GET':
                    pp=path.strip('/').split('/')
                    if path.strip('/')=='db/nw' or (len(pp)==3 and pp[:2]==['db','cf'] and pp[2] in ['site','brand','themes','cthemes','txt','banner','bsch','ctl','maint','feat','supc','socs','sub','subc']):
                        self.pubreads.append(path); return r.fulfill(body=json.dumps(copy.deepcopy(self.get(path))),content_type='application/json')
                    self.unauth.append(path); return r.fulfill(status=401,body='{"error":"Permission denied"}',content_type='application/json')
                if r.request.method=='PUT':
                    fp=path.strip('/')
                    if fp.startswith('db/u/') and role!='admin' and not fp.startswith('db/u/'+(tok_info(tok)[0] or '?')): self.denied.append(fp); return r.fulfill(status=401,body='{"error":"Permission denied"}',content_type='application/json')
                    self.setp(fp,json.loads(r.request.post_data or 'null')); self.puts.append(fp); return r.fulfill(body=r.request.post_data or 'null',content_type='application/json')
                if r.request.method=='GET': self.reads.append((path,role))
                if r.request.method=='GET' and path.strip('/')=='db/p' and role!='admin':
                    # يقلّد قاعدة القراءة بالاستعلام: لازم orderBy + equalTo = uid الشخص نفسه
                    qs=up.parse_qs(up.urlparse(u).query); ob=(qs.get('orderBy') or [''])[0].strip('"'); eq=(qs.get('equalTo') or [''])[0].strip('"'); me_uid=tok_info(tok)[0]
                    if ob not in('a','b') or eq!=me_uid: self.denied.append('READ db/p without own-uid query'); return r.fulfill(status=401,body='{"error":"Permission denied"}',content_type='application/json')
                    allp=self.get('db/p') or {}; return r.fulfill(body=json.dumps({k:v for k,v in allp.items() if v.get(ob)==eq}),content_type='application/json')
                if r.request.method=='PATCH':
                    body=json.loads(r.request.post_data or '{}')
                    why=check_rules(self,path,body,tok_info(tok)[0],role)
                    if why: self.denied.append(why); return r.fulfill(status=401,body='{"error":"Permission denied"}',content_type='application/json')
                    # emulate rules: cf writes need admin
                    for k,v in body.items():
                        full=(path.strip('/')+'/'+k).strip('/')
                        if full.startswith('db/cf/') and role!='admin': self.denied.append(full); return r.fulfill(status=401,body='{"error":"Permission denied"}',content_type='application/json')
                    for k,v in body.items(): self.setp((path.strip('/')+'/'+k).strip('/'),v)
                    self.patches.append(body); return r.fulfill(body='{}',content_type='application/json')
                return r.fulfill(body=json.dumps(copy.deepcopy(self.get(path)) or {}),content_type='application/json')
            return r.abort()
        return h
def tok_info(tok):
    """(uid, role) من توكن الدخول — JWT حقيقي الشكل (payload = base64) أو الصيغة القديمة T:uid:role"""
    try:
        parts=tok.split('.')
        if len(parts)==3:
            import base64 as b; pl=json.loads(b.urlsafe_b64decode(parts[1]+'='*(-len(parts[1])%4))); return pl.get('user_id',''),pl.get('role','')
    except Exception: pass
    p=tok.split(':'); return (p[1],p[2]) if len(p)>2 else ('','')
def tok_role(tok): return tok_info(tok)[1]
