"""يفحص الصفحات على 11 مقاس شاشة: عرض أفقي زيادة، عناصر خارج الشاشة، نص مقطوع، تداخل مع الشريط السفلي."""
import os,sys,json; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); from lib import *
PORT=int(os.environ['PORT']); WIDTHS=[int(x) for x in os.environ.get('WIDTHS','320,360,375,390,414,430,768,1024,1280,1440,1920').split(',')]
env=Env(PORT)
env.setp('db/g/g1',{'id':'g1','title':'رياضيات الصف الثالث الثانوي','t':'t1','code':'ABC123','mat':[]}); env.setp('db/g/g1/st',{'s1':{'u':'s1','s':'ok'}})
for i in range(30): env.setp(f'db/p/m{i}',{'id':f'm{i}','a':'t1' if i%2 else 's1','b':'s1' if i%2 else 't1','t':f'رسالة رقم {i} '+('نص طويل '*(i%6)),'d':1700000000000+i*60000})
for i in range(8): env.setp(f'db/f/f{i}',{'id':f'f{i}','u':'t1' if i%2 else 's1','t':'منشور تجريبي رقم %d '%i+'كلام كتير '*(i%5),'d':1700000000000+i*3600000})
CHECK="""()=>{const vw=document.documentElement.clientWidth,out={};out.hs=document.documentElement.scrollWidth>vw+1;
 const bad=[];document.querySelectorAll('#app *,header *,#bn *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width<2||r.height<2)return;const cs=getComputedStyle(e);if(cs.display==='none'||cs.visibility==='hidden'||cs.position==='fixed')return;
   if(e.closest('.stn-chips,.st-settings-tabs,.tabs,table,.tbl,pre,.scroll,[style*="overflow"],.aim,#wb'))return;
   if(r.right>vw+2||r.left<-2)bad.push(e.tagName.toLowerCase()+'.'+(typeof e.className==='string'?e.className.split(' ')[0]:'')+'@'+Math.round(r.left)+'..'+Math.round(r.right))});
 out.off=[...new Set(bad)].slice(0,4);
 const cut=[];document.querySelectorAll('#app button,#app .b,header b,#bn button,#app h1,#app h2,#app h3').forEach(e=>{const cs=getComputedStyle(e);if(cs.display==='none')return;if(e.scrollWidth>e.clientWidth+3&&cs.overflowX!=='auto'&&cs.overflowX!=='scroll'&&(cs.overflow==='hidden'||cs.textOverflow==='ellipsis'||cs.whiteSpace==='nowrap'))cut.push((e.textContent||'').trim().slice(0,18))});
 out.cut=[...new Set(cut)].slice(0,4);
 const bn=document.getElementById('bn');if(bn&&document.getElementById('app')){const bt=bn.getBoundingClientRect().top,last=[...document.querySelectorAll('#app > *')].pop();out.navgap=last?Math.round(bt-last.getBoundingClientRect().bottom+scrollY*0):null}
 return out}"""
VIEWS={'guest':[('landing',"go('dash')"),('login',"go('dash','login')"),('register',"go('dash','reg')")],
 'student':[('dash',"go('dash')"),('chats',"go('chats')"),('chat',"go('pm','t1')"),('ai',"go('ai')"),('community',"ST.tab='all';go('soc')"),('settings',"go('set')"),('account',"go('set',undefined,'account')")],
 'admin':[('admin',"go('stadm')"),('admin-accounts',"go('stadm');stA.tab('u')"),('admin-appearance',"go('stadm');stA.tab('d')")]}
EM={'student':'s1@x.com','admin':'admin@admin.com'}
issues={}; total=0
with sync_playwright() as p:
    br=p.chromium.launch()
    for W in WIDTHS:
        H=800 if W<700 else 900
        pages={}
        for role in VIEWS:
            ctx=br.new_context(viewport={'width':W,'height':H},locale='ar-EG'); pg=ctx.new_page(); ctx.route('**/*',env.route(tok_role)); pg.goto(f'http://localhost:{PORT}/index.html'); pg.wait_for_timeout(900)
            if role!='guest':
                pg.evaluate("go('dash','login')"); pg.evaluate("([e,pw])=>{RF={em:e,pw:pw}}",[EM[role],'admin1020@' if role=='admin' else 'pass1234']); pg.evaluate("login()"); pg.wait_for_timeout(2300)
            pages[role]=pg
        for role,vs in VIEWS.items():
            pg=pages[role]
            for name,js in vs:
                total+=1
                try:
                    pg.evaluate("j=>{document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove());new Function(j)()}",js); pg.wait_for_timeout(650)
                    pg.evaluate("document.querySelectorAll('.tour,.ov,.mod').forEach(e=>e.remove())"); r=pg.evaluate(CHECK)
                except Exception as e: r={'hs':False,'off':['ERR '+str(e)[:40]],'cut':[]}
                if r.get('hs') or r.get('off') or r.get('cut'): issues[f'{W}/{role}/{name}']=r
        for ctx in br.contexts: ctx.close()
    br.close()
print(f'{total} page×width combinations checked, {len(issues)} with issues')
for k,v in issues.items(): print(k,'->',json.dumps(v,ensure_ascii=False)[:230])
json.dump(issues,open(os.path.join(__import__('tempfile').gettempdir(),'resp_out.json'),'w',encoding='utf-8'),ensure_ascii=False)
