/* اختبار كامل لتسجيل الدخول ونسيت كلمة المرور وتغيير كلمة المرور على كود الواجهة نفسه (ضد Worker وهمي).
   التشغيل:  node tools/test-auth-flow.mjs platform */
import vm from 'node:vm';
import { generateKeyPairSync, createSign, createHash, webcrypto } from 'node:crypto';
import fs from 'node:fs';
const workerSrc=fs.readFileSync(new URL('../worker/worker.js',import.meta.url),'utf8');
const worker=(await import('data:text/javascript;base64,'+Buffer.from(workerSrc).toString('base64'))).default;

const SITE = process.argv[2] || 'platform';
const jsDir = new URL('../'+SITE+'/js/', import.meta.url);
// قلّد حد Cloudflare Workers: PBKDF2 مش بيقبل أكتر من 100000 دورة (Node بيقبل، فكان الخطأ بيعدّي من الاختبار)
{ const orig = crypto.subtle.deriveBits.bind(crypto.subtle);
  crypto.subtle.deriveBits = (alg, ...rest) => { if (alg && alg.name === 'PBKDF2' && alg.iterations > 100000) throw new DOMException('Pbkdf2 failed: iteration counts above 100000 are not supported (requested ' + alg.iterations + ')', 'NotSupportedError'); return orig(alg, ...rest); }; }
const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const b64u = (b) => Buffer.from(b).toString('base64url');
const hp = (p) => 'h:' + createHash('sha256').update('stp|' + p).digest('hex');
const DBU = 'https://smart-teacher-om-default-rtdb.firebaseio.com', WURL = 'https://smart-teacher-api.kimookol117.workers.dev', ORIGIN = 'https://app.test';
let db = { db: { u: { u1: { id: 'u1', name: 'Ali', email: 'ali@x.com', phone: '01012345678', role: 'student', pw: hp('oldpass1') } }, g: {}, e: {}, s: {}, m: {}, n: {}, p: {}, k: {}, nw: {}, cf: {}, sp: {} } };
const mails = [];
const getPath = (p) => p.split('/').filter(Boolean).reduce((o, k) => (o == null ? null : o[k] ?? null), db);
const setPath = (p, v) => { const ks = p.split('/').filter(Boolean); let o = db; ks.slice(0, -1).forEach((k) => (o = o[k] = o[k] || {})); if (v === null) delete o[ks.at(-1)]; else o[ks.at(-1)] = v; };
const env = { ALLOWED_ORIGINS: ORIGIN, DB_URL: DBU, PROJECT_ID: 'proj', FIREBASE_SERVICE_ACCOUNT: JSON.stringify({ client_email: 'sa@proj.iam', private_key: pem }), EMAILJS_SERVICE: 's', EMAILJS_TEMPLATE: 't', EMAILJS_PUBLIC_KEY: 'PUB', EMAILJS_PRIVATE_KEY: 'PRIV' };
const R = (b, s = 200) => new Response(JSON.stringify(b), { status: s });
const fakeFetch = async (url, init = {}) => {
  url = String(url);
  if (url.endsWith('/register') && globalThis.__failReg > 0) { globalThis.__failReg--; return R({ ok: false, error: 'server_error', detail: 'boom' }, 500); }
  if (url.startsWith(WURL)) { const h = { ...(init.headers || {}), Origin: ORIGIN, 'CF-Connecting-IP': '5.5.5.5' }; return worker.fetch(new Request(url, { method: init.method || 'GET', headers: h, body: init.body }), env); }
  if (url.startsWith('https://oauth2.googleapis.com/token')) return R({ access_token: 'adm', expires_in: 3600 });
  if (url.includes('service_accounts/v1/jwk')) return R({ keys: [jwk] });
  if (url.startsWith('https://api.emailjs.com')) { mails.push(JSON.parse(init.body)); return R({}); }
  if (url.startsWith(DBU)) { const u = new URL(url); const path = u.pathname.replace(/\.json$/, ''); if ((init.method || 'GET') === 'PATCH') { for (const [k, v] of Object.entries(JSON.parse(init.body))) setPath(k, v); return R({}); } if (u.searchParams.get('orderBy')) return R({ error: 'x' }, 400); return R(getPath(path)); }
  return R({}, 404);
};
globalThis.fetch = fakeFetch;
const inputs = {}; const toasts = [];
const mkEl = (sel) => { const t = { style: {}, dataset: {}, classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } }, innerHTML: '', _s: sel, addEventListener() {}, removeEventListener() {}, appendChild() {}, remove() {}, matches() { return false; }, closest() { return null; }, focus() {}, click() {}, setAttribute() {}, getAttribute() { return null; }, querySelector() { return mkEl('x'); }, querySelectorAll() { return []; }, getBoundingClientRect() { return {}; } };
  return new Proxy(t, { get(o, k) { if (k === 'value') return inputs[sel] ?? ''; if (k === 'textContent' && sel === '#toast') return o._tc; if (k in o) return o[k]; if (typeof k === 'string' && k !== 'then' && !k.startsWith('on')) return () => mkEl('x'); return undefined; }, set(o, k, v) { if (k === 'textContent' && sel === '#toast') { o._tc = v; toasts.push(v); } else if (k === 'value') inputs[sel] = v; else o[k] = v; return true; } }); };
const toastEl = mkEl('#toast'); const els = {};
const document = { querySelector: (s) => (s === '#toast' ? toastEl : (els[s] ||= mkEl(s))), querySelectorAll: () => [], getElementById: (i) => document.querySelector('#' + i), createElement: () => mkEl('c'), addEventListener() {}, documentElement: { dataset: {}, style: { setProperty() {}, removeProperty() {} }, setAttribute() {}, getAttribute() { return null; }, classList: { add() {}, remove() {} } }, body: mkEl('body'), head: mkEl('head'), hidden: false, activeElement: null, readyState: 'complete', cookie: '' };
const store = (o = {}) => ({ getItem: (k) => (k in o ? o[k] : null), setItem: (k, v) => (o[k] = String(v)), removeItem: (k) => delete o[k], clear() {} });
let cur = null;
const idTokenFor = (uid) => { const h = b64u(JSON.stringify({ alg: 'RS256', kid: 'k1', typ: 'JWT' })), p = b64u(JSON.stringify({ iss: 'https://securetoken.google.com/proj', aud: 'proj', sub: uid, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 3000 })); return h + '.' + p + '.' + b64u(createSign('RSA-SHA256').update(h + '.' + p).sign(privateKey)); };
const authObj = { onAuthStateChanged(cb) { setTimeout(() => cb(cur), 0); }, get currentUser() { return cur; }, async signInWithCustomToken(t) { const uid = JSON.parse(Buffer.from(t.split('.')[1], 'base64url')).uid; cur = { uid, isAnonymous: false, getIdToken: async () => idTokenFor(uid) }; }, async signOut() { cur = null; }, async signInAnonymously() {} };
const sandbox = { URLSearchParams, document, localStorage: store(), sessionStorage: store(), navigator: { userAgent: 'node', serviceWorker: undefined, onLine: true }, location: { href: 'https://app.test/', hash: '#/login', origin: ORIGIN, pathname: '/', search: '' }, history: { replaceState() {}, pushState() {} }, fetch: fakeFetch, crypto: webcrypto, TextEncoder, TextDecoder, URL, AbortController, setTimeout, clearTimeout, setInterval: () => 0, clearInterval() {}, console, matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }), Promise, JSON, Math, Date, Object, Array, Set, Map, Uint8Array, Uint32Array, btoa, atob, requestAnimationFrame: (f) => setTimeout(f, 0), getComputedStyle: () => ({}), Notification: undefined, Blob, FileReader: class {}, Image: class {}, Audio: class {}, IntersectionObserver: class { observe() {} }, MutationObserver: class { observe() {} }, ResizeObserver: class { observe() {} }, Event: class {}, CustomEvent: class {}, alert() {}, confirm: () => true, prompt: () => '', scrollTo() {}, addEventListener() {}, removeEventListener() {}, innerWidth: 400, innerHeight: 800, screen: {}, performance: { now: () => Date.now() }, structuredClone };
sandbox.firebase = { initializeApp() {}, auth: () => authObj, messaging: () => ({}), apps: [] }; sandbox.firebase.auth.Auth = {};
sandbox.ST_FB = { apiKey: 'AIzaTEST', databaseURL: DBU, projectId: 'proj', authDomain: 'proj.firebaseapp.com', appId: '1:1:web:1', messagingSenderId: '1' }; sandbox.ST_WORKER_URL = WURL;
sandbox.window = sandbox; sandbox.self = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
let code = fs.readdirSync(jsDir).filter((f) => /^([0-3][0-9])-.*\.js$/.test(f)).sort().map((f) => fs.readFileSync(new URL(f, jsDir), 'utf8')).join('\n');
code += `\n;globalThis.__t={login,forgot,verify,startAccountOtp,sendOtp,setRF:v=>{RF=v},getRF:()=>RF,getOTP:()=>OTP,getS:()=>S,setMe:v=>{S.me=v},getV:()=>V,pull,setRR:v=>{RR=v},signup};`;
try { vm.runInContext(code, sandbox, { filename: 'app.js' }); } catch (e) { console.log('LOAD ERROR', e.message, (e.stack || '').split('\n').slice(0, 4).join('\n')); process.exit(2); }
const T = sandbox.__t; const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, fail = 0; const ok = (n, c, x) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); };
const lastToast = () => toasts.at(-1);
await sleep(200);
// 1. wrong password gives clear message
T.setRF({ em: 'ali@x.com', pw: 'WRONG' }); await T.login(); ok('wrong pw -> clear msg', /كلمة المرور غلط/.test(lastToast()), lastToast());
T.setRF({ em: 'nobody@x.com', pw: 'x' }); await T.login(); ok('unknown user -> clear msg', /مش مسجّل/.test(lastToast()), lastToast());
// 2. correct login
T.setRF({ em: 'ali@x.com', pw: 'oldpass1' }); await T.login(); ok('login with right password', T.getS().me === 'u1', { me: T.getS().me, t: lastToast() });
// 3. forgot password (logged out)
T.setMe(null); cur = null; T.setRF({ fe: 'ali@x.com' }); await T.forgot(); await sleep(100);
ok('forgot -> code emailed by server', mails.length === 1 && T.getOTP() && T.getOTP().sent === 1, { mails: mails.length, otp: T.getOTP() && T.getOTP().sent, t: lastToast() });
const code1 = mails[0]?.template_params.code;
inputs['#op'] = '000000'; inputs['#np'] = 'brandnew77'; inputs['#np2'] = 'brandnew77'; await T.verify(); ok('wrong code rejected', T.getS().me !== 'u1' && /غير صحيح/.test(lastToast()), lastToast());
inputs['#np2'] = 'different77'; inputs['#op'] = code1; await T.verify(); ok('mismatched confirm rejected', /غير متطابقتين/.test(lastToast()), lastToast());
inputs['#np2'] = 'brandnew77'; await T.verify(); await sleep(50);
ok('right code -> pw changed + auto login', T.getS().me === 'u1' && T.getOTP() === null, { me: T.getS().me, t: lastToast() });
// 4. login with the new password after logout
T.setMe(null); cur = null; T.setRF({ em: 'ali@x.com', pw: 'brandnew77' }); await T.login(); ok('login with NEW password', T.getS().me === 'u1', lastToast());
T.setMe(null); cur = null; T.setRF({ em: 'ali@x.com', pw: 'oldpass1' }); await T.login(); ok('OLD password no longer works', T.getS().me !== 'u1', lastToast());
// 5. change password from settings (logged in)
T.setRF({ em: 'ali@x.com', pw: 'brandnew77' }); await T.login(); await sleep(50);
inputs['#oldpw'] = 'WRONGOLD'; inputs['#newpw'] = 'thirdpass88'; inputs['#newpw2'] = 'thirdpass88'; await T.startAccountOtp('cpw'); ok('change pw: wrong current rejected', /الحالية غير صحيحة/.test(lastToast()), lastToast());
inputs['#oldpw'] = 'brandnew77'; await T.startAccountOtp('cpw'); ok('change pw: success toast', /تم تغيير كلمة المرور/.test(lastToast()), lastToast());
T.setMe(null); cur = null; T.setRF({ em: 'ali@x.com', pw: 'thirdpass88' }); await T.login(); ok('login with password changed in settings', T.getS().me === 'u1', lastToast());
// 6. forgot for unknown email
T.setMe(null); T.setRF({ fe: 'ghost@x.com' }); await T.forgot(); await sleep(100); ok('forgot unknown email -> clear msg + back to form', /مفيش حساب/.test(lastToast()) && T.getOTP() === null, lastToast());

// 7. تسجيل حساب جديد: لو أول محاولة فشلت، المحاولة التانية لازم تبعت الباسورد (كان بيتمسح وبيطلع bad_password)
mails.length = 0; T.setMe(null); cur = null; globalThis.__failReg = 1; T.setRR('student');
T.setRF({ nm: 'New Student', em: 'newstu@x.com', ph: '01155555555', pw: 'secret12', cp: 'secret12' }); await T.signup(); await sleep(150);
ok('signup: verification code emailed', mails.length >= 1 && T.getOTP() && T.getOTP().h, { mails: mails.length, t: lastToast() });
const sc = mails.at(-1)?.template_params.code; inputs['#op'] = sc;
await T.verify(); await sleep(100); ok('signup: first attempt fails with clear server message', /تعذر إنشاء الحساب/.test(lastToast()) && /boom|500/.test(lastToast()), lastToast());
await T.verify(); await sleep(250); ok('signup: retry on same screen succeeds (password not lost)', T.getS().me && T.getS().u.some((x) => x.email === 'newstu@x.com'), { me: T.getS().me, t: lastToast() });
T.setMe(null); cur = null; T.setRF({ em: 'newstu@x.com', pw: 'secret12' }); await T.login(); ok('signup: new account can log in with its password', !!T.getS().me && T.getS().me !== 'u1', lastToast());
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
