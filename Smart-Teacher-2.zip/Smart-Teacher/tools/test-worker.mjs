/* اختبار الـ Worker (دخول / نسيت كلمة المرور / تغيير كلمة المرور) على نسخة وهمية من Firebase و EmailJS.
   التشغيل:  node tools/test-worker.mjs */
import { generateKeyPairSync, createSign, createHash } from 'node:crypto';
import fs from 'node:fs';
const workerSrc=fs.readFileSync(new URL('../worker/worker.js',import.meta.url),'utf8');
const worker=(await import('data:text/javascript;base64,'+Buffer.from(workerSrc).toString('base64'))).default;

// قلّد حد Cloudflare Workers: PBKDF2 مش بيقبل أكتر من 100000 دورة (Node بيقبل، فكان الخطأ بيعدّي من الاختبار)
{ const orig = crypto.subtle.deriveBits.bind(crypto.subtle);
  crypto.subtle.deriveBits = (alg, ...rest) => { if (alg && alg.name === 'PBKDF2' && alg.iterations > 100000) throw new DOMException('Pbkdf2 failed: iteration counts above 100000 are not supported (requested ' + alg.iterations + ')', 'NotSupportedError'); return orig(alg, ...rest); }; }
const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const b64u = (b) => Buffer.from(b).toString('base64url');
const hp = (p) => 'h:' + createHash('sha256').update('stp|' + p).digest('hex');
// in-memory RTDB
let db = { db: { u: {
  u1: { id: 'u1', name: 'Ali', email: 'ali@x.com', phone: '01012345678', role: 'student', pw: hp('oldpass1') },
  u2: { id: 'u2', name: 'Mona', email: 'mona@x.com', phone: '01199999999', role: 'teacher', pw: 'plainpass' },
} } };
const sent = [];
const getPath = (p) => p.split('/').filter(Boolean).reduce((o, k) => (o == null ? null : o[k] ?? null), db);
const setPath = (p, v) => { const ks = p.split('/').filter(Boolean); let o = db; ks.slice(0, -1).forEach((k) => (o = o[k] = o[k] || {})); if (v === null) delete o[ks.at(-1)]; else o[ks.at(-1)] = v; };
globalThis.fetch = async (url, init = {}) => {
  url = String(url);
  const R = (b, s = 200) => new Response(JSON.stringify(b), { status: s });
  if (url.startsWith('https://oauth2.googleapis.com/token')) return R({ access_token: 'adm', expires_in: 3600 });
  if (url.includes('service_accounts/v1/jwk')) return R({ keys: [jwk] });
  if (url.startsWith('https://api.emailjs.com')) { const b = JSON.parse(init.body); sent.push(b); return R({}, b.accessToken === 'PRIV' ? 200 : 403); }
  if (url.startsWith('https://fb.test/') || url.includes('firebaseio.com')) {
    const u = new URL(url); const path = u.pathname.replace(/\.json$/, '');
    if ((init.method || 'GET') === 'PATCH') { for (const [k, v] of Object.entries(JSON.parse(init.body))) setPath(k, v); return R({}); }
    const ob = u.searchParams.get('orderBy');
    if (ob) return R({ error: 'Index not defined' }, 400); // force fallback path
    return R(getPath(path));
  }
  throw new Error('unexpected fetch ' + url);
};
const env = { ALLOWED_ORIGINS: 'https://app.test', DB_URL: 'https://fb.test', PROJECT_ID: 'proj',
  FIREBASE_SERVICE_ACCOUNT: JSON.stringify({ client_email: 'sa@proj.iam', private_key: pem, project_id: 'proj' }),
  EMAILJS_SERVICE: 's', EMAILJS_TEMPLATE: 't', EMAILJS_PUBLIC_KEY: 'PUB', EMAILJS_PRIVATE_KEY: 'PRIV', ADMIN_EMAIL: 'admin@admin.com', ADMIN_PASSWORD: 'admin1020@' };
const call = async (path, body, hdr = {}, method = 'POST') => { const r = await worker.fetch(new Request('https://w.test' + path, { method, headers: { 'Content-Type': 'application/json', Origin: 'https://app.test', 'CF-Connecting-IP': '1.1.1.' + Math.floor(Math.random()*250), ...hdr }, body: method === 'POST' ? JSON.stringify(body) : undefined }), env); return { s: r.status, b: await r.json().catch(() => null) }; };
let pass = 0, fail = 0; const ok = (n, c, x) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); };
let r;
r = await call('/login', { id: 'ali@x.com', password: 'oldpass1' }); ok('login old-hash by email', r.s === 200 && r.b.uid === 'u1', r);
ok('  password upgraded to pbkdf2', db.db.u.u1.pw.startsWith('p2$'), db.db.u.u1.pw);
r = await call('/login', { id: 'ali@x.com', password: 'oldpass1' }); ok('login again after upgrade', r.s === 200, r);
r = await call('/login', { id: '+20 101 234 5678', password: 'oldpass1' }); ok('login by phone (+20 format)', r.s === 200 && r.b.uid === 'u1', r);
r = await call('/login', { id: 'mona@x.com', password: 'plainpass' }); ok('login plaintext legacy', r.s === 200, r);
r = await call('/login', { id: 'ali@x.com', password: 'WRONG' }); ok('wrong pw -> 401 bad_pw', r.s === 401 && r.b.reason === 'bad_pw', r);
r = await call('/login', { id: 'nobody@x.com', password: 'x' }); ok('unknown -> 401 no_user', r.s === 401 && r.b.reason === 'no_user', r);
// reset flow
r = await call('/reset/start', { email: 'nobody@x.com' }); ok('reset/start unknown -> 404', r.s === 404, r);
r = await call('/reset/start', { email: 'ali@x.com' }); ok('reset/start ok + mail sent', r.s === 200 && sent.length === 1 && /^\d{6}$/.test(sent[0].template_params.code), r);
const code = sent[0].template_params.code;
ok('  code NOT returned to browser', !JSON.stringify(r.b).includes(code), r);
r = await call('/reset/confirm', { email: 'ali@x.com', code: code === '123456' ? '654321' : '123456', password: 'newpass99' }); ok('confirm wrong code -> 401', r.s === 401 && r.b.error === 'bad_code', r);
r = await call('/reset/confirm', { email: 'ali@x.com', code, password: 'short' }); ok('confirm short pw -> 400', r.s === 400, r);
r = await call('/reset/confirm', { email: 'ali@x.com', code, password: 'newpass99' }); ok('confirm right code -> 200 + token', r.s === 200 && r.b.token && r.b.uid === 'u1', r);
r = await call('/reset/confirm', { email: 'ali@x.com', code, password: 'another99' }); ok('code is single-use', r.s === 410, r);
r = await call('/login', { id: 'ali@x.com', password: 'newpass99' }); ok('login with NEW password', r.s === 200, r);
r = await call('/login', { id: 'ali@x.com', password: 'oldpass1' }); ok('old password rejected', r.s === 401, r);
// brute force on code
await call('/reset/start', { email: 'mona@x.com' }); const c2 = sent.at(-1).template_params.code; let last;
for (let i = 0; i < 6; i++) last = await call('/reset/confirm', { email: 'mona@x.com', code: c2 === '111111' ? '222222' : '111111', password: 'newpass99' });
r = await call('/reset/confirm', { email: 'mona@x.com', code: c2, password: 'newpass99' }); ok('code locked after 5 wrong tries', r.s !== 200, r);
// mail not configured
const e2 = { ...env }; delete e2.EMAILJS_PRIVATE_KEY; const rr = await worker.fetch(new Request('https://w.test/reset/start', { method: 'POST', headers: { Origin: 'https://app.test', 'Content-Type': 'application/json', 'CF-Connecting-IP': '9.9.9.9' }, body: JSON.stringify({ email: 'ali@x.com' }) }), e2);
ok('mail not configured -> 503', rr.status === 503, rr.status);
// change-password with real id token
const idTok = (uid, role) => { const h = b64u(JSON.stringify({ alg: 'RS256', kid: 'k1', typ: 'JWT' })), p = b64u(JSON.stringify({ iss: 'https://securetoken.google.com/proj', aud: 'proj', sub: uid, ...(role ? { role } : {}), iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 3000 })); const sg = createSign('RSA-SHA256').update(h + '.' + p).sign(privateKey); return h + '.' + p + '.' + b64u(sg); };
r = await call('/change-password', { old: 'WRONGOLD', password: 'brandnew1' }, { Authorization: 'Bearer ' + idTok('u1') }); ok('change-pw wrong old -> 401', r.s === 401 && r.b.error === 'bad_old', r);
r = await call('/change-password', { old: 'newpass99', password: 'brandnew1' }, { Authorization: 'Bearer ' + idTok('u1') }); ok('change-pw ok', r.s === 200, r);
r = await call('/login', { id: 'ali@x.com', password: 'brandnew1' }); ok('login with changed pw', r.s === 200, r);
r = await call('/change-password', { old: 'x', password: 'brandnew2' }); ok('change-pw without token -> 401', r.s === 401, r);

// ---- دخول الإدارة من نفس شاشة الدخول ----
r = await call('/login', { id: 'ADMIN@admin.com', password: 'admin1020@' }); ok('admin login (email case-insensitive) -> role admin', r.s === 200 && r.b.role === 'admin' && r.b.uid === 'admroot' && r.b.token, r);
ok('  admin user doc created in DB with role admin', db.db.u.admroot && db.db.u.admroot.role === 'admin' && db.db.u.admroot.email === 'admin@admin.com', db.db.u.admroot);
ok('  no password hash stored for admin', !db.db.u.admroot.pw, db.db.u.admroot);
r = await call('/login', { id: 'admin@admin.com', password: 'wrong' }); ok('admin wrong password -> 401', r.s === 401, r);
r = await call('/login', { id: 'admin@admin.com', password: 'admin1020' }); ok('admin password must match exactly', r.s === 401, r);
const e3 = { ...env }; delete e3.ADMIN_PASSWORD; const r3 = await worker.fetch(new Request('https://w.test/login', { method: 'POST', headers: { Origin: 'https://app.test', 'Content-Type': 'application/json', 'CF-Connecting-IP': '8.8.8.8' }, body: JSON.stringify({ id: 'admin@admin.com', password: 'admin1020@' }) }), e3);
ok('admin login disabled when secret not set', r3.status === 401, r3.status);


// ---- حسابات بتتعمل من لوحة الإدارة (بتتكتب في القاعدة مباشرة بهاش قديم) لازم تدخل بالـ Worker وتتحوّل لـ PBKDF2 ----
{ for (const [em, role, pw] of [['teach@x.com', 'teacher', 'Teach1234x'], ['asst@x.com', 'assistant', 'Asst1234x'], ['stud@x.com', 'student', 'Stud1234x'], ['par@x.com', 'parent', 'Par1234xxx']]) {
    db.db.u['a_' + role] = { id: 'a_' + role, name: 'Admin Made ' + role, email: em, phone: '', role, ok: 1, pv: 1, ev: 1, by: 'admin', pw: hp(pw) };
    r = await call('/login', { id: em, password: pw }); ok('admin-made ' + role + ' account logs in with the role in the token', r.s === 200 && r.b.role === role && r.b.uid === 'a_' + role, r);
    ok('  its password hash upgraded to PBKDF2 on first login', db.db.u['a_' + role].pw.startsWith('p2$'), db.db.u['a_' + role].pw); }
  r = await call('/login', { id: 'teach@x.com', password: 'wrong-password' }); ok('admin-made account: wrong password rejected', r.s === 401, r); }
// ---- فحص الإعدادات /health?check=1 ----
{ const rq = (e, origin) => worker.fetch(new Request('https://w.test/health?check=1', { headers: origin ? { Origin: origin } : {} }), e).then(async (x) => ({ s: x.status, b: await x.json() }));
  let d = await rq({ ...env, DB_URL: 'https://proj-default-rtdb.firebaseio.com' }, 'https://app.test'); ok('diagnose: healthy setup -> ok', d.s === 200 && d.b.ok === true, d.b);
  ok('diagnose: never leaks secrets', !JSON.stringify(d.b).includes('admin1020') && !JSON.stringify(d.b).includes('PRIVATE KEY'), d.b);
  d = await rq({ ...env, PROJECT_ID: 'other-project' }, 'https://app.test'); ok('diagnose: project mismatch detected', d.b.ok === false && d.b.checks.service_account_project && d.b.checks.service_account_project.ok === false, d.b);
  const e5 = { ...env }; delete e5.ADMIN_PASSWORD; d = await rq(e5); ok('diagnose: missing ADMIN_PASSWORD flagged', d.b.checks.ADMIN_PASSWORD.ok === false, d.b);
  d = await rq({ ...env, ALLOWED_ORIGINS: 'https://other.com' }, 'https://app.test'); ok('diagnose: origin not allowed flagged', d.b.checks.origin_allowed && d.b.checks.origin_allowed.ok === false, d.b);
  d = await rq({ ...env, FIREBASE_SERVICE_ACCOUNT: 'not json' }); ok('diagnose: bad service account flagged', d.b.checks.FIREBASE_SERVICE_ACCOUNT.ok === false, d.b); }
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
