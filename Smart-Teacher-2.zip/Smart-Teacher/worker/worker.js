/* ==========================================================================
   Smart Teacher API — Cloudflare Worker (الخطة المجانية)
   المرحلة 1: وسيط الذكاء الاصطناعي (مفاتيح Groq تفضل سرية هنا)
   المرحلة 2: تسجيل دخول موثّق (السيرفر يتحقق من الباسورد ويدّي توكن Firebase بـ uid ودور)

   Secrets (من Cloudflare ← Settings ← Variables and Secrets، النوع Secret):
     GROQ_KEYS                  مفاتيح Groq الجديدة مفصولة بفاصلة
     FIREBASE_SERVICE_ACCOUNT   محتوى ملف Service Account كامل (JSON)
   Variables (نص عادي):
     ALLOWED_ORIGINS            دومين موقعك، مثال: https://smart-teacher-v1.vercel.app  (يقبل أكتر من واحد بفاصلة)
     DB_URL                     https://smart-teacher-om-default-rtdb.firebaseio.com
     PROJECT_ID                 smart-teacher-om
     EMAILJS_SERVICE / EMAILJS_TEMPLATE / EMAILJS_PUBLIC_KEY  (متغيرات عادية: بيانات EmailJS لإيميل استرجاع كلمة المرور)
     EMAILJS_PRIVATE_KEY        (Secret: الـ Private Key من EmailJS ← Account ← API Keys)
     ADMIN_EMAIL                (متغير عادي: إيميل دخول الإدارة)
     ADMIN_PASSWORD             (Secret: كلمة سر دخول الإدارة — الدخول من نفس شاشة دخول المنصة)
   ========================================================================== */
const enc = new TextEncoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64uJson = (o) => b64u(enc.encode(JSON.stringify(o)));
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
const now = () => Math.floor(Date.now() / 1000);

/* ---------- CORS / ردود ---------- */
function corsHeaders(req, env) {
  const origin = req.headers.get('Origin') || '';
  const ok = String(env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean).includes(origin);
  return ok ? { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Max-Age': '86400' } : { 'Vary': 'Origin' };
}
const json = (req, env, status, body) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Referrer-Policy':'no-referrer', 'Permissions-Policy':'camera=(), microphone=(), geolocation=()', ...corsHeaders(req, env) } });

/* ---------- حدود معدّل الاستخدام (في ذاكرة الـ isolate: حماية أساسية) ---------- */
const hits = new Map();
function limited(key, max, windowSec) {
  const t = Date.now(), arr = (hits.get(key) || []).filter((x) => t - x < windowSec * 1000);
  if (arr.length >= max) { hits.set(key, arr); return true; }
  arr.push(t); hits.set(key, arr);
  if (hits.size > 5000) for (const k of hits.keys()) { hits.delete(k); if (hits.size < 2500) break; }
  return false;
}
const peek = (key, windowSec) => (hits.get(key) || []).filter((x) => Date.now() - x < windowSec * 1000).length;

/* ---------- JWT RS256 بمفتاح Service Account ---------- */
let _sa, _key;
function sa(env) { if (!_sa) _sa = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT); return _sa; }
async function signingKey(env) {
  if (_key) return _key;
  const pem = sa(env).private_key.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  _key = await crypto.subtle.importKey('pkcs8', Uint8Array.from(atob(pem), (c) => c.charCodeAt(0)), { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  return _key;
}
async function signJwt(env, payload) {
  const head = b64uJson({ alg: 'RS256', typ: 'JWT' }), body = b64uJson(payload);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', await signingKey(env), enc.encode(head + '.' + body));
  return head + '.' + body + '.' + b64u(sig);
}
/* توكن دخول Firebase (Custom Token) بـ uid ودور */
const customToken = (env, uid, claims) => signJwt(env, { iss: sa(env).client_email, sub: sa(env).client_email, aud: 'https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit', iat: now(), exp: now() + 3600, uid, claims });

/* ---------- وصول Admin لقاعدة البيانات ---------- */
let _at = { t: '', exp: 0 };
async function adminToken(env) {
  if (_at.t && _at.exp - 60 > now()) return _at.t;
  const jwt = await signJwt(env, { iss: sa(env).client_email, scope: 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email', aud: 'https://oauth2.googleapis.com/token', iat: now(), exp: now() + 3600 });
  const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + jwt });
  if (!r.ok) throw new Error('oauth ' + r.status);
  const d = await r.json(); _at = { t: d.access_token, exp: now() + (d.expires_in || 3600) };
  return _at.t;
}
async function dbGet(env, path, query = '') {
  const r = await fetch(`${env.DB_URL.replace(/\/$/, '')}/${path}.json${query ? '?' + String(query).replace(/^[?&]/, '') : ''}`, { headers: { Authorization: 'Bearer ' + await adminToken(env) } });
  if (!r.ok) { const e = new Error('db ' + r.status); e.status = r.status; throw e; }
  return r.json();
}
async function dbPatch(env, updates) {
  const r = await fetch(`${env.DB_URL.replace(/\/$/, '')}/.json`, { method:'PATCH', headers:{'Content-Type':'application/json',Authorization:'Bearer '+await adminToken(env)}, body:JSON.stringify(updates) });
  if (!r.ok) { const e=new Error('db '+r.status); e.status=r.status; throw e; }
  return r.json().catch(()=>null);
}

/* ---------- التحقق من Firebase ID Token ---------- */
let _jwks = { keys: null, exp: 0 };
async function verifyIdToken(env, token) {
  try {
    const [h, p, s] = String(token || '').split('.'); if (!s) return null;
    const head = JSON.parse(new TextDecoder().decode(unb64u(h))), pay = JSON.parse(new TextDecoder().decode(unb64u(p)));
    if (head.alg !== 'RS256') return null;
    if (!_jwks.keys || _jwks.exp < now()) {
      const r = await fetch('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com');
      if (!r.ok) return null; _jwks = { keys: (await r.json()).keys, exp: now() + 3600 };
    }
    const jwk = _jwks.keys.find((k) => k.kid === head.kid); if (!jwk) return null;
    const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    if (!(await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, unb64u(s), enc.encode(h + '.' + p)))) return null;
    if (pay.iss !== 'https://securetoken.google.com/' + env.PROJECT_ID || pay.aud !== env.PROJECT_ID || !pay.sub || pay.exp < now() || pay.iat > now() + 300) return null;
    return pay;
  } catch (e) { return null; }
}

/* ---------- المرحلة 1: وسيط Groq ---------- */
const MODEL_RE = /^[A-Za-z0-9._\-\/]{1,80}$/;
let kIdx = 0;
async function groq(env, path, init) {
  const keys = String(env.GROQ_KEYS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!keys.length) return new Response('{"error":{"message":"no keys"}}', { status: 503 });
  let last;
  for (let i = 0; i < keys.length; i++) {
    const k = keys[(kIdx + i) % keys.length];
    last = await fetch('https://api.groq.com/openai/v1/' + path, { ...init, headers: { ...(init.headers || {}), Authorization: 'Bearer ' + k } });
    if (last.status !== 401 && last.status !== 429) { kIdx = (kIdx + i + 1) % keys.length; return last; }
  }
  return last;
}
async function handleAI(req, env, url) {
  const auth = await verifyIdToken(env, (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, ''));
  if (!auth) return json(req, env, 401, { error: { message: 'unauthorized' } });
  const ip = req.headers.get('CF-Connecting-IP') || 'x';
  if (limited('ai:' + auth.sub + ':' + ip, 20, 60) || limited('aiip:' + ip, 60, 60)) return json(req, env, 429, { error: { message: 'too many requests' } });
  if (url.pathname === '/ai/models' && req.method === 'GET') {
    const r = await groq(env, 'models', { method: 'GET' });
    return new Response(r.body, { status: r.status, headers: { 'Content-Type': 'application/json', ...corsHeaders(req, env) } });
  }
  if (url.pathname === '/ai/chat' && req.method === 'POST') {
    const raw = await req.text(); if (raw.length > 1024 * 1024) return json(req, env, 413, { error: { message: 'too large' } });
    let b; try { b = JSON.parse(raw); } catch (e) { return json(req, env, 400, { error: { message: 'bad json' } }); }
    if (!MODEL_RE.test(b.model || '') || !Array.isArray(b.messages) || !b.messages.length || b.messages.length > 40 || b.messages.some(m => !m || !['system','user','assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 20000)) return json(req, env, 400, { error: { message: 'bad request' } });
    const body = { model: b.model, messages: b.messages, temperature: Math.min(Math.max(Number(b.temperature) || 0.4, 0), 1.5), max_tokens: Math.min(Math.max(Number(b.max_tokens) || 1024, 1), 2048), stream: false };
    const r = await groq(env, 'chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return new Response(r.body, { status: r.status, headers: { 'Content-Type': 'application/json', ...corsHeaders(req, env) } });
  }
  return json(req, env, 404, { error: { message: 'not found' } });
}

/* ---------- المرحلة 2: تسجيل دخول موثّق ---------- */
async function hashPw(p) { return 'h:' + [...new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode('stp|' + p)))].map((b) => b.toString(16).padStart(2, '0')).join(''); }
function same(a, b) { a = String(a || ''); b = String(b || ''); if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }
const digits = (s) => String(s || '').replace(/\D/g, '');
const phoneKey = (s) => { const d = digits(s); return d.length >= 10 ? d.slice(-10) : d; };
async function findUser(env, id) {
  const isMail = id.includes('@'), field = isMail ? 'email' : 'phone';
  let users;
  try {
    if (isMail) users = await dbGet(env, 'db/u', `&orderBy="email"&equalTo=${encodeURIComponent(JSON.stringify(id))}`);
    else { users = {}; for (const v of new Set([id, digits(id), '0' + phoneKey(id), '20' + phoneKey(id), '+20' + phoneKey(id)])) Object.assign(users, (await dbGet(env, 'db/u', `&orderBy="phone"&equalTo=${encodeURIComponent(JSON.stringify(v))}`)) || {}); }
  } catch (e) { // لو الفهرس (indexOn) لسه مش مضاف: بنقرأ المستخدمين ونفلتر (أبطأ بس شغّال)
    const all = (await dbGet(env, 'db/u')) || {}; users = {};
    for (const [k, u] of Object.entries(all)) if (u && (isMail ? u.email === id : phoneKey(u.phone) && phoneKey(u.phone) === phoneKey(id))) users[k] = u;
  }
  for (const [k, u] of Object.entries(users || {})) if (u && (u.id || k)) return { ...u, id: u.id || k };
  return null;
}
async function pbkdf2Pw(password, saltB64) {
  const salt = saltB64 ? unb64u(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations:100000}, key, 256);
  return 'p2$100000$' + b64u(salt) + '$' + b64u(bits);
}
async function verifyPw(password, stored) {
  stored=String(stored||'');
  if (stored.startsWith('p2$')) {
    const m=stored.match(/^p2\$(\d+)\$([^$]+)\$([^$]+)$/); if(!m)return false;
    const salt=unb64u(m[2]), want=unb64u(m[3]);
    const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
    const bits=new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations:Math.min(200000,Math.max(60000,+m[1]))},key,256));
    if(bits.length!==want.length)return false;let d=0;for(let i=0;i<bits.length;i++)d|=bits[i]^want[i];return d===0;
  }
  return same(stored, await hashPw(password)) || (!stored.startsWith('h:') && same(stored,password));
}

async function handleRegister(req, env) {
  const ip=req.headers.get('CF-Connecting-IP')||'x';
  if(limited('reg:'+ip, 5, 3600)) return json(req,env,429,{ok:false,error:'too_many'});
  let b;try{b=await req.json()}catch(e){return json(req,env,400,{ok:false})}
  const u=b&&b.user||{}, password=String(b.password||'');
  const role=['student','teacher','assistant','parent'].includes(u.role)?u.role:null;
  const email=String(u.email||'').trim().toLowerCase();
  const bad=!role?'bad_role':!u.id?'bad_id':!u.name?'bad_name':!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)?'bad_email':(password.length<6||password.length>200)?'bad_password':'';
  if(bad) return json(req,env,400,{ok:false,error:'bad_request',reason:bad});
  const all=(await dbGet(env,'db/u'))||{};
  if(Object.values(all).some(x=>x&&String(x.email||'').toLowerCase()===email)) return json(req,env,409,{ok:false,error:'email_exists'});
  if(role!=='parent'&&u.phone&&Object.values(all).some(x=>x&&x.role===role&&String(x.phone||'')===String(u.phone))) return json(req,env,409,{ok:false,error:'phone_exists'});
  const clean={...u,id:String(u.id),email,role,pw:await pbkdf2Pw(password)};delete clean.admin;delete clean.isAdmin;
  const updates={['db/u/'+clean.id]:clean};
  if(role==='parent'&&b.link){
    const st=all[b.link];
    if(!st||st.role!=='student'||!st.pc||String(st.pc)!==String(b.parentCode||'')) return json(req,env,400,{ok:false,error:'bad_link'});
    updates['db/pl/'+clean.id+'_'+st.id]={id:clean.id+'_'+st.id,p:clean.id,s:st.id,d:Date.now(),a:'code',x:0};
  }
  await dbPatch(env,updates);
  return json(req,env,201,{ok:true,token:await customToken(env,clean.id,{role}),uid:clean.id,role});
}
async function handleParentLookup(req,env){
  const ip=req.headers.get('CF-Connecting-IP')||'x';if(limited('plook:'+ip,20,600))return json(req,env,429,{ok:false});
  const q=new URL(req.url).searchParams.get('code')||'';if(!/^\d{6}$/.test(q))return json(req,env,400,{ok:false});
  const all=(await dbGet(env,'db/u'))||{};for(const [id,u] of Object.entries(all)){if(u&&u.role==='student'&&String(u.pc||'')===q)return json(req,env,200,{ok:true,id,name:String(u.name||'').slice(0,80)});}return json(req,env,404,{ok:false});
}

async function handleLogin(req, env) {
  let b; try { b = await req.json(); } catch (e) { return json(req, env, 400, { ok: false }); }
  const id = String(b.id || '').trim().toLowerCase(), pw = String(b.password || '');
  if (!id || !pw || id.length > 120 || pw.length > 200) return json(req, env, 400, { ok: false });
  const ip = req.headers.get('CF-Connecting-IP') || 'x', lk = 'login:' + ip + ':' + id;
  if (peek(lk, 600) >= 8) return json(req, env, 429, { ok: false, error: 'too_many', retry: 600 });
  /* ---- دخول الإدارة: الإيميل وكلمة السر محفوظين كمتغيرات (Secrets) في Cloudflare مش في كود الموقع ---- */
  if (env.ADMIN_EMAIL && env.ADMIN_PASSWORD && id === String(env.ADMIN_EMAIL).trim().toLowerCase()) {
    if (!same(await sha256hex('adm|' + pw), await sha256hex('adm|' + String(env.ADMIN_PASSWORD)))) { limited(lk, 8, 600); return json(req, env, 401, { ok: false, reason: 'bad_pw' }); }
    const cur = await dbGet(env, 'db/u/admroot').catch(() => null);
    if (!cur || cur.role !== 'admin' || cur.email !== id) {
      await dbPatch(env, { 'db/u/admroot': { ...(cur || {}), id: 'admroot', name: (cur && cur.name) || 'الإدارة', email: id, role: 'admin', ok: 1, ev: 1, pv: 1 } });
    }
    return json(req, env, 200, { ok: true, token: await customToken(env, 'admroot', { role: 'admin' }), uid: 'admroot', role: 'admin' });
  }
  const u = await findUser(env, id);
  if (!u) { limited(lk, 8, 600); return json(req, env, 401, { ok: false, reason: 'no_user' }); }
  if (!u.pw || !(await verifyPw(pw, u.pw))) { limited(lk, 8, 600); return json(req, env, 401, { ok: false, reason: u.pw ? 'bad_pw' : 'no_pw' }); }
  const role = ['student', 'teacher', 'assistant', 'parent', 'admin'].includes(u.role) ? u.role : 'student';
  if (!String(u.pw).startsWith('p2$')) { try { await dbPatch(env, { ['db/u/'+u.id+'/pw']: await pbkdf2Pw(pw) }); } catch(e) {} }
  return json(req, env, 200, { ok: true, token: await customToken(env, u.id, { role }), uid: u.id, role });
}


/* ---------- v13.3: استرجاع كلمة المرور + تغييرها (الباسورد بيتحفظ من السيرفر فقط) ---------- */
const sha256hex = async (t) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(t)))].map((b) => b.toString(16).padStart(2, '0')).join('');
async function sendResetMail(env, u, code) {
  if (!env.EMAILJS_SERVICE || !env.EMAILJS_TEMPLATE || !env.EMAILJS_PUBLIC_KEY || !env.EMAILJS_PRIVATE_KEY) { const e = new Error('mail_not_configured'); e.code = 'mail_not_configured'; throw e; }
  const r = await fetch('https://api.emailjs.com/api/v1.0/email/send', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
    service_id: env.EMAILJS_SERVICE, template_id: env.EMAILJS_TEMPLATE, user_id: env.EMAILJS_PUBLIC_KEY, accessToken: env.EMAILJS_PRIVATE_KEY,
    template_params: { to_email: u.email, email: u.email, user_email: u.email, reply_to: u.email, to_name: u.name || '', name: u.name || '', user_name: u.name || '', code, otp: code, passcode: code, message: code, app_name: 'المعلم الذكي', expires: '15', time: '15 دقيقة' } }) });
  if (!r.ok) { const e = new Error('mail_failed'); e.code = 'mail_failed'; e.detail = (await r.text().catch(() => '')).slice(0, 160); throw e; }
}
async function handleResetStart(req, env) {
  let b; try { b = await req.json(); } catch (e) { return json(req, env, 400, { ok: false }); }
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160) return json(req, env, 400, { ok: false, error: 'bad_email' });
  const ip = req.headers.get('CF-Connecting-IP') || 'x';
  if (limited('rs:ip:' + ip, 10, 3600) || limited('rs:' + email, 4, 3600)) return json(req, env, 429, { ok: false, error: 'too_many' });
  const u = await findUser(env, email);
  if (!u) return json(req, env, 404, { ok: false, error: 'no_user' });
  const code = String(100000 + crypto.getRandomValues(new Uint32Array(1))[0] % 900000), exp = Date.now() + 15 * 60 * 1000;
  await dbPatch(env, { ['rst/' + u.id]: { h: await sha256hex(code + '|' + u.id + '|' + exp), exp, t: 0 } });
  try { await sendResetMail(env, u, code); }
  catch (e) { await dbPatch(env, { ['rst/' + u.id]: null }).catch(() => {}); return json(req, env, e.code === 'mail_not_configured' ? 503 : 502, { ok: false, error: e.code || 'mail_failed', detail: e.detail || '' }); }
  return json(req, env, 200, { ok: true, exp });
}
async function handleResetConfirm(req, env) {
  let b; try { b = await req.json(); } catch (e) { return json(req, env, 400, { ok: false }); }
  const email = String(b.email || '').trim().toLowerCase(), code = String(b.code || '').trim(), pw = String(b.password || '');
  if (!/^\d{6}$/.test(code) || pw.length < 8 || pw.length > 200 || !email) return json(req, env, 400, { ok: false, error: 'bad_request' });
  const ip = req.headers.get('CF-Connecting-IP') || 'x';
  if (limited('rc:ip:' + ip, 30, 3600)) return json(req, env, 429, { ok: false, error: 'too_many' });
  const u = await findUser(env, email);
  if (!u) return json(req, env, 404, { ok: false, error: 'no_user' });
  const rec = await dbGet(env, 'rst/' + u.id).catch(() => null);
  if (!rec || !rec.h || Date.now() > (rec.exp || 0)) return json(req, env, 410, { ok: false, error: 'expired' });
  if ((rec.t || 0) >= 5) { await dbPatch(env, { ['rst/' + u.id]: null }).catch(() => {}); return json(req, env, 429, { ok: false, error: 'too_many_tries' }); }
  if (!same(await sha256hex(code + '|' + u.id + '|' + rec.exp), rec.h)) { await dbPatch(env, { ['rst/' + u.id + '/t']: (rec.t || 0) + 1 }); return json(req, env, 401, { ok: false, error: 'bad_code', left: 4 - (rec.t || 0) }); }
  const role = ['student', 'teacher', 'assistant', 'parent', 'admin'].includes(u.role) ? u.role : 'student';
  await dbPatch(env, { ['db/u/' + u.id + '/pw']: await pbkdf2Pw(pw), ['rst/' + u.id]: null });
  return json(req, env, 200, { ok: true, token: await customToken(env, u.id, { role }), uid: u.id, role });
}
async function handleChangePassword(req, env) {
  const auth = await verifyIdToken(env, (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, ''));
  if (!auth) return json(req, env, 401, { ok: false, error: 'unauthorized' });
  let b; try { b = await req.json(); } catch (e) { return json(req, env, 400, { ok: false }); }
  const oldPw = String(b.old || ''), pw = String(b.password || '');
  if (!oldPw || pw.length < 8 || pw.length > 200) return json(req, env, 400, { ok: false, error: 'bad_request' });
  if (limited('cp:' + auth.sub, 8, 600)) return json(req, env, 429, { ok: false, error: 'too_many' });
  const u = await dbGet(env, 'db/u/' + auth.sub).catch(() => null);
  if (!u || !u.pw) return json(req, env, 404, { ok: false, error: 'no_user' });
  if (!(await verifyPw(oldPw, u.pw))) return json(req, env, 401, { ok: false, error: 'bad_old' });
  await dbPatch(env, { ['db/u/' + auth.sub + '/pw']: await pbkdf2Pw(pw) });
  return json(req, env, 200, { ok: true });
}


/* ---------- فحص الإعدادات: افتح  /health?check=1  وهيقولك إيه المتظبّط وإيه الناقص (من غير ما يكشف أي سر) ---------- */
async function diagnose(req, env) {
  const out = { ok: true, service: 'smart-teacher-api', v: '13.5', checks: {} };
  const c = (k, pass, hint) => { out.checks[k] = pass ? { ok: true } : { ok: false, hint }; if (!pass) out.ok = false; };
  c('DB_URL', /^https:\/\/[^\s]+\.(firebaseio\.com|firebasedatabase\.app)\/?$/.test(String(env.DB_URL || '').trim()), 'DB_URL ناقص أو غلط — لازم يبدأ بـ https:// وينتهي بـ firebaseio.com (من غير أي مسافة)');
  c('PROJECT_ID', !!env.PROJECT_ID, 'PROJECT_ID ناقص — اكتب smart-teacher-om');
  let saj = null; try { saj = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT); } catch (e) { /* ignore */ }
  c('FIREBASE_SERVICE_ACCOUNT', !!(saj && saj.client_email && saj.private_key), 'لازم تلصق محتوى ملف الـ JSON كامل (من أول { لآخر }) كـ Secret باسم FIREBASE_SERVICE_ACCOUNT');
  if (saj && saj.client_email) {
    c('service_account_project', !env.PROJECT_ID || saj.project_id === env.PROJECT_ID, 'الـ Service Account بتاع مشروع "' + saj.project_id + '" لكن PROJECT_ID="' + env.PROJECT_ID + '" — لازم الاتنين يكونوا نفس المشروع (smart-teacher-om). ولّد مفتاح جديد من نفس المشروع.');
    c('db_matches_project', String(env.DB_URL || '').includes(String(saj.project_id || '\u0000')), 'DB_URL مش تابع لنفس مشروع الـ Service Account');
    try { await adminToken(env); c('google_oauth', true); } catch (e) { c('google_oauth', false, 'جوجل رفض مفتاح الـ Service Account (' + String(e.message || e).slice(0, 60) + ') — ولّد مفتاح جديد من Project settings ← Service accounts والصقه كامل'); }
    if (out.checks.google_oauth && out.checks.google_oauth.ok && out.checks.DB_URL.ok) {
      try { await dbGet(env, 'db/u', 'shallow=true'); c('database_read', true); } catch (e) { c('database_read', false, 'الـ Worker مش قادر يقرأ القاعدة (' + String(e.message || e).slice(0, 60) + ') — راجع DB_URL، وإن Realtime Database متفعّلة'); }
    }
    try { await customToken(env, 'diag', { role: 'diag' }); c('custom_token', true); } catch (e) { c('custom_token', false, 'تعذر توقيع توكن الدخول — مفتاح الـ Service Account تالف'); }
  }
  c('ALLOWED_ORIGINS', !!String(env.ALLOWED_ORIGINS || '').trim(), 'ALLOWED_ORIGINS ناقص — اكتب دومين موقعك (مثال: https://smart-teacher.vercel.app)');
  const origin = req.headers.get('Origin'); if (origin) c('origin_allowed', !!corsHeaders(req, env)['Access-Control-Allow-Origin'], 'الدومين "' + origin + '" مش موجود في ALLOWED_ORIGINS');
  c('ADMIN_EMAIL', !!env.ADMIN_EMAIL, 'ADMIN_EMAIL ناقص — من غيره دخول الإدارة مقفول');
  c('ADMIN_PASSWORD', !!env.ADMIN_PASSWORD, 'ADMIN_PASSWORD ناقص (Secret) — من غيره دخول الإدارة مقفول');
  c('EMAILJS (نسيت كلمة المرور)', !!(env.EMAILJS_SERVICE && env.EMAILJS_TEMPLATE && env.EMAILJS_PUBLIC_KEY && env.EMAILJS_PRIVATE_KEY), 'متغيّرات EMAILJS_* ناقصة (مطلوبة لـ «نسيت كلمة المرور» فقط)');
  return out;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req, env) });
    try {
      if ((url.pathname === '/' || url.pathname === '/health') && url.searchParams.get('check')) return json(req, env, 200, await diagnose(req, env));
      if (url.pathname === '/' || url.pathname === '/health') return json(req, env, 200, { ok: true, service: 'smart-teacher-api', v: '13.5', routes: ['/login', '/register', '/parent-lookup', '/reset/start', '/reset/confirm', '/change-password', '/ai/chat', '/ai/models'] });
      const origin = req.headers.get('Origin');
      if (origin && !corsHeaders(req, env)['Access-Control-Allow-Origin']) return json(req, env, 403, { error: 'origin not allowed' });
      if (url.pathname.startsWith('/ai/')) return await handleAI(req, env, url);
      if (url.pathname === '/login' && req.method === 'POST') return await handleLogin(req, env);
      if (url.pathname === '/register' && req.method === 'POST') return await handleRegister(req, env);
      if (url.pathname === '/parent-lookup' && req.method === 'GET') return await handleParentLookup(req, env);
      if (url.pathname === '/reset/start' && req.method === 'POST') return await handleResetStart(req, env);
      if (url.pathname === '/reset/confirm' && req.method === 'POST') return await handleResetConfirm(req, env);
      if (url.pathname === '/change-password' && req.method === 'POST') return await handleChangePassword(req, env);
      return json(req, env, 404, { error: 'not found' });
    } catch (e) { return json(req, env, 500, { ok: false, error: 'server_error', detail: String(e && e.message || e).slice(0, 140) }); }
  },
};
